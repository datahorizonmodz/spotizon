# SPOTIZON

SPOTIZON is a native Android music client built with Kotlin, Jetpack Compose, and Media3. The original DATZON Music V1.62.9 web/API project is kept at the repository root so the same repository can also be deployed to Vercel.

## What is included

- `android-native/` — native Android UI and media player. It is not a WebView wrapper.
- `.github/workflows/build-android.yml` — builds a debug APK using GitHub Actions and uploads `SPOTIZON-debug-apk` as an artifact.
- `api/`, `server/`, `lib/`, `cloud-functions/`, `index.html`, `app.js`, `styles.css`, `vercel.json`, and related files — the original Vercel web/API project from DATZON Music V1.62.9.

## Android features

- Dark liquid-glass inspired SPOTIZON interface.
- Native search UI using the Vercel endpoint `/api/spotify-catalog/search`.
- Native audio playback through Media3, including a media-session service for system playback controls and background playback.
- Track metadata and artwork from the catalog API.
- Backend URL can be configured in-app. API secrets are never embedded in the APK.

## Configure the Vercel backend

The app needs the HTTPS origin of the Vercel deployment that serves these API endpoints. On first launch, tap **Hubungkan server** and enter the Vercel deployment URL, for example `https://your-project.vercel.app`.

The app calls these endpoints:

- `GET /api/spotify-catalog/search?q=QUERY&limit=10`
- `GET /api/theresav/audio?url=https%3A%2F%2Fopen.spotify.com%2Ftrack%2FTRACK_ID`

Keep credentials in Vercel Environment Variables, not in Android source code or GitHub. The Vercel project associated with this source uses these variable names as required by their respective features:

- `SPOTIFY_CLIENT_ID`
- `SPOTIFY_CLIENT_SECRET`
- `SPOTIFY_MARKET` (optional; defaults to `ID` in the backend)
- `THERESAV_API_KEY`
- `SYLVATICA_API_KEY`
- `FIREBASE_SERVICE_ACCOUNT_JSON` **or** `FIREBASE_PROJECT_ID`, `FIREBASE_CLIENT_EMAIL`, and `FIREBASE_PRIVATE_KEY`
- `RESEND_API_KEY`
- `OTP_FROM_EMAIL`
- `OTP_SECRET` (use a random value of at least 32 characters)

Not every feature needs every variable. Do not commit actual values to this repository. Firebase web configuration in `firebase-config.js` is client-side configuration; Firebase security must still be enforced by Authentication and Firestore rules.

If you connect this repository to the **existing Vercel project**, that project's Environment Variables remain associated with that Vercel project. If you create a separate Vercel project for SPOTIZON, configure the required variables again in that new project's settings.

## Build the Android APK on GitHub

1. Create a repository named `spotizon` under the GitHub account `datahorizonmodz`.
2. Upload the contents of this project to the repository root, including the hidden `.github` folder. Do not upload the ZIP file as a single file; extract it first and upload its contents.
3. Open the **Actions** tab and select **Build Spotizon Android APK**.
4. Select **Run workflow** if a run did not start on its own.
5. When the run passes, download the `SPOTIZON-debug-apk` artifact. Extract the artifact ZIP to obtain `app-debug.apk` and install it on Android.

Debug APKs are for testing. Create a release signing key and build a signed release APK before public distribution.

## Current limitations

The app is a native first version with search and playback. The existing website contains additional features (accounts, playlist sync, admin tools, lyrics, and other providers) that are not automatically present in the native UI yet. Some endpoints require valid Vercel environment variables and provider availability. Playback can fail if the external resolver does not return a valid audio stream.
