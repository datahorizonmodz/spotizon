package com.datzon.spotizon

import android.content.ComponentName
import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import coil.compose.AsyncImage
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

private val Background = Color(0xFF080D11)
private val Panel = Color(0xFF111B20)
private val PanelLight = Color(0xFF18272B)
private val Mint = Color(0xFF9AF3C7)
private val MintDeep = Color(0xFF4DCB9A)
private val PrimaryText = Color(0xFFF2F7F5)
private val SecondaryText = Color(0xFF8C9E9C)
private val ErrorText = Color(0xFFFF9C9C)

private data class MusicTrack(
    val id: String,
    val title: String,
    val artists: String,
    val album: String,
    val coverUrl: String,
    val durationMs: Long
) {
    val spotifyUrl: String get() = "https://open.spotify.com/track/$id"
}

@OptIn(UnstableApi::class)
class MainActivity : ComponentActivity() {
    private var mediaController by mutableStateOf<MediaController?>(null)
    private var controllerFuture: ListenableFuture<MediaController>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Mint,
                onPrimary = Background,
                background = Background,
                surface = Panel,
                onSurface = PrimaryText
            )) {
                SpotizonApp(controller = mediaController)
            }
        }
    }

    override fun onStart() {
        super.onStart()
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        controllerFuture = future
        future.addListener({
            try {
                mediaController = future.get()
            } catch (_: Exception) {
                mediaController = null
            }
        }, ContextCompat.getMainExecutor(this))
    }

    override fun onStop() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        mediaController = null
        super.onStop()
    }
}

@OptIn(UnstableApi::class)
@Composable
private fun SpotizonApp(controller: MediaController?) {
    val context = LocalContext.current
    val preferences = remember { context.getSharedPreferences("spotizon", Context.MODE_PRIVATE) }
    var apiBase by remember { mutableStateOf(preferences.getString("api_base", "").orEmpty()) }
    var editApiBase by remember { mutableStateOf(apiBase) }
    var showSettings by remember { mutableStateOf(apiBase.isBlank()) }
    var settingsError by remember { mutableStateOf("") }
    var searchText by remember { mutableStateOf("") }
    var tracks by remember { mutableStateOf<List<MusicTrack>>(emptyList()) }
    var queue by remember { mutableStateOf<List<MusicTrack>>(emptyList()) }
    var nowPlaying by remember { mutableStateOf<MusicTrack?>(null) }
    var loading by remember { mutableStateOf(false) }
    var playing by remember { mutableStateOf(false) }
    var playerPosition by remember { mutableStateOf(0L) }
    var playerDuration by remember { mutableStateOf(0L) }
    var errorMessage by remember { mutableStateOf("") }
    var infoMessage by remember { mutableStateOf("Cari lagu, lalu tap hasilnya untuk mulai memutar.") }
    val scope = rememberCoroutineScope()

    LaunchedEffect(controller, queue) {
        while (true) {
            val activeIndex = controller?.currentMediaItemIndex ?: -1
            if (activeIndex in queue.indices) nowPlaying = queue[activeIndex]
            playing = controller?.isPlaying == true
            playerPosition = controller?.currentPosition?.coerceAtLeast(0L) ?: 0L
            playerDuration = (controller?.duration ?: 0L).takeIf { it > 0 } ?: 0L
            delay(350)
        }
    }

    fun search(query: String) {
        val cleanQuery = query.trim()
        if (apiBase.isBlank()) {
            showSettings = true
            return
        }
        if (cleanQuery.isBlank()) {
            errorMessage = "Tulis judul lagu atau nama artis dulu."
            return
        }
        loading = true
        errorMessage = ""
        infoMessage = "Sedang mencari di katalog musik..."
        scope.launch {
            try {
                val result = searchTracks(apiBase, cleanQuery)
                tracks = result
                infoMessage = if (result.isEmpty()) "Belum ada hasil. Coba kata kunci lain." else "Ditemukan ${result.size} lagu. Pilih lagu untuk memutar."
            } catch (error: Exception) {
                errorMessage = error.message ?: "Pencarian gagal. Periksa URL Vercel dan konfigurasi API."
                infoMessage = ""
            } finally {
                loading = false
            }
        }
    }

    fun playFromList(list: List<MusicTrack>, index: Int) {
        val player = controller
        if (player == null) {
            errorMessage = "Player sedang disiapkan. Coba tap lagu sekali lagi."
            return
        }
        if (apiBase.isBlank() || index !in list.indices) return
        queue = list
        nowPlaying = list[index]
        errorMessage = ""
        try {
            val items = list.map { track ->
                val encodedTrack = URLEncoder.encode(track.spotifyUrl, "UTF-8")
                val streamUrl = "${apiBase.trimEnd('/')}/api/theresav/audio?url=$encodedTrack"
                val metadata = MediaMetadata.Builder()
                    .setTitle(track.title)
                    .setArtist(track.artists)
                    .setAlbumTitle(track.album)
                    .apply { if (track.coverUrl.isNotBlank()) setArtworkUri(Uri.parse(track.coverUrl)) }
                    .build()
                MediaItem.Builder()
                    .setUri(streamUrl)
                    .setMimeType(MimeTypes.AUDIO_MPEG)
                    .setMediaMetadata(metadata)
                    .build()
            }
            player.setMediaItems(items, index, 0L)
            player.prepare()
            player.play()
        } catch (error: Exception) {
            errorMessage = error.message ?: "Lagu gagal diputar."
        }
    }

    Surface(modifier = Modifier.fillMaxSize(), color = Background) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color(0xFF142629), Background, Color(0xFF090D10))))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding())
                    .padding(bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding())
            ) {
                Header(onSettings = {
                    editApiBase = apiBase
                    showSettings = true
                })

                if (apiBase.isBlank()) {
                    SetupWelcome(onConfigure = {
                        editApiBase = apiBase
                        settingsError = ""
                        showSettings = true
                    })
                } else {
                    SearchPanel(
                        query = searchText,
                        onQueryChange = { searchText = it },
                        onSearch = { search(searchText) },
                        loading = loading
                    )
                    QuickSearches { query ->
                        searchText = query
                        search(query)
                    }

                    if (infoMessage.isNotBlank()) {
                        Text(
                            infoMessage,
                            color = SecondaryText,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(horizontal = 22.dp, vertical = 8.dp)
                        )
                    }
                    if (errorMessage.isNotBlank()) {
                        Text(
                            errorMessage,
                            color = ErrorText,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(horizontal = 22.dp, vertical = 4.dp)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("HASIL PENCARIAN", color = PrimaryText, fontSize = 12.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold)
                        Text("SPOTIFY CATALOG", color = Mint, fontSize = 9.sp, letterSpacing = 1.2.sp)
                    }

                    if (loading) {
                        Box(Modifier.fillMaxWidth().padding(30.dp), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(color = Mint, strokeWidth = 2.dp)
                        }
                    } else if (tracks.isEmpty()) {
                        EmptyState()
                    } else {
                        LazyColumn(
                            modifier = Modifier.weight(1f).fillMaxWidth(),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 16.dp),
                            verticalArrangement = Arrangement.spacedBy(9.dp)
                        ) {
                            itemsIndexed(tracks, key = { index, track -> "${track.id}-$index" }) { index, track ->
                                TrackRow(track = track, onPlay = { playFromList(tracks, index) })
                            }
                        }
                    }
                }

                if (nowPlaying != null && apiBase.isNotBlank()) {
                    PlayerBar(
                        track = nowPlaying!!,
                        isPlaying = playing,
                        position = playerPosition,
                        duration = playerDuration,
                        onToggle = {
                            if (controller?.isPlaying == true) controller.pause() else controller?.play()
                        },
                        onNext = { if (controller?.hasNextMediaItem() == true) controller.seekToNextMediaItem() },
                        onPrevious = { if (controller?.hasPreviousMediaItem() == true) controller.seekToPreviousMediaItem() },
                        onSeek = { value -> controller?.seekTo(value) }
                    )
                }
            }
        }
    }

    if (showSettings) {
        ApiSettingsDialog(
            value = editApiBase,
            validationError = settingsError,
            onValueChange = { editApiBase = it; settingsError = "" },
            onDismiss = { if (apiBase.isNotBlank()) showSettings = false },
            onSave = {
                val normalized = normalizeApiBase(editApiBase)
                if (normalized == null) {
                    settingsError = "URL tidak valid. Gunakan HTTPS, misalnya https://spotizon.vercel.app"
                } else {
                    apiBase = normalized
                    preferences.edit().putString("api_base", normalized).apply()
                    showSettings = false
                    errorMessage = ""
                    infoMessage = "URL backend tersimpan: $normalized"
                }
            }
        )
    }
}

@Composable
private fun Header(onSettings: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 15.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier.size(42.dp).clip(RoundedCornerShape(15.dp))
                    .background(Brush.linearGradient(listOf(Mint, Color(0xFF4DCB9A))))
                    .border(1.dp, Color.White.copy(alpha = .22f), RoundedCornerShape(15.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text("S", color = Background, fontSize = 25.sp, fontWeight = FontWeight.Black)
            }
            Spacer(Modifier.width(12.dp))
            Column {
                Text("SPOTIZON", color = PrimaryText, fontSize = 21.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                Text("YOUR SOUND, YOUR SPACE", color = SecondaryText, fontSize = 8.sp, letterSpacing = 1.7.sp)
            }
        }
        Box(
            modifier = Modifier.size(43.dp).clip(CircleShape).background(Color.White.copy(alpha = .055f))
                .border(1.dp, Color.White.copy(alpha = .10f), CircleShape).clickable(onClick = onSettings),
            contentAlignment = Alignment.Center
        ) {
            Text("⚙", color = Mint, fontSize = 21.sp)
        }
    }
}

@Composable
private fun SearchPanel(query: String, onQueryChange: (String) -> Unit, onSearch: () -> Unit, loading: Boolean) {
    Column(Modifier.padding(horizontal = 18.dp, vertical = 6.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp))
                .background(Brush.linearGradient(listOf(Color.White.copy(alpha = .095f), Color.White.copy(alpha = .035f))))
                .border(BorderStroke(1.dp, Color.White.copy(alpha = .12f)), RoundedCornerShape(22.dp))
                .padding(start = 16.dp, end = 7.dp, top = 6.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("⌕", color = Mint, fontSize = 28.sp)
            OutlinedTextField(
                value = query,
                onValueChange = onQueryChange,
                modifier = Modifier.weight(1f),
                placeholder = { Text("Lagu, artis, album...", color = SecondaryText, fontSize = 14.sp) },
                singleLine = true,
                textStyle = androidx.compose.ui.text.TextStyle(color = PrimaryText, fontSize = 14.sp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { onSearch() }),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color.Transparent,
                    unfocusedBorderColor = Color.Transparent,
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    cursorColor = Mint
                )
            )
            Box(
                modifier = Modifier.size(45.dp).clip(RoundedCornerShape(16.dp)).background(Mint)
                    .clickable(enabled = !loading, onClick = onSearch),
                contentAlignment = Alignment.Center
            ) {
                Text(if (loading) "…" else "➜", color = Background, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun QuickSearches(onTap: (String) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(start = 22.dp, end = 22.dp, top = 12.dp, bottom = 5.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        listOf("NIKI", "Tulus", "K-pop", "Chill").forEach { label ->
            Box(
                modifier = Modifier.clip(CircleShape).background(Color.White.copy(alpha = .045f))
                    .border(1.dp, Color.White.copy(alpha = .08f), CircleShape)
                    .clickable { onTap(label) }.padding(horizontal = 13.dp, vertical = 8.dp)
            ) {
                Text(label, color = if (label == "NIKI") Mint else SecondaryText, fontSize = 11.sp, fontWeight = FontWeight.Medium)
            }
        }
    }
}

@Composable
private fun TrackRow(track: MusicTrack, onPlay: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
            .background(Brush.linearGradient(listOf(Color.White.copy(alpha = .06f), Color.White.copy(alpha = .025f))))
            .border(1.dp, Color.White.copy(alpha = .065f), RoundedCornerShape(20.dp))
            .clickable(onClick = onPlay).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AsyncImage(
            model = track.coverUrl.takeIf { it.isNotBlank() },
            contentDescription = "Sampul ${track.album}",
            modifier = Modifier.size(58.dp).clip(RoundedCornerShape(13.dp)).background(PanelLight)
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(track.title, color = PrimaryText, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(4.dp))
            Text(track.artists, color = Mint.copy(alpha = .85f), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(3.dp))
            Text(track.album, color = SecondaryText, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Spacer(Modifier.width(8.dp))
        Column(horizontalAlignment = Alignment.End) {
            Box(
                modifier = Modifier.size(39.dp).clip(CircleShape).background(Mint)
                    .border(1.dp, Color.White.copy(alpha = .20f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text("▶", color = Background, fontSize = 13.sp)
            }
            Spacer(Modifier.height(6.dp))
            Text(formatDuration(track.durationMs), color = SecondaryText, fontSize = 10.sp)
        }
    }
}

@Composable
private fun EmptyState() {
    Column(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 30.dp, vertical = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier.size(92.dp).clip(RoundedCornerShape(30.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF203A38), Color(0xFF111B20))))
                .border(1.dp, Mint.copy(alpha = .2f), RoundedCornerShape(30.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text("♫", color = Mint, fontSize = 43.sp)
        }
        Spacer(Modifier.height(18.dp))
        Text("Find your next repeat.", color = PrimaryText, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(7.dp))
        Text("Cari lagu favoritmu. Hasilnya akan muncul di sini.", color = SecondaryText, fontSize = 12.sp)
    }
}

@Composable
private fun PlayerBar(
    track: MusicTrack,
    isPlaying: Boolean,
    position: Long,
    duration: Long,
    onToggle: () -> Unit,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    onSeek: (Long) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF243B38), Color(0xFF111D21))))
            .border(1.dp, Mint.copy(alpha = .22f), RoundedCornerShape(24.dp))
            .padding(horizontal = 15.dp, vertical = 11.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            AsyncImage(model = track.coverUrl.takeIf { it.isNotBlank() }, contentDescription = null,
                modifier = Modifier.size(47.dp).clip(RoundedCornerShape(12.dp)).background(PanelLight))
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) {
                Text(track.title, color = PrimaryText, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(track.artists, color = SecondaryText, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Text("‹", modifier = Modifier.clickable(onClick = onPrevious).padding(horizontal = 9.dp), color = PrimaryText, fontSize = 28.sp)
            Box(Modifier.size(39.dp).clip(CircleShape).background(Mint).clickable(onClick = onToggle), contentAlignment = Alignment.Center) {
                Text(if (isPlaying) "Ⅱ" else "▶", color = Background, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }
            Text("›", modifier = Modifier.clickable(onClick = onNext).padding(horizontal = 9.dp), color = PrimaryText, fontSize = 28.sp)
        }
        if (duration > 0) {
            Slider(
                value = position.coerceIn(0L, duration).toFloat(),
                onValueChange = { onSeek(it.toLong()) },
                valueRange = 0f..duration.toFloat(),
                modifier = Modifier.fillMaxWidth().height(26.dp),
                colors = androidx.compose.material3.SliderDefaults.colors(
                    thumbColor = Mint,
                    activeTrackColor = Mint,
                    inactiveTrackColor = Color.White.copy(alpha = .14f)
                )
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(formatDuration(position), color = SecondaryText, fontSize = 9.sp)
                Text(formatDuration(duration), color = SecondaryText, fontSize = 9.sp)
            }
        }
    }
}

@Composable
private fun SetupWelcome(onConfigure: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp, vertical = 30.dp),
        horizontalAlignment = Alignment.Start
    ) {
        Text("YOUR MUSIC,\nYOUR UNIVERSE.", color = PrimaryText, fontSize = 36.sp, lineHeight = 40.sp, fontWeight = FontWeight.Black, letterSpacing = (-1).sp)
        Spacer(Modifier.height(14.dp))
        Text("Pengalaman musik native dengan pencarian katalog, pemutar audio, dan tampilan liquid glass.", color = SecondaryText, fontSize = 14.sp, lineHeight = 22.sp)
        Spacer(Modifier.height(28.dp))
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF1D3A34), Color(0xFF111B20))))
                .border(1.dp, Mint.copy(alpha = .22f), RoundedCornerShape(26.dp)).padding(22.dp)
        ) {
            Text("CONNECT YOUR VERCEL BACKEND", color = Mint, fontSize = 10.sp, letterSpacing = 1.3.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            Text("Masukkan domain deployment Vercel. API keys tetap berada di Environment Variables server, bukan di APK.", color = PrimaryText, fontSize = 13.sp, lineHeight = 20.sp)
            Spacer(Modifier.height(18.dp))
            Box(Modifier.clip(RoundedCornerShape(15.dp)).background(Mint).clickable(onClick = onConfigure).padding(horizontal = 18.dp, vertical = 13.dp)) {
                Text("Hubungkan server  ↗", color = Background, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun ApiSettingsDialog(
    value: String,
    validationError: String,
    onValueChange: (String) -> Unit,
    onDismiss: () -> Unit,
    onSave: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel,
        titleContentColor = PrimaryText,
        textContentColor = SecondaryText,
        title = { Text("Hubungkan Vercel", fontWeight = FontWeight.Bold) },
        text = {
            Column {
                Text("Tempel URL deployment Vercel yang menjalankan API musik, tanpa path tambahan. Contoh: https://spotizon.vercel.app")
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = value,
                    onValueChange = onValueChange,
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    placeholder = { Text("https://nama-project.vercel.app") },
                    textStyle = androidx.compose.ui.text.TextStyle(color = PrimaryText, fontSize = 13.sp),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Mint,
                        unfocusedBorderColor = Color.White.copy(alpha = .18f),
                        focusedLabelColor = Mint,
                        cursorColor = Mint
                    )
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onSave) { Text("Simpan", color = Mint, fontWeight = FontWeight.Bold) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Batal", color = SecondaryText) }
        }
    )
}

private suspend fun searchTracks(baseUrl: String, query: String): List<MusicTrack> = withContext(Dispatchers.IO) {
    val url = "${baseUrl.trimEnd('/')}/api/spotify-catalog/search?q=${URLEncoder.encode(query, "UTF-8")}&limit=10"
    val connection = (URL(url).openConnection() as HttpURLConnection).apply {
        requestMethod = "GET"
        connectTimeout = 15_000
        readTimeout = 20_000
        setRequestProperty("Accept", "application/json")
        setRequestProperty("User-Agent", "Spotizon-Android/1.0")
    }
    try {
        val status = connection.responseCode
        val stream = if (status in 200..299) connection.inputStream else connection.errorStream
        val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        val json = try { JSONObject(body) } catch (_: Exception) { JSONObject() }
        if (status !in 200..299) {
            val serverMessage = json.optString("error").ifBlank { json.optString("message") }
            throw IOException(serverMessage.ifBlank { "Server Vercel merespons HTTP $status." })
        }
        if (!json.optBoolean("ok", false)) {
            throw IOException(json.optString("error").ifBlank { "Respons API tidak valid." })
        }
        val items = json.optJSONObject("tracks")?.optJSONArray("items") ?: return@withContext emptyList()
        buildList {
            for (index in 0 until items.length()) {
                val item = items.optJSONObject(index) ?: continue
                val id = item.optString("id").trim()
                val title = item.optString("name").trim()
                if (id.isBlank() || title.isBlank()) continue
                val artistsArray = item.optJSONArray("artists")
                val artists = buildList {
                    if (artistsArray != null) {
                        for (i in 0 until artistsArray.length()) {
                            val name = artistsArray.optJSONObject(i)?.optString("name")?.trim().orEmpty()
                            if (name.isNotBlank()) add(name)
                        }
                    }
                }.joinToString(", ").ifBlank { "Unknown artist" }
                val albumObject = item.optJSONObject("album")
                val album = albumObject?.optString("name")?.trim().orEmpty().ifBlank { "Single" }
                val images = albumObject?.optJSONArray("images")
                val cover = images?.optJSONObject(0)?.optString("url")?.trim().orEmpty()
                add(MusicTrack(id, title, artists, album, cover, item.optLong("duration_ms", 0L)))
            }
        }
    } finally {
        connection.disconnect()
    }
}

private fun normalizeApiBase(raw: String): String? {
    val cleaned = raw.trim().trimEnd('/')
    val uri = try { Uri.parse(cleaned) } catch (_: Exception) { return null }
    if (uri.scheme != "https" || uri.host.isNullOrBlank()) return null
    if (uri.query != null || uri.fragment != null) return null
    return cleaned
}

private fun formatDuration(milliseconds: Long): String {
    if (milliseconds <= 0) return "0:00"
    val totalSeconds = milliseconds / 1000
    return String.format(Locale.US, "%d:%02d", totalSeconds / 60, totalSeconds % 60)
}
