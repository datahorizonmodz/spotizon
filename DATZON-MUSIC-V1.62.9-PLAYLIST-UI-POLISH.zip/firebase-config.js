/*
  DATZON Music Firebase Web configuration.
  Firebase Web API keys are public identifiers. Access to user data remains protected
  by Firebase Authentication and the Firestore rules included in this package.
*/
window.DATZON_FIREBASE_CONFIG = Object.freeze({
  firebase: Object.freeze({
    apiKey: 'AIzaSyDvaR0UIBsgiaMCrZ8lQl_J2XtZYA3ECz4',
    authDomain: 'musicdatzon.firebaseapp.com',
    projectId: 'musicdatzon',
    storageBucket: 'musicdatzon.firebasestorage.app',
    messagingSenderId: '728636112158',
    appId: '1:728636112158:web:f5bcd0528dce489565dd0f'
  }),
  cloudinary: Object.freeze({
    cloudName: 'zgaeghpu',
    uploadPreset: 'profile',
    folder: 'datzon-profile'
  })
});
