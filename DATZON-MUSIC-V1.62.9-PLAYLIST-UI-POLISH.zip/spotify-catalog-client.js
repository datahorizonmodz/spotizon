(() => {
  'use strict';
  const cache = new Map();
  const inflight = new Map();
  const DEFAULT_TTL = 5 * 60 * 1000;

  async function request(path, params = {}, options = {}) {
    const url = new URL(path, location.origin);
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined && value !== null && value !== '') url.searchParams.set(key, value);
    });
    const key = url.toString();
    const ttl = Number(options.ttl || DEFAULT_TTL);
    const existing = cache.get(key);
    if (!options.force && existing && existing.at + ttl > Date.now()) return existing.value;
    if (!options.force && inflight.has(key)) return inflight.get(key);
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), Number(options.timeout || 15000));
    const task = fetch(url, { headers:{ Accept:'application/json' }, cache:'no-store', signal:controller.signal })
      .then(async response => {
        const data = await response.json().catch(() => ({}));
        if (!response.ok || data?.ok === false) {
          const error = new Error(data?.error || 'Gagal memuat data Spotify.');
          error.status = response.status;
          throw error;
        }
        cache.set(key, { at:Date.now(), value:data });
        return data;
      })
      .finally(() => { clearTimeout(timer); inflight.delete(key); });
    inflight.set(key, task);
    return task;
  }


  async function requestJson(path, payload = {}, options = {}) {
    const url = new URL(path, location.origin);
    const cacheKey = `${url.toString()}::${JSON.stringify(payload)}`;
    const ttl = Number(options.ttl || DEFAULT_TTL);
    const existing = cache.get(cacheKey);
    if (!options.force && existing && existing.at + ttl > Date.now()) return existing.value;
    if (!options.force && inflight.has(cacheKey)) return inflight.get(cacheKey);
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), Number(options.timeout || 20000));
    const task = fetch(url, {
      method:'POST',
      headers:{ Accept:'application/json', 'Content-Type':'application/json' },
      body:JSON.stringify(payload),
      cache:'no-store',
      signal:controller.signal
    }).then(async response => {
      const data = await response.json().catch(() => ({}));
      if (!response.ok || data?.ok === false) {
        const error = new Error(data?.error || 'Gagal memuat data Spotify.');
        error.status = response.status;
        throw error;
      }
      cache.set(cacheKey, { at:Date.now(), value:data });
      return data;
    }).finally(() => { clearTimeout(timer); inflight.delete(cacheKey); });
    inflight.set(cacheKey, task);
    return task;
  }

  window.DatzonSpotifyCatalog = Object.freeze({
    search(query, options = {}) { return request('/api/spotify-catalog?action=search', { q:query, offset:options.offset || 0, limit:Math.min(10, options.limit || 10) }, { ttl:10*60*1000, timeout:16000, force:options.force }); },
    artistSearch(query, options = {}) { return request('/api/spotify-catalog?action=artists-search', { q:query, limit:options.limit || 18 }, { ttl:10*60*1000, timeout:14000, force:options.force }); },
    artistBasic(idOrName, options = {}) { const value=String(idOrName||'').trim(); const params=/^[A-Za-z0-9]{22}$/.test(value)?{id:value}:{name:value}; return request('/api/spotify-catalog?action=artist-basic', params, { ttl:6*60*60*1000, timeout:12000, force:options.force }); },
    artist(idOrName, options = {}) {
      const value = String(idOrName || '').trim();
      const params = /^[A-Za-z0-9]{22}$/.test(value) ? { id:value } : { name:value };
      return request('/api/spotify-catalog?action=artist', params, { ttl:6*60*60*1000, timeout:18000, force:options.force });
    },
    album(id, options = {}) { return request('/api/spotify-catalog?action=album', { id }, { ttl:6*60*60*1000, timeout:18000, force:options.force }); },
    playlist(id, options = {}) { return request('/api/spotify-catalog?action=playlist', { id }, { ttl:30*60*1000, timeout:14000, force:options.force }); },
    track(id, options = {}) { return request('/api/spotify-catalog?action=track', { id }, { ttl:24*60*60*1000, timeout:14000, force:options.force }); },
    trackSearch(query, options = {}) { return request('/api/spotify-catalog?action=track', { q:query }, { ttl:10*60*1000, timeout:14000, force:options.force }); },
    enrichTracks(items, options = {}) { return requestJson('/api/spotify-catalog?action=enrich-tracks', { items:Array.isArray(items)?items:[] }, { ttl:30*60*1000, timeout:30000, force:options.force }); },
    clearCache() { cache.clear(); }
  });
})();
