(() => {
  'use strict';
  const PREFIX = 'datzon_music_avatar_color_';
  const memory = new Map();
  function hash(value='') { let h=2166136261; for (let i=0;i<value.length;i++){h^=value.charCodeAt(i); h=Math.imul(h,16777619);} return (h>>>0).toString(36); }
  function clamp(v,min=0,max=255){return Math.max(min,Math.min(max,v));}
  function darken([r,g,b], factor=.48){ return [Math.round(r*factor),Math.round(g*factor),Math.round(b*factor)]; }
  function mute([r,g,b]){
    const avg=(r+g+b)/3;
    return [r,g,b].map(v=>Math.round(v*.78+avg*.22));
  }
  function usable(rgb){ const [r,g,b]=rgb; const max=Math.max(r,g,b), min=Math.min(r,g,b); return max-min>18 || max<80 || min>175; }
  async function extract(url){
    const key=hash(url);
    if(memory.has(key)) return memory.get(key);
    try { const saved=JSON.parse(localStorage.getItem(PREFIX+key)||'null'); if(Array.isArray(saved)&&saved.length===3){memory.set(key,saved);return saved;} } catch{}
    const result=await new Promise((resolve,reject)=>{
      const img=new Image(); img.crossOrigin='anonymous'; img.decoding='async';
      img.onload=()=>{
        try{
          const canvas=document.createElement('canvas'); canvas.width=32; canvas.height=32;
          const ctx=canvas.getContext('2d',{willReadFrequently:true}); ctx.drawImage(img,0,0,32,32);
          const data=ctx.getImageData(0,0,32,32).data; let r=0,g=0,b=0,w=0;
          for(let i=0;i<data.length;i+=4){ if(data[i+3]<180)continue; const rr=data[i],gg=data[i+1],bb=data[i+2]; const max=Math.max(rr,gg,bb),min=Math.min(rr,gg,bb); const sat=max-min; const lum=(rr+gg+bb)/3; if(lum<12||lum>244)continue; const weight=1+sat/80; r+=rr*weight;g+=gg*weight;b+=bb*weight;w+=weight; }
          if(!w) throw new Error('no pixels'); resolve([Math.round(r/w),Math.round(g/w),Math.round(b/w)]);
        }catch(error){reject(error);}
      }; img.onerror=reject; img.src=url;
    });
    const rgb=usable(result)?result:[60,86,74]; memory.set(key,rgb); try{localStorage.setItem(PREFIX+key,JSON.stringify(rgb));}catch{} return rgb;
  }
  async function apply(element,url){
    if(!element||!url)return null;
    try{
      const rgb=mute(await extract(url)); const a=darken(rgb,.58), b=darken(rgb,.28);
      element.style.setProperty('--profile-dominant',rgb.join(','));
      element.style.background=`linear-gradient(145deg, rgba(${a.join(',')},.96), rgba(${b.join(',')},.98))`;
      return rgb;
    }catch{return null;}
  }
  window.DatzonDominantColor=Object.freeze({extract,apply});
})();
