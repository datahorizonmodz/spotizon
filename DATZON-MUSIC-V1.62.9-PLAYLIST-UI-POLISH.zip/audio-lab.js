(() => {
  'use strict';
  const STORAGE='datzon_audio_settings';
  const frequencies=[60,120,250,500,1000,2000,4000,8000,12000,16000];
  const defaults={preset:'Normal',preamp:0,bass:0,treble:0,eq:Object.fromEntries(frequencies.map(f=>[f,0])),reverbWet:0,reverbDry:100,reverbRoom:35,pan:0,width:100,compressor:{threshold:-24,ratio:4,attack:.003,release:.25},visualizer:'spectrum'};
  const presets={
    Normal:{},
    'Bass Boost':{bass:6,eq:{60:5,120:4,250:2}},
    'Deep Bass':{bass:9,eq:{60:8,120:6,250:3,500:-1}},
    Pop:{eq:{60:2,120:2,1000:1,4000:2,8000:2}},
    Rock:{eq:{60:3,120:2,500:-1,2000:2,4000:3,8000:2}},
    'Hip-Hop':{bass:7,eq:{60:6,120:4,250:2,2000:1,8000:2}},
    Electronic:{bass:5,treble:3,eq:{60:5,120:3,4000:2,8000:3,12000:2}},
    Vocal:{bass:-2,eq:{250:-1,500:1,1000:3,2000:4,4000:2},treble:1},
    Acoustic:{eq:{120:1,250:2,1000:2,2000:2,8000:1}},
    'Treble Boost':{treble:7,eq:{4000:3,8000:5,12000:5,16000:4}}
  };
  let settings=load();
  let ctx=null,source=null,nodes=null,engineReady=false,panel=null,raf=0,roomTimer=0;
  const audio=()=>document.getElementById('audio');
  function deepClone(value){return JSON.parse(JSON.stringify(value));}
  function load(){try{const saved=JSON.parse(localStorage.getItem(STORAGE)||'null');return merge(defaults,saved||{});}catch{return deepClone(defaults);}}
  function merge(base,extra){const out=deepClone(base); Object.keys(extra||{}).forEach(k=>{ if(extra[k]&&typeof extra[k]==='object'&&!Array.isArray(extra[k])) out[k]={...(out[k]||{}),...extra[k]}; else out[k]=extra[k]; }); return out;}
  function save(){try{localStorage.setItem(STORAGE,JSON.stringify(settings));}catch{}}
  function nonDefault(value=settings){
    if(Number(value.preamp)||Number(value.bass)||Number(value.treble)||Number(value.reverbWet)||Number(value.pan)||Number(value.width)!==100)return true;
    if(Object.values(value.eq||{}).some(v=>Number(v)!==0))return true;
    const c=value.compressor||{}; const d=defaults.compressor;
    return ['threshold','ratio','attack','release'].some(k=>Math.abs(Number(c[k])-Number(d[k]))>0.0001);
  }
  function currentSrcSafe(){const el=audio(); const src=String(el?.currentSrc||el?.src||''); if(!src)return false; if(src.startsWith('blob:')||src.startsWith('data:'))return true; try{return new URL(src,location.href).origin===location.origin;}catch{return false;}}
  function makeImpulse(seconds=1.4,decay=2.4){const rate=ctx.sampleRate,length=Math.max(1,Math.floor(rate*seconds)),buffer=ctx.createBuffer(2,length,rate);for(let c=0;c<2;c++){const data=buffer.getChannelData(c);for(let i=0;i<length;i++) data[i]=(Math.random()*2-1)*Math.pow(1-i/length,decay);}return buffer;}
  function connect(){
    const el=audio(); if(!el)throw new Error('Pemutar audio tidak ditemukan');
    if(!currentSrcSafe())throw new Error('Audio effects tidak tersedia untuk sumber audio ini.');
    if(engineReady)return;
    ctx=new (window.AudioContext||window.webkitAudioContext)(); source=ctx.createMediaElementSource(el);
    const preamp=ctx.createGain();
    const bass=ctx.createBiquadFilter(); bass.type='lowshelf'; bass.frequency.value=120;
    const eq=frequencies.map((freq,index)=>{const f=ctx.createBiquadFilter(); f.type='peaking';f.frequency.value=freq;f.Q.value=(index===0||index===frequencies.length-1) ? 0.8 : 1.05;return f;});
    const treble=ctx.createBiquadFilter();treble.type='highshelf';treble.frequency.value=8000;
    const compressor=ctx.createDynamicsCompressor();
    const splitter=ctx.createChannelSplitter(2),merger=ctx.createChannelMerger(2);
    const midL=ctx.createGain(),midR=ctx.createGain(),sideL=ctx.createGain(),sideR=ctx.createGain(),midBus=ctx.createGain(),sideBus=ctx.createGain();
    midL.gain.value=.5;midR.gain.value=.5;sideL.gain.value=.5;sideR.gain.value=-.5;
    const leftMid=ctx.createGain(),rightMid=ctx.createGain(),leftSide=ctx.createGain(),rightSide=ctx.createGain();rightSide.gain.value=-1;
    const pan=ctx.createStereoPanner();
    const dry=ctx.createGain(),wet=ctx.createGain(),convolver=ctx.createConvolver(),mix=ctx.createGain(),analyser=ctx.createAnalyser(); analyser.fftSize=2048;analyser.smoothingTimeConstant=.78;
    source.connect(preamp); preamp.connect(bass); let prev=bass; eq.forEach(f=>{prev.connect(f);prev=f;}); prev.connect(treble);treble.connect(compressor);compressor.connect(splitter);
    splitter.connect(midL,0);splitter.connect(midR,1);midL.connect(midBus);midR.connect(midBus);splitter.connect(sideL,0);splitter.connect(sideR,1);sideL.connect(sideBus);sideR.connect(sideBus);
    midBus.connect(leftMid);midBus.connect(rightMid);sideBus.connect(leftSide);sideBus.connect(rightSide);leftMid.connect(merger,0,0);leftSide.connect(merger,0,0);rightMid.connect(merger,0,1);rightSide.connect(merger,0,1);
    merger.connect(pan);pan.connect(dry);dry.connect(mix);pan.connect(convolver);convolver.connect(wet);wet.connect(mix);mix.connect(analyser);analyser.connect(ctx.destination);
    nodes={preamp,bass,eq,treble,compressor,splitter,merger,midL,midR,sideL,sideR,midBus,sideBus,leftMid,rightMid,leftSide,rightSide,pan,dry,wet,convolver,mix,analyser}; engineReady=true; applySettings();
  }
  function dbToGain(db){return Math.pow(10,Number(db||0)/20);}
  function updateImpulse(){if(!nodes||!ctx)return;const room=Math.max(0,Math.min(100,Number(settings.reverbRoom||0)))/100;nodes.convolver.buffer=makeImpulse(.35+room*2.8,1.2+room*3.2);}
  function applySettings(){if(!nodes)return;const now=ctx.currentTime;nodes.preamp.gain.setTargetAtTime(dbToGain(settings.preamp),now,.015);nodes.bass.gain.setTargetAtTime(Number(settings.bass),now,.015);nodes.treble.gain.setTargetAtTime(Number(settings.treble),now,.015);frequencies.forEach((f,i)=>nodes.eq[i].gain.setTargetAtTime(Number(settings.eq[f]||0),now,.015));nodes.pan.pan.setTargetAtTime(Math.max(-1,Math.min(1,Number(settings.pan)/100)),now,.015);const width=Math.max(0,Math.min(200,Number(settings.width||100)))/100;nodes.leftSide.gain.setTargetAtTime(width,now,.015);nodes.rightSide.gain.setTargetAtTime(-width,now,.015);nodes.dry.gain.setTargetAtTime(Math.max(0,Math.min(100,Number(settings.reverbDry)))/100,now,.015);nodes.wet.gain.setTargetAtTime(Math.max(0,Math.min(100,Number(settings.reverbWet)))/100,now,.015);const c=settings.compressor||defaults.compressor;nodes.compressor.threshold.setTargetAtTime(Number(c.threshold),now,.015);nodes.compressor.ratio.setTargetAtTime(Number(c.ratio),now,.015);nodes.compressor.attack.setTargetAtTime(Number(c.attack),now,.015);nodes.compressor.release.setTargetAtTime(Number(c.release),now,.015);clearTimeout(roomTimer);roomTimer=setTimeout(updateImpulse,120);}
  function ensure(){try{connect(); if(ctx?.state==='suspended')ctx.resume().catch(()=>{}); return true;}catch(error){showStatus(error.message);return false;}}
  function setPreset(name){const patch=presets[name]||{};settings=merge(defaults,patch);settings.preset=name;save();if(engineReady)applySettings();renderControls();}
  function manual(){if(settings.preset!=='Custom')settings.preset='Custom';save();}
  function set(path,value){if(path.startsWith('eq.'))settings.eq[path.slice(3)]=Number(value);else if(path.startsWith('compressor.'))settings.compressor[path.split('.')[1]]=Number(value);else settings[path]=Number(value);manual();if(ensure())applySettings();syncValueLabels();}
  function reset(){settings=deepClone(defaults);save();if(engineReady)applySettings();renderControls();}
  function showStatus(text=''){const el=panel?.querySelector('[data-audio-lab-status]');if(el){el.textContent=text;el.hidden=!text;}}
  function slider(label,path,min,max,step,value,suffix=''){return `<label class="audio-lab-control"><span><b>${label}</b><em data-value-for="${path}">${Number(value).toFixed(step<1?2:0)}${suffix}</em></span><input type="range" min="${min}" max="${max}" step="${step}" value="${value}" data-audio-setting="${path}" data-suffix="${suffix}"></label>`;}
  function eqMarkup(){return `<div class="audio-eq-grid">${frequencies.map(f=>`<label><input type="range" orient="vertical" min="-12" max="12" step="1" value="${settings.eq[f]||0}" data-audio-setting="eq.${f}"><span>${f>=1000?`${f/1000}K`:f}</span><em data-value-for="eq.${f}">${settings.eq[f]||0}</em></label>`).join('')}</div>`;}
  function renderControls(){if(!panel)return;const body=panel.querySelector('[data-audio-lab-body]');if(!body)return;body.innerHTML=`
    <div class="audio-lab-section"><label class="audio-preset"><span>Preset</span><select data-audio-preset>${[...Object.keys(presets),'Custom'].map(p=>`<option ${settings.preset===p?'selected':''}>${p}</option>`).join('')}</select></label>${slider('Master / Preamp','preamp',-12,12,1,settings.preamp,' dB')}${slider('Bass','bass',-12,12,1,settings.bass,' dB')}${slider('Treble','treble',-12,12,1,settings.treble,' dB')}</div>
    <div class="audio-lab-section"><div class="audio-lab-section-title"><b>Equalizer</b><span>-12 dB — +12 dB</span></div>${eqMarkup()}</div>
    <div class="audio-lab-section"><div class="audio-lab-section-title"><b>Reverb</b></div>${slider('Wet','reverbWet',0,100,1,settings.reverbWet,'%')}${slider('Dry','reverbDry',0,100,1,settings.reverbDry,'%')}${slider('Room','reverbRoom',0,100,1,settings.reverbRoom,'%')}</div>
    <div class="audio-lab-section"><div class="audio-lab-section-title"><b>Stereo</b></div>${slider('Pan L / R','pan',-100,100,1,settings.pan,'%')}${slider('Stereo Width','width',0,200,1,settings.width,'%')}</div>
    <div class="audio-lab-section"><div class="audio-lab-section-title"><b>Visualizer</b><select data-visualizer-mode><option value="spectrum" ${settings.visualizer==='spectrum'?'selected':''}>Spectrum</option><option value="waveform" ${settings.visualizer==='waveform'?'selected':''}>Waveform</option></select></div><canvas class="audio-visualizer" width="600" height="180" data-audio-visualizer></canvas></div>
    <button class="audio-lab-reset" data-audio-reset>RESET DEFAULT</button>`;
    body.querySelector('[data-audio-preset]').onchange=e=>{if(e.target.value!=='Custom')setPreset(e.target.value);};
    body.querySelectorAll('[data-audio-setting]').forEach(input=>input.addEventListener('input',()=>set(input.dataset.audioSetting,input.value)));
    body.querySelector('[data-visualizer-mode]').onchange=e=>{settings.visualizer=e.target.value;save();};
    body.querySelector('[data-audio-reset]').onclick=reset;startVisualizer();
  }
  function syncValueLabels(){if(!panel)return;panel.querySelectorAll('[data-audio-setting]').forEach(input=>{const label=panel.querySelector(`[data-value-for="${CSS.escape(input.dataset.audioSetting)}"]`);if(label)label.textContent=`${Number(input.value).toFixed(Number(input.step)<1?2:0)}${input.dataset.suffix||''}`;});const select=panel.querySelector('[data-audio-preset]');if(select)select.value=settings.preset;}
  function startVisualizer(){cancelAnimationFrame(raf);const canvas=panel?.querySelector('[data-audio-visualizer]');if(!canvas)return;const g=canvas.getContext('2d');const draw=()=>{raf=requestAnimationFrame(draw);const w=canvas.width,h=canvas.height;g.clearRect(0,0,w,h);g.fillStyle='rgba(255,255,255,.04)';g.fillRect(0,0,w,h);if(!nodes?.analyser)return;g.strokeStyle='rgba(255,255,255,.9)';g.fillStyle='rgba(255,255,255,.78)';if(settings.visualizer==='waveform'){const arr=new Uint8Array(nodes.analyser.fftSize);nodes.analyser.getByteTimeDomainData(arr);g.beginPath();arr.forEach((v,i)=>{const x=i/(arr.length-1)*w,y=v/255*h;if(i===0)g.moveTo(x,y);else g.lineTo(x,y);});g.stroke();}else{const arr=new Uint8Array(nodes.analyser.frequencyBinCount);nodes.analyser.getByteFrequencyData(arr);const bars=64,step=Math.floor(arr.length/bars);for(let i=0;i<bars;i++){const v=arr[i*step]/255;const bw=w/bars-2;g.fillRect(i*w/bars,h-v*h,bw,v*h);}}};draw();}
  let sheetObserver=null;
  function cleanupPanelReference(){
    cancelAnimationFrame(raf);raf=0;
    sheetObserver?.disconnect?.();sheetObserver=null;
    panel=null;
  }
  function open(){
    if(!window.DatzonPlayerSheet?.open)return;
    if(panel?.isConnected)return;
    cleanupPanelReference();
    const body=`<div class="audio-lab-sheet-content"><header class="audio-lab-sheet-head"><div><small>DATZON MUSIC</small><h2>Audio Settings</h2></div><button type="button" data-audio-lab-close aria-label="Tutup"><svg class="icon"><use href="#i-close"></use></svg></button></header><p class="audio-lab-status" data-audio-lab-status hidden></p><div class="audio-lab-body" data-audio-lab-body></div></div>`;
    panel=window.DatzonPlayerSheet.open(body,'audio-lab-player-sheet',{kind:'queue',initialSnap:'half'});
    panel?.querySelector('[data-audio-lab-close]')?.addEventListener('click',()=>window.DatzonPlayerSheet.close());
    renderControls();
    ensure();
    const modalRoot=document.getElementById('modalRoot');
    if(modalRoot){sheetObserver=new MutationObserver(()=>{if(panel&&!panel.isConnected)cleanupPanelReference();});sheetObserver.observe(modalRoot,{childList:true,subtree:true});}
  }
  function close(){
    if(panel?.isConnected)window.DatzonPlayerSheet?.close?.();
    cleanupPanelReference();
  }
  window.DatzonAudioLab=Object.freeze({open,close,ensure,applySettings,settings:()=>deepClone(settings),isActive:()=>engineReady,shouldAutoEnable:()=>engineReady||nonDefault(settings),requiresSameOrigin:()=>engineReady||nonDefault(settings)});
})();
