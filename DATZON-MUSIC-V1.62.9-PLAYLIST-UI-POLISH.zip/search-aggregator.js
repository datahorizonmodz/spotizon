(() => {
  'use strict';

  const VERSION_TAGS = Object.freeze(['remix','live','instrumental','acoustic','sped up','slowed','karaoke','radio edit','demo','remaster','version']);
  const normalize = value => String(value || '')
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/\b(featuring|feat\.?|ft\.?)\b/g, ' feat ')
    .replace(/[^a-z0-9]+/g, ' ')
    .trim();

  function versionFingerprint(title = '') {
    const text = normalize(title);
    return VERSION_TAGS.filter(tag => text.includes(tag)).sort().join('|');
  }

  function stableInterleave(tracks = [], artists = [], albums = [], playlists = []) {
    const feed = [];
    let artistIndex = 0;
    let albumIndex = 0;
    let playlistIndex = 0;
    tracks.forEach((track, index) => {
      feed.push({ kind:'track', data:track });
      const position = index + 1;
      if ((position === 3 || position === 11 || position === 19) && artists[artistIndex]) {
        feed.push({ kind:'artist', data:artists[artistIndex++] });
      }
      if (position === 7) {
        if (playlists[playlistIndex]) feed.push({ kind:'playlist', data:playlists[playlistIndex++] });
        if (playlists[playlistIndex]) feed.push({ kind:'playlist', data:playlists[playlistIndex++] });
        if (albums[albumIndex]) feed.push({ kind:'album', data:albums[albumIndex++] });
      }
      if (position === 15) {
        if (albums[albumIndex]) feed.push({ kind:'album', data:albums[albumIndex++] });
        if (playlists[playlistIndex]) feed.push({ kind:'playlist', data:playlists[playlistIndex++] });
      }
    });
    while (artistIndex < artists.length || albumIndex < albums.length || playlistIndex < playlists.length) {
      if (artists[artistIndex]) feed.push({ kind:'artist', data:artists[artistIndex++] });
      if (albums[albumIndex]) feed.push({ kind:'album', data:albums[albumIndex++] });
      if (playlists[playlistIndex]) feed.push({ kind:'playlist', data:playlists[playlistIndex++] });
    }
    return feed;
  }

  window.DatzonSearchAggregator = Object.freeze({ normalize, versionFingerprint, stableInterleave });
})();
