const THERESAV_API_BASE = 'https://api.theresav.eu';
const THERESAV_API_KEY = process.env.THERESAV_API_KEY || '';

function sendJson(response, status, payload) {
  response.setHeader('Content-Type', 'application/json; charset=utf-8');
  response.setHeader('Cache-Control', 'no-store, max-age=0');
  response.status(status).send(JSON.stringify(payload));
}

export async function proxyTheresav(request, response, kind) {
  if (String(request.method || 'GET').toUpperCase() !== 'GET') {
    response.setHeader('Allow', 'GET');
    return sendJson(response, 405, { status:false, message:'Metode tidak didukung.' });
  }

  if (!THERESAV_API_KEY) return sendJson(response, 503, { status:false, message:'THERESAV_API_KEY belum dikonfigurasi di Environment Variables.' });

  const isDownload = kind === 'download';
  const value = String(isDownload ? request.query?.url || '' : request.query?.query || '').trim();
  if (!value) return sendJson(response, 400, { status:false, message:isDownload ? 'URL Spotify wajib diisi.' : 'Query pencarian wajib diisi.' });
  if (isDownload && !/^https:\/\/open\.spotify\.com\/track\/[A-Za-z0-9]{22}(?:[?/#].*)?$/i.test(value)) {
    return sendJson(response, 400, { status:false, message:'URL Spotify track tidak valid.' });
  }

  const path = isDownload ? '/api/download/spotify' : '/api/search/spotify';
  const upstream = new URL(`${THERESAV_API_BASE}${path}`);
  upstream.searchParams.set(isDownload ? 'url' : 'query', value);

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), isDownload ? 45000 : 30000);
  try {
    const upstreamResponse = await fetch(upstream, {
      method: 'GET',
      headers: {
        Accept: 'application/json',
        'x-apikey': THERESAV_API_KEY
      },
      signal: controller.signal,
      cache: 'no-store'
    });
    const text = await upstreamResponse.text();
    response.setHeader('Content-Type', upstreamResponse.headers.get('content-type') || 'application/json; charset=utf-8');
    response.setHeader('Cache-Control', 'no-store, max-age=0');
    return response.status(upstreamResponse.status).send(text || '{}');
  } catch (error) {
    const timedOut = error?.name === 'AbortError';
    return sendJson(response, timedOut ? 504 : 502, {
      status:false,
      message: timedOut ? 'Theresav terlalu lama merespons.' : 'Theresav tidak dapat dihubungi.',
      error: String(error?.message || error || '')
    });
  } finally {
    clearTimeout(timer);
  }
}
