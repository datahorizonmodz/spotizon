import { getAdminServices } from './firebase-admin.js';

const APP_ID = 'DATZON Music';
const SCHEMA_VERSION = 4;
const MAX_PLAYLISTS_PER_REQUEST = 6;
const MAX_PARTICIPANTS = 24;
const MAX_TRACKS = 200;

class PlaylistSyncError extends Error {
  constructor(code, message, status = 400) {
    super(message);
    this.name = 'PlaylistSyncError';
    this.code = code;
    this.status = status;
  }
}

function bearerToken(request) {
  const header = String(request?.headers?.authorization || request?.headers?.Authorization || '').trim();
  const match = header.match(/^Bearer\s+(.+)$/i);
  return match ? match[1].trim() : '';
}

function safeId(value = '') {
  return String(value || '').trim().replace(/[^A-Za-z0-9._-]/g, '-').replace(/^-+|-+$/g, '').slice(0, 120);
}

function safeString(value, max = 160) {
  return String(value || '').trim().slice(0, max);
}

function uniqueIds(values = []) {
  return [...new Set((Array.isArray(values) ? values : []).map(value => safeString(value, 128)).filter(Boolean))].slice(0, MAX_PARTICIPANTS);
}

function sameSet(left = [], right = []) {
  const a = [...new Set(left)].sort();
  const b = [...new Set(right)].sort();
  return a.length === b.length && a.every((value, index) => value === b[index]);
}

function durationSeconds(track = {}) {
  const durationMs = Number(track.durationMs || track.duration_ms || 0);
  if (Number.isFinite(durationMs) && durationMs > 0) return Math.round(durationMs / 1000);
  const parts = String(track.duration || '').trim().split(':').map(Number);
  if (!parts.length || parts.some(value => !Number.isFinite(value) || value < 0)) return 0;
  return Math.round(parts.reduce((total, value) => total * 60 + value, 0));
}

function compactTrack(track = {}) {
  const spotifyTrackId = safeString(track.spotifyTrackId || track.spotifyId || '', 64).replace(/[^A-Za-z0-9]/g, '');
  return {
    id: safeString(track.id || spotifyTrackId, 120),
    spotifyTrackId,
    title: safeString(track.title || track.name || 'Lagu', 180) || 'Lagu',
    artist: safeString(track.artist || track.artistName || 'Artis tidak diketahui', 220) || 'Artis tidak diketahui',
    artistNames: (Array.isArray(track.artistNames) ? track.artistNames : []).slice(0, 8).map(value => safeString(value, 100)).filter(Boolean),
    duration: safeString(track.duration, 20),
    thumbnail: safeString(track.thumbnail || track.image, 900),
    album: safeString(track.album, 180),
    url: safeString(track.url || track.spotifyUrl, 900),
    source: safeString(track.source || 'Playlist DATZON', 100),
    isrc: safeString(track.isrc, 32),
    explicit: Boolean(track.explicit)
  };
}

function validateRecord(raw = {}) {
  const id = safeId(raw.id);
  const ownerUid = safeString(raw.ownerUid || raw.collabOwnerUid, 128);
  const collaborative = Boolean(raw.collaborative || raw.sourceType === 'collaborative');
  const visibility = String(raw.visibility || '').toLowerCase() === 'public' ? 'public' : 'private';
  const participantUids = uniqueIds([ownerUid, ...(Array.isArray(raw.participantUids) ? raw.participantUids : [])]);
  if (!id || !ownerUid) throw new PlaylistSyncError('invalid_playlist', 'Data playlist tidak valid.');
  if (!participantUids.includes(ownerUid)) throw new PlaylistSyncError('invalid_participants', 'Data kolaborator tidak valid.');
  if (!collaborative && (visibility !== 'public' || participantUids.length !== 1)) {
    throw new PlaylistSyncError('invalid_playlist_visibility', 'Playlist single yang dibagikan harus publik.');
  }
  const tracks = (Array.isArray(raw.tracks) ? raw.tracks : []).slice(0, MAX_TRACKS).map(compactTrack);
  const createdAt = Math.max(1, Math.round(Number(raw.createdAt || Date.now()) || Date.now()));
  const updatedAt = Math.max(createdAt, Math.round(Number(raw.updatedAt || createdAt) || createdAt));
  const participantProfiles = (Array.isArray(raw.participantProfiles) ? raw.participantProfiles : []).slice(0, MAX_PARTICIPANTS).map(item => ({
    uid: safeString(item?.uid, 128),
    fullName: safeString(item?.fullName || item?.username || 'Pengguna DATZON', 100),
    username: safeString(item?.username, 50),
    photoURL: safeString(item?.photoURL, 900)
  })).filter(item => item.uid && participantUids.includes(item.uid));
  return {
    app: APP_ID,
    schemaVersion: SCHEMA_VERSION,
    id,
    name: safeString(raw.name || raw.title || 'Playlist', 80) || 'Playlist',
    visibility,
    ownerUid,
    collabOwnerUid: ownerUid,
    collaborative,
    sourceType: collaborative ? 'collaborative' : 'public',
    participantUids,
    profileUids: [...participantUids],
    participantProfiles,
    createdAt,
    updatedAt,
    totalTracks: tracks.length,
    durationSeconds: tracks.reduce((total, track) => total + durationSeconds(track), 0),
    listed: tracks.length > 0,
    tracks
  };
}

async function verifiedActor(request) {
  const token = bearerToken(request);
  if (!token) throw new PlaylistSyncError('unauthorized', 'Sesi login tidak tersedia.', 401);
  const { auth, db } = getAdminServices();
  let decoded;
  try { decoded = await auth.verifyIdToken(token, true); }
  catch { throw new PlaylistSyncError('unauthorized', 'Sesi login sudah berakhir. Silakan login ulang.', 401); }
  const provider = String(decoded?.firebase?.sign_in_provider || '');
  if (decoded?.otpVerified !== true && provider !== 'google.com') {
    throw new PlaylistSyncError('otp_required', 'Selesaikan verifikasi akun terlebih dahulu.', 403);
  }
  const userSnapshot = await db.collection('users').doc(decoded.uid).get();
  if (!userSnapshot.exists) throw new PlaylistSyncError('profile_required', 'Profil DATZON Music belum tersedia.', 403);
  return { uid: decoded.uid, db };
}

async function hydrateParticipantProfiles(db, record) {
  const refs = record.participantUids.map(uid => db.collection('publicProfiles').doc(uid));
  const snapshots = refs.length ? await db.getAll(...refs) : [];
  const fallback = new Map((record.participantProfiles || []).map(item => [item.uid, item]));
  const profiles = record.participantUids.map((uid, index) => {
    const data = snapshots[index]?.exists ? snapshots[index].data() : {};
    const old = fallback.get(uid) || {};
    return {
      uid,
      fullName: safeString(data.fullName || old.fullName || data.username || old.username || 'Pengguna DATZON', 100),
      username: safeString(data.username || old.username, 50),
      photoURL: safeString(data.photoURL || old.photoURL, 900)
    };
  });
  return { ...record, participantProfiles: profiles, profileUids: [...record.participantUids] };
}

function ensureActorMayWrite(actorUid, incoming, existing = null) {
  if (!existing) {
    if (incoming.ownerUid !== actorUid) throw new PlaylistSyncError('forbidden', 'Hanya pembuat playlist yang dapat menerbitkan playlist ini.', 403);
    return;
  }
  const existingParticipants = uniqueIds(existing.participantUids || []);
  const actorIsOwner = String(existing.ownerUid || existing.collabOwnerUid || '') === actorUid;
  const actorIsMember = existingParticipants.includes(actorUid);
  if (!actorIsOwner && !(Boolean(existing.collaborative) && actorIsMember)) {
    throw new PlaylistSyncError('forbidden', 'Kamu tidak memiliki akses untuk mengubah playlist ini.', 403);
  }
  if (String(existing.ownerUid || '') !== incoming.ownerUid
      || String(existing.collabOwnerUid || existing.ownerUid || '') !== incoming.collabOwnerUid
      || Boolean(existing.collaborative) !== incoming.collaborative
      || String(existing.sourceType || '') !== incoming.sourceType
      || Number(existing.createdAt || 0) !== incoming.createdAt) {
    throw new PlaylistSyncError('immutable_playlist_fields', 'Identitas playlist tidak boleh diubah.', 409);
  }
  const membersChanged = !sameSet(existingParticipants, incoming.participantUids);
  const visibilityChanged = String(existing.visibility || 'private') !== incoming.visibility;
  if ((membersChanged || visibilityChanged) && !actorIsOwner) {
    throw new PlaylistSyncError('owner_required', 'Hanya pembuat playlist yang dapat mengubah anggota atau privasi.', 403);
  }
  if (!actorIsOwner && !incoming.participantUids.includes(actorUid)) {
    throw new PlaylistSyncError('forbidden', 'Akses kolaborator sudah tidak tersedia.', 403);
  }
}

async function upsertPlaylist(db, actorUid, rawRecord) {
  const incomingBase = validateRecord(rawRecord);
  const incoming = await hydrateParticipantProfiles(db, incomingBase);
  const canonicalRef = db.collection('musicPlaylists').doc(incoming.id);
  const tombstoneRef = db.collection('musicPlaylistTombstones').doc(incoming.id);
  return db.runTransaction(async transaction => {
    // V1.62.8: a deleted playlist ID is permanent. A stale owner/collaborator
    // device must never be able to resurrect tracks, cover, or membership after
    // the owner has confirmed deletion.
    const [snapshot, tombstone] = await Promise.all([
      transaction.get(canonicalRef),
      transaction.get(tombstoneRef)
    ]);
    if (tombstone.exists) {
      transaction.delete(db.collection('users').doc(actorUid).collection('playlists').doc(incoming.id));
      return { id:incoming.id, status:'deleted' };
    }
    const existing = snapshot.exists ? snapshot.data() : null;
    ensureActorMayWrite(actorUid, incoming, existing);
    if (existing && Number(existing.updatedAt || 0) > incoming.updatedAt) {
      return { id: incoming.id, status: 'stale' };
    }
    const oldProfileUids = uniqueIds(existing?.profileUids || existing?.participantUids || []);
    transaction.set(canonicalRef, incoming, { merge:false });
    incoming.profileUids.forEach(profileUid => {
      transaction.set(db.collection('musicPlaylistProfiles').doc(profileUid).collection('items').doc(incoming.id), incoming, { merge:false });
    });
    oldProfileUids.filter(uid => !incoming.profileUids.includes(uid)).forEach(profileUid => {
      transaction.delete(db.collection('musicPlaylistProfiles').doc(profileUid).collection('items').doc(incoming.id));
    });
    return { id: incoming.id, status: snapshot.exists ? 'updated' : 'created', listed: incoming.listed };
  });
}

async function unpublishPlaylist(db, actorUid, rawId) {
  const id = safeId(rawId);
  if (!id) return { id:'', status:'ignored' };
  const canonicalRef = db.collection('musicPlaylists').doc(id);
  return db.runTransaction(async transaction => {
    const snapshot = await transaction.get(canonicalRef);
    if (!snapshot.exists) return { id, status:'missing' };
    const existing = snapshot.data();
    const ownerUid = String(existing.ownerUid || existing.collabOwnerUid || '');
    if (ownerUid !== actorUid) return { id, status:'ignored' };
    const profileUids = uniqueIds(existing.profileUids || existing.participantUids || [ownerUid]);
    const publicProfileRefs = profileUids.map(uid => db.collection('publicProfiles').doc(uid));
    const publicProfileSnapshots = await Promise.all(publicProfileRefs.map(ref => transaction.get(ref)));
    const changedAtMs = Date.now();
    transaction.delete(canonicalRef);
    profileUids.forEach(profileUid => {
      transaction.delete(db.collection('musicPlaylistProfiles').doc(profileUid).collection('items').doc(id));
    });
    publicProfileSnapshots.forEach(profileSnapshot => {
      if (!profileSnapshot.exists) return;
      const data = profileSnapshot.data() || {};
      const current = Array.isArray(data.publicPlaylists) ? data.publicPlaylists : [];
      const filtered = current.filter(item => String(item?.id || '') !== id);
      if (filtered.length === current.length) return;
      transaction.set(profileSnapshot.ref, {
        publicPlaylists:filtered,
        publicPlaylistsUpdatedAtMs:changedAtMs
      }, { merge:true });
    });
    return { id, status:'unpublished' };
  });
}

async function deletePlaylist(db, actorUid, rawId) {
  const id = safeId(rawId);
  if (!id) return { id:'', status:'ignored' };
  const canonicalRef = db.collection('musicPlaylists').doc(id);
  const tombstoneRef = db.collection('musicPlaylistTombstones').doc(id);
  const actorPlaylistRef = db.collection('users').doc(actorUid).collection('playlists').doc(id);
  const result = await db.runTransaction(async transaction => {
    const [canonicalSnapshot, tombstone, actorPlaylistSnapshot] = await Promise.all([
      transaction.get(canonicalRef),
      transaction.get(tombstoneRef),
      transaction.get(actorPlaylistRef)
    ]);
    if (tombstone.exists) {
      transaction.delete(actorPlaylistRef);
      return { id, status:'already_deleted' };
    }

    // Canonical shared data is authoritative when present. For a single private
    // playlist there is intentionally no musicPlaylists record, so fall back to
    // the owner's private playlist document to authorize permanent deletion.
    const existing = canonicalSnapshot.exists
      ? canonicalSnapshot.data()
      : actorPlaylistSnapshot.exists ? actorPlaylistSnapshot.data() : null;
    if (!existing) return { id, status:'missing' };

    // A canonical record has already been normalized/authorized by this server
    // and is safe to use for participant cleanup. If canonical is absent we are
    // deleting a private single playlist from the actor's own user path; never
    // trust participant/member fields from that client-writable fallback to
    // delete documents belonging to other users.
    const ownerUid = canonicalSnapshot.exists
      ? String(existing.ownerUid || existing.collabOwnerUid || '')
      : String(existing.ownerUid || existing.collabOwnerUid || actorUid);
    if (ownerUid && ownerUid !== actorUid) return { id, status:'ignored' };
    const profileUids = canonicalSnapshot.exists
      ? uniqueIds([actorUid, ...(Array.isArray(existing.profileUids) ? existing.profileUids : existing.participantUids || [])])
      : [actorUid];
    const deletedAtMs = Date.now();
    const collaborative = canonicalSnapshot.exists
      && Boolean(existing.collaborative || existing.sourceType === 'collaborative');
    // Read public profile fallback snapshots before any transaction writes so
    // deletion remains atomic across canonical/index/private/profile payloads.
    const publicProfileRefs = profileUids.map(uid => db.collection('publicProfiles').doc(uid));
    const publicProfileSnapshots = await Promise.all(publicProfileRefs.map(ref => transaction.get(ref)));

    // Keep only a tiny permanent tombstone. No playlist name, tracks, cover,
    // participant list, duration, or other content survives deletion.
    transaction.set(tombstoneRef, {
      app:APP_ID,
      schemaVersion:SCHEMA_VERSION,
      id,
      status:'deleted',
      deleted:true,
      deletedAtMs
    }, { merge:false });
    if (canonicalSnapshot.exists) transaction.delete(canonicalRef);
    profileUids.forEach(profileUid => {
      transaction.delete(db.collection('musicPlaylistProfiles').doc(profileUid).collection('items').doc(id));
      // Collaborative snapshots are also stored in each member's private
      // playlist subcollection. Remove those copies server-side so the database
      // no longer retains the deleted playlist payload.
      transaction.delete(db.collection('users').doc(profileUid).collection('playlists').doc(id));
      if (collaborative && profileUid !== actorUid) {
        const notificationId = `collab_delete_${id}_${deletedAtMs}`.slice(0, 180);
        transaction.set(db.collection('users').doc(profileUid).collection('notifications').doc(notificationId), {
          app:APP_ID,
          schemaVersion:SCHEMA_VERSION,
          id:notificationId,
          type:'collab_playlist_remove',
          title:'Playlist kolaboratif dihapus',
          message:'Pembuat playlist menghapus playlist kolaboratif ini.',
          fromUid:actorUid,
          toUid:profileUid,
          actionData:{ playlistId:id, updatedAt:deletedAtMs, deleted:true, senderUid:actorUid },
          createdAtMs:deletedAtMs,
          expiresAtMs:deletedAtMs + (365 * 24 * 60 * 60 * 1000),
          read:false
        }, { merge:false });
      }
    });
    publicProfileSnapshots.forEach(snapshot => {
      if (!snapshot.exists) return;
      const data = snapshot.data() || {};
      const current = Array.isArray(data.publicPlaylists) ? data.publicPlaylists : [];
      const filtered = current.filter(item => String(item?.id || '') !== id);
      if (filtered.length === current.length) return;
      transaction.set(snapshot.ref, {
        publicPlaylists:filtered,
        publicPlaylistsUpdatedAtMs:deletedAtMs
      }, { merge:true });
    });
    return { id, status:'deleted' };
  });
  return { id:result.id, status:result.status };
}

export async function readAccessibleProfilePlaylists(request, body = {}) {
  const { uid, db } = await verifiedActor(request);
  const profileUid = safeString(body?.profileUid, 128);
  if (!profileUid || profileUid.includes('/')) {
    throw new PlaylistSyncError('invalid_profile', 'Profil playlist tidak valid.');
  }

  // Read the canonical directory instead of trusting one per-profile index.
  // This is a membership-gated fallback for private collaborations and also
  // repairs a target index that may have been missed by an older deployment.
  const snapshot = await db.collection('musicPlaylists')
    .where('participantUids', 'array-contains', uid)
    .get();

  const playlists = snapshot.docs
    .map(doc => ({ id: doc.id, ...doc.data() }))
    .filter(item => {
      const participants = uniqueIds(item.participantUids || []);
      const profileUids = uniqueIds(item.profileUids || item.participantUids || []);
      const tracks = Array.isArray(item.tracks) ? item.tracks : [];
      return Boolean(item.collaborative)
        && item.listed !== false
        && tracks.length > 0
        && participants.includes(uid)
        && profileUids.includes(profileUid);
    })
    .sort((a, b) => Number(b.updatedAt || 0) - Number(a.updatedAt || 0))
    .slice(0, 100);

  // Opportunistic self-heal: canonical membership is authoritative. If an
  // older build missed musicPlaylistProfiles/{profileUid}/items/{playlistId},
  // visiting the member profile restores that index for future realtime reads.
  if (playlists.length) {
    const batch = db.batch();
    playlists.forEach(item => {
      const ref = db.collection('musicPlaylistProfiles').doc(profileUid).collection('items').doc(safeId(item.id));
      batch.set(ref, item, { merge:false });
    });
    await batch.commit();
  }

  return { profileUid, playlists };
}

export async function syncPlaylistDirectory(request, body = {}) {
  const { uid, db } = await verifiedActor(request);
  const upserts = Array.isArray(body.upserts) ? body.upserts.slice(0, MAX_PLAYLISTS_PER_REQUEST) : [];
  // Backward compatibility: V1.62.7 and older used `deletes` for directory
  // removal when a public single playlist was simply switched back to private.
  // Keep that field as UNPUBLISH, not permanent deletion.
  const deletes = Array.isArray(body.deletes) ? body.deletes.slice(0, 24) : [];
  const permanentDeletes = Array.isArray(body.permanentDeletes) ? body.permanentDeletes.slice(0, 24) : [];
  if (!upserts.length && !deletes.length && !permanentDeletes.length) {
    return { synced:[], deleted:[], permanentlyDeleted:[] };
  }
  const synced = [];
  for (const item of upserts) synced.push(await upsertPlaylist(db, uid, item));
  const deleted = [];
  for (const id of deletes) deleted.push(await unpublishPlaylist(db, uid, id));
  const permanentlyDeleted = [];
  for (const id of permanentDeletes) permanentlyDeleted.push(await deletePlaylist(db, uid, id));
  return { synced, deleted, permanentlyDeleted };
}

export function playlistSyncErrorResponse(error) {
  if (error instanceof PlaylistSyncError) {
    return { status:error.status || 400, body:{ ok:false, code:error.code, error:error.message } };
  }
  console.error('[DATZON Playlist Sync]', error?.message || error);
  return { status:500, body:{ ok:false, code:'playlist_sync_failed', error:'Sinkronisasi playlist sedang bermasalah. Coba lagi beberapa saat nanti.' } };
}
