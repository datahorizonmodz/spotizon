export const SPOTIZON_OTP_EMAIL_TEMPLATE = `<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Kode verifikasi Spotizon</title>
</head>
<body style="margin:0;padding:0;background:#f3f4f6;font-family:Arial,Helvetica,sans-serif;color:#111827;">
  <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="width:100%;margin:0;padding:0;background:#f3f4f6;border-collapse:collapse;">
    <tr>
      <td align="center" style="padding:28px 12px;">
        <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="width:100%;max-width:640px;background:#ffffff;border:1px solid #e8ebef;border-radius:24px;border-collapse:separate;overflow:hidden;">

          <tr>
            <td style="padding:34px 40px 22px 40px;">
              <table role="presentation" cellspacing="0" cellpadding="0" border="0" style="border-collapse:collapse;">
                <tr>
                  <td valign="middle" width="58" style="width:58px;">
                    <table role="presentation" width="54" height="54" cellspacing="0" cellpadding="0" border="0" style="width:54px;height:54px;border-collapse:separate;">
                      <tr>
                        <td align="center" valign="middle" bgcolor="#1ed760" style="width:54px;height:54px;background:#1ed760;border:2px solid #0b1117;border-radius:999px;color:#0b1117;font-family:Arial,Helvetica,sans-serif;font-size:27px;line-height:50px;font-weight:900;text-align:center;vertical-align:middle;">D</td>
                      </tr>
                    </table>
                  </td>
                  <td valign="middle" style="padding-left:14px;">
                    <div style="font-family:Arial,Helvetica,sans-serif;font-size:22px;line-height:1.2;font-weight:800;letter-spacing:1.8px;color:#111827;">SPOTIZON</div>
                    <div style="font-family:Arial,Helvetica,sans-serif;font-size:11px;line-height:1.3;letter-spacing:3px;color:#8b94a3;padding-top:3px;">MUSIC ACCOUNT</div>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <tr>
            <td style="padding:6px 40px 0 40px;">
              <div style="font-family:Arial,Helvetica,sans-serif;font-size:13px;line-height:1.4;font-weight:700;letter-spacing:2.2px;color:#13a86b;text-transform:uppercase;">Secure verification</div>
              <h1 style="margin:12px 0 14px 0;font-family:Arial,Helvetica,sans-serif;font-size:34px;line-height:1.15;letter-spacing:-1px;color:#111827;font-weight:800;">Kode masuk Spotizon kamu</h1>
              <p style="margin:0;font-family:Arial,Helvetica,sans-serif;color:#667085;font-size:16px;line-height:1.65;">
                Gunakan kode berikut untuk melanjutkan masuk ke akun Spotizon. Jangan bagikan kode ini kepada siapa pun.
              </p>
            </td>
          </tr>

          <tr>
            <td style="padding:28px 40px 8px 40px;">
              <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="width:100%;border-collapse:separate;">
                <tr>
                  <td align="center" bgcolor="#0b1117" style="background:#0b1117;border-radius:20px;padding:28px 20px;text-align:center;">
                    <div style="font-family:Arial,Helvetica,sans-serif;font-size:12px;line-height:1.4;letter-spacing:3px;color:#8fa0ad;text-transform:uppercase;padding-bottom:12px;">Verification code</div>
                    <div style="font-family:Arial,Helvetica,sans-serif;font-size:44px;line-height:1;font-weight:900;letter-spacing:8px;color:#78f0b1;">{{CODE}}</div>
                    <div style="font-family:Arial,Helvetica,sans-serif;font-size:12px;line-height:1.5;color:#8fa0ad;padding-top:14px;">Berlaku selama {{EXPIRES_MINUTES}} menit • sekali pakai</div>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <tr>
            <td style="padding:20px 40px 0 40px;">
              <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="width:100%;background:#f8fafb;border:1px solid #edf0f2;border-radius:16px;border-collapse:separate;">
                <tr>
                  <td style="padding:18px;">
                    <div style="font-family:Arial,Helvetica,sans-serif;font-size:13px;line-height:1.4;font-weight:700;color:#111827;padding-bottom:6px;">Kenapa kamu menerima email ini?</div>
                    <div style="font-family:Arial,Helvetica,sans-serif;font-size:13px;line-height:1.6;color:#7a8491;">
                      Ada permintaan masuk atau verifikasi akun menggunakan alamat email <strong style="color:#4b5563;">{{EMAIL}}</strong>.
                    </div>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <tr>
            <td style="padding:22px 40px 34px 40px;">
              <p style="margin:0 0 10px 0;font-family:Arial,Helvetica,sans-serif;font-size:14px;line-height:1.65;color:#667085;">
                Jika kamu tidak mencoba masuk ke Spotizon, abaikan email ini. Tidak ada perubahan yang akan dilakukan pada akunmu.
              </p>
              <p style="margin:18px 0 0 0;font-family:Arial,Helvetica,sans-serif;font-size:14px;line-height:1.6;color:#111827;">
                Salam,<br><strong>Spotizon Security</strong>
              </p>
            </td>
          </tr>

          <tr>
            <td bgcolor="#0b1117" style="background:#0b1117;padding:26px 40px;">
              <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="width:100%;border-collapse:collapse;">
                <tr>
                  <td valign="middle">
                    <table role="presentation" cellspacing="0" cellpadding="0" border="0" style="border-collapse:collapse;">
                      <tr>
                        <td valign="middle" width="42" style="width:42px;">
                          <table role="presentation" width="38" height="38" cellspacing="0" cellpadding="0" border="0" style="width:38px;height:38px;border-collapse:separate;">
                            <tr>
                              <td align="center" valign="middle" bgcolor="#1ed760" style="width:38px;height:38px;background:#1ed760;border:2px solid #05080b;border-radius:999px;color:#05080b;font-family:Arial,Helvetica,sans-serif;font-size:20px;line-height:34px;font-weight:900;text-align:center;vertical-align:middle;">D</td>
                            </tr>
                          </table>
                        </td>
                        <td valign="middle" style="padding-left:11px;">
                          <div style="font-family:Arial,Helvetica,sans-serif;font-size:16px;line-height:1.2;font-weight:800;letter-spacing:1.4px;color:#ffffff;">SPOTIZON</div>
                          <div style="font-family:Arial,Helvetica,sans-serif;font-size:10px;line-height:1.3;letter-spacing:2px;color:#7e8a97;padding-top:2px;">MUSIC ACCOUNT</div>
                        </td>
                      </tr>
                    </table>
                  </td>
                  <td align="right" valign="middle" style="font-family:Arial,Helvetica,sans-serif;font-size:11px;line-height:1.55;color:#7e8a97;text-align:right;">
                    Secure access<br>Powered by DATZON
                  </td>
                </tr>
              </table>

              <div style="border-top:1px solid #1d252d;margin-top:22px;padding-top:18px;font-family:Arial,Helvetica,sans-serif;font-size:11px;line-height:1.55;color:#6f7b87;">
                Email ini dikirim otomatis. Mohon jangan membalas pesan ini.
              </div>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>
</body>
</html>`;
