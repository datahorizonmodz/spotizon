import crypto from 'node:crypto';
import { FieldValue, Timestamp } from 'firebase-admin/firestore';
import { getAdminServices } from './firebase-admin.js';
import { SPOTIZON_OTP_EMAIL_TEMPLATE } from './email-template.js';

const OTP_TTL_MS = 10 * 60 * 1000;
const RESEND_COOLDOWN_MS = 60 * 1000;
const MAX_ATTEMPTS = 5;
const EMAIL_WINDOW_MS = 15 * 60 * 1000;
const EMAIL_MAX_SENDS = 5;
const IP_WINDOW_MS = 15 * 60 * 1000;
const IP_MAX_SENDS = 20;
const RESEND_MAX = 6;
const CHALLENGE_COLLECTION = 'auth_challenges';
const RATE_COLLECTION = 'auth_rate_limits';
const USERNAME_RESERVATIONS = 'auth_username_reservations';
const MUSIC_USERNAME_COLLECTION = 'usernames';
const LEGACY_USERNAME_COLLECTION = 'musicUsernames';
const MUSIC_APP_ID = 'DATZON Music';
const MUSIC_SCHEMA_VERSION = 3;

class PublicAuthError extends Error {
  constructor(code, message, status = 400) {
    super(message);
    this.name = 'PublicAuthError';
    this.code = code;
    this.status = status;
  }
}

function requiredSecret() {
  const secret = String(process.env.OTP_SECRET || '');
  if (secret.length < 32) throw new Error('OTP_SECRET belum tersedia atau terlalu pendek. Gunakan minimal 32 karakter random.');
  return secret;
}

function requiredResendKey() {
  const value = String(process.env.RESEND_API_KEY || '').trim();
  if (!value) throw new Error('RESEND_API_KEY belum tersedia.');
  return value;
}

function otpFromEmail() {
  const value = String(process.env.OTP_FROM_EMAIL || '').trim();
  if (!value) throw new Error('OTP_FROM_EMAIL belum tersedia.');
  return value;
}

function normalizeEmail(value = '') {
  return String(value || '').trim().toLowerCase();
}

function validEmail(value = '') {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalizeEmail(value));
}

function normalizeUsername(value = '') {
  return String(value || '')
    .trim()
    .replace(/^@+/, '')
    .toLowerCase()
    .replace(/[^a-z0-9._]/g, '')
    .replace(/\.{2,}/g, '.')
    .slice(0, 24);
}

function validateUsername(value = '') {
  const normalized = normalizeUsername(value);
  if (normalized.length < 3 || !/^[a-z0-9][a-z0-9._]{1,22}[a-z0-9]$/.test(normalized)) {
    throw new PublicAuthError('invalid_username', 'Username belum valid. Gunakan 3–24 karakter huruf kecil, angka, titik, atau garis bawah.');
  }
  return normalized;
}

function validateFullName(value = '') {
  const clean = String(value || '').trim().replace(/\s+/g, ' ');
  if (clean.length < 2 || clean.length > 70) throw new PublicAuthError('invalid_full_name', 'Full Name harus berisi 2–70 karakter.');
  return clean;
}

function validatePassword(value = '') {
  const password = String(value || '');
  if (password.length < 6 || password.length > 128) throw new PublicAuthError('invalid_password', 'Password minimal 6 karakter.');
  return password;
}

function isDatzonMusicProfileData(data = {}) {
  return Number(data.musicProfileVersion || 0) >= 1
    || (typeof data.username === 'string' && data.username.length >= 3 && (
      typeof data.onboardingCompleted === 'boolean'
      || Array.isArray(data.selectedArtists)
      || typeof data.preferredStatus === 'string'
      || data.listeningSummary?.totalSeconds != null
    ));
}

function randomChallengeId() {
  return crypto.randomBytes(24).toString('base64url');
}

function randomOtp() {
  return crypto.randomInt(0, 1_000_000).toString().padStart(6, '0');
}

function hmac(value = '') {
  return crypto.createHmac('sha256', requiredSecret()).update(String(value)).digest('hex');
}

function codeHash(challengeId, version, code) {
  return hmac(`otp:${challengeId}:${version}:${String(code)}`);
}

function safeEqualHex(a = '', b = '') {
  try {
    const left = Buffer.from(String(a), 'hex');
    const right = Buffer.from(String(b), 'hex');
    return left.length === right.length && left.length > 0 && crypto.timingSafeEqual(left, right);
  } catch { return false; }
}

function identityFingerprint({ purpose, email, username = '', uid = '', provider = '' }) {
  return hmac(['identity', purpose, normalizeEmail(email), normalizeUsername(username), String(uid || ''), String(provider || '')].join(':'));
}

function requestIp(request) {
  const forwarded = String(request.headers?.['x-forwarded-for'] || '').split(',')[0].trim();
  return forwarded || String(request.headers?.['x-real-ip'] || '').trim() || 'unknown';
}

function maskedEmail(email = '') {
  const [name = '', domain = ''] = normalizeEmail(email).split('@');
  if (!domain) return '';
  if (name.length <= 2) return `${name.slice(0,1)}***@${domain}`;
  return `${name.slice(0,2)}${'*'.repeat(Math.min(5, Math.max(2, name.length - 2)))}@${domain}`;
}

function timestampMs(value) {
  if (!value) return 0;
  if (typeof value.toMillis === 'function') return value.toMillis();
  if (typeof value._seconds === 'number') return value._seconds * 1000 + Math.floor(Number(value._nanoseconds || 0) / 1e6);
  return Number(value) || 0;
}

async function applyRateLimit(db, key, max, windowMs, nowMs) {
  const id = hmac(`rate:${key}`).slice(0, 48);
  const ref = db.collection(RATE_COLLECTION).doc(id);
  await db.runTransaction(async tx => {
    const snap = await tx.get(ref);
    const current = snap.exists ? snap.data() : {};
    const resetAtMs = timestampMs(current.resetAt);
    const active = resetAtMs > nowMs;
    const count = active ? Number(current.count || 0) : 0;
    if (count >= max) throw new PublicAuthError('rate_limited', 'Terlalu banyak permintaan. Coba lagi beberapa saat nanti.', 429);
    tx.set(ref, {
      count: count + 1,
      windowStartedAt: active && current.windowStartedAt ? current.windowStartedAt : Timestamp.fromMillis(nowMs),
      resetAt: Timestamp.fromMillis(active ? resetAtMs : nowMs + windowMs),
      lastRequestAt: Timestamp.fromMillis(nowMs),
      updatedAt: FieldValue.serverTimestamp()
    }, { merge: true });
  });
}

async function enforceSendRateLimits(db, email, purpose, request, nowMs) {
  await Promise.all([
    applyRateLimit(db, `email:${purpose}:${normalizeEmail(email)}`, EMAIL_MAX_SENDS, EMAIL_WINDOW_MS, nowMs),
    applyRateLimit(db, `ip:${requestIp(request)}`, IP_MAX_SENDS, IP_WINDOW_MS, nowMs)
  ]);
}

function renderEmail(code, email) {
  return SPOTIZON_OTP_EMAIL_TEMPLATE
    .replaceAll('{{CODE}}', String(code))
    .replaceAll('{{EMAIL}}', String(email).replace(/[<>&"]/g, char => ({ '<':'&lt;','>':'&gt;','&':'&amp;','"':'&quot;' }[char])))
    .replaceAll('{{EXPIRES_MINUTES}}', '10');
}

async function sendOtpEmail(email, code) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 12_000);
  try {
    const response = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${requiredResendKey()}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        from: otpFromEmail(),
        to: [email],
        subject: 'Kode verifikasi Spotizon kamu',
        html: renderEmail(code, email)
      }),
      signal: controller.signal
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) {
      const detail = String(payload?.message || payload?.error?.message || `HTTP ${response.status}`).slice(0, 240);
      throw new Error(`Resend gagal: ${detail}`);
    }
    return payload;
  } finally {
    clearTimeout(timer);
  }
}

async function reserveUsername(db, username, challengeId, expiresAtMs, nowMs, ownerUid = '') {
  const usernameRef = db.collection(MUSIC_USERNAME_COLLECTION).doc(username);
  const legacyUsernameRef = db.collection(LEGACY_USERNAME_COLLECTION).doc(username);
  const reservationRef = db.collection(USERNAME_RESERVATIONS).doc(username);
  await db.runTransaction(async tx => {
    const [usernameSnap, legacyUsernameSnap, reservationSnap] = await Promise.all([
      tx.get(usernameRef),
      tx.get(legacyUsernameRef),
      tx.get(reservationRef)
    ]);
    const uid = String(ownerUid || '');
    if (usernameSnap.exists && (!uid || usernameSnap.data()?.uid !== uid)) {
      throw new PublicAuthError('username_taken', `Username @${username} sudah digunakan.`, 409);
    }
    // Alias dari build koreksi sebelumnya tetap dicek agar username yang
    // sempat tersimpan di musicUsernames tidak dapat diambil ulang.
    if (legacyUsernameSnap.exists && (!uid || legacyUsernameSnap.data()?.uid !== uid)) {
      throw new PublicAuthError('username_taken', `Username @${username} sudah digunakan.`, 409);
    }
    if (reservationSnap.exists) {
      const reservation = reservationSnap.data();
      const active = timestampMs(reservation.expiresAt) > nowMs;
      if (active && reservation.challengeId !== challengeId) {
        throw new PublicAuthError('username_taken', `Username @${username} sedang digunakan pada proses pendaftaran lain.`, 409);
      }
    }
    tx.set(reservationRef, {
      username,
      challengeId,
      expiresAt: Timestamp.fromMillis(expiresAtMs),
      updatedAt: FieldValue.serverTimestamp()
    }, { merge: true });
  });
}

async function releaseUsernameReservation(db, username, challengeId) {
  if (!username) return;
  const ref = db.collection(USERNAME_RESERVATIONS).doc(username);
  try {
    await db.runTransaction(async tx => {
      const snap = await tx.get(ref);
      if (snap.exists && snap.data()?.challengeId === challengeId) tx.delete(ref);
    });
  } catch {}
}

async function createChallenge({ db, request, purpose, email, uid = '', provider = '', registration = null }) {
  const nowMs = Date.now();
  const challengeId = randomChallengeId();
  const code = randomOtp();
  const version = 1;
  const expiresAtMs = nowMs + OTP_TTL_MS;
  const resendAvailableAtMs = nowMs + RESEND_COOLDOWN_MS;
  await enforceSendRateLimits(db, email, purpose, request, nowMs);

  let normalizedRegistration = null;
  if (registration) {
    normalizedRegistration = {
      fullName: validateFullName(registration.fullName),
      username: validateUsername(registration.username),
      email: normalizeEmail(registration.email),
      provider: String(registration.provider || provider || 'password')
    };
    await reserveUsername(db, normalizedRegistration.username, challengeId, expiresAtMs, nowMs, uid);
  }

  const ref = db.collection(CHALLENGE_COLLECTION).doc(challengeId);
  const payload = {
    purpose,
    uid: String(uid || ''),
    provider: String(provider || ''),
    email: normalizeEmail(email),
    emailHash: hmac(`email:${normalizeEmail(email)}`),
    codeHash: codeHash(challengeId, version, code),
    codeVersion: version,
    attempts: 0,
    maxAttempts: MAX_ATTEMPTS,
    resendCount: 0,
    createdAt: Timestamp.fromMillis(nowMs),
    expiresAt: Timestamp.fromMillis(expiresAtMs),
    resendAvailableAt: Timestamp.fromMillis(resendAvailableAtMs),
    usedAt: null,
    status: 'pending',
    deliveryStatus: 'sending',
    registration: normalizedRegistration,
    identityFingerprint: identityFingerprint({ purpose, email, username: normalizedRegistration?.username || '', uid, provider }),
    requestIpHash: hmac(`ip:${requestIp(request)}`),
    updatedAt: FieldValue.serverTimestamp()
  };
  await ref.set(payload);

  try {
    await sendOtpEmail(email, code);
    await ref.set({ deliveryStatus: 'sent', deliveredAt: FieldValue.serverTimestamp(), updatedAt: FieldValue.serverTimestamp() }, { merge: true });
  } catch (error) {
    await ref.set({ deliveryStatus: 'failed', resendAvailableAt: Timestamp.fromMillis(Date.now()), updatedAt: FieldValue.serverTimestamp() }, { merge: true }).catch(() => {});
    if (normalizedRegistration?.username) await releaseUsernameReservation(db, normalizedRegistration.username, challengeId);
    throw error;
  }

  return {
    challengeId,
    email: normalizeEmail(email),
    maskedEmail: maskedEmail(email),
    expiresAt: expiresAtMs,
    resendAvailableAt: resendAvailableAtMs,
    purpose
  };
}

async function challengeSnapshot(db, challengeId) {
  const clean = String(challengeId || '').trim();
  if (!/^[A-Za-z0-9_-]{20,80}$/.test(clean)) throw new PublicAuthError('invalid_challenge', 'Sesi verifikasi tidak valid.', 400);
  const ref = db.collection(CHALLENGE_COLLECTION).doc(clean);
  const snap = await ref.get();
  if (!snap.exists) throw new PublicAuthError('invalid_challenge', 'Sesi verifikasi tidak tersedia. Mulai ulang proses login atau pendaftaran.', 404);
  return { ref, data: snap.data(), id: snap.id };
}

async function verifyChallengeCode(db, challengeId, code) {
  const cleanCode = String(code || '').replace(/\D/g, '').slice(0, 6);
  if (cleanCode.length !== 6) throw new PublicAuthError('invalid_code', 'Kode verifikasi tidak valid.');
  const ref = db.collection(CHALLENGE_COLLECTION).doc(String(challengeId || '').trim());
  let verified = null;
  let failure = null;
  await db.runTransaction(async tx => {
    const snap = await tx.get(ref);
    if (!snap.exists) {
      failure = new PublicAuthError('invalid_challenge', 'Sesi verifikasi tidak tersedia. Mulai ulang proses.', 404);
      return;
    }
    const data = snap.data();
    const nowMs = Date.now();
    if (data.status === 'used' || data.usedAt) {
      failure = new PublicAuthError('already_used', 'Kode verifikasi sudah digunakan. Mulai ulang proses.', 409);
      return;
    }
    if (data.status === 'locked' || Number(data.attempts || 0) >= Number(data.maxAttempts || MAX_ATTEMPTS)) {
      failure = new PublicAuthError('too_many_attempts', 'Terlalu banyak percobaan. Kirim kode baru untuk melanjutkan.', 429);
      return;
    }
    if (timestampMs(data.expiresAt) <= nowMs) {
      tx.set(ref, { status: 'expired', updatedAt: FieldValue.serverTimestamp() }, { merge: true });
      failure = new PublicAuthError('expired', 'Kode verifikasi sudah kedaluwarsa.');
      return;
    }
    if (data.deliveryStatus !== 'sent') {
      failure = new PublicAuthError('delivery_pending', 'Kode belum berhasil dikirim. Coba kirim ulang kode.');
      return;
    }
    const expected = codeHash(snap.id, Number(data.codeVersion || 1), cleanCode);
    if (!safeEqualHex(expected, data.codeHash)) {
      const nextAttempts = Number(data.attempts || 0) + 1;
      tx.set(ref, {
        attempts: nextAttempts,
        status: nextAttempts >= Number(data.maxAttempts || MAX_ATTEMPTS) ? 'locked' : 'pending',
        updatedAt: FieldValue.serverTimestamp()
      }, { merge: true });
      failure = nextAttempts >= Number(data.maxAttempts || MAX_ATTEMPTS)
        ? new PublicAuthError('too_many_attempts', 'Terlalu banyak percobaan. Kirim kode baru untuk melanjutkan.', 429)
        : new PublicAuthError('invalid_code', 'Kode verifikasi tidak valid.', 400);
      return;
    }
    tx.set(ref, {
      status: 'used',
      usedAt: FieldValue.serverTimestamp(),
      attempts: Number(data.attempts || 0),
      updatedAt: FieldValue.serverTimestamp()
    }, { merge: true });
    verified = { id: snap.id, ...data };
  });
  if (failure) throw failure;
  if (!verified) throw new PublicAuthError('invalid_challenge', 'Sesi verifikasi tidak tersedia. Mulai ulang proses.', 404);
  return verified;
}

function searchTokens(...values) {
  const tokens = new Set();
  values.forEach(value => {
    const normalized = String(value || '')
      .normalize('NFKD')
      .replace(/[\u0300-\u036f]/g, '')
      .toLowerCase()
      .replace(/^@+/, '')
      .replace(/[^a-z0-9._ ]+/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
    if (!normalized) return;
    [normalized, ...normalized.split(' ')].filter(Boolean).forEach(piece => {
      for (let i = 1; i <= Math.min(piece.length, 24); i += 1) tokens.add(piece.slice(0, i));
    });
  });
  return [...tokens].slice(0, 160);
}

async function createProfileTransaction(db, { uid, fullName, username, email, photoURL = '', providers = [] }, challengeId) {
  const userRef = db.collection('users').doc(uid);
  const usernameRef = db.collection(MUSIC_USERNAME_COLLECTION).doc(username);
  const legacyUsernameRef = db.collection(LEGACY_USERNAME_COLLECTION).doc(username);
  const reservationRef = db.collection(USERNAME_RESERVATIONS).doc(username);
  const publicRef = db.collection('publicProfiles').doc(uid);
  const nowIso = new Date().toISOString();

  await db.runTransaction(async tx => {
    const [userSnap, usernameSnap, legacyUsernameSnap, reservationSnap] = await Promise.all([
      tx.get(userRef),
      tx.get(usernameRef),
      tx.get(legacyUsernameRef),
      tx.get(reservationRef)
    ]);
    const existingUserData = userSnap.exists ? userSnap.data() : {};
    if (userSnap.exists && isDatzonMusicProfileData(existingUserData)) {
      throw new PublicAuthError('profile_exists', 'Akun Spotizon ini sudah selesai terdaftar.', 409);
    }
    if (usernameSnap.exists && usernameSnap.data()?.uid !== uid) throw new PublicAuthError('username_taken', `Username @${username} sudah digunakan.`, 409);
    if (legacyUsernameSnap.exists && legacyUsernameSnap.data()?.uid !== uid) throw new PublicAuthError('username_taken', `Username @${username} sudah digunakan.`, 409);
    if (!reservationSnap.exists || reservationSnap.data()?.challengeId !== challengeId || timestampMs(reservationSnap.data()?.expiresAt) < Date.now()) {
      throw new PublicAuthError('username_reservation_expired', 'Reservasi username sudah berakhir. Mulai ulang pendaftaran.', 409);
    }
    const timestamp = FieldValue.serverTimestamp();
    const cleanProviders = [...new Set((providers || []).filter(Boolean))];
    const cleanPhotoURL = String(photoURL || '').slice(0, 1400);
    const userData = {
      fullName,
      username,
      usernameLower: username,
      photoURL: cleanPhotoURL,
      bio: '',
      socialLinks: [],
      selectedArtists: [],
      onboardingCompleted: false,
      providers: cleanProviders,
      musicEmailVerified: true,
      musicVerificationMethod: 'email_otp',
      musicProfileVersion: 1,
      updatedAt: timestamp,
      lastSeenAt: timestamp,
      preferredStatus: 'online',
      status: 'online',
      ...(!existingUserData.uid ? { uid } : {}),
      ...(!existingUserData.email ? { email } : {}),
      ...(!existingUserData.createdAt ? { createdAt: timestamp } : {}),
      ...(!existingUserData.createdAtIso ? { createdAtIso: nowIso } : {}),
      ...(!existingUserData.role ? { role: 'user' } : {})
    };
    tx.set(userRef, userData, { merge: true });
    tx.set(usernameRef, {
      app: MUSIC_APP_ID,
      schemaVersion: MUSIC_SCHEMA_VERSION,
      uid,
      username,
      email,
      updatedAt: timestamp
    }, { merge: true });
    tx.set(publicRef, {
      app: MUSIC_APP_ID,
      schemaVersion: MUSIC_SCHEMA_VERSION,
      uid,
      fullName,
      fullNameLower: fullName.toLowerCase(),
      username,
      usernameLower: username,
      photoURL: cleanPhotoURL,
      bio: '',
      socialLinks: [],
      status: 'online',
      preferredStatus: 'online',
      createdAtIso: nowIso,
      role: String(existingUserData.role || 'user').toLowerCase() === 'admin' ? 'admin' : 'user',
      listeningSummary: { totalSeconds: 0, plays: 0 },
      searchTokens: searchTokens(fullName, username),
      updatedAt: timestamp,
      lastSeenAt: timestamp
    });
    tx.delete(reservationRef);
  });
}

export async function startOtp(request, body = {}) {
  const { auth, db } = getAdminServices();
  const purpose = String(body.purpose || '').trim();
  if (purpose === 'login') {
    const idToken = String(body.idToken || '');
    let decoded;
    try { decoded = await auth.verifyIdToken(idToken, true); }
    catch { throw new PublicAuthError('invalid_credentials', 'Email/username atau password tidak valid.', 401); }
    if (String(decoded?.firebase?.sign_in_provider || '') !== 'password') {
      throw new PublicAuthError('invalid_credentials', 'Email/username atau password tidak valid.', 401);
    }
    const profileSnap = await db.collection('users').doc(decoded.uid).get();
    if (!profileSnap.exists || !isDatzonMusicProfileData(profileSnap.data())) {
      throw new PublicAuthError('incomplete_account', 'Akun belum selesai terdaftar. Selesaikan pendaftaran terlebih dahulu.', 409);
    }
    const record = await auth.getUser(decoded.uid);
    const email = normalizeEmail(record.email || decoded.email || profileSnap.data()?.email || '');
    if (!validEmail(email)) throw new PublicAuthError('email_unavailable', 'Email akun tidak tersedia untuk verifikasi.', 409);
    return createChallenge({ db, request, purpose: 'login', email, uid: decoded.uid, provider: 'password' });
  }

  if (purpose === 'register') {
    const registration = body.registration || {};
    const fullName = validateFullName(registration.fullName);
    const username = validateUsername(registration.username);
    const email = normalizeEmail(registration.email);
    validatePassword(registration.password);
    if (!validEmail(email)) throw new PublicAuthError('invalid_email', 'Format email tidak valid.');
    try {
      const existing = await auth.getUserByEmail(email);
      if (existing) throw new PublicAuthError('email_in_use', 'Email tersebut sudah digunakan. Silakan login.', 409);
    } catch (error) {
      if (error instanceof PublicAuthError) throw error;
      if (error?.code !== 'auth/user-not-found') throw error;
    }
    return createChallenge({
      db, request, purpose: 'register', email, provider: 'password',
      registration: { fullName, username, email, provider: 'password' }
    });
  }

  if (purpose === 'register-google') {
    const idToken = String(body.idToken || '');
    let decoded;
    try { decoded = await auth.verifyIdToken(idToken, true); }
    catch { throw new PublicAuthError('google_session_expired', 'Sesi Google sudah berakhir. Pilih akun Google lagi.', 401); }
    const provider = String(decoded?.firebase?.sign_in_provider || '');
    if (provider !== 'google.com' && provider !== 'custom') throw new PublicAuthError('google_session_expired', 'Sesi Google tidak valid.', 401);
    const existingProfile = await db.collection('users').doc(decoded.uid).get();
    if (existingProfile.exists && isDatzonMusicProfileData(existingProfile.data())) {
      throw new PublicAuthError('profile_exists', 'Akun Spotizon ini sudah terdaftar. Silakan masuk kembali.', 409);
    }
    const registration = body.registration || {};
    const fullName = validateFullName(registration.fullName);
    const username = validateUsername(registration.username);
    const record = await auth.getUser(decoded.uid);
    const email = normalizeEmail(record.email || decoded.email || '');
    if (!validEmail(email) || email !== normalizeEmail(registration.email)) throw new PublicAuthError('invalid_email', 'Email Google tidak sesuai dengan sesi yang dipilih.', 400);
    validatePassword(registration.password);
    return createChallenge({
      db, request, purpose: 'register-google', email, uid: decoded.uid, provider: 'google',
      registration: { fullName, username, email, provider: 'google' }
    });
  }

  throw new PublicAuthError('invalid_purpose', 'Tujuan verifikasi tidak valid.');
}

export async function resendOtp(request, body = {}) {
  const { db } = getAdminServices();
  const { ref, data, id } = await challengeSnapshot(db, body.challengeId);
  const nowMs = Date.now();
  if (data.status === 'used' || data.usedAt) throw new PublicAuthError('already_used', 'Sesi verifikasi sudah selesai. Mulai ulang proses.', 409);
  if (Number(data.resendCount || 0) >= RESEND_MAX) throw new PublicAuthError('rate_limited', 'Batas kirim ulang tercapai. Mulai ulang proses beberapa saat lagi.', 429);
  const resendAtMs = timestampMs(data.resendAvailableAt);
  if (resendAtMs > nowMs) {
    throw new PublicAuthError('cooldown', `Tunggu ${Math.ceil((resendAtMs - nowMs) / 1000)} detik sebelum mengirim ulang.`, 429);
  }
  await enforceSendRateLimits(db, data.email, data.purpose, request, nowMs);
  const code = randomOtp();
  const version = Number(data.codeVersion || 1) + 1;
  const expiresAtMs = nowMs + OTP_TTL_MS;
  const resendAvailableAtMs = nowMs + RESEND_COOLDOWN_MS;
  await ref.set({
    codeHash: codeHash(id, version, code),
    codeVersion: version,
    expiresAt: Timestamp.fromMillis(expiresAtMs),
    resendAvailableAt: Timestamp.fromMillis(resendAvailableAtMs),
    attempts: 0,
    status: 'pending',
    deliveryStatus: 'sending',
    resendCount: Number(data.resendCount || 0) + 1,
    updatedAt: FieldValue.serverTimestamp()
  }, { merge: true });

  if (data.registration?.username) {
    await reserveUsername(db, data.registration.username, id, expiresAtMs, nowMs, data.uid || '');
  }

  try {
    await sendOtpEmail(data.email, code);
    await ref.set({ deliveryStatus: 'sent', deliveredAt: FieldValue.serverTimestamp(), updatedAt: FieldValue.serverTimestamp() }, { merge: true });
  } catch (error) {
    await ref.set({ deliveryStatus: 'failed', resendAvailableAt: Timestamp.fromMillis(Date.now()), updatedAt: FieldValue.serverTimestamp() }, { merge: true }).catch(() => {});
    throw error;
  }
  return { challengeId: id, email: data.email, maskedEmail: maskedEmail(data.email), expiresAt: expiresAtMs, resendAvailableAt: resendAvailableAtMs, purpose: data.purpose };
}

export async function verifyOtp(request, body = {}) {
  const { auth, db } = getAdminServices();
  const verified = await verifyChallengeCode(db, body.challengeId, body.code);

  if (verified.purpose === 'login') {
    const profileSnap = await db.collection('users').doc(verified.uid).get();
    if (!profileSnap.exists || !isDatzonMusicProfileData(profileSnap.data())) {
      throw new PublicAuthError('incomplete_account', 'Akun belum selesai terdaftar.', 409);
    }
    const customToken = await auth.createCustomToken(verified.uid, {
      otpVerified: true,
      otpPurpose: 'login',
      otpChallengeId: verified.id
    });
    return { purpose: 'login', customToken, uid: verified.uid };
  }

  if (verified.purpose === 'register' || verified.purpose === 'register-google') {
    const registration = body.registration || {};
    const fullName = validateFullName(registration.fullName);
    const username = validateUsername(registration.username);
    const email = normalizeEmail(registration.email);
    const password = validatePassword(registration.password);
    const expected = verified.registration || {};
    if (fullName !== expected.fullName || username !== expected.username || email !== expected.email) {
      throw new PublicAuthError('registration_changed', 'Data pendaftaran berubah. Mulai ulang verifikasi agar tetap aman.', 409);
    }
    if (identityFingerprint({ purpose: verified.purpose, email, username, uid: verified.uid || '', provider: verified.provider || '' }) !== verified.identityFingerprint) {
      throw new PublicAuthError('registration_changed', 'Data pendaftaran tidak cocok dengan sesi verifikasi.', 409);
    }

    let uid = verified.uid || '';
    let createdNewAuthUser = false;
    try {
      if (verified.purpose === 'register') {
        const record = await auth.createUser({ email, password, emailVerified: true, displayName: fullName });
        uid = record.uid;
        createdNewAuthUser = true;
      } else {
        const googleIdToken = String(body.googleIdToken || '');
        let decoded;
        try { decoded = await auth.verifyIdToken(googleIdToken, true); }
        catch { throw new PublicAuthError('google_session_expired', 'Sesi Google sudah berakhir. Pilih akun Google lagi.', 401); }
        if (decoded.uid !== uid || normalizeEmail(decoded.email) !== email) throw new PublicAuthError('google_session_expired', 'Sesi Google tidak sesuai dengan pendaftaran.', 401);
        await auth.updateUser(uid, { password, emailVerified: true, displayName: fullName });
      }

      const record = await auth.getUser(uid);
      await createProfileTransaction(db, {
        uid,
        fullName,
        username,
        email,
        photoURL: verified.purpose === 'register-google' ? String(record.photoURL || '') : '',
        providers: [...new Set([verified.purpose === 'register-google' ? 'google.com' : '', 'password', ...record.providerData.map(item => item.providerId)].filter(Boolean))]
      }, verified.id);

      const customToken = await auth.createCustomToken(uid, {
        otpVerified: true,
        otpPurpose: 'register',
        otpChallengeId: verified.id
      });
      return { purpose: verified.purpose, customToken, uid, onboardingRequired: true };
    } catch (error) {
      if (createdNewAuthUser && uid) {
        try { await auth.deleteUser(uid); } catch {}
      }
      if (error instanceof PublicAuthError) throw error;
      if (error?.code === 'auth/email-already-exists') {
        throw new PublicAuthError('email_in_use', 'Email tersebut sudah digunakan. Silakan login.', 409);
      }
      if (error?.code === 'auth/invalid-password') {
        throw new PublicAuthError('invalid_password', 'Password belum memenuhi persyaratan keamanan.', 400);
      }
      throw error;
    }
  }

  throw new PublicAuthError('invalid_purpose', 'Sesi verifikasi tidak didukung.');
}

export function authErrorResponse(error) {
  if (error instanceof PublicAuthError) {
    return { status: error.status || 400, body: { ok: false, code: error.code, error: error.message } };
  }
  console.error('[Spotizon Auth]', error?.message || error);
  return { status: 500, body: { ok: false, code: 'server_error', error: 'Layanan verifikasi sedang bermasalah. Coba lagi beberapa saat nanti.' } };
}

export function otpConfigSummary() {
  // Only used server-side to make Vercel configuration errors diagnosable without exposing values.
  return {
    resendConfigured: Boolean(String(process.env.RESEND_API_KEY || '').trim()),
    fromConfigured: Boolean(String(process.env.OTP_FROM_EMAIL || '').trim()),
    otpSecretConfigured: String(process.env.OTP_SECRET || '').length >= 32,
    firebaseAdminConfigured: Boolean(String(process.env.FIREBASE_SERVICE_ACCOUNT_JSON || '').trim() || (process.env.FIREBASE_PROJECT_ID && process.env.FIREBASE_CLIENT_EMAIL && process.env.FIREBASE_PRIVATE_KEY))
  };
}
