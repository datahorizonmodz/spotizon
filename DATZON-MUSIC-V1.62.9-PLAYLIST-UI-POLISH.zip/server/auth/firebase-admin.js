import { cert, getApps, initializeApp } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import { getFirestore } from 'firebase-admin/firestore';

function parseServiceAccount() {
  const raw = String(process.env.FIREBASE_SERVICE_ACCOUNT_JSON || '').trim();
  if (raw) {
    let parsed;
    try { parsed = JSON.parse(raw); }
    catch (error) {
      throw new Error('FIREBASE_SERVICE_ACCOUNT_JSON bukan JSON yang valid.');
    }
    if (parsed.private_key) parsed.private_key = String(parsed.private_key).replace(/\\n/g, '\n');
    return parsed;
  }

  const projectId = String(process.env.FIREBASE_PROJECT_ID || '').trim();
  const clientEmail = String(process.env.FIREBASE_CLIENT_EMAIL || '').trim();
  const privateKey = String(process.env.FIREBASE_PRIVATE_KEY || '').replace(/\\n/g, '\n').trim();
  if (projectId && clientEmail && privateKey) {
    return { project_id: projectId, client_email: clientEmail, private_key: privateKey };
  }
  throw new Error('Firebase Admin belum dikonfigurasi. Isi FIREBASE_SERVICE_ACCOUNT_JSON di Vercel.');
}

export function getAdminServices() {
  if (!getApps().length) {
    const serviceAccount = parseServiceAccount();
    initializeApp({ credential: cert(serviceAccount), projectId: serviceAccount.project_id });
  }
  return { auth: getAuth(), db: getFirestore() };
}
