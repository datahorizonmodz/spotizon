import { getSpotifyArtist, getSpotifyArtistAlbums, searchSpotifyArtists, spotifyConfigured } from '../../lib/spotify.js';
import { publicSpotifyError, queryValue, sendJson } from './_http.js';

function sameName(a, b) {
  return String(a || '').normalize('NFKD').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim() === String(b || '').normalize('NFKD').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim();
}

export default async function handler(request, response) {
  if (request.method !== 'GET') return sendJson(response, 405, { ok:false, error:'Method not allowed' });
  if (!spotifyConfigured()) return sendJson(response, 503, { ok:false, error:'Spotify belum dikonfigurasi di server.' });
  let id = String(queryValue(request, 'id') || '').trim();
  const name = String(queryValue(request, 'name') || '').trim();
  try {
    let artist = null;
    if (id) artist = await getSpotifyArtist(id);
    else if (name) {
      const result = await searchSpotifyArtists(name, { limit: 10 });
      const items = Array.isArray(result?.items) ? result.items : [];
      artist = items.find(item => sameName(item?.name, name)) || null;
      if (!artist) return sendJson(response, 404, { ok:false, error:'Artis tidak ditemukan.' });
      id = artist.id;
    } else return sendJson(response, 400, { ok:false, error:'Artist ID atau nama wajib diisi.' });
    const albums = await getSpotifyArtistAlbums(id, { maxItems: 120 });
    sendJson(response, 200, { ok:true, artist, albums }, 'public, max-age=300, s-maxage=21600, stale-while-revalidate=86400');
  } catch (error) { publicSpotifyError(response, error); }
}
