import { spotifyConfigured, spotifyMarket } from '../../lib/spotify.js';
import { sendJson } from './_http.js';
export default function handler(request, response) {
  sendJson(response, 200, { ok:true, configured:spotifyConfigured(), market:spotifyMarket }, 'no-store');
}
