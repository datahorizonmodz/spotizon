import { getSpotifyPlaylist, spotifyConfigured } from '../../lib/spotify.js';
import { publicSpotifyError, queryValue, sendJson } from './_http.js';

export default async function handler(request, response) {
  if (request.method !== 'GET') return sendJson(response, 405, { ok:false, error:'Method not allowed' });
  if (!spotifyConfigured()) return sendJson(response, 503, { ok:false, error:'Spotify belum dikonfigurasi di server.' });
  const id = String(queryValue(request, 'id') || '').trim();
  if (!id) return sendJson(response, 400, { ok:false, error:'Playlist ID wajib diisi.' });
  try {
    const playlist = await getSpotifyPlaylist(id);
    sendJson(response, 200, { ok:true, playlist }, 'public, max-age=120, s-maxage=1800, stale-while-revalidate=7200');
  } catch (error) { publicSpotifyError(response, error); }
}
