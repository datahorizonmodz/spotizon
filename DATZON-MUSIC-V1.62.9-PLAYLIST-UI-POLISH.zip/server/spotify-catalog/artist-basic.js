import { getSpotifyArtist, searchSpotifyArtists, spotifyConfigured } from '../../lib/spotify.js';
import { publicSpotifyError, queryValue, sendJson } from './_http.js';

function normalized(value='') {
  return String(value).normalize('NFKD').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim();
}

export default async function handler(request, response) {
  if (request.method !== 'GET') return sendJson(response, 405, { ok:false, error:'Method not allowed' });
  if (!spotifyConfigured()) return sendJson(response, 503, { ok:false, error:'Spotify belum dikonfigurasi di server.' });
  const id = String(queryValue(request, 'id') || '').trim();
  const name = String(queryValue(request, 'name') || '').trim();
  try {
    let artist = null;
    if (id) artist = await getSpotifyArtist(id);
    else if (name) {
      const found = await searchSpotifyArtists(name, { limit:8 });
      artist = (found?.items || []).find(item => normalized(item?.name) === normalized(name)) || null;
    }
    if (!artist) return sendJson(response, 404, { ok:false, error:'Artis tidak ditemukan.' });
    return sendJson(response, 200, { ok:true, artist }, 'public, max-age=300, s-maxage=21600, stale-while-revalidate=86400');
  } catch (error) { return publicSpotifyError(response, error); }
}
