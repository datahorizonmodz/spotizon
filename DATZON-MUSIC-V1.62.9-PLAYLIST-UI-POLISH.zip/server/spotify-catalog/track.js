import { getSpotifyTrack, searchSpotifyTracks, spotifyConfigured } from '../../lib/spotify.js';
import { publicSpotifyError, queryValue, sendJson } from './_http.js';

export default async function handler(request, response) {
  if (request.method !== 'GET') return sendJson(response, 405, { ok:false, error:'Method not allowed' });
  if (!spotifyConfigured()) return sendJson(response, 503, { ok:false, error:'Spotify belum dikonfigurasi di server.' });
  const id = String(queryValue(request, 'id') || '').trim();
  const q = String(queryValue(request, 'q') || '').trim();
  try {
    const track = id ? await getSpotifyTrack(id) : (await searchSpotifyTracks(q, { limit: 5 }))?.items?.[0];
    if (!track) return sendJson(response, 404, { ok:false, error:'Track tidak ditemukan.' });
    sendJson(response, 200, { ok:true, track }, 'public, max-age=300, s-maxage=86400, stale-while-revalidate=86400');
  } catch (error) { publicSpotifyError(response, error); }
}
