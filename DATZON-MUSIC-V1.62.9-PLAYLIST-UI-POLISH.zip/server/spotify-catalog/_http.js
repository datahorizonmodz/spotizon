export function sendJson(response, status, body, cache = 'no-store') {
  response.statusCode = status;
  response.setHeader('Content-Type', 'application/json; charset=utf-8');
  response.setHeader('Cache-Control', cache);
  response.setHeader('X-Content-Type-Options', 'nosniff');
  response.end(JSON.stringify(body));
}

export function publicSpotifyError(response, error) {
  const configured = error?.code !== 'SPOTIFY_NOT_CONFIGURED';
  console.error('[DATZON Spotify Catalog]', error?.code || error?.message || error);
  sendJson(response, configured ? 502 : 503, {
    ok: false,
    error: configured ? 'Gagal memuat data Spotify.' : 'Spotify belum dikonfigurasi di server.'
  });
}

export function queryValue(request, key, fallback = '') {
  try {
    const url = new URL(request.url, 'http://localhost');
    return url.searchParams.get(key) ?? fallback;
  } catch { return fallback; }
}
