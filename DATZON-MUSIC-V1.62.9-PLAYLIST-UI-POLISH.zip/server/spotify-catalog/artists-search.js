import { searchSpotifyArtists, spotifyConfigured, spotifyMarket } from '../../lib/spotify.js';
import { publicSpotifyError, queryValue, sendJson } from './_http.js';

export default async function handler(request, response) {
  if (request.method !== 'GET') return sendJson(response, 405, { ok:false, error:'Method not allowed' });
  const q = String(queryValue(request, 'q') || '').trim();
  const limit = Math.max(1, Math.min(30, Number(queryValue(request, 'limit', '18')) || 18));
  if (!q) return sendJson(response, 400, { ok:false, error:'Query wajib diisi.' });
  if (!spotifyConfigured()) return sendJson(response, 503, { ok:false, error:'Spotify belum dikonfigurasi di server.' });
  try {
    const artists = await searchSpotifyArtists(q, { limit });
    return sendJson(response, 200, { ok:true, market:spotifyMarket, query:q, artists }, 'public, max-age=30, s-maxage=600, stale-while-revalidate=1800');
  } catch (error) { return publicSpotifyError(response, error); }
}
