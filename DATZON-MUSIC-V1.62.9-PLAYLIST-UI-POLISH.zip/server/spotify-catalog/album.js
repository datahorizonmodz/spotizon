import { getSpotifyAlbum, spotifyConfigured } from '../../lib/spotify.js';
import { publicSpotifyError, queryValue, sendJson } from './_http.js';

export default async function handler(request, response) {
  if (request.method !== 'GET') return sendJson(response, 405, { ok:false, error:'Method not allowed' });
  if (!spotifyConfigured()) return sendJson(response, 503, { ok:false, error:'Spotify belum dikonfigurasi di server.' });
  const id = String(queryValue(request, 'id') || '').trim();
  if (!id) return sendJson(response, 400, { ok:false, error:'Album ID wajib diisi.' });
  try {
    const album = await getSpotifyAlbum(id);
    sendJson(response, 200, { ok:true, album }, 'public, max-age=300, s-maxage=21600, stale-while-revalidate=86400');
  } catch (error) { publicSpotifyError(response, error); }
}
