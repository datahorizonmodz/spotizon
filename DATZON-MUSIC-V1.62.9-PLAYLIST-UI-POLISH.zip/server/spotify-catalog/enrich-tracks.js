import { findSpotifyTrackMatch } from '../../lib/spotify-match.js';
import { spotifyConfigured } from '../../lib/spotify.js';
import { sendJson } from './_http.js';

const MAX_ITEMS = 80;
const CONCURRENCY = 6;

async function readJsonBody(request) {
  if (request?.body && typeof request.body === 'object' && !Buffer.isBuffer(request.body)) return request.body;
  if (typeof request?.body === 'string') {
    try { return JSON.parse(request.body); } catch { return {}; }
  }
  const chunks = [];
  if (request && typeof request[Symbol.asyncIterator] === 'function') {
    for await (const chunk of request) chunks.push(Buffer.from(chunk));
  }
  if (!chunks.length) return {};
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch { return {}; }
}

function cleanSource(item = {}) {
  const artists = Array.isArray(item.artists)
    ? item.artists.map(value => typeof value === 'string' ? value : value?.name).filter(Boolean).slice(0, 8)
    : String(item.artist || item.primaryArtist || '').split(/,|&/).map(value => value.trim()).filter(Boolean).slice(0, 8);
  return {
    title: String(item.title || item.name || '').trim().slice(0, 240),
    artists,
    primaryArtist: artists[0] || String(item.primaryArtist || item.artist || '').trim().slice(0, 160),
    durationMs: Math.max(0, Math.min(24 * 60 * 60 * 1000, Number(item.durationMs || item.duration_ms || 0) || 0)),
    duration: String(item.duration || '').trim().slice(0, 16),
    isrc: String(item.isrc || '').trim().slice(0, 32),
    spotifyTrackId: String(item.spotifyTrackId || item.spotifyId || '').trim().slice(0, 32)
  };
}

function publicTrack(track = {}) {
  const images = Array.isArray(track?.album?.images) ? track.album.images.map(image => ({ url:String(image?.url || ''), width:Number(image?.width || 0), height:Number(image?.height || 0) })).filter(image => image.url) : [];
  return {
    id: String(track?.id || ''),
    name: String(track?.name || ''),
    duration_ms: Number(track?.duration_ms || 0),
    explicit: Boolean(track?.explicit),
    external_urls: { spotify: String(track?.external_urls?.spotify || '') },
    external_ids: { isrc: String(track?.external_ids?.isrc || '') },
    uri: String(track?.uri || ''),
    artists: Array.isArray(track?.artists) ? track.artists.map(artist => ({ id:String(artist?.id || ''), name:String(artist?.name || ''), uri:String(artist?.uri || ''), external_urls:{ spotify:String(artist?.external_urls?.spotify || '') } })).filter(artist => artist.name) : [],
    album: track?.album ? {
      id: String(track.album.id || ''),
      name: String(track.album.name || ''),
      album_type: String(track.album.album_type || ''),
      release_date: String(track.album.release_date || ''),
      images,
      external_urls: { spotify:String(track.album.external_urls?.spotify || '') }
    } : null
  };
}

async function mapLimited(items, worker, concurrency = CONCURRENCY) {
  const output = new Array(items.length);
  let cursor = 0;
  const runners = Array.from({ length: Math.min(concurrency, items.length) }, async () => {
    while (true) {
      const index = cursor++;
      if (index >= items.length) return;
      try { output[index] = await worker(items[index], index); }
      catch { output[index] = null; }
    }
  });
  await Promise.all(runners);
  return output;
}

export default async function handler(request, response) {
  if (request.method !== 'POST') return sendJson(response, 405, { ok:false, error:'Method not allowed' });
  if (!spotifyConfigured()) return sendJson(response, 503, { ok:false, error:'Spotify belum dikonfigurasi di server.' });
  const body = await readJsonBody(request);
  const rawItems = Array.isArray(body?.items) ? body.items.slice(0, MAX_ITEMS) : [];
  if (!rawItems.length) return sendJson(response, 400, { ok:false, error:'Daftar track wajib diisi.' });
  const sources = rawItems.map(cleanSource);
  const matches = await mapLimited(sources, async source => {
    if (!source.title || !source.primaryArtist) return null;
    const track = await findSpotifyTrackMatch(source);
    return track ? publicTrack(track) : null;
  });
  return sendJson(response, 200, { ok:true, matches }, 'private, max-age=0, no-store');
}
