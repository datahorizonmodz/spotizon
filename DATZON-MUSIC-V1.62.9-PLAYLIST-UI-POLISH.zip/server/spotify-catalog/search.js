import { searchSpotifyCatalog, spotifyConfigured, spotifyMarket } from '../../lib/spotify.js';
import { publicSpotifyError, queryValue, sendJson } from './_http.js';

export default async function handler(request, response) {
  if (request.method !== 'GET') return sendJson(response, 405, { ok:false, error:'Method not allowed' });
  const q = String(queryValue(request, 'q') || '').trim();
  const offset = Math.max(0, Number(queryValue(request, 'offset', '0')) || 0);
  const limit = Math.max(1, Math.min(20, Number(queryValue(request, 'limit', '12')) || 12));
  if (!q) return sendJson(response, 400, { ok:false, error:'Query wajib diisi.' });
  if (!spotifyConfigured()) return sendJson(response, 503, { ok:false, error:'Spotify belum dikonfigurasi di server.' });
  try {
    // Spotify Development Mode 2026 caps Search limit at 10. One combined
    // request is cheaper and avoids four independent rate-limit/error paths.
    const catalog = await searchSpotifyCatalog(q, { limit: Math.min(limit, 10), offset });
    sendJson(response, 200, {
      ok: true,
      market: spotifyMarket,
      query: q,
      offset,
      tracks: catalog.tracks || { items: [] },
      artists: catalog.artists || { items: [] },
      albums: catalog.albums || { items: [] },
      playlists: catalog.playlists || { items: [] }
    }, 'public, max-age=30, s-maxage=300, stale-while-revalidate=900');
  } catch (error) { publicSpotifyError(response, error); }
}
