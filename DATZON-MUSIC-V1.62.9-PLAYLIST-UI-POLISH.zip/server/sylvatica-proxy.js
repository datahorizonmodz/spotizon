const SYLVATICA_API_BASE = 'https://sylvatica.my.id';
const SYLVATICA_API_KEY = process.env.SYLVATICA_API_KEY || '';

function sendJson(response, status, payload) {
  response.setHeader('Content-Type', 'application/json; charset=utf-8');
  response.setHeader('Cache-Control', 'no-store, max-age=0');
  response.status(status).send(JSON.stringify(payload));
}

const ROUTES = {
  download: { path: '/api/download/spotify', param: 'url', timeout: 35000 },
  search: { path: '/api/search/spotify', param: 'q', timeout: 26000 },
  lyrics: { path: '/api/search/lyrics', param: 'q', timeout: 32000 }
};

export async function proxySylvatica(request, response, kind) {
  if (String(request.method || 'GET').toUpperCase() !== 'GET') {
    response.setHeader('Allow', 'GET');
    return sendJson(response, 405, { status:false, message:'Metode tidak didukung.' });
  }
  const route = ROUTES[kind];
  if (!route) return sendJson(response, 404, { status:false, message:'Endpoint Sylvatica tidak tersedia.' });
  if (!SYLVATICA_API_KEY) {
    return sendJson(response, 503, { status:false, message:'SYLVATICA_API_KEY belum dikonfigurasi di Environment Variables.' });
  }
  const value = String(request.query?.[route.param] || '').trim();
  if (!value) return sendJson(response, 400, { status:false, message:`Parameter ${route.param} wajib diisi.` });
  if (kind === 'download' && !/^https:\/\/open\.spotify\.com\/track\/[A-Za-z0-9]{22}(?:[?/#].*)?$/i.test(value)) {
    return sendJson(response, 400, { status:false, message:'URL Spotify track tidak valid.' });
  }
  if (value.length > 500) return sendJson(response, 400, { status:false, message:'Input terlalu panjang.' });

  const upstream = new URL(route.path, SYLVATICA_API_BASE);
  upstream.searchParams.set(route.param, value);
  upstream.searchParams.set('apikey', SYLVATICA_API_KEY);
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), route.timeout);
  try {
    const result = await fetch(upstream, {
      method:'GET', headers:{ Accept:'application/json' }, signal:controller.signal,
      cache:'no-store', redirect:'follow'
    });
    const text = await result.text();
    response.setHeader('Content-Type', result.headers.get('content-type') || 'application/json; charset=utf-8');
    response.setHeader('Cache-Control', 'no-store, max-age=0');
    return response.status(result.status).send(text || '{}');
  } catch (error) {
    const timeout = error?.name === 'AbortError';
    return sendJson(response, timeout ? 504 : 502, {
      status:false,
      message: timeout ? 'Sylvatica terlalu lama merespons.' : 'Sylvatica tidak dapat dihubungi.',
      error:String(error?.message || error || '')
    });
  } finally {
    clearTimeout(timer);
  }
}
