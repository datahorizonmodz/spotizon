export async function bridgeEdgeGet(request, response, handler) {
  if (String(request.method || 'GET').toUpperCase() !== 'GET') {
    response.setHeader('allow', 'GET');
    response.status(405).json({ ok:false, error:'Metode tidak didukung.' });
    return;
  }
  const forwardedHost = String(request.headers['x-forwarded-host'] || request.headers.host || 'localhost').split(',')[0].trim();
  const forwardedProto = String(request.headers['x-forwarded-proto'] || 'https').split(',')[0].trim();
  const url = new URL(String(request.url || '/'), `${forwardedProto}://${forwardedHost}`);
  const headers = new Headers();
  Object.entries(request.headers || {}).forEach(([key, value]) => {
    if (Array.isArray(value)) value.forEach(item => headers.append(key, String(item)));
    else if (value !== undefined) headers.set(key, String(value));
  });
  const edgeRequest = new Request(url, { method:'GET', headers });
  const edgeResponse = await handler({ request:edgeRequest });
  edgeResponse.headers.forEach((value, key) => response.setHeader(key, value));
  response.status(edgeResponse.status).send(await edgeResponse.text());
}
