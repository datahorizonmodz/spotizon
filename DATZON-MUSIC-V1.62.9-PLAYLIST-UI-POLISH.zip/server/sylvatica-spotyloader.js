const API_BASE = 'https://sylvatica.my.id';
const API_KEY = process.env.SYLVATICA_API_KEY || '';

function sendJson(response, status, payload) {
  response.setHeader('Content-Type', 'application/json; charset=utf-8');
  response.setHeader('Cache-Control', 'no-store, max-age=0');
  response.status(status).send(JSON.stringify(payload));
}

export default async function handler(request, response) {
  if (String(request.method || 'GET').toUpperCase() !== 'GET') {
    response.setHeader('Allow', 'GET');
    return sendJson(response, 405, { status:false, message:'Metode tidak didukung.' });
  }

  if (!API_KEY) return sendJson(response, 503, { status:false, message:'SYLVATICA_API_KEY belum dikonfigurasi di Environment Variables.' });

  const urlValue = String(request.query?.url || '').trim();
  const type = String(request.query?.type || 'track').trim().toLowerCase();
  const format = String(request.query?.format || 'mp3').trim().toLowerCase();
  const allowedTypes = new Set(['track','album','playlist','artist','search']);
  const allowedFormats = new Set(['mp3','flac','m4a']);

  if (!urlValue) return sendJson(response, 400, { status:false, message:'URL Spotify atau kata kunci wajib diisi.' });
  if (urlValue.length > 300) return sendJson(response, 400, { status:false, message:'Input terlalu panjang.' });
  if (!allowedTypes.has(type)) return sendJson(response, 400, { status:false, message:'Tipe Spotyloader tidak valid.' });
  if (type === 'track' && !allowedFormats.has(format)) return sendJson(response, 400, { status:false, message:'Format audio tidak valid.' });

  const spotifyPatterns = {
    track: /^https:\/\/open\.spotify\.com\/track\/[A-Za-z0-9]{22}(?:[?/#].*)?$/i,
    album: /^https:\/\/open\.spotify\.com\/album\/[A-Za-z0-9]{22}(?:[?/#].*)?$/i,
    playlist: /^https:\/\/open\.spotify\.com\/playlist\/[A-Za-z0-9]{22}(?:[?/#].*)?$/i
  };
  if (spotifyPatterns[type] && !spotifyPatterns[type].test(urlValue)) {
    return sendJson(response, 400, { status:false, message:`URL Spotify ${type} tidak valid.` });
  }
  if (['search','artist'].includes(type) && /^https?:\/\//i.test(urlValue) && !/^https:\/\/open\.spotify\.com\/artist\/[A-Za-z0-9]{22}(?:[?/#].*)?$/i.test(urlValue)) {
    return sendJson(response, 400, { status:false, message:'Untuk pencarian/artis hanya kata kunci atau URL Spotify artist yang diizinkan.' });
  }

  const upstream = new URL('/api/download/spotyloader', API_BASE);
  upstream.searchParams.set('url', urlValue);
  upstream.searchParams.set('type', type);
  if (type === 'track') upstream.searchParams.set('format', format);
  upstream.searchParams.set('apikey', API_KEY);

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), type === 'track' ? 50000 : 35000);

  try {
    const result = await fetch(upstream, {
      method:'GET',
      headers:{ Accept:'application/json' },
      signal:controller.signal,
      cache:'no-store',
      redirect:'follow'
    });
    const text = await result.text();
    response.setHeader('Content-Type', result.headers.get('content-type') || 'application/json; charset=utf-8');
    response.setHeader('Cache-Control', result.ok && type === 'artist' ? 'public, max-age=300, s-maxage=21600, stale-while-revalidate=86400' : (result.ok && type === 'search' ? 'public, max-age=60, s-maxage=600, stale-while-revalidate=1800' : 'no-store, max-age=0'));
    return response.status(result.status).send(text || '{}');
  } catch (error) {
    return sendJson(response, error?.name === 'AbortError' ? 504 : 502, {
      status:false,
      message:error?.name === 'AbortError' ? 'Sylvatica Spotyloader terlalu lama merespons.' : 'Sylvatica Spotyloader tidak dapat dihubungi.',
      error:String(error?.message || error || '')
    });
  } finally {
    clearTimeout(timer);
  }
}
