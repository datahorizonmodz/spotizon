import { getSpotifyCollection } from '../../lib/spotify-service.js';
import { SpotifyInputError, normalizeSpotifyId } from '../../lib/spotify-parser.js';
import { json, publicError } from '../../lib/http.js';

export async function onRequestGet({ request }) {
  const requestUrl = new URL(request.url);
  const directUrl = requestUrl.searchParams.get('url') || '';
  const id = String(requestUrl.searchParams.get('id') || '').trim();
  const type = String(requestUrl.searchParams.get('type') || 'playlist').trim().toLowerCase();
  try {
    // Browser importer sends only type + ID. The canonical Spotify URL is built server-side.
    const spotifyUrl = directUrl || (id ? normalizeSpotifyId(type, id).canonical : '');
    const payload = await getSpotifyCollection(spotifyUrl);
    return json(payload, 200, 'public, max-age=300, s-maxage=21600, stale-while-revalidate=86400');
  } catch (error) {
    if (error instanceof SpotifyInputError) return publicError('Tautan Spotify tidak valid.', 400);
    console.error('[DATZON spotify collection]', error);
    return publicError();
  }
}
