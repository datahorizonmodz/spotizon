import { getSpotifyTrackMeta } from '../../lib/spotify-service.js';
import { SpotifyInputError } from '../../lib/spotify-parser.js';
import { json, publicError } from '../../lib/http.js';

export async function onRequestGet({ request }) {
  const requestUrl = new URL(request.url);
  const id = String(requestUrl.searchParams.get('id') || '').trim();
  try {
    const payload = await getSpotifyTrackMeta(id);
    return json(payload, 200, 'public, max-age=900, s-maxage=86400, stale-while-revalidate=172800');
  } catch (error) {
    if (error instanceof SpotifyInputError) return publicError('Track Spotify tidak valid.', 400);
    console.error('[DATZON spotify track-meta]', error);
    return publicError();
  }
}
