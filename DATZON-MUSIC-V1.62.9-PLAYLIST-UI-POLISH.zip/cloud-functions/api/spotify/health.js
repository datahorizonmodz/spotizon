import { json } from '../../lib/http.js';
export function onRequestGet() {
  return json({ ok: true, runtime: 'edgeone', spotifyParser: true }, 200, 'no-store');
}
