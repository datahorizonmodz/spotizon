import { SPOTIFY_PLAYLIST_SEEDS } from '../../lib/spotify-seeds.js';
import { getSpotifyCollectionSummary } from '../../lib/spotify-service.js';
import { json, publicError } from '../../lib/http.js';

async function mapLimit(items, limit, mapper) {
  const results = new Array(items.length);
  let cursor = 0;
  const workers = Array.from({ length: Math.min(limit, items.length) }, async () => {
    while (true) {
      const index = cursor++;
      if (index >= items.length) return;
      try { results[index] = { status: 'fulfilled', value: await mapper(items[index], index) }; }
      catch (reason) { results[index] = { status: 'rejected', reason }; }
    }
  });
  await Promise.allSettled(workers);
  return results;
}

export async function onRequestGet() {
  try {
    const seeds = SPOTIFY_PLAYLIST_SEEDS.map(id => ({ type: 'playlist', id, url: `https://open.spotify.com/playlist/${id}` }));
    const settled = await mapLimit(seeds, 5, getSpotifyCollectionSummary);
    const items = settled
      .filter(item => item?.status === 'fulfilled' && item.value?.type === 'playlist' && item.value?.id && item.value?.cover)
      .map(item => item.value);
    if (!items.length) return publicError('Playlist Spotify sedang tidak tersedia.', 503);
    return json({ ok: true, items, totalSeeds: SPOTIFY_PLAYLIST_SEEDS.length, generatedAt: new Date().toISOString() }, 200, 'public, max-age=600, s-maxage=21600, stale-while-revalidate=86400');
  } catch (error) {
    console.error('[DATZON spotify home-playlists]', error);
    return publicError('Playlist Spotify sedang tidak tersedia.', 503);
  }
}
