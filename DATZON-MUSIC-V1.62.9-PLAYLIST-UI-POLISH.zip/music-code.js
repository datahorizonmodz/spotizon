(() => {
  'use strict';

  const CODE_VERSION = 'D1';
  const DISPLAY_PREFIX = 'MX-';
  const SCAN_INTERVAL = 220;
  const MAX_IMAGE_EDGE = 3200;
  const CODE128 = [
    '212222','222122','222221','121223','121322','131222','122213','122312','132212','221213','221312','231212','112232','122132','122231','113222','123122','123221','223211','221132','221231','213212','223112','312131','311222','321122','321221','312212','322112','322211','212123','212321','232121','111323','131123','131321','112313','132113','132311','211313','231113','231311','112133','112331','132131','113123','113321','133121','313121','211331','231131','213113','213311','213131','311123','311321','331121','312113','312311','332111','314111','221411','431111','111224','111422','121124','121421','141122','141221','112214','112412','122114','122411','142112','142211','241211','221114','413111','241112','134111','111242','121142','121241','114212','124112','124211','411212','421112','421211','212141','214121','412121','111143','111341','131141','114113','114311','411113','411311','113141','114131','311141','411131','211412','211214','211232','2331112'
  ];
  const START_B = 104;
  const STOP = 106;
  let active = null;

  const svg = (id) => `<svg class="icon" aria-hidden="true"><use href="#i-${id}"></use></svg>`;
  const esc = (value='') => String(value ?? '').replace(/[&<>'"]/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[ch]));
  const safeText = value => String(value || '').trim();

  function spotifyIdFrom(value='') {
    const raw = safeText(value);
    if (/^[A-Za-z0-9]{22}$/.test(raw)) return raw;
    const uri = raw.match(/^spotify:track:([A-Za-z0-9]{22})$/i);
    if (uri) return uri[1];
    const url = raw.match(/open\.spotify\.com\/track\/([A-Za-z0-9]{22})/i);
    return url ? url[1] : '';
  }

  function youtubeIdFrom(value='') {
    const raw = safeText(value);
    if (!raw) return '';
    try {
      const url = new URL(raw, location.origin);
      if (/youtu\.be$/i.test(url.hostname)) return url.pathname.split('/').filter(Boolean)[0] || '';
      if (/youtube\.com$/i.test(url.hostname) || /music\.youtube\.com$/i.test(url.hostname)) return url.searchParams.get('v') || '';
    } catch {}
    return '';
  }

  function trackSpotifyId(track={}) {
    const candidates = [
      track.spotifyTrackId, track.spotifyId, track.spotifyMetadata?.id, track.external_ids?.spotify,
      track.url, track.spotifyUrl, track.external_url, track.external_urls?.spotify, track.uri, track.id
    ];
    for (const candidate of candidates) {
      const id = spotifyIdFrom(candidate);
      if (id) return id;
    }
    return '';
  }

  function trackYoutubeId(track={}) {
    const candidates = [track.youtubeId, track.videoId, track.url, track.webpage_url, track.externalUrl, track.audioUrl];
    for (const candidate of candidates) {
      const id = youtubeIdFrom(candidate);
      if (id) return id;
    }
    const id = safeText(track.id);
    if (/^[A-Za-z0-9_-]{11}$/.test(id) && /youtube|ytmusic|nanz/i.test(safeText(track.source))) return id;
    return '';
  }

  function compactSource(value='') {
    return safeText(value).toLowerCase().replace(/[^a-z0-9]+/g,'').slice(0,10) || 'datzon';
  }

  function canonicalTrackKey(track={}) {
    const sid = trackSpotifyId(track);
    if (sid) return `spotify:${sid}`;
    const yid = trackYoutubeId(track);
    if (yid) return `youtube:${yid}`;
    const id = safeText(track.providerId || track.canonicalId || track.id);
    if (id && id.length <= 64 && /^[A-Za-z0-9._:-]+$/.test(id)) return `provider:${compactSource(track.source)}:${id}`;
    const title = safeText(track.title || track.name).slice(0,80);
    const artist = safeText(track.artist || track.artistName || (Array.isArray(track.artistNames) ? track.artistNames.join(', ') : '')).slice(0,80);
    const duration = safeText(track.duration || track.durationText || track.durationMs || '').slice(0,12);
    const meta = `${title}\t${artist}\t${duration}`;
    return `meta:${base64UrlEncode(meta)}`;
  }

  function base64UrlEncode(text='') {
    const bytes = new TextEncoder().encode(String(text));
    let binary = '';
    bytes.forEach(byte => { binary += String.fromCharCode(byte); });
    return btoa(binary).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
  }

  function base64UrlDecode(text='') {
    const normalized = String(text).replace(/-/g,'+').replace(/_/g,'/');
    const padded = normalized + '='.repeat((4 - normalized.length % 4) % 4);
    const binary = atob(padded);
    const bytes = Uint8Array.from(binary, ch => ch.charCodeAt(0));
    return new TextDecoder().decode(bytes);
  }

  function machinePayload(canonical='') {
    if (/^spotify:[A-Za-z0-9]{22}$/.test(canonical)) return `${CODE_VERSION}S${canonical.slice(8)}`;
    if (/^youtube:[A-Za-z0-9_-]{6,20}$/.test(canonical)) return `${CODE_VERSION}Y${canonical.slice(8)}`;
    return `${CODE_VERSION}C${base64UrlEncode(canonical)}`;
  }

  function parseMachinePayload(payload='') {
    const raw = safeText(payload);
    if (!raw.startsWith(CODE_VERSION) || raw.length < 6 || raw.length > 180) return '';
    if (raw.startsWith(`${CODE_VERSION}S`) && /^[A-Za-z0-9]{22}$/.test(raw.slice(3))) return `spotify:${raw.slice(3)}`;
    if (raw.startsWith(`${CODE_VERSION}Y`) && /^[A-Za-z0-9_-]{6,20}$/.test(raw.slice(3))) return `youtube:${raw.slice(3)}`;
    if (raw.startsWith(`${CODE_VERSION}C`)) {
      try {
        const decoded = base64UrlDecode(raw.slice(3));
        if (/^(spotify:[A-Za-z0-9]{22}|youtube:[A-Za-z0-9_-]{6,20}|provider:[a-z0-9]{1,10}:[A-Za-z0-9._:-]{1,64}|meta:[A-Za-z0-9_-]{4,180})$/.test(decoded)) return decoded;
      } catch {}
    }
    return '';
  }

  function canonicalFromTrackUrl(value='') {
    const raw=safeText(value);
    if(!raw)return '';
    try {
      const url=new URL(raw, location.origin);
      const match=url.pathname.match(/^\/track\/([A-Za-z0-9]{22})(?:\/|$)/);
      if(match)return `spotify:${match[1]}`;
    } catch {}
    return '';
  }

  function scannedCanonical(value='') {
    return parseMachinePayload(value) || canonicalFromTrackUrl(value);
  }

  async function displayCode(canonical='') {
    let bytes;
    try {
      bytes = new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(canonical)));
    } catch {
      let h1 = 0x811c9dc5, h2 = 0x9e3779b9;
      for (let i=0;i<canonical.length;i++) { h1 = Math.imul(h1 ^ canonical.charCodeAt(i), 16777619); h2 = Math.imul(h2 ^ canonical.charCodeAt(i), 2246822519); }
      bytes = new Uint8Array(8);
      new DataView(bytes.buffer).setUint32(0,h1>>>0); new DataView(bytes.buffer).setUint32(4,h2>>>0);
    }
    const alphabet='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let bits=0, count=0, out='';
    for (const byte of bytes) {
      bits=(bits<<8)|byte; count+=8;
      while(count>=5 && out.length<16){ count-=5; out+=alphabet[(bits>>count)&31]; }
      if(out.length>=16)break;
    }
    return `${DISPLAY_PREFIX}${out.padEnd(16,'X')}`;
  }

  function encodeCode128B(text='') {
    const values = [START_B];
    for (const ch of String(text)) {
      const code = ch.charCodeAt(0);
      if (code < 32 || code > 126) throw new Error('Payload Music Code tidak didukung.');
      values.push(code - 32);
    }
    let checksum = START_B;
    for (let i=1;i<values.length;i++) checksum += values[i] * i;
    values.push(checksum % 103, STOP);
    return values;
  }

  function barcodeModules(payload='') {
    return encodeCode128B(payload).map(value => CODE128[value]).join('');
  }


  function roundedRect(ctx, x, y, w, h, radius) {
    const r = Math.max(0, Math.min(radius, w / 2, h / 2));
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }

  function visualMusicBars(seedText='', count=23) {
    const seed = [...String(seedText || '')].reduce((sum,ch,index)=>(Math.imul(sum ^ ch.charCodeAt(0), 16777619) + index * 97) >>> 0, 2166136261);
    let x = seed || 0x9e3779b9;
    const next = () => {
      x ^= x << 13; x ^= x >>> 17; x ^= x << 5;
      return (x >>> 0) / 4294967295;
    };
    const bars = [];
    for (let i=0;i<count;i++) {
      const centerBias = 1 - Math.min(1, Math.abs(i - (count - 1) / 2) / ((count - 1) / 2));
      const height = 78 + Math.round((next() * .66 + centerBias * .34) * 150);
      const width = 13 + Math.round(next() * 8);
      bars.push({height, width});
    }
    bars[0] = {height:86,width:18};
    bars[bars.length-1] = {height:86,width:18};
    return bars;
  }

  function drawMachineLane(ctx, payload, x, y, width, height) {
    const patterns = encodeCode128B(payload).map(value => CODE128[value]);
    const quiet = 12;
    const totalModules = quiet * 2 + patterns.reduce((sum, pattern) => sum + [...pattern].reduce((a,b)=>a+Number(b),0),0);
    const scale = width / totalModules;
    let cursor = x + quiet * scale;
    ctx.fillStyle = '#0a0a0a';
    for (const pattern of patterns) {
      let black = true;
      for (const digit of pattern) {
        const barWidth = Number(digit) * scale;
        if (black) ctx.fillRect(Math.round(cursor), y, Math.max(1, Math.ceil(barWidth)), height);
        cursor += barWidth;
        black = !black;
      }
    }
  }

  const QR_EXP = new Uint8Array(512);
  const QR_LOG = new Int16Array(256);
  (()=>{
    let value=1;
    for(let i=0;i<255;i++){
      QR_EXP[i]=value; QR_LOG[value]=i;
      value<<=1; if(value&0x100)value^=0x11d;
    }
    for(let i=255;i<512;i++)QR_EXP[i]=QR_EXP[i-255];
  })();

  function qrMul(a,b){ if(!a||!b)return 0; return QR_EXP[QR_LOG[a]+QR_LOG[b]]; }
  function qrGenerator(degree){
    let poly=[1];
    for(let i=0;i<degree;i++){
      const next=new Array(poly.length+1).fill(0);
      for(let j=0;j<poly.length;j++){
        next[j]^=poly[j];
        next[j+1]^=qrMul(poly[j],QR_EXP[i]);
      }
      poly=next;
    }
    return poly;
  }
  function qrRemainder(data, degree){
    const gen=qrGenerator(degree);
    const result=new Array(degree).fill(0);
    for(const byte of data){
      const factor=byte^result[0];
      result.shift(); result.push(0);
      if(!factor)continue;
      for(let i=0;i<degree;i++)result[i]^=qrMul(gen[i+1],factor);
    }
    return result;
  }
  function qrAppendBits(target,value,length){ for(let i=length-1;i>=0;i--)target.push((value>>>i)&1); }
  function qrBytes(text=''){ return [...new TextEncoder().encode(String(text))]; }
  function qrConfigForLength(byteLength){
    if(byteLength<=84)return {version:5,moduleCount:37,dataCodewords:86,blocks:2,dataPerBlock:43,eccPerBlock:24,align:[6,30]};
    if(byteLength<=106)return {version:6,moduleCount:41,dataCodewords:108,blocks:4,dataPerBlock:27,eccPerBlock:16,align:[6,34]};
    throw new Error('URL track terlalu panjang untuk QR Music Code.');
  }
  function qrCodewords(text=''){
    const bytes=qrBytes(text);
    const cfg=qrConfigForLength(bytes.length);
    const bits=[];
    qrAppendBits(bits,0b0100,4); // byte mode
    qrAppendBits(bits,bytes.length,8);
    bytes.forEach(byte=>qrAppendBits(bits,byte,8));
    const capacity=cfg.dataCodewords*8;
    for(let i=0;i<Math.min(4,capacity-bits.length);i++)bits.push(0);
    while(bits.length%8)bits.push(0);
    const data=[];
    for(let i=0;i<bits.length;i+=8){let value=0;for(let j=0;j<8;j++)value=(value<<1)|(bits[i+j]||0);data.push(value);}
    for(let toggle=0;data.length<cfg.dataCodewords;toggle++)data.push(toggle%2?0x11:0xec);
    const blocks=[];
    for(let i=0;i<cfg.blocks;i++){
      const chunk=data.slice(i*cfg.dataPerBlock,(i+1)*cfg.dataPerBlock);
      blocks.push({data:chunk,ecc:qrRemainder(chunk,cfg.eccPerBlock)});
    }
    const out=[];
    for(let i=0;i<cfg.dataPerBlock;i++)blocks.forEach(block=>out.push(block.data[i]));
    for(let i=0;i<cfg.eccPerBlock;i++)blocks.forEach(block=>out.push(block.ecc[i]));
    return {cfg,codewords:out};
  }
  function qrBchDigit(value){let digit=0;while(value){digit++;value>>>=1;}return digit;}
  function qrTypeInfo(data){
    const G15=0x537,G15_MASK=0x5412;
    let d=data<<10;
    while(qrBchDigit(d)-qrBchDigit(G15)>=0)d^=G15<<(qrBchDigit(d)-qrBchDigit(G15));
    return ((data<<10)|d)^G15_MASK;
  }
  function qrMask(mask,row,col){
    switch(mask){
      case 0:return (row+col)%2===0;
      case 1:return row%2===0;
      case 2:return col%3===0;
      case 3:return (row+col)%3===0;
      case 4:return (Math.floor(row/2)+Math.floor(col/3))%2===0;
      case 5:return (row*col)%2+(row*col)%3===0;
      case 6:return ((row*col)%2+(row*col)%3)%2===0;
      case 7:return ((row*col)%3+(row+col)%2)%2===0;
      default:return false;
    }
  }
  function qrFinder(modules,row,col){
    const count=modules.length;
    for(let r=-1;r<=7;r++)for(let c=-1;c<=7;c++){
      const y=row+r,x=col+c;if(y<0||y>=count||x<0||x>=count)continue;
      modules[y][x]=(r>=0&&r<=6&&(c===0||c===6)||c>=0&&c<=6&&(r===0||r===6)||r>=2&&r<=4&&c>=2&&c<=4);
    }
  }
  function qrAlignment(modules,positions){
    for(const row of positions)for(const col of positions){
      if(modules[row][col]!==null)continue;
      for(let r=-2;r<=2;r++)for(let c=-2;c<=2;c++)modules[row+r][col+c]=(Math.abs(r)===2||Math.abs(c)===2||(r===0&&c===0));
    }
  }
  function qrType(modules,mask){
    const count=modules.length,bits=qrTypeInfo(mask); // M level = 00
    for(let i=0;i<15;i++){
      const dark=((bits>>>i)&1)===1;
      if(i<6)modules[i][8]=dark;else if(i<8)modules[i+1][8]=dark;else modules[count-15+i][8]=dark;
      if(i<8)modules[8][count-i-1]=dark;else if(i<9)modules[8][7]=dark;else modules[8][15-i-1]=dark;
    }
    modules[count-8][8]=true;
  }
  function qrBuild(codewords,cfg,mask){
    const count=cfg.moduleCount,modules=Array.from({length:count},()=>Array(count).fill(null));
    qrFinder(modules,0,0);qrFinder(modules,count-7,0);qrFinder(modules,0,count-7);
    qrAlignment(modules,cfg.align);
    for(let i=8;i<count-8;i++)if(modules[i][6]===null)modules[i][6]=i%2===0;
    for(let i=8;i<count-8;i++)if(modules[6][i]===null)modules[6][i]=i%2===0;
    qrType(modules,mask);
    let row=count-1,inc=-1,byteIndex=0,bitIndex=7;
    for(let col=count-1;col>0;col-=2){
      if(col===6)col--;
      while(true){
        for(let c=0;c<2;c++)if(modules[row][col-c]===null){
          let dark=false;
          if(byteIndex<codewords.length)dark=((codewords[byteIndex]>>>bitIndex)&1)===1;
          if(qrMask(mask,row,col-c))dark=!dark;
          modules[row][col-c]=dark;
          bitIndex--;if(bitIndex<0){byteIndex++;bitIndex=7;}
        }
        row+=inc;
        if(row<0||row>=count){row-=inc;inc=-inc;break;}
      }
    }
    return modules;
  }
  function qrLostPoint(m){
    const n=m.length;let lost=0;
    for(let r=0;r<n;r++)for(let c=0;c<n;c++){
      let same=0;const dark=m[r][c];
      for(let dr=-1;dr<=1;dr++)for(let dc=-1;dc<=1;dc++){if(!dr&&!dc)continue;const y=r+dr,x=c+dc;if(y<0||y>=n||x<0||x>=n)continue;if(m[y][x]===dark)same++;}
      if(same>5)lost+=3+same-5;
    }
    for(let r=0;r<n-1;r++)for(let c=0;c<n-1;c++){const count=[m[r][c],m[r+1][c],m[r][c+1],m[r+1][c+1]].filter(Boolean).length;if(count===0||count===4)lost+=3;}
    for(let r=0;r<n;r++)for(let c=0;c<n-6;c++)if(m[r][c]&&!m[r][c+1]&&m[r][c+2]&&m[r][c+3]&&m[r][c+4]&&!m[r][c+5]&&m[r][c+6])lost+=40;
    for(let c=0;c<n;c++)for(let r=0;r<n-6;r++)if(m[r][c]&&!m[r+1][c]&&m[r+2][c]&&m[r+3][c]&&m[r+4][c]&&!m[r+5][c]&&m[r+6][c])lost+=40;
    let darkCount=0;m.forEach(row=>row.forEach(value=>{if(value)darkCount++;}));
    lost+=Math.floor(Math.abs(100*darkCount/(n*n)-50)/5)*10;
    return lost;
  }
  function qrMatrix(text=''){
    const {cfg,codewords}=qrCodewords(text);
    let best=null,bestLoss=Infinity;
    for(let mask=0;mask<8;mask++){const matrix=qrBuild(codewords,cfg,mask),loss=qrLostPoint(matrix);if(loss<bestLoss){bestLoss=loss;best=matrix;}}
    return best;
  }
  function drawQr(ctx,text,x,y,size){
    const matrix=qrMatrix(text),quiet=4,n=matrix.length,total=n+quiet*2,module=size/total;
    ctx.save();ctx.fillStyle='#f5f6f3';roundedRect(ctx,x,y,size,size,22);ctx.fill();
    ctx.fillStyle='#050505';
    for(let r=0;r<n;r++)for(let c=0;c<n;c++)if(matrix[r][c]){
      const px=x+(c+quiet)*module,py=y+(r+quiet)*module;
      const radius=Math.max(.35,module*.12);
      roundedRect(ctx,px,py,module+.18,module+.18,radius);ctx.fill();
    }
    ctx.restore();
  }

  async function loadCanvasImage(url=''){
    return new Promise(resolve=>{
      if(!url){resolve(null);return;}
      const img=new Image();img.crossOrigin='anonymous';img.decoding='async';
      img.onload=()=>resolve(img);img.onerror=()=>resolve(null);img.src=url;
    });
  }
  function coverCrop(ctx,img,x,y,w,h){
    if(!img)return false;
    const sw=img.naturalWidth||img.width,sh=img.naturalHeight||img.height;if(!sw||!sh)return false;
    const scale=Math.max(w/sw,h/sh),dw=sw*scale,dh=sh*scale;
    ctx.drawImage(img,x+(w-dw)/2,y+(h-dh)/2,dw,dh);return true;
  }
  function musicCodeTrackUrl(track={}){
    const spotify=trackSpotifyId(track);
    const fallback=safeText(track.id||track.providerId||track.canonicalId).replace(/[^A-Za-z0-9._-]/g,'').slice(0,100);
    const id=spotify||fallback;
    return id?new URL(`/track/${encodeURIComponent(id)}`,location.origin).href:location.href;
  }
  function drawMusicWaveAndMachine(ctx,payload,seedText,x,y,width,height,panelColor='#7898c6'){
    // V1.62.4: hapus tepat satu visual bar lagi dari sisi kiri dan kanan.
    // Hasil akhirnya 16 rounded bars tanpa terminal/edge bar buatan, sehingga
    // waveform benar-benar simetris dan tidak tampak ada satu garis nyasar di
    // kedua ujung poster Music Code.
    const bars=visualMusicBars(seedText||payload,22).slice(3,-3),centerY=y+height/2,gap=18;
    const raw=bars.reduce((sum,b)=>sum+b.width,0)+gap*(bars.length-1),fit=width/raw;
    let cursor=x+(width-raw*fit)/2;
    ctx.fillStyle='#080808';
    for(const bar of bars){
      const w=bar.width*fit;
      const h=Math.min(height*.98,bar.height*1.12);
      roundedRect(ctx,cursor,centerY-h/2,w,h,Math.min(w/2,9));
      ctx.fill();
      cursor+=w+gap*fit;
    }
    const laneH=Math.max(34,Math.round(height*.18));
    ctx.fillStyle=panelColor;ctx.fillRect(x-2,centerY-laneH/2-5,width+4,laneH+10);
    drawMachineLane(ctx,payload,x,centerY-laneH/2,width,laneH);
  }

  function musicCodePanelColor(img){
    const fallback=[120,152,198];
    if(!img)return fallback;
    try{
      const sample=document.createElement('canvas');sample.width=36;sample.height=36;
      const sg=sample.getContext('2d',{willReadFrequently:true});sg.drawImage(img,0,0,36,36);
      const data=sg.getImageData(0,0,36,36).data;
      let r=0,g=0,b=0,w=0;
      for(let i=0;i<data.length;i+=4){
        if(data[i+3]<180)continue;
        const rr=data[i],gg=data[i+1],bb=data[i+2];
        const max=Math.max(rr,gg,bb),min=Math.min(rr,gg,bb),sat=max-min,lum=(rr+gg+bb)/3;
        if(lum<10||lum>247)continue;
        const weight=1+sat/90;
        r+=rr*weight;g+=gg*weight;b+=bb*weight;w+=weight;
      }
      if(!w)return fallback;
      let rgb=[Math.round(r/w),Math.round(g/w),Math.round(b/w)];
      const avg=(rgb[0]+rgb[1]+rgb[2])/3;
      rgb=rgb.map(v=>Math.round(v*.82+avg*.18));
      // Keep the footer readable with black QR/wave bars even for very dark covers.
      const luminance=.2126*rgb[0]+.7152*rgb[1]+.0722*rgb[2];
      if(luminance<108){const lift=(108-luminance)/147;rgb=rgb.map(v=>Math.round(v+(255-v)*Math.min(.46,lift)));}
      if(luminance>218)rgb=rgb.map(v=>Math.round(v*.9));
      return rgb.map(v=>Math.max(32,Math.min(232,v)));
    }catch{return fallback;}
  }
  const rgbCss=rgb=>`rgb(${rgb[0]},${rgb[1]},${rgb[2]})`;

  async function renderMusicCard(canvas,{payload,canonical,trackUrl,cover,title,artist}){
    canvas.width=1200;canvas.height=1520;
    const g=canvas.getContext('2d');g.imageSmoothingEnabled=true;g.imageSmoothingQuality='high';
    g.fillStyle='#0b0b0b';g.fillRect(0,0,1200,1520);
    const image=await loadCanvasImage(cover);
    const panelColor=musicCodePanelColor(image);
    const panelCss=rgbCss(panelColor);
    if(!coverCrop(g,image,0,0,1200,1160)){
      const grad=g.createLinearGradient(0,0,1200,1160);grad.addColorStop(0,'#536f99');grad.addColorStop(1,'#1d2b42');g.fillStyle=grad;g.fillRect(0,0,1200,1160);
    }
    const overlay=g.createLinearGradient(0,770,0,1160);overlay.addColorStop(0,'rgba(0,0,0,0)');overlay.addColorStop(1,'rgba(0,0,0,.68)');g.fillStyle=overlay;g.fillRect(0,700,1200,460);
    g.fillStyle='#fff';g.textAlign='left';g.textBaseline='alphabetic';
    g.font='800 82px "Share Tech Mono", monospace';
    const safeTitle=String(title||'Lagu');const titleLines=[];let current='';
    for(const word of safeTitle.split(/\s+/)){const test=current?`${current} ${word}`:word;if(g.measureText(test).width>1030&&current){titleLines.push(current);current=word;}else current=test;if(titleLines.length>=1)break;}
    if(current&&titleLines.length<2)titleLines.push(current);
    const titleBaseY=995,titleStep=78;
    titleLines.slice(0,2).forEach((line,index)=>g.fillText(line,48,titleBaseY+index*titleStep));
    const artistY=titleBaseY+Math.max(0,titleLines.length-1)*titleStep+62;
    g.font='700 52px "Share Tech Mono", monospace';g.fillStyle='rgba(255,255,255,.92)';g.fillText(String(artist||'Artis tidak diketahui').slice(0,44),48,artistY);
    g.fillStyle=panelCss;g.fillRect(0,1160,1200,360);
    drawQr(g,trackUrl,30,1190,300);
    drawMusicWaveAndMachine(g,payload,canonical,372,1198,780,275,panelCss);
    g.fillStyle='rgba(0,0,0,.66)';g.font='700 22px "Share Tech Mono", monospace';g.textAlign='right';g.fillText('DATZON MUSIC CODE',1152,1492);
  }



  function rootOverlay(className, html, options={}) {
    closeActive();
    const initialSnap = options.initialSnap || 'content';
    const sheetApi = window.DatzonPlayerSheet;
    if (sheetApi?.open) {
      const root = sheetApi.open(html, `music-code-player-sheet ${className || ''}`, {kind:'queue', initialSnap});
      active = { root, stream:null, timer:null, processing:false, closed:false, usesSheet:true, observer:null };
      const modal = document.getElementById('modalRoot');
      if (modal) {
        active.observer = new MutationObserver(() => {
          if (!root.isConnected && active?.root === root) {
            const current = active;
            if (current.timer) clearTimeout(current.timer);
            try { current.stream?.getTracks?.().forEach(track => track.stop()); } catch {}
            current.stream = null;
            current.observer?.disconnect?.();
            document.removeEventListener('keydown', escapeHandler);
            active = null;
          }
        });
        active.observer.observe(modal, {childList:true,subtree:true});
      }
      document.addEventListener('keydown', escapeHandler);
      return root;
    }
    const root = document.createElement('div');
    root.className = `music-code-overlay ${className || ''}`;
    root.innerHTML = html;
    document.body.appendChild(root);
    active = { root, stream:null, timer:null, processing:false, closed:false, usesSheet:false, observer:null };
    requestAnimationFrame(()=>root.classList.add('is-open'));
    root.addEventListener('click', event => { if (event.target === root) closeActive(); });
    document.addEventListener('keydown', escapeHandler);
    return root;
  }

  function escapeHandler(event){ if(event.key==='Escape') closeActive(); }

  function stopStream() {
    if (!active?.stream) return;
    try { active.stream.getTracks().forEach(track => track.stop()); } catch {}
    active.stream = null;
  }


  function closeActive() {
    const current = active;
    if (!current) return;
    current.closed = true;
    if (current.timer) clearTimeout(current.timer);
    try { current.stream?.getTracks?.().forEach(track => track.stop()); } catch {}
    current.stream = null;
    current.observer?.disconnect?.();
    document.removeEventListener('keydown', escapeHandler);
    active = null;
    if (current.usesSheet && window.DatzonPlayerSheet?.close) {
      window.DatzonPlayerSheet.close();
      return;
    }
    current.root?.classList.remove('is-open');
    current.root?.classList.add('is-closing');
    setTimeout(()=>current.root?.remove(),220);
  }


  function status(root, text, tone='') {
    const el=root?.querySelector('[data-music-code-status]');
    if(!el)return;
    el.textContent=text||''; el.dataset.tone=tone; el.hidden=!text;
  }


  function downloadCanvas(canvas, filename='DATZON-MUSIC-CODE.png') {
    if (!canvas) return;
    const saveBlob = blob => {
      if (!blob) return;
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename.replace(/[^\w.-]+/g,'-').slice(0,120);
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(()=>URL.revokeObjectURL(url),1500);
    };
    if (canvas.toBlob) canvas.toBlob(saveBlob,'image/png',1);
    else {
      try {
        const data = canvas.toDataURL('image/png');
        const a = document.createElement('a'); a.href=data; a.download=filename; a.click();
      } catch {}
    }
  }


  async function show(track, handlers={}) {
    let resolvedTrack = track || {};
    try {
      if (typeof handlers.resolveIdentity === 'function') resolvedTrack = await handlers.resolveIdentity(track) || track;
    } catch {}
    const canonical = canonicalTrackKey(resolvedTrack);
    const code = await displayCode(canonical);
    const payload = machinePayload(canonical);
    const cover = resolvedTrack.thumbnail || resolvedTrack.cover || 'assets/placeholder.svg';
    const title = resolvedTrack.title || resolvedTrack.name || 'Lagu';
    const artist = resolvedTrack.artist || resolvedTrack.artistName || (Array.isArray(resolvedTrack.artistNames)?resolvedTrack.artistNames.join(', '):'');
    const trackUrl=musicCodeTrackUrl(resolvedTrack);
    const spotifyTrackId=trackSpotifyId(resolvedTrack);
    try {
      window.DatzonFirebase?.saveMusicCodeTrack?.({
        musicCode:code, canonicalTrackKey:canonical, title, artist, trackUrl, spotifyTrackId,
        providerTrackId:safeText(resolvedTrack.providerId || resolvedTrack.id), source:safeText(resolvedTrack.source),
        cover, album:safeText(resolvedTrack.album), duration:safeText(resolvedTrack.duration)
      }).catch?.(()=>{});
    } catch {}
    const root = rootOverlay('music-code-display-sheet', `<div class="music-code-sheet-content music-code-display-content">
      <header class="music-code-sheet-head"><div><small>DATZON MUSIC</small><h2>Kode Lagu</h2></div><button data-music-code-close aria-label="Tutup">${svg('close')}</button></header>
      <div class="music-code-poster"><canvas data-music-code-canvas aria-label="Kode Lagu ${esc(code)}"></canvas></div>
      <p data-music-code-status hidden></p>
      <strong class="music-code-label">${esc(code)}</strong><small class="music-code-brand">Scan di DATZON atau gunakan QR untuk membuka lagu</small>
      <div class="music-code-actions"><button data-music-code-download>${svg('download')}<span>Download Kode</span></button></div>
    </div>`, {initialSnap:'content'});
    root.querySelector('[data-music-code-close]').onclick=closeActive;
    const canvas=root.querySelector('[data-music-code-canvas]');
    status(root,'Menyiapkan Kode Lagu...');
    try{await renderMusicCard(canvas,{payload,canonical,trackUrl,cover,title,artist});status(root,'');}
    catch(error){status(root,'Kode visual gagal dimuat sempurna. Coba buka ulang.','error');console.warn('[DATZON Music Code render]',error);}
    root.querySelector('[data-music-code-download]').onclick=()=>downloadCanvas(canvas,`DATZON-MUSIC-CODE-${code}.png`);
    return {canonical,code,payload,trackUrl};
  }


  async function nativeDetector() {
    if (!('BarcodeDetector' in window)) return null;
    try {
      let wanted=['code_128','qr_code'];
      if (typeof BarcodeDetector.getSupportedFormats === 'function') {
        const formats = await BarcodeDetector.getSupportedFormats();
        wanted=wanted.filter(format=>formats.includes(format));
        if (!wanted.length) return null;
      }
      return new BarcodeDetector({formats:wanted});
    } catch { return null; }
  }

  function patternError(runs, pattern) {
    if (runs.length !== pattern.length) return Infinity;
    const units=[...pattern].map(Number); const expected=units.reduce((a,b)=>a+b,0); const total=runs.reduce((a,b)=>a+b,0);
    if(!total)return Infinity; const module=total/expected;
    return runs.reduce((sum,value,index)=>sum+Math.abs(value/module-units[index]),0)/expected;
  }

  function nearestSymbol(runs, maxError=.38) {
    let best=-1,bestError=Infinity;
    for(let value=0;value<106;value++){
      const error=patternError(runs,CODE128[value]);
      if(error<bestError){bestError=error;best=value;}
    }
    return bestError<=maxError?{value:best,error:bestError}:null;
  }

  function decodeRuns(runs, colors) {
    const decodeCandidate = values => {
      if (values.at(-1) !== STOP || values.length < 5) return '';
      const checksumValue = values[values.length - 2];
      let checksum = START_B;
      for (let i = 1; i < values.length - 2; i++) checksum += values[i] * i;
      if (checksum % 103 !== checksumValue) return '';
      let text = '';
      for (const value of values.slice(1, -2)) {
        if (value < 0 || value > 94) return '';
        text += String.fromCharCode(value + 32);
      }
      return text;
    };
    for (let start=0; start<runs.length-18; start++) {
      if (colors[start] !== 1) continue;
      if (patternError(runs.slice(start,start+6), CODE128[START_B]) > .34) continue;
      let pos=start+6; const values=[START_B]; let guard=0;
      while (pos < runs.length-5 && guard++ < 220) {
        if (pos + 7 <= runs.length && patternError(runs.slice(pos,pos+7), CODE128[STOP]) < .32) {
          const text = decodeCandidate([...values, STOP]);
          if (text) return text;
          // A 7-run window can coincidentally resemble STOP across two normal
          // symbols. If checksum is invalid, keep decoding the 6-run symbol.
        }
        if (pos + 6 > runs.length) break;
        const symbol=nearestSymbol(runs.slice(pos,pos+6));
        if(!symbol)break;
        values.push(symbol.value); pos+=6;
      }
    }
    return '';
  }


  function scanLine(imageData,y) {
    const {width,data}=imageData; let min=255,max=0;
    const lum=new Uint8Array(width);
    for(let x=0;x<width;x++){
      const i=(y*width+x)*4;
      const v=Math.round(data[i]*.299+data[i+1]*.587+data[i+2]*.114);
      lum[x]=v; if(v<min)min=v;if(v>max)max=v;
    }
    if(max-min<48)return '';
    const decodeBinary = binary => {
      if (!binary?.length) return '';
      const runs=[],colors=[]; let current=binary[0],count=1;
      for(let i=1;i<binary.length;i++){
        if(binary[i]===current)count++;
        else {runs.push(count);colors.push(current);current=binary[i];count=1;}
      }
      runs.push(count);colors.push(current);
      return decodeRuns(runs,colors);
    };
    for (const ratio of [.34,.40,.47,.54,.61,.68]) {
      const threshold=min+(max-min)*ratio;
      const raw=Array.from(lum,v=>v<threshold?1:0);
      // First decode untouched pixels. On phone screenshots a Code128 module can
      // be only ~2 px wide; a median filter can erase those narrow modules.
      let decoded=decodeBinary(raw);
      if(decoded)return decoded;
      const smoothed=raw.map((v,i)=>{
        let sum=0,count=0;
        for(let d=-1;d<=1;d++){
          const j=i+d;
          if(j>=0&&j<raw.length){sum+=raw[j];count++;}
        }
        return sum>=Math.ceil(count/2)?1:0;
      });
      decoded=decodeBinary(smoothed);
      if(decoded)return decoded;
    }
    return '';
  }

  function fallbackDecodeCanvas(canvas, dense=false) {
    const ctx=canvas.getContext('2d',{willReadFrequently:true});
    const imageData=ctx.getImageData(0,0,canvas.width,canvas.height);
    const positions=[];
    // Screenshot scanning used to miss the code simply because the machine lane
    // occupied only a handful of rows. Scan in pixel steps instead of coarse
    // percentages so codes near the bottom of a full-phone screenshot are found.
    const step = dense
      ? Math.max(2, Math.round(canvas.height / 520))
      : Math.max(4, Math.round(canvas.height / 180));
    const center = Math.round(canvas.height*.5);
    for(let offset=0;offset<canvas.height;offset+=step){
      const a=center-offset, b=center+offset;
      if(a>=0)positions.push(a);
      if(b<canvas.height&&b!==a)positions.push(b);
    }
    for(const y of positions){
      const value=scanLine(imageData,y);
      if(value)return value;
    }
    return '';
  }

  async function detectFromSource(source, fallbackCanvas=null) {
    const detector=await nativeDetector();
    if(detector){
      try{const results=await detector.detect(source);const found=results.find(item=>scannedCanonical(item.rawValue));if(found)return found.rawValue;}catch{}
    }
    if(fallbackCanvas)return fallbackDecodeCanvas(fallbackCanvas,true);
    return '';
  }

  async function resolvePayload(raw, handlers, root) {
    const canonical=scannedCanonical(raw);
    if(!canonical){status(root,'Kode Lagu tidak dikenali atau formatnya tidak valid.','error');return false;}
    if(active?.processing)return false;
    active.processing=true; stopStream();
    status(root,'Kode ditemukan. Membuka lagu...','success');
    try{
      const track=await handlers.resolveCanonical?.(canonical);
      if(!track)throw new Error('Kode Lagu tidak dikenali atau sudah tidak tersedia.');
      closeActive();
      await handlers.openTrack?.(track);
      return true;
    }catch(error){
      if(active)active.processing=false;
      status(root,error?.message||'Kode Lagu tidak dikenali atau sudah tidak tersedia.','error');
      return false;
    }
  }


  function scannerChoiceMarkup(){return `<div class="music-code-sheet-content music-code-choice" role="dialog" aria-modal="true" aria-label="Scan Kode Lagu">
    <header class="music-code-sheet-head"><div><small>DATZON MUSIC</small><h2>Scan Kode Lagu</h2></div><button data-music-code-close aria-label="Tutup">${svg('close')}</button></header>
    <button class="music-code-choice-row" data-scan-camera aria-label="Scan menggunakan kamera"><span>${svg('camera')}</span><div><strong>Scan dengan Kamera</strong><small>Gunakan kamera belakang HP</small></div>${svg('chevron')}</button>
    <button class="music-code-choice-row" data-scan-image aria-label="Pilih gambar Kode Lagu"><span>${svg('album')}</span><div><strong>Pilih Gambar</strong><small>Baca screenshot atau gambar kode dari galeri</small></div>${svg('chevron')}</button>
    <input type="file" accept="image/*" data-music-code-file hidden>
  </div>`;}


  function openScanner(handlers={}) {
    const root=rootOverlay('music-code-scanner-choice-sheet',scannerChoiceMarkup(),{initialSnap:'content'});
    root.querySelectorAll('[data-music-code-close]').forEach(button=>button.onclick=closeActive);
    root.querySelector('[data-scan-camera]').onclick=()=>startCamera(root,handlers);
    const input=root.querySelector('[data-music-code-file]');
    root.querySelector('[data-scan-image]').onclick=()=>input.click();
    input.onchange=()=>{const file=input.files?.[0];if(file)scanImageFile(file,handlers);};
  }


  async function scanImageFile(file,handlers={}) {
    closeActive();
    const root=rootOverlay('music-code-image-scanner-sheet',`<div class="music-code-sheet-content music-code-scanner" role="dialog" aria-modal="true" aria-label="Membaca Kode Lagu">
      <header class="music-code-sheet-head"><div><small>DATZON MUSIC</small><h2>Scan Kode Lagu</h2></div><button data-music-code-close aria-label="Tutup">${svg('close')}</button></header>
      <div class="music-code-image-preview" data-image-preview>${svg('album')}</div>
      <p data-music-code-status>Membaca Kode Lagu...</p>
      <button class="music-code-alt" data-pick-another>${svg('album')}<span>Pilih gambar lain</span></button>
      <input type="file" accept="image/*" data-music-code-file hidden>
    </div>`,{initialSnap:'content'});
    root.querySelector('[data-music-code-close]').onclick=closeActive;
    const picker=root.querySelector('[data-music-code-file]');
    root.querySelector('[data-pick-another]').onclick=()=>picker.click();
    picker.onchange=()=>{const next=picker.files?.[0];if(next)scanImageFile(next,handlers);};
    try{
      const bitmap=await createImageBitmap(file);
      const scale=Math.min(1,MAX_IMAGE_EDGE/Math.max(bitmap.width,bitmap.height));
      const canvas=document.createElement('canvas');
      canvas.width=Math.max(1,Math.round(bitmap.width*scale));
      canvas.height=Math.max(1,Math.round(bitmap.height*scale));
      const g=canvas.getContext('2d',{willReadFrequently:true});
      g.drawImage(bitmap,0,0,canvas.width,canvas.height);
      const preview=root.querySelector('[data-image-preview]');
      const url=URL.createObjectURL(file);
      preview.innerHTML=`<img src="${url}" alt="Gambar Kode Lagu">`;
      setTimeout(()=>URL.revokeObjectURL(url),60000);
      let raw=await detectFromSource(bitmap,canvas);
      // Second pass with a sharpened / high contrast copy improves screenshots
      // that have been resized by chat/social apps.
      if(!raw){
        const contrast=document.createElement('canvas');
        contrast.width=canvas.width; contrast.height=canvas.height;
        const cg=contrast.getContext('2d',{willReadFrequently:true});
        cg.filter='contrast(165%) grayscale(1)';
        cg.drawImage(canvas,0,0);
        raw=fallbackDecodeCanvas(contrast,true);
      }
      bitmap.close?.();
      if(!raw){status(root,'Kode Lagu tidak ditemukan. Coba gunakan gambar kode hasil Download Kode atau screenshot yang lebih jelas.','error');return;}
      await resolvePayload(raw,handlers,root);
    }catch(error){
      status(root,'Gambar tidak dapat dibaca. Pilih gambar lain yang lebih jelas.','error');
    }
  }



  async function startCamera(choiceRoot,handlers={}) {
    closeActive();
    const root=rootOverlay('music-code-camera-scanner-sheet',`<div class="music-code-sheet-content music-code-scanner" role="dialog" aria-modal="true" aria-label="Scan Kode Lagu">
      <header class="music-code-sheet-head"><div><small>DATZON MUSIC</small><h2>Scan Kode Lagu</h2></div><button data-music-code-close aria-label="Tutup">${svg('close')}</button></header>
      <div class="music-code-camera"><video data-music-code-video autoplay muted playsinline></video><div class="music-code-scan-frame"><i></i></div></div>
      <p data-music-code-status>Menyiapkan kamera...</p>
      <div class="music-code-camera-actions" hidden data-camera-error-actions><button data-camera-retry>Coba Lagi</button><button data-camera-image>Pilih Gambar</button></div>
      <input type="file" accept="image/*" data-music-code-file hidden>
    </div>`,{initialSnap:'content'});
    root.querySelector('[data-music-code-close]').onclick=closeActive;
    const picker=root.querySelector('[data-music-code-file]');
    root.querySelector('[data-camera-image]').onclick=()=>picker.click();
    picker.onchange=()=>{const file=picker.files?.[0];if(file)scanImageFile(file,handlers);};
    root.querySelector('[data-camera-retry]').onclick=()=>startCamera(root,handlers);
    if(!navigator.mediaDevices?.getUserMedia){
      status(root,'Kamera tidak tersedia pada perangkat atau browser ini.','error');
      root.querySelector('[data-camera-error-actions]').hidden=false;
      return;
    }
    try{
      const stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:'environment'},width:{ideal:1920},height:{ideal:1080}},audio:false});
      if(!active||active.root!==root){stream.getTracks().forEach(track=>track.stop());return;}
      active.stream=stream;
      const video=root.querySelector('[data-music-code-video]');
      video.srcObject=stream;
      await video.play();
      status(root,'Arahkan kamera ke Kode Lagu.');
      cameraLoop(video,root,handlers);
    }catch(error){
      const denied=error?.name==='NotAllowedError'||error?.name==='SecurityError';
      const unavailable=error?.name==='NotFoundError'||error?.name==='OverconstrainedError';
      status(root,denied?'Akses kamera ditolak. Izinkan akses kamera pada pengaturan browser untuk menggunakan pemindai.':unavailable?'Kamera tidak tersedia pada perangkat atau browser ini.':'Kamera tidak dapat digunakan. Tutup aplikasi lain yang sedang memakai kamera lalu coba lagi.','error');
      root.querySelector('[data-camera-error-actions]').hidden=false;
    }
  }


  async function cameraLoop(video,root,handlers={}) {
    const detector=await nativeDetector(); const scratch=document.createElement('canvas');
    const tick=async()=>{
      if(!active||active.root!==root||active.closed||active.processing)return;
      try{
        let raw='';
        if(detector){try{const results=await detector.detect(video);raw=results.find(item=>parseMachinePayload(item.rawValue))?.rawValue||'';}catch{}}
        if(!raw&&video.videoWidth>0){
          const vw=video.videoWidth,vh=video.videoHeight;const cropW=Math.round(vw*.88),cropH=Math.round(vh*.48),sx=Math.round((vw-cropW)/2),sy=Math.round((vh-cropH)/2);const scale=Math.min(1,1200/cropW);scratch.width=Math.max(1,Math.round(cropW*scale));scratch.height=Math.max(1,Math.round(cropH*scale));scratch.getContext('2d').drawImage(video,sx,sy,cropW,cropH,0,0,scratch.width,scratch.height);raw=fallbackDecodeCanvas(scratch,false);
        }
        if(raw){await resolvePayload(raw,handlers,root);return;}
      }catch{}
      if(active&&active.root===root)active.timer=setTimeout(tick,SCAN_INTERVAL);
    };
    tick();
  }

  window.addEventListener('pagehide',stopStream);
  window.addEventListener('popstate',stopStream);

  window.DatzonMusicCode=Object.freeze({
    show, openScanner, close:closeActive, canonicalTrackKey, displayCode, machinePayload, parseMachinePayload,
    _test:{ encodeCode128B, barcodeModules, patternError, nearestSymbol, decodeRuns, drawMachineLane, fallbackDecodeCanvas }
  });
})();
