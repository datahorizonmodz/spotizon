(() => {
  'use strict';
  const esc=value=>String(value??'').replace(/[&<>'"]/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[ch]));
  const chevron='<svg class="icon" viewBox="0 0 24 24" aria-hidden="true"><path d="m9 18 6-6-6-6"></path></svg>';
  const more='<svg class="icon" aria-hidden="true"><use href="#i-more"></use></svg>';
  function entityCard(entity={}, index=0){
    if(entity.kind==='artist')return `<button class="spotify-result-row mixed-entity-row mixed-artist-card" data-mixed-feed="${index}" data-kind="artist"><img src="${esc(entity.image||'assets/placeholder.svg')}" alt="Foto ${esc(entity.name)}" loading="lazy" onerror="this.src='assets/placeholder.svg'"><span><strong>${esc(entity.name)}</strong><small>Artis${entity.followers?` • ${esc(entity.followersLabel||'')}`:''}</small></span><i class="mixed-chevron">${chevron}</i></button>`;
    if(entity.kind==='album'){const type=entity.albumType==='single'?'Single':entity.albumType==='compilation'?'Compilation':'Album';const year=entity.releaseDate?String(entity.releaseDate).slice(0,4):'';return `<button class="spotify-result-row mixed-entity-row mixed-album-card" data-mixed-feed="${index}" data-kind="album"><img src="${esc(entity.cover||'assets/placeholder.svg')}" alt="Sampul ${esc(entity.name)}" loading="lazy" onerror="this.src='assets/placeholder.svg'"><span><strong>${esc(entity.name)}</strong><small>${esc([type,entity.artist,year].filter(Boolean).join(' • '))}</small></span><i class="mixed-chevron mixed-entity-more">${more}</i></button>`;}
    if(entity.kind==='playlist')return `<button class="spotify-result-row mixed-entity-row mixed-playlist-card" data-mixed-feed="${index}" data-kind="playlist"><img src="${esc(entity.cover||'assets/placeholder.svg')}" alt="Sampul ${esc(entity.name)}" loading="lazy" onerror="this.src='assets/placeholder.svg'"><span><strong>${esc(entity.name)}</strong><small>${esc(['Playlist',entity.owner,entity.totalTracks?`${entity.totalTracks} lagu`:''].filter(Boolean).join(' • '))}</small></span><i class="mixed-chevron mixed-entity-more">${more}</i></button>`;
    return '';
  }
  window.DatzonCatalogUI=Object.freeze({entityCard});
})();
