'use strict';

const CONFIG = Object.freeze({
  appName: 'DATZON Music',
  version: '1.62.9',
  apiBase: 'https://api.cmnty.eu.cc',
  primarySearchProvider: 'theresav',
  primaryAudioProvider: 'theresav',
  theresavSearchEnabled: true,
  theresavAudioEnabled: true,
  theresavProxyBase: '/api/theresav',
  sylvaticaAudioEnabled: true,
  sylvaticaSearchEnabled: true,
  cmntyAudioEnabled: true,
  cmntySearchEnabled: true,
  sylvaticaDownloadProxyPath: '/api/sylvatica?action=download',
  sylvaticaSearchProxyPath: '/api/sylvatica?action=search',
  sylvaticaLyricsProxyPath: '/api/sylvatica?action=lyrics',
  sylvaticaSpotyloaderEnabled: true,
  sylvaticaSpotyloaderProxyPath: '/api/sylvatica?action=spotyloader',
  sylvaticaSpotyloaderAudioProxyPath: '/api/sylvatica/audio',
  searchSuggestPath: '/api/search-suggest',
  bintangAudioEnabled: true,
  bintangApiBase: 'https://bintangapi.my.id',
  bintangDownloadPath: '/api/downloader/spotify',
  ikyySearchEnabled: true,
  ikyyAudioEnabled: true,
  ikyyApiBase: 'https://api.ikyyxd.my.id',
  ikyySearchPath: '/search/spotify',
  ikyyDownloadPath: '/download/spotifydl',
  jereAudioEnabled: true,
  jereApiBase: 'https://api.jerexd.my.id',
  jereApiKey: 'jere_dfakzfYPpnwi',
  jereDownloadPaths: ['/api/downloader/spotifyv3', '/api/downloader/spotifyv2', '/api/downloader/spotify'],
  anabotEnabled: true,
  anabotApiBase: 'https://anabot.my.id',
  anabotApiKey: 'freeApikey',
  anabotArtistPath: '/api/spotify/artist',
  anabotPlaylistPath: '/api/spotify/playlist',
  anabotFeaturedPlaylistId: '0Zl5d2zsthrg3Jid7erpnT',
  apiKeys: [
    'cmnty-909a43416785c078e3c94a75062d0b58',
    'cmnty-9f189a984dcafffee2c218375516f195',
    'cmnty-364127d70eb76a1f18e31f7d557a7d82',
    'cmnty-b55e30f7d0e71003bba3651ecfdf6104',
    'cmnty-17a8107bfaa8e78c33f71b991182734b',
    'cmnty-656d4d33bd1b9cbee7ae0cf67c661329',
    'cmnty-d1f13b506b760ac0d8b66ca237809ae2',
    'cmnty-9c05aae5be50d73852c6c611ed8b7ef4'
  ],
  blackRoseEnabled: false,
  playbackBitrates: ['320k', '192k', '128k', '64k'],
  requestTimeout: 35000,
  cacheMs: 1000 * 60 * 30,
  searchCacheMs: 1000 * 60 * 15,
  lyricsCacheMs: 1000 * 60 * 60 * 12,
  negativeLyricsCacheMs: 1000 * 60 * 20,
  discoveryCacheMs: 1000 * 60 * 60 * 6,
  appleTopSongsFeed: 'https://rss.marketingtools.apple.com/api/v2/id/music/most-played/50/songs.json',
  appleTopAlbumsFeed: 'https://rss.marketingtools.apple.com/api/v2/id/music/most-played/25/albums.json',
  itunesSearchBase: 'https://itunes.apple.com/search',
  musicBrainzBase: 'https://musicbrainz.org/ws/2',
  coverArtArchiveBase: 'https://coverartarchive.org/release-group',
  wikipediaApiBase: 'https://id.wikipedia.org/w/api.php',
  spotifyCatalogEnabled: true,
  spotifyCatalogMarket: 'ID',
  artistCacheMs: 1000 * 60 * 60 * 24 * 7,
  spotifyArtistCacheMs: 1000 * 60 * 60 * 12
});

const FALLBACK_TRACKS = [
  { title: 'Tulus - Teh Hijau', artist: 'Tulus', duration: '3:33', thumbnail: 'https://i.scdn.co/image/ab67616d0000b273e4086e5f9d79cf18ed601015', popularity: 88, album: 'Teh Hijau', release_date: '2026-06-30', url: 'https://open.spotify.com/track/4R9G7azXaZe93KTX65P9fU' },
  { title: 'eńau - Sesi Potret', artist: 'eńau', duration: '4:03', thumbnail: 'https://i.scdn.co/image/ab67616d0000b273172768978c7f929803ad7e8b', popularity: 92, album: 'Sesi Potret', release_date: '2026-01-29', url: 'https://open.spotify.com/track/4xoY4lZNoTjEuHsSmhgF1G' },
  { title: 'Tulus - Jatuh Suka', artist: 'Tulus', duration: '3:55', thumbnail: 'https://i.scdn.co/image/ab67616d0000b273d34a0632f6861e8875d6899b', popularity: 84, album: 'Manusia', release_date: '2022-03-03', url: 'https://open.spotify.com/track/6PqWdGIYq5xdLaa4zCZfRp' },
  { title: 'Sal Priadi - Foto kita blur', artist: 'Sal Priadi', duration: '4:31', thumbnail: 'https://i.scdn.co/image/ab67616d0000b2733489e60f1b695d3e2b814682', popularity: 75, album: 'Foto kita blur', release_date: '2024-03-29', url: 'https://open.spotify.com/track/0qbRvZ1alpPGmV52wKb2gJ' },
  { title: 'Ghea Indrawari - 1000X', artist: 'Ghea Indrawari', duration: '4:12', thumbnail: 'https://i.scdn.co/image/ab67616d0000b27353ab629cb64f2dad691e1301', popularity: 66, album: '1000X', release_date: '2026-02-06', url: 'https://open.spotify.com/track/6ksyG6PARbZD5j4WTMJ08G' },
  { title: 'Naykilla - MMG (My Mine Gueh)', artist: 'Naykilla', duration: '3:13', thumbnail: 'https://i.scdn.co/image/ab67616d0000b273671059f40b6662d84ea412d9', popularity: 81, album: 'MMG (My Mine Gueh)', release_date: '2026-06-19', url: 'https://open.spotify.com/track/2AtJq58CHh4qBUqTpU75vU' },
  { title: 'Tulus - Hati-Hati di Jalan', artist: 'Tulus', duration: '4:02', thumbnail: 'https://i.scdn.co/image/ab67616d0000b273d34a0632f6861e8875d6899b', popularity: 83, album: 'Manusia', release_date: '2022-03-03', url: 'https://open.spotify.com/track/2hHeGD57S0BcopfVcmehdl' },
  { title: 'Tulus - Diri', artist: 'Tulus', duration: '4:00', thumbnail: 'https://i.scdn.co/image/ab67616d0000b273d34a0632f6861e8875d6899b', popularity: 76, album: 'Manusia', release_date: '2022-03-03', url: 'https://open.spotify.com/track/2qgjqbi96IAOBzZFC6H57U' },
  { title: 'Tulus - Interaksi', artist: 'Tulus', duration: '2:50', thumbnail: 'https://i.scdn.co/image/ab67616d0000b273d34a0632f6861e8875d6899b', popularity: 79, album: 'Manusia', release_date: '2022-03-03', url: '' },
  { title: 'Tulus - Satu Kali', artist: 'Tulus', duration: '4:14', thumbnail: 'https://i.scdn.co/image/ab67616d0000b273d34a0632f6861e8875d6899b', popularity: 73, album: 'Manusia', release_date: '2022-03-03', url: '' }
]

const HOME_SPOTLIGHT_SEEDS = Object.freeze([
  { title: 'Birds of a Feather', artist: 'Billie Eilish', search: 'Birds of a Feather Billie Eilish' },
  { title: 'Drop Dead', artist: 'Olivia Rodrigo', search: 'Drop Dead Olivia Rodrigo', spotifyUrl: 'https://open.spotify.com/track/6gkbtMtioHgtyGjrMel6ei', thumbnail: 'https://image-cdn-ak.spotifycdn.com/image/ab67616d00001e02c25b53f0a34aa1bb4f77cb3e' },
  { title: 'The Fate of Ophelia', artist: 'Taylor Swift', search: 'The Fate of Ophelia Taylor Swift' },
  { title: 'Espresso', artist: 'Sabrina Carpenter', search: 'Espresso Sabrina Carpenter' },
  { title: 'Die With A Smile', artist: 'Lady Gaga & Bruno Mars', search: 'Die With A Smile Lady Gaga Bruno Mars' },
  { title: 'Sesi Potret', artist: 'énau feat. Ari Lesmana', search: 'Sesi Potret enau Ari Lesmana' },
  { title: 'Teh Hijau', artist: 'Tulus', search: 'Teh Hijau Tulus', spotifyUrl: 'https://open.spotify.com/track/4R9G7azXaZe93KTX65P9fU', thumbnail: 'https://i.scdn.co/image/ab67616d0000b273e4086e5f9d79cf18ed601015' },
  { title: 'Dunia Yang Nanti', artist: 'Raim Laode', search: 'Dunia Yang Nanti Raim Laode' },
  { title: 'Jangan Paksa Rindu - Beda', artist: 'Ifan Seventeen', search: 'Jangan Paksa Rindu Beda Ifan Seventeen' },
  { title: 'Foto kita blur', artist: 'Sal Priadi', search: 'Foto kita blur Sal Priadi', spotifyUrl: 'https://open.spotify.com/track/0qbRvZ1alpPGmV52wKb2gJ', thumbnail: 'https://i.scdn.co/image/ab67616d0000b2733489e60f1b695d3e2b814682' },
  { title: 'TABOLA BALE', artist: 'Silet Open Up feat. Jacson Seran', search: 'TABOLA BALE Silet Open Up Jacson Seran' },
  { title: 'Terpikat Senyummu', artist: 'Idgitaf', search: 'Terpikat Senyummu Idgitaf' }
]);

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const view = $('#view');
const bottomNav = $('#bottomNav');
const miniPlayer = $('#miniPlayer');
const audio = $('#audio');
const modalRoot = $('#modalRoot');
const restoreInput = $('#restoreInput');
const desktopSidebarRoot = $('#desktopSidebarRoot');
const desktopSpotlightRail = $('#desktopSpotlightRail');
const desktopContextRail = $('#desktopContextRail');
const desktopNavRail = $('#desktopNavRail');

const storage = {
  get(key, fallback) {
    try { const value = localStorage.getItem(`datzon_music_${key}`); return value ? JSON.parse(value) : fallback; }
    catch { return fallback; }
  },
  set(key, value) {
    try { localStorage.setItem(`datzon_music_${key}`, JSON.stringify(value)); } catch {}
  },
  remove(key) { localStorage.removeItem(`datzon_music_${key}`); }
};

const state = {
  route: 'home',
  username: storage.get('username', 'Tamu'),
  catalog: storage.get('catalog', []),
  catalogAt: storage.get('catalogAt', 0),
  searchResults: [],
  searchMixedResults: [],
  searchEntities: { artists: [], albums: [], playlists: [] },
  searchSpotifyOffset: 0,
  searchHasMore: false,
  searchQuery: '',
  searchLoading: false,
  queue: storage.get('queue', []),
  queueRecommendations: storage.get('queueRecommendations', []),
  queueRecommendationsKey: storage.get('queueRecommendationsKey', ''),
  currentIndex: Number(storage.get('currentIndex', -1)),
  current: storage.get('current', null),
  favorites: storage.get('favorites', []),
  history: storage.get('history', []),
  searchHistory: storage.get('searchHistory', []),
  downloads: storage.get('downloads', []),
  listeningStats: storage.get('listeningStats', { totalSeconds: 0, plays: 0, tracks: {}, artists: {}, days: {} }),
  settings: {
    dataSaver: false,
    offlineMode: false,
    highQuality: true,
    privateSession: false,
    dynamicTheme: true,
    themeMode: 'auto',
    reduceMotion: false,
    liquidGlass: true,
    showCanvas: true,
    textScale: 'Normal',
    coverShape: 'Membulat',
    autoplay: true,
    gapless: true,
    continueQueue: true,
    savePosition: true,
    normalizeVolume: false,
    crossfadeSeconds: 0,
    playOnSelect: true,
    skipFailed: true,
    confirmQueueClear: true,
    autoPip: false,
    downloadCellular: true,
    streamingQuality: 'Sangat tinggi, 320 kbps',
    downloadQuality: '320 kbps',
    historyLimit: 100,
    saveHistory: true,
    useHistoryRecommendations: true,
    showRecentArtists: true,
    saveSearchHistory: true,
    publicPlaylists: false,
    explicitFilter: false,
    notifications: false,
    notifyDownloads: true,
    notifyFailures: true,
    notifyLyrics: false,
    notifyUpdates: true,
    notifyProvider: false,
    mediaControls: true,
    backgroundPlayback: true,
    preventSleepLyrics: false,
    lyricsAutoFocus: false,
    ...storage.get('settings', {})
  },
  isPlaying: false,
  resolving: false,
  currentAudioUrl: '',
  shuffle: storage.get('shuffle', false),
  repeat: storage.get('repeat', 'off'),
  sleepTimer: null,
  sleepTimerEndAt: Number(storage.get('sleepTimerEndAt', 0)) || 0,
  sleepTimerMode: storage.get('sleepTimerMode', ''),
  spotlightIndex: Math.max(0, Number(storage.get('spotlightIndex', 0)) || 0),
  spotlightManualUntil: 0,
  homeSpotlight: storage.get('homeSpotlight', []),
  homeSpotlightAt: Number(storage.get('homeSpotlightAt', 0)) || 0,
  homeError: '',
  apiOnline: null,
  playContext: storage.get('playContext', { eyebrow: 'MEMAINKAN DARI DATZON MUSIC', label: 'Pilihan untukmu' }),
  lastPlayerRoute: 'home',
  lyricsKey: '',
  lyricsLines: [],
  lyricsLoading: false,
  lyricsError: '',
  lyricsSynced: false,
  lyricsSource: '',
  lastLyricIndex: -1,
  playerPreparing: false,
  playerPrepareToken: 0,
  audioReady: false,
  audioFullyBuffered: false,
  audioBufferingProgress: 0,
  lyricsReady: false,
  artworkReady: false,
  playerPrepareError: '',
  sleepTimerLabel: storage.get('sleepTimerLabel', ''),
  mixMode: storage.get('mixMode', false),
  hiddenSuggestions: storage.get('hiddenSuggestions', {}),
  queueEditMode: false,
  queueSelection: new Set(),
  queueSheetLoading: false,
  dragQueueIndex: null,
  apiKeyIndex: Math.max(0, Number(storage.get('apiKeyIndex', 0)) || 0),
  homeFilter: 'all',
  libraryView: storage.get('libraryView', 'list') === 'grid' ? 'grid' : 'list',
  libraryFilter: ['all','playlist','artist'].includes(storage.get('libraryFilter', 'all')) ? storage.get('libraryFilter', 'all') : 'all',
  librarySort: ['recent','added','alphabetical','creator'].includes(storage.get('librarySort', 'recent')) ? storage.get('librarySort', 'recent') : 'recent',
  homeDiscovery: storage.get('homeDiscovery', { topSongs: [], topAlbums: [], artistPool: [], artistCatalogs: {} }),
  homeDiscoveryAt: Number(storage.get('homeDiscoveryAt', 0)) || 0,
  homeDiscoveryLoading: false,
  homeDiscoverySource: storage.get('homeDiscoverySource', ''),
  homeFeaturedPlaylist: storage.get('homeFeaturedPlaylistV1400', { id: '', name: '', owner: '', description: '', totalTracks: 0, tracks: [] }),
  homeFeaturedPlaylistAt: Number(storage.get('homeFeaturedPlaylistAtV1400', 0)) || 0,
  homeFeaturedPlaylistLoading: false,
  homeSimilarGroups: storage.get('homeSimilarGroupsV1500', []),
  homeSimilarGroupsAt: Number(storage.get('homeSimilarGroupsAtV1500', 0)) || 0,
  homeSimilarGroupsLoading: false,
  homeInitialLoading: true,
  homeReady: false,
  homeSessionSeed: `${Date.now()}-${Math.random()}`,
  systemActivity: storage.get('systemActivity', []),
  systemActivityUnread: Number(storage.get('systemActivityUnread', 0)) || 0,
  systemActivityOpen: false,
  artistProfiles: storage.get('artistProfiles', {}),
  artistProfilesAt: storage.get('artistProfilesAt', {}),
  spotifyAuth: storage.get('spotifyAuth', { accessToken: '', refreshToken: '', expiresAt: 0 }),
  spotifyArtistProfiles: storage.get('spotifyArtistProfiles', {}),
  spotifyArtistProfilesAt: storage.get('spotifyArtistProfilesAt', {}),
  artistView: { name: '', seedTrack: null, profile: null, loading: false, error: '' },
  artistReturnRoute: 'home',
  preferredArtists: storage.get('preferredArtists', []),
  preferredArtistMeta: storage.get('preferredArtistMeta', []),
  guestPlaylists: storage.get('guestPlaylists', []),
  accountPlaylists: storage.get('accountPlaylists', {}),
  auth: { configured: false, ready: false, loading: true, user: null, profile: null, hydratedUid: '', cloudLoaded: false, pendingGoogle: null, pendingOtp: null, pendingRegistration: null },
  globalNotifications: [],
  announcements: [],
  announcementReads: storage.get('announcementReads', []),
  notificationsOpen: false,
  social: { loading: false, loaded: false, friends: [], following: [], followers: [], searchResults: [], searchQuery: '', searchLoading: false, leaderboard: [], leaderboardLoading: false },
  publicProfileView: { uid: '', profile: null, relationship: null, social: null, playlists: [], playlistsReady: false, playlistsError: '', loading: false, error: '' },
  datzonPlaylistView: { id: '', data: null, loading: false, error: '', sourceProfile: null },
  spotifyHomeCollections: storage.get('spotifyHomeCollectionsV1450', []),
  spotifyHomeCollectionsAt: Number(storage.get('spotifyHomeCollectionsAtV1450', 0)) || 0,
  spotifyHomeCollectionsLoading: false,
  spotifyHomeCollectionsError: '',
  spotifyCollectionView: { type: '', id: '', data: null, loading: false, error: '' },
  spotifySavedCollections: storage.get('spotifySavedCollectionsV1440', []),
  spotifyTrackMetaCache: storage.get('spotifyTrackMetaV1440', {}),
  spotifyCollectionReturnScroll: null,
  importTarget: 'local',
  adminReports: [],
  adminReportsLoading: false,
  adminReportsLoaded: false,
  reportDraftFiles: [],
  reportDraftSubject: '',
  reportDraftDescription: ''
};

if (!storage.get('cmntyOnlyMigrationV126', false)) {
  state.systemActivity = (state.systemActivity || []).filter(entry => {
    const text = `${entry?.provider || ''} ${entry?.title || ''} ${entry?.detail || ''}`;
    return !/BlackRose/i.test(text);
  });
  state.systemActivityUnread = Math.min(state.systemActivityUnread, state.systemActivity.length);
  storage.set('systemActivity', state.systemActivity);
  storage.set('systemActivityUnread', state.systemActivityUnread);
  storage.set('cmntyOnlyMigrationV126', true);
}

if (!storage.get('qualityAndLyricsDefaultsV134', false)) {
  if (!state.settings.streamingQuality || state.settings.streamingQuality === 'Otomatis') {
    state.settings.streamingQuality = 'Sangat tinggi, 320 kbps';
    state.settings.highQuality = true;
    state.settings.dataSaver = false;
  }
  state.settings.lyricsAutoFocus = false;
  storage.set('settings', state.settings);
  storage.set('qualityAndLyricsDefaultsV134', true);
}

let activeSheetController = null;
let playbackSyncTimer = null;
let publicPlaylistSyncTimer = null;
let pendingAutoplayTimer = null;
let nextTrackPreloadTimer = null;
let playbackEndWatchdog = null;
let backgroundAdvanceLock = false;
let nextAudioWarmup = null;
let nextTrackPreload = { signature: '', fromKey: '', index: -1, promise: null, value: null, at: 0 };
let userSeekActive = false;
let pendingSeekSeconds = null;
let audioStallRecoveryTimer = null;
let audioRecoveryInFlight = false;
let activePlaybackOriginalUrl = '';
let activePlaybackPrepareController = null;
let currentFullBufferPromise = null;
const fullAudioBlobCache = new Map();
const FULL_AUDIO_CACHE_LIMIT = 3;
const FULL_AUDIO_MAX_BYTES = 42 * 1024 * 1024;
let homeSpotlightTimer = null;
let lastRenderedRoute = '';
let listeningLastTick = 0;
let listeningLastPersist = 0;
let wakeLockSentinel = null;
let deferredInstallPrompt = null;
let firebaseSyncQueued = false;
let firebaseAuthUnsubscribe = null;
let firebaseNotificationsUnsubscribe = null;
let publicProfilePlaylistsUnsubscribe = null;
let datzonPlaylistUnsubscribe = null;
let leaderboardUnsubscribe = null;
let pendingPublicPlaylistSyncPrevious = null;
const playerThemeCache = new Map();
const publicJsonCache = new Map();
const primaryTrackResolutionCache = new Map();
const cmntyDownloaderCache = new Map();
const cmntyDownloaderFailureCache = new Map();
const theresavDownloaderCache = new Map();
const theresavDownloaderFailureCache = new Map();
const sylvaticaDownloaderCache = new Map();
const sylvaticaDownloaderFailureCache = new Map();
const externalDownloaderCache = new Map();
const externalDownloaderFailureCache = new Map();
const anabotArtistCache = new Map();
const sylvaticaSpotyloaderArtistCache = new Map();
const sylvaticaSpotyloaderPackageCache = new Map();
const anabotPlaylistCache = new Map();
const cmntyPlayCache = new Map();
const cmntyPlayFailureCache = new Map();
const spotifySearchCache = new Map();
const timedLyricsCache = new Map();
const sylvaticaLyricsCache = new Map();
const THERESAV_PACKAGE_CACHE_MS = 1000 * 60 * 15;
const THERESAV_FAILURE_CACHE_MS = 1000 * 20;
const CMNTY_PACKAGE_CACHE_MS = 1000 * 60 * 15;
const SYLVATICA_PACKAGE_CACHE_MS = 1000 * 60 * 15;
const CMNTY_PLAY_CACHE_MS = 1000 * 60 * 10;
const CMNTY_FAILURE_CACHE_MS = 1000 * 30;
const SYLVATICA_FAILURE_CACHE_MS = 1000 * 30;
const EXTERNAL_PROVIDER_CACHE_MS = 1000 * 60 * 15;
const EXTERNAL_PROVIDER_FAILURE_CACHE_MS = 1000 * 20;
const ANABOT_CACHE_MS = 1000 * 60 * 60 * 6;
const FRESH_AUDIO_URL_MS = 1000 * 60 * 8;
const CMNTY_ALLOWED_ENDPOINTS = new Set([
  '/downloader/spotify',
  '/downloader/spotify-play',
  '/search/spotify',
  '/search/spotify-lyrics'
]);
const SPOTIFY_SEARCH_STORAGE_KEY = 'spotifySearchCacheV1470';
if (!storage.get('spotifySearchCacheMigrationV1470', false)) {
  storage.remove('spotifySearchCacheV1410');
  storage.remove('spotifySearchCacheV1401');
  storage.remove('spotifySearchCacheV1400');
  storage.set('spotifySearchCacheMigrationV1470', true);
}
const CMNTY_SEARCH_STORAGE_KEY = 'cmntySearchCacheV126';
const CMNTY_LYRICS_STORAGE_KEY = 'cmntyLyricsCacheV126';
const SYLVATICA_LYRICS_STORAGE_KEY = 'sylvaticaLyricsCacheV1394';
if (!storage.get('sylvaticaLyricsCacheMigrationV1394', false)) {
  storage.remove('sylvaticaLyricsCacheV1381');
  storage.set('sylvaticaLyricsCacheMigrationV1394', true);
}

function readPersistentApiCache(storageKey, key, maxAge) {
  const cache = storage.get(storageKey, {});
  const entry = cache?.[key];
  if (!entry || Date.now() - Number(entry.at || 0) >= maxAge) return null;
  return entry.value;
}

function writePersistentApiCache(storageKey, key, value, limit = 30) {
  const cache = storage.get(storageKey, {});
  cache[key] = { at: Date.now(), value };
  const sorted = Object.entries(cache)
    .sort((a, b) => Number(b[1]?.at || 0) - Number(a[1]?.at || 0))
    .slice(0, Math.max(5, limit));
  storage.set(storageKey, Object.fromEntries(sorted));
}
const cmntyKeyCooldownUntil = (() => {
  const saved = storage.get('cmntyKeyCooldownUntil', []);
  return Array.from({ length: CONFIG.apiKeys.length }, (_, index) => Number(saved?.[index] || 0));
})();

function unlockPageScroll(force = false) {
  const hasOpenOverlay = Boolean(modalRoot?.querySelector('.player-sheet-backdrop, .modal-backdrop'));
  if (hasOpenOverlay && !force) return;
  document.documentElement.classList.remove('sheet-open');
  document.body.classList.remove('sheet-open');
  document.documentElement.style.removeProperty('overflow');
  document.documentElement.style.removeProperty('overflow-y');
  document.body.style.removeProperty('overflow');
  document.body.style.removeProperty('overflow-y');
  document.body.style.removeProperty('position');
}

function resetPlayerViewport() {
  unlockPageScroll(true);
  const reset = () => {
    document.documentElement.scrollTop = 0;
    document.body.scrollTop = 0;
    if (view) view.scrollTop = 0;
    window.scrollTo(0, 0);
    const nested = view?.querySelector('.player-page, .player-content, .full-lyrics-page, .full-lyrics-scroll');
    if (nested && 'scrollTop' in nested) nested.scrollTop = 0;
  };
  reset();
  requestAnimationFrame(() => {
    reset();
    requestAnimationFrame(reset);
  });
}

function icon(name, className = '') {
  return `<svg class="icon ${className}" aria-hidden="true"><use href="#i-${name}"></use></svg>`;
}
function esc(value = '') {
  return String(value).replace(/[&<>'"]/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[ch]));
}
function trackKey(track) { return track?.url || `${track?.artist || ''}|${track?.title || ''}`; }
function cleanTitle(track) {
  const title = String(track?.title || track?.name || 'Tanpa Judul').trim();
  const artist = String(track?.artist || '').trim();
  if (!artist) return title;
  const patterns = [`${artist} - `, `${artist} – `, `${artist} — `];
  for (const prefix of patterns) if (title.toLowerCase().startsWith(prefix.toLowerCase())) return title.slice(prefix.length).trim();
  return title;
}
function isUnknownArtist(value = '') {
  const text = String(value || '').trim();
  return !text || /^(?:unknown|unknown artist|artis tidak diketahui|tidak diketahui|n\/?a|null|undefined|-)$/i.test(text);
}

function meaningfulText(value = '') {
  const text = String(value ?? '').trim();
  return text && !/^(?:unknown|n\/?a|null|undefined|-)$/i.test(text) ? text : '';
}

function enhanceArtworkUrl(value = '') {
  let url = String(value || '').trim();
  if (!url || url.startsWith('assets/')) return url || 'assets/placeholder.svg';
  // Apple/iTunes artwork commonly arrives at 30–100 px. Request the largest public rendition.
  url = url
    .replace(/\/(?:\d{2,4})x(?:\d{2,4})bb\.(jpg|jpeg|png|webp)(\?.*)?$/i, '/1200x1200bb.$1$2')
    .replace(/\/(?:\d{2,4})x(?:\d{2,4})\.(jpg|jpeg|png|webp)(\?.*)?$/i, '/1200x1200.$1$2')
    // Spotify album CDN: upgrade 64/300 px variants to the 640 px public variant.
    .replace(/ab67616d00004851/gi, 'ab67616d0000b273')
    .replace(/ab67616d00001e02/gi, 'ab67616d0000b273')
    // Spotify artist CDN: upgrade 160/320 px variants to the 640 px public variant.
    .replace(/ab6761610000f178/gi, 'ab6761610000e5eb')
    .replace(/ab67616100005174/gi, 'ab6761610000e5eb')
    .replace(/([?&])w=\d+/i, '$1w=1200')
    .replace(/([?&])h=\d+/i, '$1h=1200');
  if (/googleusercontent\.com/i.test(url)) {
    url = url.replace(/=s\d+(?:-c)?$/i, '=s1200-c').replace(/=w\d+-h\d+(?:-c)?$/i, '=w1200-h1200-c');
  }
  if (/ytimg\.com\/vi\//i.test(url)) url = url.replace(/\/(?:default|mqdefault|hqdefault|sddefault)\.(jpg|webp)(\?.*)?$/i, '/maxresdefault.$1$2');
  return url;
}

function normalizeArtistValue(...values) {
  for (const raw of values) {
    let value = raw;
    if (Array.isArray(value)) value = value.map(item => typeof item === 'string' ? item : item?.name).filter(Boolean).join(', ');
    else if (value && typeof value === 'object') value = value.name || value.artist || value.artistName || '';
    const text = String(value || '').trim();
    if (!isUnknownArtist(text)) return text;
  }
  return 'Artis tidak diketahui';
}

function extractArtistNames(...values) {
  const names = [];
  const push = value => {
    const name = String(value || '').trim();
    if (name && !isUnknownArtist(name) && !names.some(item => normalizeMatchText(item) === normalizeMatchText(name))) names.push(name);
  };
  const walk = value => {
    if (!value) return;
    if (Array.isArray(value)) { value.forEach(walk); return; }
    if (typeof value === 'object') {
      push(value.name || value.artist || value.artistName);
      return;
    }
    if (typeof value === 'string' && !/[,&]|\b(?:feat\.?|featuring|ft\.?| x )\b/i.test(value)) push(value);
  };
  values.forEach(walk);
  return names;
}

function extractSpotifyArtistIds(...values) {
  const ids = [];
  const push = value => {
    const id = String(value || '').trim();
    if (/^[A-Za-z0-9]{22}$/.test(id) && !ids.includes(id)) ids.push(id);
  };
  const walk = value => {
    if (!value) return;
    if (Array.isArray(value)) { value.forEach(walk); return; }
    if (typeof value === 'object') {
      push(value.id || value.artistId || value.artist_id || value.spotifyId || value.spotify_id);
      if (value.uri) push(String(value.uri).match(/spotify:artist:([A-Za-z0-9]{22})/i)?.[1]);
      if (value.url || value.href || value.external_urls?.spotify) {
        push(String(value.url || value.href || value.external_urls?.spotify).match(/open\.spotify\.com\/artist\/([A-Za-z0-9]{22})/i)?.[1]);
      }
      return;
    }
    push(value);
  };
  values.forEach(walk);
  return ids;
}

function extractSpotifyArtistUrls(...values) {
  const urls = [];
  const push = value => {
    const text = String(value || '').trim();
    const match = text.match(/https:\/\/open\.spotify\.com\/artist\/([A-Za-z0-9]{22})/i);
    const url = match ? `https://open.spotify.com/artist/${match[1]}` : '';
    if (url && !urls.includes(url)) urls.push(url);
  };
  const walk = value => {
    if (!value) return;
    if (Array.isArray(value)) { value.forEach(walk); return; }
    if (typeof value === 'object') {
      push(value.external_url || value.externalUrl || value.url || value.href || value.external_urls?.spotify);
      const id = String(value.id || value.artistId || value.artist_id || value.spotifyId || value.spotify_id || '').trim();
      if (/^[A-Za-z0-9]{22}$/.test(id)) push(`https://open.spotify.com/artist/${id}`);
      return;
    }
    push(value);
  };
  values.forEach(walk);
  return urls;
}

function buildArtistDetails(names = [], ids = [], urls = []) {
  const count = Math.max(names.length, ids.length, urls.length);
  const details = [];
  for (let index = 0; index < count; index += 1) {
    const name = String(names[index] || '').trim();
    const id = String(ids[index] || '').trim();
    const url = String(urls[index] || (id ? `https://open.spotify.com/artist/${id}` : '')).trim();
    if (!name && !id && !url) continue;
    details.push({ name, id: /^[A-Za-z0-9]{22}$/.test(id) ? id : '', url });
  }
  return details;
}

function normalizeTrack(raw) {
  const metadata = raw?.metadata || raw || {};
  const albumValue = typeof metadata.album === 'object' ? metadata.album?.name : metadata.album;
  const rawAlbumValue = typeof raw?.album === 'object' ? raw.album?.name : raw?.album;
  const id = raw?.id || metadata.id || metadata.tid || raw?.tid || '';
  const spotifyUrl = metadata.spotifyUrl || metadata.spotify_url || metadata.spotify || metadata.external_urls?.spotify || raw?.spotifyUrl || raw?.spotify_url || raw?.spotify || raw?.external_urls?.spotify || '';
  const artistNames = extractArtistNames(
    metadata.artistNames, metadata.artistDetails, metadata.artists_detail, metadata.artists,
    raw?.artistNames, raw?.artistDetails, raw?.artists_detail, raw?.artists
  );
  const artistIds = extractSpotifyArtistIds(
    metadata.artistIds, metadata.artist_ids, metadata.artistId, metadata.artist_id, metadata.spotifyArtistId,
    raw?.artistIds, raw?.artist_ids, raw?.artistId, raw?.artist_id, raw?.spotifyArtistId,
    metadata.artistDetails, metadata.artists_detail, metadata.artists, raw?.artistDetails, raw?.artists_detail, raw?.artists
  );
  const artistUrls = extractSpotifyArtistUrls(
    metadata.artistUrls, metadata.artist_urls, metadata.artistDetails, metadata.artists_detail, metadata.artists,
    raw?.artistUrls, raw?.artist_urls, raw?.artistDetails, raw?.artists_detail, raw?.artists
  );
  const artistDetails = buildArtistDetails(artistNames, artistIds, artistUrls);
  return {
    title: meaningfulText(metadata.title || metadata.name || metadata.trackName || raw?.title || raw?.name) || 'Tanpa Judul',
    artist: normalizeArtistValue(metadata.artist, metadata.artistName, metadata.artists, metadata.author, raw?.artist, raw?.artistName, raw?.artists, raw?.author),
    artistNames,
    duration: meaningfulText(metadata.duration || metadata.durationText || raw?.duration || raw?.durationText) || '0:00',
    thumbnail: enhanceArtworkUrl(metadata.thumbnail || metadata.cover || metadata.image || metadata.artwork || raw?.thumbnail || raw?.cover || raw?.image || raw?.artwork || 'assets/placeholder.svg'),
    popularity: Number(metadata.popularity ?? raw?.popularity ?? 0),
    album: meaningfulText(albumValue || metadata.collectionName || rawAlbumValue || raw?.collectionName),
    release_date: metadata.release_date || metadata.releaseDate || metadata.date || raw?.release_date || raw?.releaseDate || '',
    url: spotifyUrl || metadata.link || metadata.url || raw?.link || raw?.url || (id && /^[A-Za-z0-9]{22}$/.test(String(id)) ? `https://open.spotify.com/track/${id}` : ''),
    audioUrl: raw?.audioUrl || metadata.audioUrl || '',
    downloadUrl: raw?.downloadUrl || metadata.downloadUrl || raw?.download || metadata.download || '',
    source: raw?.source || metadata.source || '',
    sourceUrl: raw?.sourceUrl || metadata.sourceUrl || '',
    previewUrl: raw?.previewUrl || metadata.previewUrl || '',
    audioIsPreview: Boolean(raw?.audioIsPreview || metadata.audioIsPreview),
    audioResolvedAt: Number(raw?.audioResolvedAt || metadata.audioResolvedAt || 0),
    metadataResolvedAt: Number(raw?.metadataResolvedAt || metadata.metadataResolvedAt || 0),
    syncedLyricsPayload: raw?.syncedLyricsPayload ?? metadata.syncedLyricsPayload ?? '',
    lyricsProvider: raw?.lyricsProvider || metadata.lyricsProvider || '',
    genre: raw?.genre || metadata.genre || '',
    rank: Number(raw?.rank || metadata.rank || 0),
    artistId: artistIds[0] || '',
    artistIds,
    artistUrls,
    artistDetails,
    id
  };
}
function dedupeTracks(list) {
  const map = new Map();
  list.map(normalizeTrack).forEach(item => {
    const key = trackKey(item);
    if (key && !map.has(key)) map.set(key, item);
  });
  return [...map.values()];
}
function greeting() {
  const h = new Date().getHours();
  if (h < 11) return 'Selamat Pagi';
  if (h < 15) return 'Selamat Siang';
  if (h < 18) return 'Selamat Sore';
  return 'Selamat Malam';
}
function formatTime(seconds) {
  if (!Number.isFinite(seconds) || seconds < 0) return '0:00';
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60).toString().padStart(2, '0');
  return `${m}:${s}`;
}
function durationSeconds(value) {
  if (typeof value === 'number') return value > 10000 ? value / 1000 : value;
  const parts = String(value || '').split(':').map(Number);
  return parts.length === 2 && parts.every(Number.isFinite) ? parts[0] * 60 + parts[1] : 0;
}


function normalizeMatchText(value = '') {
  return String(value)
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLocaleLowerCase('id')
    .replace(/\b(official|music|video|audio|lyrics?|lyric video|visualizer)\b/g, ' ')
    .replace(/[()[\]{}'"`~!@#$%^&*_+=|\\/:;,.?<>-]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function artistParts(value = '') {
  return normalizeMatchText(value)
    .split(/\s*(?:,|&| x | feat | featuring | ft )\s*/)
    .map(item => item.trim())
    .filter(Boolean);
}

function artistDisplayParts(value = '', expectedCount = 0) {
  const raw = String(value || '').trim();
  if (!raw) return [];
  let parts = raw
    .split(/\s+(?:feat\.?|featuring|ft\.?)\s+|\s+&\s+|\s+[x×]\s+/i)
    .map(item => item.trim())
    .filter(Boolean);
  if (Number(expectedCount) > parts.length && raw.includes(',')) {
    const commaParts = raw.split(/\s*,\s*/).map(item => item.trim()).filter(Boolean);
    if (commaParts.length >= Math.min(2, Number(expectedCount))) parts = commaParts;
  }
  return [...new Set(parts)];
}

function artistCreditEntries(track = state.current) {
  const normalized = track ? normalizeTrack(track) : null;
  if (!normalized) return [];
  const ids = extractSpotifyArtistIds(normalized.artistIds, normalized.artistId, normalized.artistDetails, track?.artists_detail, track?.artists);
  const urls = extractSpotifyArtistUrls(normalized.artistUrls, normalized.artistDetails, track?.artists_detail, track?.artists);
  const explicitNames = extractArtistNames(normalized.artistNames, normalized.artistDetails, track?.artistNames, track?.artists_detail, track?.artists);
  const names = explicitNames.length ? explicitNames : artistDisplayParts(normalized.artist, Math.max(ids.length, urls.length));
  return names.map((name, index) => ({
    name,
    id: ids[index] || '',
    url: urls[index] || (ids[index] ? `https://open.spotify.com/artist/${ids[index]}` : '')
  }));
}

function primaryArtistName(track = state.current) {
  return artistCreditEntries(track)[0]?.name || String(track?.artist || '').trim();
}

function sanitizePlaybackTrack(track) {
  const normalized = normalizeTrack(track);
  const previewSource = normalized.audioIsPreview || /preview|itunes/i.test(String(normalized.source || ''));
  return normalizeTrack({
    ...normalized,
    audioUrl: previewSource ? '' : normalized.audioUrl,
    previewUrl: '',
    audioIsPreview: false
  });
}

function collectPrimaryTrackCandidates(payload, output = [], depth = 0, seen = new Set()) {
  if (payload == null || depth > 6 || typeof payload !== 'object') return output;
  if (seen.has(payload)) return output;
  seen.add(payload);
  if (Array.isArray(payload)) {
    payload.forEach(item => collectPrimaryTrackCandidates(item, output, depth + 1, seen));
    return output;
  }
  const looksLikeTrack = Boolean(
    (payload.title || payload.name || payload.trackName || payload.track_name || payload.songName || payload.song_name) &&
    (payload.artist || payload.artistName || payload.artist_name || payload.artists || payload.author || payload.album || payload.spotifyUrl || payload.spotify_url || payload.spotify || payload.spotifyLink || payload.spotify_link || payload.trackUrl || payload.track_url || payload.external_urls || payload.link || payload.url || payload.thumbnail || payload.cover || payload.coverUrl || payload.cover_url || payload.image)
  );
  if (looksLikeTrack) output.push(payload);
  ['result', 'data', 'results', 'tracks', 'items', 'songs', 'list', 'music', 'musics', 'entries'].forEach(key => {
    if (payload[key] != null) collectPrimaryTrackCandidates(payload[key], output, depth + 1, seen);
  });
  return output;
}

function normalizePrimaryTrackCandidate(raw) {
  const spotifyArtistObjects = Array.isArray(raw?.artists) && raw.artists.some(item => item && typeof item === 'object');
  if (spotifyArtistObjects || raw?.external_urls?.spotify || (raw?.duration_ms && raw?.album?.images)) return normalizeSpotifyTrack(raw);
  const artistValue = Array.isArray(raw?.artists)
    ? raw.artists.map(item => typeof item === 'string' ? item : item?.name).filter(Boolean).join(', ')
    : (raw?.artists?.name || raw?.artist || raw?.artistName || raw?.artist_name || raw?.author || '');
  const albumValue = typeof raw?.album === 'object' ? raw.album?.name : raw?.album;
  return normalizeTrack({
    ...raw,
    title: raw?.title || raw?.name || raw?.trackName || raw?.track_name || raw?.songName || raw?.song_name,
    artist: artistValue,
    artistIds: extractSpotifyArtistIds(raw?.artistIds, raw?.artist_ids, raw?.artistId, raw?.artist_id, raw?.spotifyArtistId, raw?.artists),
    artistId: extractSpotifyArtistIds(raw?.artistIds, raw?.artist_ids, raw?.artistId, raw?.artist_id, raw?.spotifyArtistId, raw?.artists)[0] || '',
    duration: raw?.duration_ms ? formatTime(raw.duration_ms / 1000) : raw?.trackTimeMillis ? formatTime(raw.trackTimeMillis / 1000) : (raw?.duration || raw?.length),
    thumbnail: raw?.thumbnail || raw?.thumbnailUrl || raw?.thumbnail_url || raw?.cover || raw?.coverUrl || raw?.cover_url || raw?.albumCover || raw?.album_cover || raw?.cover?.url || raw?.image?.url || raw?.images?.[0]?.url || raw?.image || raw?.imageUrl || raw?.image_url || raw?.artwork || raw?.artworkUrl100 || raw?.album?.images?.[0]?.url || raw?.album?.image || raw?.album?.cover,
    album: albumValue || raw?.collectionName,
    release_date: raw?.release_date || raw?.releaseDate || raw?.release || raw?.date,
    url: raw?.spotifyUrl || raw?.spotify_url || raw?.spotify || raw?.spotifyLink || raw?.spotify_link || raw?.trackUrl || raw?.track_url || raw?.external_urls?.spotify || raw?.link || raw?.url || (raw?.id ? `https://open.spotify.com/track/${raw.id}` : '')
  });
}

function primaryTrackMatchScore(candidate, target) {
  const candidateTitle = normalizeMatchText(cleanTitle(candidate));
  const targetTitle = normalizeMatchText(cleanTitle(target));
  const candidateArtists = artistParts(candidate.artist);
  const targetArtists = artistParts(target.artist);
  let score = 0;
  if (candidateTitle && targetTitle) {
    if (candidateTitle === targetTitle) score += 90;
    else if (candidateTitle.includes(targetTitle) || targetTitle.includes(candidateTitle)) score += 58;
    else {
      const targetTokens = new Set(targetTitle.split(' ').filter(Boolean));
      const shared = candidateTitle.split(' ').filter(token => targetTokens.has(token)).length;
      score += Math.min(40, shared * 10);
    }
  }
  if (candidateArtists.length && targetArtists.length) {
    if (candidateArtists.some(item => targetArtists.includes(item))) score += 55;
    else if (candidateArtists.some(item => targetArtists.some(targetArtist => item.includes(targetArtist) || targetArtist.includes(item)))) score += 34;
  }
  const candidateDuration = durationSeconds(candidate.duration);
  const targetDuration = durationSeconds(target.duration);
  if (candidateDuration > 35 && targetDuration > 35) {
    const diff = Math.abs(candidateDuration - targetDuration);
    if (diff <= 3) score += 18;
    else if (diff <= 8) score += 10;
  }
  if (candidate.album && target.album && normalizeMatchText(candidate.album) === normalizeMatchText(target.album)) score += 10;
  return score;
}

function mergePrimaryTrackMetadata(originalTrack, primaryTrack, extra = {}) {
  const original = normalizeTrack(originalTrack);
  const primary = normalizeTrack(primaryTrack);
  const primaryDuration = durationSeconds(primary.duration);
  const originalDuration = durationSeconds(original.duration);
  const preferredArtist = !isUnknownArtist(primary.artist) ? primary.artist : original.artist;
  const preferredTitle = meaningfulText(primary.title) && primary.title !== 'Tanpa Judul' ? primary.title : original.title;
  const preferredCover = primary.thumbnail && !String(primary.thumbnail).includes('placeholder') ? primary.thumbnail : original.thumbnail;
  return normalizeTrack({
    ...original,
    ...primary,
    ...extra,
    title: preferredTitle,
    artist: preferredArtist,
    duration: primaryDuration > 30 ? primary.duration : originalDuration > 30 ? original.duration : primary.duration,
    thumbnail: preferredCover,
    album: meaningfulText(primary.album) || meaningfulText(original.album),
    release_date: primary.release_date || original.release_date,
    url: spotifyTrackUrl(primary) || spotifyTrackUrl(original) || primary.url || original.url,
    id: primary.id || original.id,
    source: extra.source || primary.source || original.source || 'Spotify Audio Provider',
    audioUrl: extra.audioUrl || primary.audioUrl || original.audioUrl || '',
    audioResolvedAt: Number(extra.audioResolvedAt || primary.audioResolvedAt || original.audioResolvedAt || 0),
    metadataResolvedAt: Number(extra.metadataResolvedAt || primary.metadataResolvedAt || original.metadataResolvedAt || Date.now()),
    previewUrl: '',
    audioIsPreview: false
  });
}

function parseSylvaticaSpotifyPackage(data, requestedSpotifyUrl = '') {
  const result = data?.result || data?.data || {};
  const metadata = result?.metadata || data?.metadata || {};
  const links = result?.links || data?.links || {};
  const audioUrl = links?.mp3 || links?.audio || links?.download || findMediaUrl(result) || findMediaUrl(data);
  const spotifyUrl = metadata?.spotifyUrl || metadata?.spotify_url || metadata?.spotify || requestedSpotifyUrl;
  const now = Date.now();
  const track = normalizeTrack({
    title: metadata?.name || metadata?.title || metadata?.trackName,
    artist: metadata?.artist || metadata?.artistName || metadata?.artists,
    album: metadata?.album,
    thumbnail: metadata?.cover || metadata?.thumbnail || metadata?.image || links?.cover,
    duration: metadata?.duration || metadata?.durationText,
    release_date: metadata?.date || metadata?.release_date || metadata?.releaseDate,
    url: spotifyUrl,
    id: metadata?.tid || metadata?.id,
    audioUrl,
    downloadUrl: audioUrl,
    audioResolvedAt: audioUrl ? now : 0,
    metadataResolvedAt: now,
    source: 'Sylvatica Spotify Downloader',
    sourceUrl: spotifyUrl,
    previewUrl: '',
    audioIsPreview: false
  });
  return { raw: data, track, audioUrl, spotifyUrl: spotifyTrackUrl(track) || spotifyUrl };
}

async function fetchSylvaticaSpotifyPackage(spotifyUrl, options = {}) {
  if (!CONFIG.sylvaticaAudioEnabled) {
    const error = new Error('Sylvatica audio dinonaktifkan sementara');
    error.disabledProvider = true;
    error.nonRotatable = true;
    throw error;
  }
  const normalizedUrl = String(spotifyUrl || '').trim();
  if (!/open\.spotify\.com\/track\//i.test(normalizedUrl)) throw new Error('Link Spotify lagu tidak tersedia');
  const force = Boolean(options.force);
  const cached = sylvaticaDownloaderCache.get(normalizedUrl);
  if (!force && cached && Date.now() - cached.at < SYLVATICA_PACKAGE_CACHE_MS) return await cached.value;
  const recentFailure = sylvaticaDownloaderFailureCache.get(normalizedUrl);
  if (!force && recentFailure && Date.now() - recentFailure.at < SYLVATICA_FAILURE_CACHE_MS) throw recentFailure.error;

  const request = (async () => {
    const data = await sylvaticaApiFetch('download', { url: normalizedUrl }, 32000, 'Sylvatica Spotify');
    const parsed = parseSylvaticaSpotifyPackage(data, normalizedUrl);
    if (!parsed.spotifyUrl) parsed.spotifyUrl = normalizedUrl;
    if (!parsed.audioUrl) throw new Error('Sylvatica tidak mengirim URL audio');
    return parsed;
  })();

  sylvaticaDownloaderCache.set(normalizedUrl, { at: Date.now(), value: request });
  try {
    const value = await request;
    sylvaticaDownloaderFailureCache.delete(normalizedUrl);
    sylvaticaDownloaderCache.set(normalizedUrl, { at: Date.now(), value: Promise.resolve(value) });
    return value;
  } catch (error) {
    sylvaticaDownloaderCache.delete(normalizedUrl);
    sylvaticaDownloaderFailureCache.set(normalizedUrl, { at: Date.now(), error });
    throw error;
  }
}

function firstHttpUrl(...values) {
  for (const value of values) {
    if (typeof value === 'string' && /^https?:\/\//i.test(value.trim())) return value.trim();
  }
  return '';
}

function parseExternalSpotifyPackage(data, requestedSpotifyUrl = '', providerLabel = 'Spotify Provider') {
  const result = data?.result || data?.data || data || {};
  const metadata = result?.metadata || data?.metadata || result?.track || result?.song || result || {};
  const links = result?.links || data?.links || result?.download || result || {};
  const audioUrl = firstHttpUrl(links?.mp3, links?.audio, links?.audioUrl, links?.audio_url, links?.download, links?.downloadUrl, links?.download_url, links?.play, links?.playUrl, links?.play_url, links?.url) || findMediaUrl(result) || findMediaUrl(data);
  const spotifyUrl = metadata?.spotifyUrl || metadata?.spotify_url || metadata?.spotify || metadata?.external_urls?.spotify || result?.spotifyUrl || result?.spotify_url || result?.spotify || requestedSpotifyUrl;
  const now = Date.now();
  const track = normalizeTrack({
    ...metadata,
    title: metadata?.name || metadata?.title || metadata?.trackName || result?.name || result?.title,
    artist: metadata?.artist || metadata?.artistName || metadata?.artists || result?.artist || result?.artists,
    artistIds: extractSpotifyArtistIds(metadata?.artistIds, metadata?.artist_ids, metadata?.artistId, metadata?.artist_id, metadata?.artists, result?.artistIds, result?.artist_id, result?.artists),
    album: metadata?.album || result?.album,
    thumbnail: metadata?.cover || metadata?.cover_url || metadata?.thumbnail || metadata?.image || metadata?.image_url || metadata?.artwork || result?.cover || result?.cover_url || result?.thumbnail || result?.image || result?.image_url || links?.cover || links?.cover_url || data?.cover || data?.cover_url,
    duration: metadata?.duration_ms ? formatTime(Number(metadata.duration_ms) / 1000) : (result?.duration_ms ? formatTime(Number(result.duration_ms) / 1000) : (metadata?.duration || metadata?.durationText || result?.duration)),
    release_date: metadata?.date || metadata?.release_date || metadata?.releaseDate || result?.release_date,
    url: spotifyUrl,
    id: metadata?.tid || metadata?.id || result?.id,
    audioUrl,
    downloadUrl: audioUrl,
    audioResolvedAt: audioUrl ? now : 0,
    metadataResolvedAt: now,
    source: providerLabel,
    sourceUrl: spotifyUrl,
    previewUrl: '',
    audioIsPreview: false
  });
  return { raw: data, track, audioUrl, spotifyUrl: spotifyTrackUrl(track) || spotifyUrl };
}

async function fetchExternalSpotifyPackage(providerKey, spotifyUrl, options = {}) {
  const specs = {
    bintang: { enabled: CONFIG.bintangAudioEnabled, base: CONFIG.bintangApiBase, path: CONFIG.bintangDownloadPath, label: 'Bintang API Spotify', params: url => ({ url }), timeout: 22000 },
    ikyy: { enabled: CONFIG.ikyyAudioEnabled, base: CONFIG.ikyyApiBase, path: CONFIG.ikyyDownloadPath, label: 'Ikyy Spotify Downloader', params: url => ({ url }), timeout: 22000 },
    jerev3: { enabled: CONFIG.jereAudioEnabled, base: CONFIG.jereApiBase, path: CONFIG.jereDownloadPaths[0], label: 'Jere Spotify V3', params: url => ({ apikey: CONFIG.jereApiKey, url }), timeout: 22000 },
    jerev2: { enabled: CONFIG.jereAudioEnabled, base: CONFIG.jereApiBase, path: CONFIG.jereDownloadPaths[1], label: 'Jere Spotify V2', params: url => ({ apikey: CONFIG.jereApiKey, url }), timeout: 22000 },
    jere: { enabled: CONFIG.jereAudioEnabled, base: CONFIG.jereApiBase, path: CONFIG.jereDownloadPaths[2], label: 'Jere Spotify', params: url => ({ apikey: CONFIG.jereApiKey, url }), timeout: 22000 }
  };
  const spec = specs[providerKey];
  if (!spec?.enabled) {
    const error = new Error(`${spec?.label || providerKey} dinonaktifkan sementara`);
    error.disabledProvider = true;
    throw error;
  }
  const normalizedUrl = String(spotifyUrl || '').trim();
  if (!/open\.spotify\.com\/track\//i.test(normalizedUrl)) throw new Error('Link Spotify lagu tidak tersedia');
  const force = Boolean(options.force);
  const cacheKey = `${providerKey}|${normalizedUrl}`;
  const cached = externalDownloaderCache.get(cacheKey);
  if (!force && cached && Date.now() - cached.at < EXTERNAL_PROVIDER_CACHE_MS) return await cached.value;
  const recentFailure = externalDownloaderFailureCache.get(cacheKey);
  if (!force && recentFailure && Date.now() - recentFailure.at < EXTERNAL_PROVIDER_FAILURE_CACHE_MS) throw recentFailure.error;
  const request = (async () => {
    const data = await externalApiFetch(spec.base, spec.path, spec.params(normalizedUrl), spec.timeout, spec.label);
    const parsed = parseExternalSpotifyPackage(data, normalizedUrl, spec.label);
    if (!parsed.audioUrl) throw new Error(`${spec.label} tidak mengirim URL audio`);
    return parsed;
  })();
  externalDownloaderCache.set(cacheKey, { at: Date.now(), value: request });
  try {
    const value = await request;
    externalDownloaderFailureCache.delete(cacheKey);
    externalDownloaderCache.set(cacheKey, { at: Date.now(), value: Promise.resolve(value) });
    return value;
  } catch (error) {
    externalDownloaderCache.delete(cacheKey);
    externalDownloaderFailureCache.set(cacheKey, { at: Date.now(), error });
    throw error;
  }
}

function audioProviderOrder() {
  const defaults = ['theresav', 'cmnty', 'sylvatica', 'sylvatica-spotyloader', 'bintang', 'ikyy', 'jerev3', 'jerev2', 'jere'];
  const preferred = String(CONFIG.primaryAudioProvider || 'theresav').toLowerCase();
  return [preferred, ...defaults.filter(provider => provider !== preferred)];
}

function activeAudioProviderLabel() {
  const labels = [];
  audioProviderOrder().forEach(provider => {
    if (provider === 'theresav' && CONFIG.theresavAudioEnabled) labels.push('Theresav Spotify');
    if (provider === 'sylvatica' && CONFIG.sylvaticaAudioEnabled) labels.push('Sylvatica Spotify');
    if (provider === 'sylvatica-spotyloader' && CONFIG.sylvaticaSpotyloaderEnabled) labels.push('Sylvatica Spotyloader');
    if (provider === 'bintang' && CONFIG.bintangAudioEnabled) labels.push('Bintang API');
    if (provider === 'ikyy' && CONFIG.ikyyAudioEnabled) labels.push('Ikyy API');
    if (/^jere/.test(provider) && CONFIG.jereAudioEnabled && !labels.includes('Jere API')) labels.push('Jere API');
    if (provider === 'cmnty' && CONFIG.cmntyAudioEnabled) labels.push('CMNTY Spotify');
  });
  return labels.join(' • ') || 'Tidak ada provider audio aktif';
}

function audioSourceEnabled(source = '') {
  const text = String(source || '');
  if (/Theresav/i.test(text)) return CONFIG.theresavAudioEnabled;
  if (/CMNTY/i.test(text)) return CONFIG.cmntyAudioEnabled;
  if (/Sylvatica Spotyloader/i.test(text)) return CONFIG.sylvaticaSpotyloaderEnabled;
  if (/Sylvatica/i.test(text)) return CONFIG.sylvaticaAudioEnabled;
  if (/Bintang/i.test(text)) return CONFIG.bintangAudioEnabled;
  if (/Ikyy/i.test(text)) return CONFIG.ikyyAudioEnabled;
  if (/Jere/i.test(text)) return CONFIG.jereAudioEnabled;
  return true;
}

function firstSuccessfulProvider(tasks, errors = []) {
  const activeTasks = tasks.filter(task => typeof task?.run === 'function');
  if (!activeTasks.length) return Promise.reject(new Error('Tidak ada provider cadangan yang aktif'));
  return new Promise((resolve, reject) => {
    let pending = activeTasks.length;
    let settled = false;
    activeTasks.forEach(task => {
      Promise.resolve()
        .then(task.run)
        .then(value => {
          if (settled) return;
          settled = true;
          resolve(value);
        })
        .catch(error => {
          errors.push(error?.message || `${task.name || 'Provider'} gagal`);
          pending -= 1;
          if (!pending && !settled) reject(new Error(errors.at(-1) || 'Semua provider cadangan gagal'));
        });
    });
  });
}

function findDeepFirst(payload, keys = [], depth = 0, seen = new Set()) {
  if (payload == null || depth > 10 || typeof payload !== 'object') return undefined;
  if (seen.has(payload)) return undefined;
  seen.add(payload);
  const wanted = new Set(keys.map(key => String(key).toLowerCase()));
  if (!Array.isArray(payload)) {
    for (const [key, value] of Object.entries(payload)) {
      if (wanted.has(String(key).toLowerCase()) && value !== undefined && value !== null && value !== '') return value;
    }
  }
  for (const child of (Array.isArray(payload) ? payload : Object.values(payload))) {
    const found = findDeepFirst(child, keys, depth + 1, seen);
    if (found !== undefined) return found;
  }
  return undefined;
}

function normalizeTheresavTrackCandidate(raw = {}, requestedSpotifyUrl = '') {
  const base = raw?.metadata || raw?.track || raw?.song || raw?.info || raw || {};
  const detailSource = base?.artists_detail || base?.artist_details || raw?.artists_detail || raw?.artist_details || [];
  const artistNames = extractArtistNames(detailSource, base?.artists, raw?.artists, base?.artist, raw?.artist);
  const artistIds = extractSpotifyArtistIds(detailSource, base?.artistIds, base?.artist_ids, raw?.artistIds, raw?.artist_ids);
  const artistUrls = extractSpotifyArtistUrls(detailSource, base?.artistUrls, base?.artist_urls, raw?.artistUrls, raw?.artist_urls);
  const candidate = normalizePrimaryTrackCandidate({
    ...raw, ...base,
    title: base?.title || base?.name || base?.trackName || base?.track_name || base?.songName || base?.song_name || raw?.title || raw?.name,
    artist: artistNames.join(', ') || base?.artist || base?.artistName || base?.artist_name || base?.artists || raw?.artist || raw?.artists,
    artistNames,
    artistIds,
    artistId: artistIds[0] || '',
    artistUrls,
    artistDetails: buildArtistDetails(artistNames, artistIds, artistUrls),
    artists_detail: detailSource,
    thumbnail: base?.thumbnail || base?.thumbnailUrl || base?.thumbnail_url || base?.cover || base?.coverUrl || base?.cover_url || base?.albumCover || base?.album_cover || base?.cover?.url || base?.image?.url || base?.images?.[0]?.url || base?.album?.cover || base?.album?.image || base?.image || base?.imageUrl || base?.image_url || base?.artwork || base?.album?.images?.[0]?.url || raw?.thumbnail || raw?.cover || raw?.image,
    duration: base?.duration || base?.durationText || base?.duration_text || raw?.duration,
    duration_ms: base?.duration_ms || base?.durationMs || raw?.duration_ms,
    album: base?.album || base?.albumName || base?.album_name || raw?.album,
    spotifyUrl: base?.spotifyUrl || base?.spotify_url || base?.spotify || base?.spotifyLink || base?.spotify_link || base?.trackUrl || base?.track_url || base?.external_urls?.spotify || raw?.spotifyUrl || raw?.spotify_url || requestedSpotifyUrl,
    id: base?.id || base?.trackId || base?.track_id || base?.spotifyId || base?.spotify_id || raw?.id
  });
  return normalizeTrack({ ...candidate, artistNames, artistIds, artistUrls, artistDetails: buildArtistDetails(artistNames, artistIds, artistUrls), source: 'Theresav Spotify' });
}

function parseTheresavSpotifyPackage(data, requestedSpotifyUrl = '') {
  const roots = [data?.result, data?.data, data?.track, data?.song, data].filter(Boolean);
  let track = null;
  for (const root of roots) {
    const parsed = normalizeTheresavTrackCandidate(root, requestedSpotifyUrl);
    if ((parsed.title && parsed.title !== 'Tanpa Judul') || !isUnknownArtist(parsed.artist) || !String(parsed.thumbnail).includes('placeholder.svg')) { track = parsed; break; }
  }
  track = track || normalizeTheresavTrackCandidate({}, requestedSpotifyUrl);
  const audioUrl = firstHttpUrl(
    findDeepFirst(data, ['downloadUrl','download_url','audioUrl','audio_url','mp3Url','mp3_url','streamUrl','stream_url','playUrl','play_url']),
    findDeepFirst(data, ['download','audio','mp3','stream','play'])
  ) || findMediaUrl(data);
  const cover = firstHttpUrl(findDeepFirst(data, ['cover','coverUrl','cover_url','coverImage','cover_image','thumbnail','thumbnailUrl','thumbnail_url','image','imageUrl','image_url','albumImage','album_image','artwork'])) || track.thumbnail;
  const spotifyUrl = firstHttpUrl(findDeepFirst(data, ['spotifyUrl','spotify_url','spotifyLink','spotify_link','trackUrl','track_url'])) || spotifyTrackUrl(track) || requestedSpotifyUrl;
  const lyricPayload = extractLyricsPayload(data);
  const syncedLyrics = lyricPayload && payloadHasTimestamps(lyricPayload, durationSeconds(track.duration)) ? lyricPayload : '';
  const now = Date.now();
  track = normalizeTrack({
    ...track,
    thumbnail: cover || track.thumbnail,
    url: spotifyUrl || requestedSpotifyUrl,
    audioUrl,
    downloadUrl: audioUrl,
    audioResolvedAt: audioUrl ? now : 0,
    metadataResolvedAt: now,
    syncedLyricsPayload: syncedLyrics,
    lyricsProvider: syncedLyrics ? 'Theresav Synced Lyrics' : '',
    source: 'Theresav Spotify Downloader',
    previewUrl: '', audioIsPreview: false
  });
  return { raw: data, track, audioUrl, spotifyUrl: spotifyTrackUrl(track) || requestedSpotifyUrl, syncedLyricsPayload: syncedLyrics };
}

async function theresavApiFetch(kind, params = {}, timeout = CONFIG.requestTimeout) {
  const safeKind = kind === 'download' ? 'download' : 'search';
  const url = new URL(CONFIG.theresavProxyBase, location.origin);
  url.searchParams.set('action', safeKind);
  Object.entries(params).forEach(([key, value]) => { if (value !== undefined && value !== null && value !== '') url.searchParams.set(key, value); });
  const provider = safeKind === 'download' ? 'Theresav Spotify Downloader' : 'Theresav Spotify Search';
  const activityId = beginSystemActivity(safeKind === 'download' ? 'Menyiapkan metadata dan audio' : 'Mencari lagu', `Menghubungi ${provider}`, provider, { track: params.query || params.url || '' });
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);
  try {
    const response = await fetch(url, { headers: { Accept:'application/json' }, signal: controller.signal, cache:'no-store' });
    const raw = await response.text();
    let data = {};
    try { data = raw ? JSON.parse(raw) : {}; } catch { data = { message: raw }; }
    if (payloadRejected(response, data)) throw new Error(apiFailureMessage(response, data, provider));
    finishSystemActivity(activityId, 'success', `${provider} berhasil merespons`);
    return data;
  } catch (error) {
    const message = error?.name === 'AbortError' ? `${provider} terlalu lama merespons` : (error?.message || `${provider} gagal`);
    finishSystemActivity(activityId, 'error', message);
    throw new Error(message);
  } finally { clearTimeout(timer); }
}

async function fetchTheresavSpotifyPackage(spotifyUrl, options = {}) {
  if (!CONFIG.theresavAudioEnabled) throw new Error('Theresav audio dinonaktifkan sementara');
  const normalizedUrl = String(spotifyUrl || '').trim();
  if (!/open\.spotify\.com\/track\//i.test(normalizedUrl)) throw new Error('Link Spotify lagu tidak tersedia');
  const force = Boolean(options.force);
  const cached = theresavDownloaderCache.get(normalizedUrl);
  if (!force && cached && Date.now() - cached.at < THERESAV_PACKAGE_CACHE_MS) return await cached.value;
  const recentFailure = theresavDownloaderFailureCache.get(normalizedUrl);
  if (!force && recentFailure && Date.now() - recentFailure.at < THERESAV_FAILURE_CACHE_MS) throw recentFailure.error;
  const request = (async () => {
    const data = await theresavApiFetch('download', { url: normalizedUrl }, 45000);
    const parsed = parseTheresavSpotifyPackage(data, normalizedUrl);
    if (!parsed.audioUrl) throw new Error('Theresav tidak mengirim URL audio penuh');
    return parsed;
  })();
  theresavDownloaderCache.set(normalizedUrl, { at: Date.now(), value: request });
  try {
    const value = await request;
    theresavDownloaderFailureCache.delete(normalizedUrl);
    theresavDownloaderCache.set(normalizedUrl, { at: Date.now(), value: Promise.resolve(value) });
    return value;
  } catch (error) {
    theresavDownloaderCache.delete(normalizedUrl);
    theresavDownloaderFailureCache.set(normalizedUrl, { at: Date.now(), error });
    throw error;
  }
}


async function sylvaticaSpotyloaderFetch(params = {}, timeout = 32000, provider = 'Sylvatica Spotyloader') {
  if (!CONFIG.sylvaticaSpotyloaderEnabled) throw new Error('Sylvatica Spotyloader dinonaktifkan');
  const url = new URL(CONFIG.sylvaticaSpotyloaderProxyPath, location.origin);
  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== '') url.searchParams.set(key, value);
  });
  const activityId = beginSystemActivity(
    String(params.type || '').toLowerCase() === 'artist' ? 'Memuat profil artis' : (String(params.type || '').toLowerCase() === 'search' ? 'Mencari lagu' : 'Menyiapkan metadata dan audio'),
    `Menghubungi ${provider}`,
    provider,
    { track: params.url || '' }
  );
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);
  try {
    const response = await fetch(url, { headers: { Accept:'application/json' }, signal: controller.signal, cache: String(params.type || '').toLowerCase() === 'artist' ? 'default' : 'no-store' });
    const raw = await response.text();
    let data = {};
    try { data = raw ? JSON.parse(raw) : {}; } catch { data = { message: raw }; }
    if (payloadRejected(response, data)) throw new Error(apiFailureMessage(response, data, provider));
    finishSystemActivity(activityId, 'success', `${provider} berhasil merespons`);
    return data;
  } catch (error) {
    const message = error?.name === 'AbortError' ? `${provider} terlalu lama merespons` : (error?.message || `${provider} gagal`);
    finishSystemActivity(activityId, 'error', message);
    throw new Error(message);
  } finally {
    clearTimeout(timer);
  }
}

async function sylvaticaApiFetch(kind, params = {}, timeout = 30000, provider = 'Sylvatica') {
  const paths = {
    download: CONFIG.sylvaticaDownloadProxyPath,
    search: CONFIG.sylvaticaSearchProxyPath,
    lyrics: CONFIG.sylvaticaLyricsProxyPath
  };
  const path = paths[kind];
  if (!path) throw new Error('Endpoint Sylvatica tidak dikenal');
  const url = new URL(path, location.origin);
  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== '') url.searchParams.set(key, value);
  });
  const activityId = beginSystemActivity(
    kind === 'lyrics' ? 'Mencari lirik' : kind === 'search' ? 'Mencari lagu' : 'Menyiapkan metadata dan audio',
    `Menghubungi ${provider}`,
    provider,
    { track: params.q || params.url || '' }
  );
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);
  try {
    const response = await fetch(url, { headers:{ Accept:'application/json' }, signal:controller.signal, cache:'no-store' });
    const raw = await response.text();
    let data = {};
    try { data = raw ? JSON.parse(raw) : {}; } catch { data = { message:raw }; }
    if (payloadRejected(response, data)) throw new Error(apiFailureMessage(response, data, provider));
    finishSystemActivity(activityId, 'success', `${provider} berhasil merespons`);
    return data;
  } catch (error) {
    const message = error?.name === 'AbortError' ? `${provider} terlalu lama merespons` : (error?.message || `${provider} gagal`);
    finishSystemActivity(activityId, 'error', message);
    throw new Error(message);
  } finally {
    clearTimeout(timer);
  }
}

function normalizeSylvaticaSpotyloaderTrack(raw = {}, fallbackArtist = '') {
  const artists = extractArtistNames(raw?.artistDetails, raw?.artists_detail, raw?.artists, raw?.artist, fallbackArtist);
  const artistIds = extractSpotifyArtistIds(raw?.artistDetails, raw?.artists_detail, raw?.artistIds, raw?.artist_ids, raw?.artists);
  const artistUrls = extractSpotifyArtistUrls(raw?.artistDetails, raw?.artists_detail, raw?.artistUrls, raw?.artist_urls, raw?.artists);
  const durationMs = Number(raw?.duration_ms || raw?.durationMs || 0);
  const spotifyUrl = raw?.url || raw?.spotifyUrl || raw?.spotify_url || raw?.external_urls?.spotify || '';
  return normalizeTrack({
    title: raw?.name || raw?.title || raw?.trackName || raw?.track_name,
    artist: raw?.artist || artists.join(', ') || fallbackArtist,
    artistNames: artists,
    artistIds,
    artistId: artistIds[0] || '',
    artistUrls,
    artistDetails: buildArtistDetails(artists, artistIds, artistUrls),
    duration: durationMs > 0 ? formatTime(durationMs / 1000) : (raw?.duration || raw?.durationText || ''),
    thumbnail: raw?.image || raw?.thumbnail || raw?.cover || raw?.artwork || 'assets/placeholder.svg',
    album: typeof raw?.album === 'object' ? raw.album?.name : raw?.album,
    release_date: raw?.release_date || raw?.releaseDate || '',
    url: spotifyUrl,
    id: raw?.id || raw?.trackId || raw?.track_id || '',
    previewUrl: raw?.preview_url || raw?.previewUrl || '',
    source: 'Sylvatica Spotyloader'
  });
}

function parseSylvaticaSpotyloaderTrackPackage(data, requestedSpotifyUrl = '') {
  const post = data?.result?.post || data?.result || data?.data?.post || data?.data || data || {};
  const candidates = [
    post?.track,
    post?.song,
    post?.metadata,
    post,
    ...(Array.isArray(post?.tracks) ? post.tracks : []),
    ...(Array.isArray(post?.top_tracks) ? post.top_tracks : [])
  ].filter(Boolean);
  let track = null;
  const requestedId = spotifyTrackIdFromValue(requestedSpotifyUrl);
  for (const raw of candidates) {
    const parsed = normalizeSylvaticaSpotyloaderTrack(raw);
    if (!track) track = parsed;
    if (requestedId && (parsed.id === requestedId || spotifyTrackIdFromTrack(parsed) === requestedId)) {
      track = parsed;
      break;
    }
  }
  track = track || normalizeTrack({ url: requestedSpotifyUrl, source: 'Sylvatica Spotyloader' });
  const audioUrl = firstHttpUrl(
    findDeepFirst(data, ['downloadUrl','download_url','audioUrl','audio_url','mp3Url','mp3_url','streamUrl','stream_url','playUrl','play_url','download_link','downloadLink']),
    findDeepFirst(data, ['download','audio','mp3','stream','play'])
  ) || findMediaUrl(data);
  const now = Date.now();
  track = normalizeTrack({
    ...track,
    url: spotifyTrackUrl(track) || requestedSpotifyUrl,
    audioUrl,
    downloadUrl: audioUrl,
    audioResolvedAt: audioUrl ? now : 0,
    metadataResolvedAt: now,
    source: 'Sylvatica Spotyloader',
    previewUrl: '',
    audioIsPreview: false
  });
  return { raw: data, track, audioUrl, spotifyUrl: spotifyTrackUrl(track) || requestedSpotifyUrl };
}

async function fetchSylvaticaSpotyloaderTrackPackage(spotifyUrl, options = {}) {
  if (!CONFIG.sylvaticaSpotyloaderEnabled) throw new Error('Sylvatica Spotyloader dinonaktifkan');
  const normalizedUrl = String(spotifyUrl || '').trim();
  if (!/open\.spotify\.com\/track\/[A-Za-z0-9]{22}/i.test(normalizedUrl)) throw new Error('Link Spotify lagu tidak tersedia');
  const key = `track:${normalizedUrl}`;
  const cached = !options.force ? sylvaticaSpotyloaderPackageCache.get(key) : null;
  if (cached && Date.now() - cached.at < 1000 * 60 * 20) return await cached.value;
  const request = (async () => {
    const data = await sylvaticaSpotyloaderFetch({ url: normalizedUrl, type:'track', format:'mp3' }, 45000);
    const parsed = parseSylvaticaSpotyloaderTrackPackage(data, normalizedUrl);
    if (!parsed.audioUrl) throw new Error('Sylvatica Spotyloader tidak mengirim URL audio penuh');
    return parsed;
  })();
  sylvaticaSpotyloaderPackageCache.set(key, { at: Date.now(), value: request });
  try {
    const result = await request;
    sylvaticaSpotyloaderPackageCache.set(key, { at: Date.now(), value: Promise.resolve(result) });
    return result;
  } catch (error) {
    sylvaticaSpotyloaderPackageCache.delete(key);
    throw error;
  }
}

function sylvaticaArtistTrackList(post = {}) {
  const list = Array.isArray(post?.top_tracks) ? post.top_tracks : (Array.isArray(post?.tracks) ? post.tracks : []);
  return dedupeTracks(list.map(item => normalizeSylvaticaSpotyloaderTrack(item, post?.name || ''))).slice(0, 30);
}

async function fetchSylvaticaSpotyloaderArtistProfile(name, seedTrack = null, force = false) {
  if (!CONFIG.sylvaticaSpotyloaderEnabled) return null;
  const artistName = String(name || '').trim();
  if (!artistName) return null;

  const wanted = normalizeMatchText(artistName);
  let contextTrack = seedTrack ? sanitizePlaybackTrack(seedTrack) : null;
  let credits = contextTrack ? artistCreditEntries(contextTrack) : [];
  let exactCredit = credits.find(item => normalizeMatchText(item.name) === wanted) || null;

  // Bila track berasal dari hasil search lama dan belum membawa artists_detail,
  // ambil ulang exact track package sekali. Ini penting agar profile artist selalu
  // dikunci ke Spotify Artist ID/URL, bukan pencarian nama yang rawan salah artis.
  if (contextTrack && !exactCredit?.url && !exactCredit?.id) {
    try {
      const exact = await resolveExactArtistContextTrack(contextTrack, force);
      if (exact) {
        contextTrack = exact;
        credits = artistCreditEntries(exact);
        exactCredit = credits.find(item => normalizeMatchText(item.name) === wanted) || null;
      }
    } catch {}
  }

  const directId = String(exactCredit?.id || '').trim();
  const directUrl = String(exactCredit?.url || (directId ? `https://open.spotify.com/artist/${directId}` : '')).trim();
  const lookup = directUrl || artistName;
  const cacheKey = directId || wanted;
  const cached = !force ? sylvaticaSpotyloaderArtistCache.get(cacheKey) : null;
  if (cached && Date.now() - cached.at < CONFIG.artistCacheMs) return await Promise.resolve(cached.value);

  const request = (async () => {
    const data = await sylvaticaSpotyloaderFetch({ url: lookup, type:'artist' }, 32000);
    const post = data?.result?.post || data?.result || data?.data?.post || data?.data || null;
    if (!post || String(post?.type || 'artist').toLowerCase() !== 'artist') throw new Error('Sylvatica tidak mengirim profil artis yang valid');

    const responseName = String(post?.name || artistName).trim();
    const responseId = String(post?.id || directId || '').trim();
    // Kalau lookup terpaksa memakai nama, jangan menerima hasil artis lain.
    if (!directUrl && normalizeMatchText(responseName) !== wanted) {
      throw new Error(`Sylvatica mengembalikan artis berbeda: ${responseName}`);
    }
    if (directId && responseId && responseId !== directId) {
      throw new Error('Sylvatica mengembalikan Spotify Artist ID yang berbeda');
    }

    let tracks = sylvaticaArtistTrackList(post);
    tracks = await enrichTracksWithSpotifyMeta(tracks, 12);
    const spotifyId = /^[A-Za-z0-9]{22}$/.test(responseId) ? responseId : directId;
    return {
      name: responseName,
      image: enhanceArtworkUrl(post?.image || post?.thumbnail || post?.cover || contextTrack?.thumbnail || 'assets/placeholder.svg'),
      spotifyId,
      spotifyUrl: post?.url || (spotifyId ? `https://open.spotify.com/artist/${spotifyId}` : directUrl),
      tracks,
      source: 'Sylvatica Spotyloader Artist'
    };
  })();

  // Coalesce concurrent Home + Artist page requests supaya quota provider tidak terbuang.
  sylvaticaSpotyloaderArtistCache.set(cacheKey, { at: Date.now(), value: request });
  try {
    const profile = await request;
    sylvaticaSpotyloaderArtistCache.set(cacheKey, { at: Date.now(), value: profile });
    return profile;
  } catch (error) {
    sylvaticaSpotyloaderArtistCache.delete(cacheKey);
    throw error;
  }
}

async function enrichTrackWithSpotifyMeta(track) {
  const normalized = normalizeTrack(track);
  const id = spotifyTrackIdFromTrack(normalized);
  if (!id) return normalized;
  const meta = await Promise.race([
    fetchSpotifyTrackMeta(id),
    new Promise(resolve => setTimeout(() => resolve(null), 6500))
  ]).catch(() => null);
  if (!meta) return normalized;
  return normalizeTrack({
    ...normalized,
    id: meta.id || normalized.id,
    title: meta.name || meta.title || normalized.title,
    artist: Array.isArray(meta.artists) && meta.artists.length ? meta.artists.join(', ') : (meta.artist || normalized.artist),
    artistNames: Array.isArray(meta.artists) && meta.artists.length ? meta.artists : normalized.artistNames,
    duration: Number(meta.durationMs || meta.duration_ms || 0) > 0 ? formatTime(Number(meta.durationMs || meta.duration_ms) / 1000) : normalized.duration,
    thumbnail: enhanceArtworkUrl(meta.cover || meta.image || meta.thumbnail || normalized.thumbnail),
    album: meta.album || normalized.album,
    release_date: meta.releaseDate || meta.release_date || normalized.release_date,
    url: meta.spotifyUrl || normalized.url || `https://open.spotify.com/track/${id}`,
    source: normalized.source || 'Sylvatica Spotyloader Artist'
  });
}

async function enrichTracksWithSpotifyMeta(tracks, limit = 12) {
  const source = dedupeTracks(tracks || []).slice(0, Math.max(1, Number(limit) || 12));
  if (!source.length) return [];
  const result = new Array(source.length);
  let cursor = 0;
  const workers = Array.from({ length: Math.min(4, source.length) }, async () => {
    while (cursor < source.length) {
      const index = cursor++;
      result[index] = await enrichTrackWithSpotifyMeta(source[index]).catch(() => source[index]);
    }
  });
  await Promise.all(workers);
  return result.filter(Boolean);
}

async function resolveExactArtistContextTrack(track, force = false) {
  const normalized = sanitizePlaybackTrack(track);
  if (!normalized) return normalized;
  const existing = artistCreditEntries(normalized);
  if (existing.length && existing.every(item => item.id || item.url)) return normalized;
  const spotifyUrl = spotifyTrackUrl(normalized);
  if (!spotifyUrl) return normalized;
  try {
    const raw = await theresavApiFetch('download', { url: spotifyUrl }, 30000);
    const packageData = parseTheresavSpotifyPackage(raw, spotifyUrl);
    if (packageData?.track) return mergePrimaryTrackMetadata(normalized, packageData.track, {
      audioUrl: packageData.audioUrl || normalized.audioUrl,
      downloadUrl: packageData.audioUrl || normalized.downloadUrl,
      audioResolvedAt: packageData.audioUrl ? Date.now() : normalized.audioResolvedAt,
      metadataResolvedAt: Date.now(),
      source: packageData.track?.source || normalized.source
    });
  } catch {}
  try {
    const packageData = await fetchSylvaticaSpotyloaderTrackPackage(spotifyUrl, { force });
    if (packageData?.track) return mergePrimaryTrackMetadata(normalized, packageData.track, {
      audioUrl: packageData.audioUrl || normalized.audioUrl,
      downloadUrl: packageData.audioUrl || normalized.downloadUrl,
      audioResolvedAt: packageData.audioUrl ? Date.now() : normalized.audioResolvedAt,
      metadataResolvedAt: Date.now(),
      source: packageData.track?.source || normalized.source
    });
  } catch {}
  return normalized;
}


function collectSylvaticaSpotyloaderSearchTracks(payload, output = [], depth = 0, seen = new Set()) {
  if (payload == null || depth > 8 || typeof payload !== 'object' || seen.has(payload)) return output;
  seen.add(payload);
  if (Array.isArray(payload)) {
    payload.forEach(item => collectSylvaticaSpotyloaderSearchTracks(item, output, depth + 1, seen));
    return output;
  }

  const type = String(payload?.type || '').toLowerCase();
  const url = String(payload?.url || payload?.spotifyUrl || payload?.spotify_url || payload?.external_urls?.spotify || '');
  const looksTrack = type === 'track' || /open\.spotify\.com\/track\/[A-Za-z0-9]{22}/i.test(url);
  const explicitlyNonTrack = ['artist','album','playlist','search'].includes(type) && type !== 'track';
  if (looksTrack && !explicitlyNonTrack) output.push(normalizeSylvaticaSpotyloaderTrack(payload));

  for (const child of Object.values(payload)) {
    if (child && typeof child === 'object') collectSylvaticaSpotyloaderSearchTracks(child, output, depth + 1, seen);
  }
  return output;
}

async function fetchSearchSuggestions(query, limit = 8) {
  const clean = String(query || '').trim();
  if (clean.length < 2) return [];
  try {
    const url = new URL(CONFIG.searchSuggestPath, location.origin);
    url.searchParams.set('q', clean);
    url.searchParams.set('limit', String(Math.max(1, Math.min(12, Number(limit) || 8))));
    const response = await fetch(url, { headers:{ Accept:'application/json' }, cache:'no-store' });
    const data = await response.json();
    const list = Array.isArray(data?.suggestions) ? data.suggestions : [];
    return [...new Set(list.map(item => String(item || '').replace(/\s+/g, ' ').trim()).filter(Boolean))].slice(0, limit);
  } catch {
    return [];
  }
}

function mountSearchSuggestionController() {
  const input = $('#searchInput', view);
  const panel = $('#searchSuggestions', view);
  if (!input || !panel) return;
  let timer = null;
  let requestId = 0;

  const hide = () => {
    panel.classList.remove('show');
    panel.innerHTML = '';
  };
  const renderSuggestions = items => {
    if (!items.length || document.activeElement !== input) return hide();
    panel.innerHTML = items.map((item, index) => `<button type="button" class="search-suggestion-row" data-search-suggestion="${index}">${icon('search')}<span>${esc(item)}</span></button>`).join('');
    panel.classList.add('show');
    $$('[data-search-suggestion]', panel).forEach(button => button.onclick = () => {
      const value = items[Number(button.dataset.searchSuggestion)] || '';
      if (!value) return;
      state.searchQuery = value;
      hide();
      renderSearch();
      setTimeout(() => $('#searchForm', view)?.requestSubmit(), 0);
    });
  };
  const run = async () => {
    const query = input.value.trim();
    const id = ++requestId;
    if (query.length < 2) return hide();
    const suggestions = await fetchSearchSuggestions(query, 8);
    if (id !== requestId || input.value.trim() !== query) return;
    renderSuggestions(suggestions);
  };
  input.addEventListener('input', () => {
    clearTimeout(timer);
    timer = setTimeout(run, 180);
  });
  input.addEventListener('focus', () => {
    if (input.value.trim().length >= 2) {
      clearTimeout(timer);
      timer = setTimeout(run, 30);
    }
  });
  input.addEventListener('keydown', event => {
    if (event.key === 'Escape') hide();
  });
  input.addEventListener('blur', () => {
    window.setTimeout(() => {
      const active = document.activeElement;
      if (!active?.closest?.('.search-box-wrap')) hide();
    }, 140);
  });
}


async function fetchPrimarySpotifyPackage(spotifyUrl, options = {}) {
  const errors = [];

  // Theresav adalah provider utama untuk metadata, cover, audio penuh, download, dan lirik bertimestamp bawaan.
  if (CONFIG.theresavAudioEnabled) {
    try { return await fetchTheresavSpotifyPackage(spotifyUrl, options); }
    catch (error) { errors.push(error?.message || 'Theresav gagal'); }
  }

  // CMNTY menjadi fallback pertama setelah Theresav.
  if (CONFIG.cmntyAudioEnabled) {
    try { return await fetchCmntySpotifyPackage(spotifyUrl, options); }
    catch (error) { errors.push(error?.message || 'CMNTY gagal'); }
  }

  // Sylvatica menjadi fallback berikutnya ketika Theresav dan CMNTY gagal, kosong, atau sedang sibuk.
  if (CONFIG.sylvaticaAudioEnabled) {
    try { return await fetchSylvaticaSpotifyPackage(spotifyUrl, options); }
    catch (error) { errors.push(error?.message || 'Sylvatica gagal'); }
  }

  // Spotyloader baru menjadi fallback metadata/audio tambahan sebelum provider eksternal lain.
  if (CONFIG.sylvaticaSpotyloaderEnabled) {
    try { return await fetchSylvaticaSpotyloaderTrackPackage(spotifyUrl, options); }
    catch (error) { errors.push(error?.message || 'Sylvatica Spotyloader gagal'); }
  }

  // Bintang dan Ikyy dicoba bersamaan agar fallback tetap cepat.
  try {
    return await firstSuccessfulProvider([
      CONFIG.bintangAudioEnabled ? { name: 'Bintang API', run: () => fetchExternalSpotifyPackage('bintang', spotifyUrl, options) } : null,
      CONFIG.ikyyAudioEnabled ? { name: 'Ikyy API', run: () => fetchExternalSpotifyPackage('ikyy', spotifyUrl, options) } : null
    ].filter(Boolean), errors);
  } catch { /* Lanjut ke keluarga endpoint Jere. */ }

  // Ketiga versi Jere tetap menjadi lapisan fallback terakhir.
  try {
    return await firstSuccessfulProvider([
      CONFIG.jereAudioEnabled ? { name: 'Jere V3', run: () => fetchExternalSpotifyPackage('jerev3', spotifyUrl, options) } : null,
      CONFIG.jereAudioEnabled ? { name: 'Jere V2', run: () => fetchExternalSpotifyPackage('jerev2', spotifyUrl, options) } : null,
      CONFIG.jereAudioEnabled ? { name: 'Jere V1', run: () => fetchExternalSpotifyPackage('jere', spotifyUrl, options) } : null
    ].filter(Boolean), errors);
  } catch { /* Semua fallback penuh sudah dicoba. */ }

  const error = new Error('Semua sumber audio penuh sedang tidak tersedia. Tekan putar untuk mencoba lagi.');
  error.providerErrors = errors;
  throw error;
}

function parseCmntyDownloaderPackage(data, requestedSpotifyUrl = '') {
  const result = data?.result || data?.data || {};
  const metadata = result?.metadata || data?.metadata || {};
  const links = result?.links || data?.links || {};
  const audioUrl = links?.mp3 || links?.audio || links?.download || findMediaUrl(result) || findMediaUrl(data);
  const spotifyUrl = metadata?.spotifyUrl || metadata?.spotify_url || metadata?.spotify || requestedSpotifyUrl;
  const now = Date.now();
  const track = normalizeTrack({
    title: metadata?.name || metadata?.title || metadata?.trackName,
    artist: metadata?.artist || metadata?.artistName || metadata?.artists,
    album: metadata?.album,
    thumbnail: metadata?.cover || metadata?.thumbnail || metadata?.image,
    duration: metadata?.duration || metadata?.durationText,
    release_date: metadata?.date || metadata?.release_date || metadata?.releaseDate,
    url: spotifyUrl,
    id: metadata?.tid || metadata?.id,
    audioUrl,
    downloadUrl: audioUrl,
    audioResolvedAt: audioUrl ? now : 0,
    metadataResolvedAt: now,
    source: 'CMNTY Spotify Downloader',
    previewUrl: '',
    audioIsPreview: false
  });
  return { raw: data, track, audioUrl, spotifyUrl: spotifyTrackUrl(track) || spotifyUrl };
}

async function fetchCmntySpotifyPackage(spotifyUrl, options = {}) {
  if (!CONFIG.cmntyAudioEnabled) {
    const error = new Error('CMNTY audio dinonaktifkan sementara');
    error.disabledProvider = true;
    error.nonRotatable = true;
    throw error;
  }
  const normalizedUrl = String(spotifyUrl || '').trim();
  if (!/open\.spotify\.com\/track\//i.test(normalizedUrl)) throw new Error('Link Spotify lagu tidak tersedia');
  const force = Boolean(options.force);
  const cached = cmntyDownloaderCache.get(normalizedUrl);
  if (!force && cached && Date.now() - cached.at < CMNTY_PACKAGE_CACHE_MS) return cached.value;

  const recentFailure = cmntyDownloaderFailureCache.get(normalizedUrl);
  if (!force && recentFailure && Date.now() - recentFailure.at < CMNTY_FAILURE_CACHE_MS) {
    throw recentFailure.error;
  }

  const request = (async () => {
    const data = await apiFetch('/downloader/spotify', { query: normalizedUrl }, 55000);
    const parsed = parseCmntyDownloaderPackage(data, normalizedUrl);
    if (!parsed.spotifyUrl) parsed.spotifyUrl = normalizedUrl;
    if (isUnknownArtist(parsed.track.artist) && !parsed.track.title) throw new Error('Metadata CMNTY tidak lengkap');
    return parsed;
  })();

  cmntyDownloaderCache.set(normalizedUrl, { at: Date.now(), value: request });
  try {
    const value = await request;
    cmntyDownloaderFailureCache.delete(normalizedUrl);
    cmntyDownloaderCache.set(normalizedUrl, { at: Date.now(), value: Promise.resolve(value) });
    return value;
  } catch (error) {
    cmntyDownloaderCache.delete(normalizedUrl);
    cmntyDownloaderFailureCache.set(normalizedUrl, { at: Date.now(), error });
    throw error;
  }
}

async function resolveTrackMetadataWithPrimary(track, options = {}) {
  const original = sanitizePlaybackTrack(track);
  const force = Boolean(options.force);
  const originalSpotifyUrl = spotifyTrackUrl(original);

  if (originalSpotifyUrl) {
    try {
      const packageData = await fetchPrimarySpotifyPackage(originalSpotifyUrl, { force });
      return mergePrimaryTrackMetadata(original, packageData.track, {
        audioUrl: packageData.audioUrl,
        downloadUrl: packageData.audioUrl,
        audioResolvedAt: packageData.audioUrl ? Date.now() : 0,
        metadataResolvedAt: Date.now(),
        source: packageData.track?.source || activeAudioProviderLabel(),
        syncedLyricsPayload: packageData.syncedLyricsPayload || packageData.track?.syncedLyricsPayload || '',
        lyricsProvider: packageData.track?.lyricsProvider || ''
      });
    } catch (cmntyError) {
      if (!isUnknownArtist(original.artist) && original.title !== 'Tanpa Judul') return original;
      try {
        const candidates = await searchSpotify(cleanTitle(original));
        const exactUrl = candidates.find(candidate => spotifyTrackUrl(candidate) === originalSpotifyUrl);
        const best = exactUrl || candidates
          .map(candidate => ({ candidate, score: primaryTrackMatchScore(candidate, original) }))
          .sort((a, b) => b.score - a.score)[0]?.candidate;
        return best ? mergePrimaryTrackMetadata(original, best, { source: best.source || 'Spotify Search API utama' }) : original;
      } catch {
        return original;
      }
    }
  }

  const cacheKey = `${normalizeMatchText(cleanTitle(original))}|${normalizeMatchText(isUnknownArtist(original.artist) ? '' : original.artist)}`;
  if (!cacheKey.replace('|', '')) return original;
  if (!force && primaryTrackResolutionCache.has(cacheKey)) {
    const cached = await primaryTrackResolutionCache.get(cacheKey);
    return normalizeTrack({ ...cached });
  }

  const request = (async () => {
    try {
      const query = `${cleanTitle(original)} ${isUnknownArtist(original.artist) ? '' : original.artist}`.trim();
      const candidates = await searchSpotify(query);
      const ranked = candidates
        .map(candidate => ({ candidate, score: primaryTrackMatchScore(candidate, original) }))
        .sort((a, b) => b.score - a.score);
      const best = ranked[0];
      if (!best || best.score < (isUnknownArtist(original.artist) ? 48 : 65)) return original;
      let matched = mergePrimaryTrackMetadata(original, best.candidate, { source: best.candidate.source || 'Spotify Search API utama' });
      const matchedSpotifyUrl = spotifyTrackUrl(matched);
      if (matchedSpotifyUrl) {
        try {
          const packageData = await fetchPrimarySpotifyPackage(matchedSpotifyUrl, { force });
          matched = mergePrimaryTrackMetadata(matched, packageData.track, {
            audioUrl: packageData.audioUrl,
            downloadUrl: packageData.audioUrl,
            audioResolvedAt: packageData.audioUrl ? Date.now() : 0,
            metadataResolvedAt: Date.now(),
            source: packageData.track?.source || activeAudioProviderLabel(),
            syncedLyricsPayload: packageData.syncedLyricsPayload || packageData.track?.syncedLyricsPayload || '',
            lyricsProvider: packageData.track?.lyricsProvider || ''
          });
        } catch { /* Hasil pencarian utama tetap dipakai jika downloader sedang sibuk. */ }
      }
      return matched;
    } catch {
      return original;
    }
  })();

  primaryTrackResolutionCache.set(cacheKey, request);
  const result = await request;
  if (spotifyTrackUrl(result)) primaryTrackResolutionCache.set(cacheKey, Promise.resolve(result));
  else primaryTrackResolutionCache.delete(cacheKey);
  return normalizeTrack({ ...result });
}

function fallbackPlayerAccent(track) {
  const palette = [
    [126, 136, 48], [42, 94, 128], [118, 67, 143], [145, 72, 65],
    [39, 112, 93], [156, 105, 45], [54, 89, 151], [118, 78, 54]
  ];
  const seed = `${track?.thumbnail || ''}|${track?.url || ''}|${track?.title || ''}`;
  let hash = 0;
  for (let i = 0; i < seed.length; i += 1) hash = ((hash << 5) - hash + seed.charCodeAt(i)) | 0;
  return palette[Math.abs(hash) % palette.length];
}

function normalizeAccent(rgb) {
  let [r, g, b] = rgb.map(value => Math.max(0, Math.min(255, Number(value) || 0)));
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  const light = (max + min) / 2;
  const delta = max - min;
  if (delta < 28) {
    const boost = max === r ? [22, -4, -8] : max === g ? [-6, 20, -3] : [-5, 2, 22];
    r += boost[0]; g += boost[1]; b += boost[2];
  }
  if (light < 72) {
    const scale = 82 / Math.max(1, light);
    r *= scale; g *= scale; b *= scale;
  }
  if (light > 188) {
    const scale = 178 / light;
    r *= scale; g *= scale; b *= scale;
  }
  return [r, g, b].map(value => Math.round(Math.max(28, Math.min(218, value))));
}

function normalizeNeutralAccent(rgb) {
  const luma = Math.round(.2126 * rgb[0] + .7152 * rgb[1] + .0722 * rgb[2]);
  const neutral = Math.max(118, Math.min(188, luma));
  return [neutral, Math.min(194, neutral + 3), Math.min(201, neutral + 7)];
}

function sampleDominantAccent(image) {
  const canvas = document.createElement('canvas');
  canvas.width = 48;
  canvas.height = 48;
  const context = canvas.getContext('2d', { willReadFrequently: true });
  if (!context) throw new Error('Canvas tidak tersedia');
  context.drawImage(image, 0, 0, canvas.width, canvas.height);
  const pixels = context.getImageData(0, 0, canvas.width, canvas.height).data;
  const colorBuckets = new Map();
  const neutralBuckets = new Map();
  for (let i = 0; i < pixels.length; i += 16) {
    const alpha = pixels[i + 3];
    if (alpha < 180) continue;
    const r = pixels[i], g = pixels[i + 1], b = pixels[i + 2];
    const max = Math.max(r, g, b), min = Math.min(r, g, b);
    const luma = .2126 * r + .7152 * g + .0722 * b;
    const saturation = max ? (max - min) / max : 0;
    if (luma < 38 || luma > 238 || max < 54) continue;
    if (saturation >= .14) {
      const qr = Math.round(r / 24) * 24;
      const qg = Math.round(g / 24) * 24;
      const qb = Math.round(b / 24) * 24;
      const key = `${qr},${qg},${qb}`;
      const centerWeight = 1 - Math.min(.65, Math.abs(luma - 132) / 230);
      const weight = (.45 + saturation * 1.8) * centerWeight;
      const bucket = colorBuckets.get(key) || { score: 0, r: 0, g: 0, b: 0, count: 0 };
      bucket.score += weight;
      bucket.r += r; bucket.g += g; bucket.b += b; bucket.count += 1;
      colorBuckets.set(key, bucket);
      continue;
    }
    if (luma >= 74 && luma <= 228) {
      const q = Math.round(luma / 18) * 18;
      const key = String(q);
      const lightPreference = 1 - Math.min(.72, Math.abs(luma - 164) / 180);
      const bucket = neutralBuckets.get(key) || { score: 0, r: 0, g: 0, b: 0, count: 0 };
      bucket.score += .55 + lightPreference;
      bucket.r += r; bucket.g += g; bucket.b += b; bucket.count += 1;
      neutralBuckets.set(key, bucket);
    }
  }
  const colorWinner = [...colorBuckets.values()].sort((a, b) => b.score - a.score)[0];
  if (colorWinner?.count) return normalizeAccent([colorWinner.r / colorWinner.count, colorWinner.g / colorWinner.count, colorWinner.b / colorWinner.count]);
  const neutralWinner = [...neutralBuckets.values()].sort((a, b) => b.score - a.score)[0];
  if (neutralWinner?.count) return normalizeNeutralAccent([neutralWinner.r / neutralWinner.count, neutralWinner.g / neutralWinner.count, neutralWinner.b / neutralWinner.count]);
  throw new Error('Warna aksen tidak ditemukan');
}

function resolvePlayerAccent(track) {
  const key = track?.thumbnail || trackKey(track);
  if (!key) return Promise.resolve(fallbackPlayerAccent(track));
  if (playerThemeCache.has(key)) return Promise.resolve(playerThemeCache.get(key));
  return new Promise(resolve => {
    const fallback = fallbackPlayerAccent(track);
    const image = new Image();
    image.crossOrigin = 'anonymous';
    image.decoding = 'async';
    image.onload = () => {
      try {
        const color = sampleDominantAccent(image);
        playerThemeCache.set(key, color);
        resolve(color);
      } catch {
        playerThemeCache.set(key, fallback);
        resolve(fallback);
      }
    };
    image.onerror = () => {
      playerThemeCache.set(key, fallback);
      resolve(fallback);
    };
    image.src = track?.thumbnail || 'assets/placeholder.svg';
  });
}

function applyPlayerTheme(track) {
  const page = $('.player-page', view);
  if (!page || !track) return;
  const key = trackKey(track);
  const fallback = fallbackPlayerAccent(track);
  page.style.setProperty('--player-accent-rgb', fallback.join(','));
  page.style.setProperty('--lyrics-card-rgb', fallback.join(','));
  resolvePlayerAccent(track).then(color => {
    const currentPage = $('.player-page', view);
    if (!currentPage || trackKey(state.current) !== key) return;
    currentPage.style.setProperty('--player-accent-rgb', color.join(','));
    currentPage.style.setProperty('--lyrics-card-rgb', color.join(','));
    currentPage.classList.add('theme-ready');
  });
}

function appThemeFallback(track = state.current) {
  const saved = storage.get('appThemeRgb', null);
  if (Array.isArray(saved) && saved.length === 3 && saved.every(Number.isFinite)) return saved;
  return fallbackPlayerAccent(track || { title: 'DATZON Music', artist: 'DATZON' });
}

function fixedThemeRgb(mode = state.settings.themeMode) {
  const themes = {
    green: [26, 96, 55],
    blue: [31, 87, 132],
    purple: [91, 55, 137],
    off: [38, 40, 42]
  };
  return themes[mode] || [26, 96, 55];
}

function applyExperienceSettings() {
  const root = document.documentElement;
  root.classList.toggle('datzon-reduce-motion', Boolean(state.settings.reduceMotion));
  root.classList.toggle('datzon-no-glass', state.settings.liquidGlass === false);
  root.dataset.textScale = state.settings.textScale === 'Sangat kecil' ? 'xsmall' : state.settings.textScale === 'Kecil' ? 'small' : state.settings.textScale === 'Besar' ? 'large' : state.settings.textScale === 'Sangat besar' ? 'xlarge' : 'normal';
  root.dataset.coverShape = state.settings.coverShape === 'Persegi' ? 'square' : 'rounded';
  audio.volume = state.settings.normalizeVolume ? .88 : 1;
  audio.loop = state.repeat === 'one';
}

function setGlobalThemeRgb(color) {
  const rgb = (Array.isArray(color) ? color : [34, 82, 42]).map(value => Math.max(0, Math.min(255, Math.round(Number(value) || 0))));
  const root = document.documentElement;
  root.style.setProperty('--app-accent-rgb', rgb.join(','));
  root.style.setProperty('--accent', `rgb(${rgb.join(',')})`);
  // --spotify-green sengaja tidak pernah ditimpa warna cover.
  const dark = rgb.map(value => Math.round(value * .32));
  document.querySelector('meta[name="theme-color"]')?.setAttribute('content', `rgb(${dark.join(',')})`);
  storage.set('appThemeRgb', rgb);
}

function applyGlobalAppTheme(track = state.current) {
  applyExperienceSettings();
  const mode = String(state.settings.themeMode || 'auto').toLowerCase();
  if (state.settings.dynamicTheme === false || mode !== 'auto') {
    setGlobalThemeRgb(fixedThemeRgb(mode));
    return;
  }
  const fallback = appThemeFallback(track);
  setGlobalThemeRgb(fallback);
  if (!track?.thumbnail) return;
  const key = trackKey(track);
  resolvePlayerAccent(track).then(color => {
    if (state.current && trackKey(state.current) !== key) return;
    if (state.settings.dynamicTheme === false || String(state.settings.themeMode || 'auto').toLowerCase() !== 'auto') return;
    setGlobalThemeRgb(color);
  });
}

function absoluteMediaArtworkUrl(source = '') {
  try { return new URL(String(source || 'assets/icon.svg'), window.location.href).href; }
  catch { return new URL('assets/icon.svg', window.location.href).href; }
}

function mediaSessionArtwork(track = state.current) {
  const src = absoluteMediaArtworkUrl(track?.thumbnail || 'assets/icon.svg');
  return [
    { src, sizes: '96x96' },
    { src, sizes: '256x256' },
    { src, sizes: '512x512' }
  ];
}

function updateDynamicFavicon() {
  const link = document.querySelector('link[rel="icon"]');
  if (!link) return;
  link.href = new URL('assets/favicon-48.png', window.location.href).href;
  link.setAttribute('type', 'image/png');
  link.setAttribute('sizes', '48x48');
}

function updateMediaSessionPosition() {
  if (!('mediaSession' in navigator) || typeof navigator.mediaSession.setPositionState !== 'function') return;
  const duration = Number(audio.duration);
  const position = Number(audio.currentTime);
  if (!Number.isFinite(duration) || duration <= 0 || !Number.isFinite(position)) return;
  try {
    navigator.mediaSession.setPositionState({
      duration,
      playbackRate: Number(audio.playbackRate) || 1,
      position: Math.max(0, Math.min(position, Math.max(0, duration - .001)))
    });
  } catch {}
}

function updateMediaSessionPlaybackState() {
  if (!('mediaSession' in navigator)) return;
  try { navigator.mediaSession.playbackState = state.isPlaying ? 'playing' : 'paused'; }
  catch {}
}

function updateMediaSessionMetadata(track = state.current) {
  if (!track) return;
  if (state.settings.mediaControls === false) {
    document.title = 'DATZON Music';
    updateDynamicFavicon(null);
    if ('mediaSession' in navigator) { try { navigator.mediaSession.metadata = null; } catch {} }
    return;
  }
  const title = cleanTitle(track) || String(track.title || 'DATZON Music');
  const artist = isUnknownArtist(track.artist) ? 'DATZON Music' : String(track.artist || 'DATZON Music');
  const album = String(track.album || track.collectionName || 'DATZON Music');
  document.title = `${title} • ${artist}`;
  updateDynamicFavicon(track);
  if (!('mediaSession' in navigator) || typeof window.MediaMetadata !== 'function') return;
  try {
    navigator.mediaSession.metadata = new MediaMetadata({
      title,
      artist,
      album,
      artwork: mediaSessionArtwork(track)
    });
    updateMediaSessionPlaybackState();
    updateMediaSessionPosition();
  } catch {}
}

function setupMediaSession() {
  if (!('mediaSession' in navigator)) return;
  const bind = (action, handler) => {
    try { navigator.mediaSession.setActionHandler(action, handler); }
    catch {}
  };
  bind('play', () => audio.play().catch(() => {}));
  bind('pause', () => audio.pause());
  bind('previoustrack', previousTrack);
  bind('nexttrack', () => nextTrack(true));
  bind('seekbackward', details => {
    const offset = Number(details?.seekOffset) || 10;
    void seekAudioTo(Math.max(0, (audio.currentTime || 0) - offset));
  });
  bind('seekforward', details => {
    const offset = Number(details?.seekOffset) || 10;
    const max = Number.isFinite(audio.duration) ? audio.duration : (audio.currentTime || 0) + offset;
    void seekAudioTo(Math.min(max, (audio.currentTime || 0) + offset));
  });
  bind('seekto', details => {
    const target = Number(details?.seekTime);
    if (!Number.isFinite(target)) return;
    void seekAudioTo(target);
  });
  bind('stop', () => {
    audio.pause();
    audio.currentTime = 0;
    state.isPlaying = false;
    updateMediaSessionPlaybackState();
    updateMediaSessionPosition();
  });
}

function resetRouteViewport() {
  const reset = () => {
    document.documentElement.scrollTop = 0;
    document.body.scrollTop = 0;
    if (view) view.scrollTop = 0;
    window.scrollTo(0, 0);
  };
  reset();
  requestAnimationFrame(() => {
    reset();
    requestAnimationFrame(reset);
  });
}


function ensureListeningStats() {
  if (!state.listeningStats || typeof state.listeningStats !== 'object') state.listeningStats = {};
  state.listeningStats.totalSeconds = Number(state.listeningStats.totalSeconds || 0);
  state.listeningStats.plays = Number(state.listeningStats.plays || 0);
  state.listeningStats.tracks = state.listeningStats.tracks && typeof state.listeningStats.tracks === 'object' ? state.listeningStats.tracks : {};
  state.listeningStats.artists = state.listeningStats.artists && typeof state.listeningStats.artists === 'object' ? state.listeningStats.artists : {};
  state.listeningStats.days = state.listeningStats.days && typeof state.listeningStats.days === 'object' ? state.listeningStats.days : {};
  return state.listeningStats;
}

function listeningDayKey(date = new Date()) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function recordTrackStarted(track) {
  if (!track || state.settings.privateSession) return;
  const stats = ensureListeningStats();
  const key = trackKey(track);
  const artist = String(track.artist || 'Artis tidak diketahui');
  stats.plays += 1;
  stats.tracks[key] = {
    title: cleanTitle(track), artist, thumbnail: track.thumbnail || 'assets/placeholder.svg',
    plays: Number(stats.tracks[key]?.plays || 0) + 1,
    seconds: Number(stats.tracks[key]?.seconds || 0),
    lastPlayedAt: Date.now(), url: track.url || ''
  };
  stats.artists[artist] = {
    name: artist, thumbnail: track.thumbnail || stats.artists[artist]?.thumbnail || 'assets/placeholder.svg',
    plays: Number(stats.artists[artist]?.plays || 0) + 1,
    seconds: Number(stats.artists[artist]?.seconds || 0),
    lastPlayedAt: Date.now()
  };
  const day = listeningDayKey();
  stats.days[day] = { plays: Number(stats.days[day]?.plays || 0) + 1, seconds: Number(stats.days[day]?.seconds || 0) };
  storage.set('listeningStats', stats);
}

function recordListeningTick(force = false) {
  const now = Date.now();
  if (!state.current || state.settings.privateSession || audio.paused || audio.ended) {
    listeningLastTick = now;
    return;
  }
  if (!listeningLastTick) { listeningLastTick = now; return; }
  const elapsed = Math.max(0, Math.min(8, (now - listeningLastTick) / 1000));
  listeningLastTick = now;
  if (elapsed < .15) return;
  const stats = ensureListeningStats();
  const key = trackKey(state.current);
  const artist = String(state.current.artist || 'Artis tidak diketahui');
  stats.totalSeconds += elapsed;
  if (!stats.tracks[key]) recordTrackStarted(state.current);
  if (stats.tracks[key]) stats.tracks[key].seconds = Number(stats.tracks[key].seconds || 0) + elapsed;
  if (!stats.artists[artist]) stats.artists[artist] = { name: artist, thumbnail: state.current.thumbnail || '', plays: 0, seconds: 0, lastPlayedAt: Date.now() };
  stats.artists[artist].seconds = Number(stats.artists[artist].seconds || 0) + elapsed;
  const day = listeningDayKey();
  stats.days[day] = stats.days[day] || { plays: 0, seconds: 0 };
  stats.days[day].seconds = Number(stats.days[day].seconds || 0) + elapsed;
  if (force || now - listeningLastPersist > 15000) {
    listeningLastPersist = now;
    storage.set('listeningStats', stats);
  }
}

function formatListeningTime(seconds = 0) {
  const total = Math.max(0, Math.round(Number(seconds) || 0));
  if (total < 60) return `${total} detik`;
  const minutes = Math.floor(total / 60);
  if (minutes < 60) return `${minutes} menit`;
  const hours = Math.floor(minutes / 60);
  const rest = minutes % 60;
  return `${hours} jam${rest ? ` ${rest} menit` : ''}`;
}

function localStorageUsageText() {
  try {
    let bytes = 0;
    for (let index = 0; index < localStorage.length; index += 1) {
      const key = localStorage.key(index) || '';
      if (!key.startsWith('datzon_music_')) continue;
      bytes += key.length + String(localStorage.getItem(key) || '').length;
    }
    const kb = bytes * 2 / 1024;
    return kb < 1024 ? `${kb.toFixed(1)} KB` : `${(kb / 1024).toFixed(2)} MB`;
  } catch { return 'Tidak diketahui'; }
}

function notificationTone(message = '') {
  const text = String(message).toLowerCase().trim();

  // Validation/auth/network/provider failures must never look like a success.
  // Keep this message-based so existing notify(...) calls across the app remain compatible.
  const errorPattern = /(?:\bgagal\b|\berror\b|\bsalah\b|tidak ditemukan|tidak tersedia|tidak valid|tidak dapat|belum tersimpan|belum memiliki|belum tersedia|belum diaktifkan|ditolak|diblokir|terputus|bermasalah|\bhabis\b|\bpenuh\b|terlalu banyak|tidak boleh|minimal \d|silakan login|login ulang|dibatalkan|akses .*ditolak|kesalahan)/i;
  if (errorPattern.test(text)) return 'error';

  if (/(?:menyiapkan|memuat|mencari|diproses|menghubungi|menyinkronkan)/i.test(text)) return 'progress';
  return 'success';
}

function removeToastCard(card, immediate = false) {
  if (!card || !card.isConnected) return;
  clearTimeout(card._lifeTimer);
  clearTimeout(card._removeTimer);
  if (immediate || state.settings.reduceMotion) {
    card.remove();
    return;
  }
  card.classList.add('is-leaving');
  card._removeTimer = setTimeout(() => card.remove(), 280);
}

function notify(message) {
  const stack = $('#toastStack');
  if (!stack) return;
  const tone = notificationTone(message);
  const card = document.createElement('div');
  card.className = `ios-toast ios-toast-${tone} is-entering`;
  card.setAttribute('role', 'status');
  card.innerHTML = `<span class="ios-toast-status">${icon(tone === 'error' ? 'close' : tone === 'progress' ? 'refresh' : 'check-circle')}</span><strong>${esc(message)}</strong><span class="ios-toast-bell">${icon('bell')}</span>`;
  stack.prepend(card);
  requestAnimationFrame(() => requestAnimationFrame(() => card.classList.remove('is-entering')));

  const cards = $$('.ios-toast', stack);
  cards.slice(2).forEach(oldCard => removeToastCard(oldCard));
  card._lifeTimer = setTimeout(() => removeToastCard(card), 5000);
}

function apiActionLabel(path = '') {
  if (/search\/spotify-lyrics/i.test(path)) return 'Mencari lirik';
  if (/search\/spotify/i.test(path)) return 'Mencari lagu';
  if (/downloader\/spotify-play/i.test(path)) return 'Menyiapkan audio cadangan';
  if (/downloader\/spotify/i.test(path) || /download\/spotify/i.test(path)) return 'Menyiapkan metadata dan audio';
  if (/download\/spotify-play/i.test(path)) return 'Menyiapkan audio cadangan';
  if (/info\/spotify/i.test(path)) return 'Mengambil lirik bertimestamp';
  return 'Menghubungi layanan musik';
}

function activityTimeText(timestamp = Date.now()) {
  try { return new Intl.DateTimeFormat('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' }).format(new Date(timestamp)); }
  catch { return new Date(timestamp).toLocaleTimeString(); }
}

function saveSystemActivity() {
  storage.set('systemActivity', state.systemActivity.slice(0, 100));
  storage.set('systemActivityUnread', state.systemActivityUnread);
  storage.set('spotlightIndex', state.spotlightIndex);
  storage.set('homeSpotlight', state.homeSpotlight);
  storage.set('homeSpotlightAt', state.homeSpotlightAt);
}

function updateActivityBadge() {
  const button = $('[data-system-activity]', view);
  if (!button) return;
  const badge = $('.system-activity-badge', button);
  if (!badge) return;
  const count = Math.min(99, Number(state.systemActivityUnread) || 0);
  badge.textContent = count ? String(count) : '';
  badge.hidden = count === 0;
}

function refreshSystemActivitySheet() {
  if (!state.systemActivityOpen) return;
  const list = $('[data-system-activity-list]', modalRoot);
  if (list) list.innerHTML = systemActivityListMarkup();
}

function beginSystemActivity(title, detail = '', provider = '', options = {}) {
  const entry = {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`,
    timestamp: Date.now(),
    title: String(title || 'Aktivitas sistem'),
    detail: String(detail || ''),
    provider: String(provider || ''),
    status: options.status || 'loading',
    track: String(options.track || ''),
    keyNumber: Number(options.keyNumber || 0)
  };
  state.systemActivity.unshift(entry);
  state.systemActivity = state.systemActivity.slice(0, 100);
  if (!state.systemActivityOpen) state.systemActivityUnread = Math.min(99, state.systemActivityUnread + 1);
  saveSystemActivity();
  updateActivityBadge();
  refreshSystemActivitySheet();
  return entry.id;
}

function finishSystemActivity(id, status = 'success', detail = '') {
  const entry = state.systemActivity.find(item => item.id === id);
  if (!entry) return;
  entry.status = status;
  entry.finishedAt = Date.now();
  if (detail) entry.detail = String(detail);
  saveSystemActivity();
  refreshSystemActivitySheet();
}

function logSystemActivity(title, detail = '', provider = '', status = 'success', options = {}) {
  const id = beginSystemActivity(title, detail, provider, { ...options, status });
  return id;
}


function firebaseService() {
  return window.DatzonFirebase || null;
}

function isFirebaseConfigured() {
  return Boolean(firebaseService()?.isConfigured?.());
}

async function ensureFirebaseReady() {
  const service = firebaseService();
  if (!service?.isConfigured?.()) {
    showFirebaseSetupInfo();
    return null;
  }
  try {
    await service.waitUntilReady?.();
    return service;
  } catch (error) {
    const message = service.firebaseErrorMessage?.(error) || error?.message || 'Firebase gagal dimuat.';
    notify(message);
    showFirebaseSetupInfo(message);
    return null;
  }
}

function isLoggedIn() {
  return Boolean(state.auth?.user && state.auth?.profile);
}

function isAdminAccount() {
  return isLoggedIn() && String(state.auth.profile?.role || '').toLowerCase() === 'admin';
}

function currentAccountName() {
  return isLoggedIn() ? (state.auth.profile.fullName || state.auth.profile.username || state.username) : (state.username || 'Tamu');
}

function currentProfilePhoto() {
  return isLoggedIn() ? String(state.auth.profile.photoURL || state.auth.user.photoURL || '') : '';
}

function accountAvatarPlaybackClass() {
  return state.isPlaying && state.current ? ' is-listening' : '';
}

function syncAccountAvatarPlaybackState(root = document) {
  root.querySelectorAll?.('.avatar-button, .drawer-avatar, .profile-avatar-large').forEach(element => {
    element.classList.toggle('is-listening', Boolean(state.isPlaying && state.current));
  });
}

function normalizedAccountStatus(profile = state.auth.profile) {
  const raw = String(profile?.preferredStatus || profile?.status || 'online').toLowerCase();
  if (!navigator.onLine) return 'offline';
  return ['online', 'offline', 'busy'].includes(raw) ? raw : 'online';
}

function accountStatusLabel(status = normalizedAccountStatus()) {
  return status === 'busy' ? 'Sibuk' : status === 'offline' ? 'Offline' : 'Online';
}

function accountAvatarButtonMarkup(attribute = '') {
  const photo = currentProfilePhoto();
  const initial = accountInitial();
  return `<button class="avatar-button ${photo ? 'has-photo' : ''}${accountAvatarPlaybackClass()}" ${attribute}>${photo ? `<img src="${esc(photo)}" alt="Foto profil ${esc(currentAccountName())}" referrerpolicy="no-referrer" onerror="this.parentElement.classList.remove('has-photo');this.remove()"><b>${esc(initial)}</b>` : `<b>${esc(initial)}</b>`}</button>`;
}


function timestampMillis(value) {
  if (!value) return 0;
  if (typeof value.toMillis === 'function') return value.toMillis();
  if (typeof value.toDate === 'function') return value.toDate().getTime();
  if (typeof value === 'number') return value;
  const parsed = new Date(value).getTime();
  return Number.isFinite(parsed) ? parsed : 0;
}

function socialTimeText(value) {
  const millis = timestampMillis(value) || Date.now();
  const diff = Date.now() - millis;
  if (diff < 60000) return 'Baru saja';
  if (diff < 3600000) return `${Math.max(1, Math.floor(diff / 60000))} menit lalu`;
  if (diff < 86400000) return `${Math.floor(diff / 3600000)} jam lalu`;
  if (diff < 604800000) return `${Math.floor(diff / 86400000)} hari lalu`;
  try { return new Intl.DateTimeFormat('id-ID', { day:'2-digit', month:'short', year:'numeric' }).format(new Date(millis)); }
  catch { return new Date(millis).toLocaleDateString(); }
}

function publicProfilePhoto(profile = {}) {
  return String(profile.photoURL || '');
}

function publicProfileInitial(profile = {}) {
  return String(profile.fullName || profile.username || 'D').trim().slice(0,1).toUpperCase() || 'D';
}

function publicAvatarMarkup(profile = {}, className = 'social-avatar') {
  const photo = publicProfilePhoto(profile);
  return `<span class="${className} ${photo ? 'has-photo' : ''}">${photo ? `<img src="${esc(photo)}" alt="" referrerpolicy="no-referrer" onerror="this.remove();this.parentElement.classList.remove('has-photo')">` : ''}<b>${esc(publicProfileInitial(profile))}</b></span>`;
}

function normalizedProfileSocialUrl(value = '') {
  const raw = String(value || '').trim();
  if (!raw) return '';
  const candidate = /^[a-z][a-z0-9+.-]*:\/\//i.test(raw) ? raw : `https://${raw}`;
  try {
    const url = new URL(candidate);
    if (!['http:','https:'].includes(url.protocol) || !url.hostname) return '';
    url.hash = '';
    return url.toString();
  } catch { return ''; }
}

function normalizedProfileSocialLinks(values = []) {
  const seen = new Set();
  const links = [];
  (Array.isArray(values) ? values : []).forEach(value => {
    const url = normalizedProfileSocialUrl(value);
    if (!url || seen.has(url) || links.length >= 8) return;
    seen.add(url);
    links.push(url);
  });
  return links;
}

function socialLinkMeta(value = '') {
  const url = normalizedProfileSocialUrl(value);
  if (!url) return { platform:'website', label:'Website', handle:'Website', icon:'external', url:'' };
  const parsed = new URL(url);
  const host = parsed.hostname.toLowerCase().replace(/^www\./, '');
  const parts = parsed.pathname.split('/').filter(Boolean).map(part => {
    try { return decodeURIComponent(part); } catch { return part; }
  });
  let platform = 'website';
  let label = 'Website';
  let iconName = 'external';
  let handle = host;
  if (host === 'instagram.com' || host.endsWith('.instagram.com')) { platform='instagram'; label='Instagram'; iconName='camera'; handle=parts[0] ? `@${parts[0].replace(/^@/,'')}` : label; }
  else if (host === 'tiktok.com' || host.endsWith('.tiktok.com')) { platform='tiktok'; label='TikTok'; iconName='music'; handle=parts[0] ? `@${parts[0].replace(/^@/,'')}` : label; }
  else if (host === 'youtube.com' || host === 'youtu.be' || host.endsWith('.youtube.com')) { platform='youtube'; label='YouTube'; iconName='play'; handle=parts.find(part => part.startsWith('@')) || (parts[1] && ['channel','c','user'].includes(parts[0]) ? parts[1] : label); }
  else if (host === 'open.spotify.com' || host === 'spotify.com' || host.endsWith('.spotify.com')) { platform='spotify'; label='Spotify'; iconName='radio'; handle=parts[0] === 'user' && parts[1] ? `@${parts[1]}` : label; }
  else if (host === 'x.com' || host === 'twitter.com' || host.endsWith('.twitter.com')) { platform='x'; label='X'; iconName='external'; handle=parts[0] ? `@${parts[0].replace(/^@/,'')}` : label; }
  else if (host === 'threads.net' || host.endsWith('.threads.net')) { platform='threads'; label='Threads'; iconName='external'; handle=parts[0] ? `@${parts[0].replace(/^@/,'')}` : label; }
  else if (host === 'facebook.com' || host === 'fb.com' || host.endsWith('.facebook.com')) { platform='facebook'; label='Facebook'; iconName='user'; handle=parts[0] || label; }
  else if (host === 'soundcloud.com' || host.endsWith('.soundcloud.com')) { platform='soundcloud'; label='SoundCloud'; iconName='music'; handle=parts[0] ? `@${parts[0].replace(/^@/,'')}` : label; }
  return { platform, label, handle, icon:iconName, url };
}

function socialBrandMarkup(meta = {}) {
  const textBrand = meta.platform === 'x' ? '<b>X</b>' : meta.platform === 'threads' ? '<b>@</b>' : meta.platform === 'facebook' ? '<b>f</b>' : '';
  return `<span class="profile-social-brand brand-${esc(meta.platform || 'website')}">${textBrand || icon(meta.icon || 'external', meta.platform === 'youtube' ? 'fill' : '')}</span>`;
}

function profileBioMarkup(profile = {}) {
  const bio = String(profile.bio || '').trim();
  const links = normalizedProfileSocialLinks(profile.socialLinks || []);
  if (!bio && !links.length) return '';
  return `<section class="profile-bio-card">${bio ? `<p>${esc(bio)}</p>` : ''}${links.length ? `<div class="profile-social-links">${links.map(value => { const meta=socialLinkMeta(value); return `<a href="${esc(meta.url)}" target="_blank" rel="noopener noreferrer" aria-label="Buka ${esc(meta.label)} ${esc(meta.handle)}">${socialBrandMarkup(meta)}<span><strong>${esc(meta.label)}</strong><small>${esc(meta.handle)}</small></span>${icon('external')}</a>`; }).join('')}</div>` : ''}</section>`;
}

function profileSocialStatsMarkup(graph = {}) {
  const stats = [
    ['friends','Teman',Array.isArray(graph.friends) ? graph.friends.length : 0],
    ['followers','Followers',Array.isArray(graph.followers) ? graph.followers.length : 0],
    ['following','Following',Array.isArray(graph.following) ? graph.following.length : 0]
  ];
  return `<section class="profile-social-stats">${stats.map(([kind,label,count]) => `<button type="button" data-profile-social-kind="${kind}"><strong>${count}</strong><span>${label}</span></button>`).join('')}</section>`;
}

function showProfileSocialList(kind, graph = {}, owner = {}) {
  const config = {
    friends: ['Teman','Akun yang saling mengikuti'],
    followers: ['Followers','Akun yang mengikuti profil ini'],
    following: ['Following','Akun yang diikuti profil ini']
  }[kind] || ['Koneksi','Daftar pengguna'];
  const profiles = Array.isArray(graph[kind]) ? graph[kind] : [];
  const sheet = openPlayerSheet(`<div class="profile-social-list-sheet"><header><div><small>${esc((owner.fullName || owner.username || 'PROFIL').toUpperCase())}</small><h2>${config[0]}</h2><p>${profiles.length} akun • ${config[1]}</p></div><button data-close-profile-social aria-label="Tutup">${icon('close')}</button></header><div class="social-list">${profiles.length ? profiles.map(profile => socialProfileRow(profile)).join('') : `<div class="social-empty">Belum ada pengguna di daftar ${esc(config[0])}.</div>`}</div></div>`, 'profile-social-list-player-sheet', { kind:'adaptive', initialSnap:'full' });
  $('[data-close-profile-social]', sheet).onclick = () => closeModal();
  bindSocialRows(sheet);
}

function bindProfileSocialStats(root, graph, owner) {
  $$('[data-profile-social-kind]', root).forEach(button => button.onclick = () => showProfileSocialList(button.dataset.profileSocialKind, graph, owner));
}

function notificationUnreadCount() {
  const userUnread = (state.globalNotifications || []).filter(item => !item.read).length;
  const reads = new Set(state.announcementReads || []);
  const announcementUnread = (state.announcements || []).filter(item => !reads.has(item.id)).length;
  return userUnread + announcementUnread;
}

function updateGlobalNotificationBadge() {
  const button = $('[data-global-notifications]', view);
  if (!button) return;
  const badge = $('.system-activity-badge', button);
  if (!badge) return;
  const count = Math.min(99, notificationUnreadCount());
  badge.textContent = count ? String(count) : '';
  badge.hidden = count === 0;
}

function initializeNotificationStream() {
  firebaseNotificationsUnsubscribe?.();
  firebaseNotificationsUnsubscribe = null;
  const service = firebaseService();
  if (!service?.listenNotifications) return;
  firebaseNotificationsUnsubscribe = service.listenNotifications(payload => {
    const notifications = Array.isArray(payload?.notifications) ? payload.notifications : [];
    const collaborative = notifications.filter(item => ['collab_playlist_sync','collab_playlist_remove'].includes(item?.type));
    state.globalNotifications = notifications.filter(item => !['collab_playlist_sync','collab_playlist_remove'].includes(item?.type));
    state.announcements = Array.isArray(payload?.announcements) ? payload.announcements : [];
    collaborative.forEach(item => {
      const marker = `collabSync:${item.id}`;
      if (sessionStorage.getItem(marker)) return;
      sessionStorage.setItem(marker, '1');
      try {
        if (item?.type === 'collab_playlist_remove') applyCollaborativePlaylistRemoval(item);
        else applyCollaborativePlaylistNotification(item);
      } catch (error) { console.warn('[DATZON collab receive]', error); }
      Promise.resolve(service.deleteNotification?.(item.id)).catch(() => {}).finally(() => window.setTimeout(() => sessionStorage.removeItem(marker), 30000));
    });
    updateGlobalNotificationBadge();
    if (state.notificationsOpen) refreshGlobalNotificationsSheet();
  });
  if (isLoggedIn()) Promise.resolve(service.pruneExpiredNotifications?.()).catch(() => {});
}

function relationStatusFor(uid) {
  const all = [...(state.social.friends || []), ...(state.social.following || []), ...(state.social.followers || [])];
  const item = all.find(profile => profile.uid === uid);
  const relation = item?.relationship;
  if (!relation) return 'none';
  if (relation.status === 'friends') return 'friends';
  const followers = relation.followerUids || [];
  if (followers.includes(state.auth.user?.uid)) return relation.status === 'pending' ? 'pending' : 'following';
  return 'follower';
}

function relationButtonLabel(uid) {
  const status = relationStatusFor(uid);
  if (status === 'friends') return 'Teman';
  if (status === 'pending') return 'Diminta';
  if (status === 'following') return 'Mengikuti';
  if (status === 'follower') return 'Ikuti balik';
  return 'Tambah teman';
}

function socialProfileByUid(uid) {
  const safeUid = String(uid || '');
  return [...(state.social.friends || []), ...(state.social.following || []), ...(state.social.followers || []), ...(state.social.searchResults || [])]
    .find(item => String(item?.uid || '') === safeUid) || null;
}

function socialRouteIsList(route = state.route) {
  return ['friends','following','followers'].includes(route);
}

async function loadSocialGraph(force = false) {
  if (!isLoggedIn()) {
    state.social = { ...state.social, loaded:true, loading:false, friends:[], following:[], followers:[] };
    return state.social;
  }
  if (state.social.loading) return state.social;
  if (state.social.loaded && !force) return state.social;
  state.social.loading = true;
  try {
    const service = await ensureFirebaseReady();
    if (!service) throw new Error('Firebase belum siap');
    const graph = await service.loadSocialGraph();
    state.social = { ...state.social, ...graph, loading:false, loaded:true };
  } catch (error) {
    state.social.loading = false;
    notify(firebaseService()?.firebaseErrorMessage?.(error) || error?.message || 'Data teman gagal dimuat');
  }
  return state.social;
}

async function requestFriend(uid, button = null) {
  if (!isLoggedIn()) { navigate('login'); return; }
  const originalButtonLabel = button?.textContent || 'Tambah teman';
  if (button) { button.disabled = true; button.textContent = 'Memproses...'; }
  try {
    const service = await ensureFirebaseReady();
    if (!service) return;
    const result = await service.sendFriendRequest(uid);
    state.social.loaded = false;
    await loadSocialGraph(true);
    notify(result?.status === 'friends' ? 'Sekarang kalian berteman' : 'Permintaan teman dikirim');
    if (state.route === 'people') renderPeopleSearchPage();
    else if (socialRouteIsList()) renderSocialListPage(state.route);
    if (state.route === 'public-profile') await openPublicProfile(uid, { replace:true });
  } catch (error) {
    notify(firebaseService()?.firebaseErrorMessage?.(error) || error?.message || 'Permintaan teman gagal');
    if (button) { button.disabled = false; button.textContent = originalButtonLabel; }
  }
}

function socialProfileRow(profile, options = {}) {
  const totalSeconds = Number(profile?.listeningSummary?.totalSeconds || 0);
  const isSelf = Boolean(state.auth.user?.uid) && String(profile?.uid || '') === String(state.auth.user.uid);
  const action = options.action === false || isSelf ? '' : `<button class="social-add-btn ${relationStatusFor(profile.uid) === 'friends' ? 'is-friend' : ''}" data-social-add="${esc(profile.uid)}">${esc(relationButtonLabel(profile.uid))}</button>`;
  return `<article class="social-profile-row" data-public-profile="${esc(profile.uid)}">${publicAvatarMarkup(profile)}<div><strong>${esc(profile.fullName || profile.username || 'Pengguna DATZON')}</strong><small>@${esc(profile.username || 'pengguna')} • ${esc(formatListeningTime(totalSeconds))}</small><em class="status-${esc(String(profile.status || 'offline'))}">${esc(accountStatusLabel(profile.status || 'offline'))}</em></div>${action}</article>`;
}

function showUnfriendConfirm(uid) {
  const profile = socialProfileByUid(uid) || state.publicProfileView?.profile || {};
  const name = profile.fullName || profile.username || 'pengguna ini';
  openModal('Hapus pertemanan?', `<p class="modal-description">Kamu yakin ingin menghapus <strong>${esc(name)}</strong> dari teman? Hubungan Teman, Mengikuti, dan Pengikut di antara kalian akan dihapus.</p><div class="relationship-confirm-actions"><button class="secondary-btn" data-cancel-unfriend>Batal</button><button class="danger-btn" data-confirm-unfriend>Hapus teman</button></div>`, root => {
    $('[data-cancel-unfriend]', root).onclick = () => closeModal();
    $('[data-confirm-unfriend]', root).onclick = async event => {
      const button = event.currentTarget;
      button.disabled = true;
      try {
        const service = await ensureFirebaseReady();
        if (!service) throw new Error('Firebase belum siap');
        await service.removeRelationship(uid);
        state.social.loaded = false;
        await loadSocialGraph(true);
        closeModal();
        notify(`${name} dihapus dari teman`);
        if (state.route === 'public-profile') await openPublicProfile(uid, { replace:true });
        else if (state.route === 'people') renderPeopleSearchPage();
        else if (socialRouteIsList()) renderSocialListPage(state.route);
      } catch (error) {
        notify(firebaseService()?.firebaseErrorMessage?.(error) || error?.message || 'Gagal menghapus pertemanan');
        button.disabled = false;
      }
    };
  });
}

function showUnfollowConfirm(uid) {
  const profile = socialProfileByUid(uid) || state.publicProfileView?.profile || {};
  const name = profile.fullName || profile.username || 'pengguna ini';
  openModal('Batal mengikuti?', `<p class="modal-description">Kamu tidak akan lagi mengikuti <strong>${esc(name)}</strong>. Akun ini juga akan hilang dari daftar Following kamu.</p><div class="relationship-confirm-actions"><button class="secondary-btn" data-cancel-unfollow>Batal</button><button class="danger-btn" data-confirm-unfollow>Batal mengikuti</button></div>`, root => {
    $('[data-cancel-unfollow]', root).onclick = () => closeModal();
    $('[data-confirm-unfollow]', root).onclick = async event => {
      const button = event.currentTarget;
      button.disabled = true;
      try {
        const service = await ensureFirebaseReady();
        if (!service) throw new Error('Firebase belum siap');
        await service.unfollowUser(uid);
        state.social.loaded = false;
        await loadSocialGraph(true);
        closeModal();
        notify(`Berhenti mengikuti ${name}`);
        if (state.route === 'public-profile') await openPublicProfile(uid, { replace:true });
        else if (state.route === 'people') renderPeopleSearchPage();
        else if (socialRouteIsList()) renderSocialListPage(state.route);
      } catch (error) {
        notify(firebaseService()?.firebaseErrorMessage?.(error) || error?.message || 'Gagal membatalkan mengikuti');
        button.disabled = false;
      }
    };
  });
}

function bindSocialRows(root = view) {
  $$('[data-public-profile]', root).forEach(row => row.onclick = event => {
    if (event.target.closest('[data-social-add]')) return;
    if (root !== view) closeModal(true);
    openPublicProfile(row.dataset.publicProfile);
  });
  $$('[data-social-add]', root).forEach(button => button.onclick = event => {
    event.stopPropagation();
    const status = relationStatusFor(button.dataset.socialAdd);
    if (status === 'friends') { showUnfriendConfirm(button.dataset.socialAdd); return; }
    if (['pending','following'].includes(status)) { showUnfollowConfirm(button.dataset.socialAdd); return; }
    requestFriend(button.dataset.socialAdd, button);
  });
}

function socialPageHeader(title, subtitle = '') {
  return `<header class="settings-title-row utility-title-row social-title-row"><button data-back>${icon('arrow-left')}</button><div><h1>${esc(title)}</h1>${subtitle ? `<small>${esc(subtitle)}</small>` : ''}</div><button data-social-directory-menu aria-label="Buka daftar sosial">${icon('list-view')}</button></header>`;
}

function bindSocialPageHeader() {
  const back = $('[data-back]', view); if (back) back.onclick = () => navigateBack('home');
  const menu = $('[data-social-directory-menu]', view); if (menu) menu.onclick = showSocialDirectoryMenu;
}

function showSocialDirectoryMenu() {
  const logged = isLoggedIn();
  const items = [
    { route:'friends', label:'Teman', detail:'Akun yang saling add / saling mengikuti', count:state.social.friends?.length || 0, icon:'group' },
    { route:'following', label:'Following', detail:'Akun yang kamu add atau ikuti', count:state.social.following?.length || 0, icon:'arrow-right' },
    { route:'followers', label:'Followers', detail:'Akun yang add atau mengikuti kamu', count:state.social.followers?.length || 0, icon:'user' }
  ];
  const sheet = openPlayerSheet(`<div class="social-directory-sheet"><header><div><small>DAFTAR SOSIAL</small><h2>Teman & koneksi</h2><p>${logged ? 'Pilih daftar yang ingin dibuka.' : 'Login untuk melihat daftar sosial akunmu.'}</p></div><button data-close-social-directory>${icon('close')}</button></header><div class="social-directory-options">${items.map(item => `<button class="${state.route === item.route ? 'selected' : ''}" data-social-directory-route="${item.route}"><span class="social-directory-icon">${icon(item.icon)}</span><span><strong>${item.label}</strong><small>${item.detail}</small></span><em>${item.count}</em>${icon('chevron')}</button>`).join('')}</div></div>`, 'social-directory-player-sheet', { kind:'compact', initialSnap:'half' });
  $('[data-close-social-directory]', sheet).onclick = () => closeModal(true);
  $$('[data-social-directory-route]', sheet).forEach(button => button.onclick = () => {
    const route = button.dataset.socialDirectoryRoute;
    closeModal(true);
    navigate(route);
  });
}

async function performFriendSearch(query) {
  state.social.searchQuery = String(query || '').trim();
  if (!state.social.searchQuery) { state.social.searchResults = []; renderPeopleSearchPage(); return; }
  state.social.searchLoading = true;
  renderPeopleSearchPage();
  try {
    const service = await ensureFirebaseReady();
    state.social.searchResults = service ? await service.searchUsers(state.social.searchQuery, 30) : [];
  } catch (error) {
    state.social.searchResults = [];
    notify(firebaseService()?.firebaseErrorMessage?.(error) || error?.message || 'Pencarian pengguna gagal');
  }
  state.social.searchLoading = false;
  renderPeopleSearchPage();
}

function renderPeopleSearchPage() {
  const logged = isLoggedIn();
  const social = state.social;
  view.innerHTML = `<div class="page spotify-settings-page utility-page friends-page people-search-page">${socialPageHeader('Cari Pengguna', logged ? 'Temukan akun DATZON dengan nama atau @username' : 'Login untuk mencari dan menambahkan pengguna')}
    <section class="friend-search-card"><form id="friendSearchForm"><div>${icon('search')}<input id="friendSearchInput" value="${esc(social.searchQuery || '')}" placeholder="Cari nama atau @username" autocomplete="off"><button type="submit">Cari</button></div></form></section>
    ${!logged ? `<section class="social-login-empty">${icon('group')}<h2>Temukan pengguna DATZON</h2><p>Login agar kamu bisa mencari pengguna, mengikuti akun, dan membuat pertemanan.</p><button data-social-login>Login / Register</button></section>` : social.searchQuery ? `<section class="social-section"><div class="social-section-title"><h2>Hasil pencarian</h2><span>${social.searchResults.length}</span></div><div class="social-list">${social.searchLoading ? '<div class="social-loading">Mencari pengguna...</div>' : social.searchResults.length ? social.searchResults.map(item => socialProfileRow(item)).join('') : '<div class="social-empty">Tidak ada pengguna yang cocok.</div>'}</div></section>` : `<section class="social-search-intro">${icon('search')}<h2>Cari teman baru</h2><p>Ketik nama lengkap atau @username. Daftar Teman, Following, dan Followers sekarang tersedia dari tombol daftar di kanan atas.</p></section>`}
  </div>`;
  bindSocialPageHeader();
  $('[data-social-login]', view)?.addEventListener('click', () => navigate('login'));
  $('#friendSearchForm', view)?.addEventListener('submit', event => { event.preventDefault(); performFriendSearch($('#friendSearchInput', view)?.value || ''); });
  bindSocialRows(view);
  if (logged && !social.loaded && !social.loading) loadSocialGraph(true).then(() => { if (state.route === 'people') renderPeopleSearchPage(); });
}

function renderSocialListPage(kind = 'friends') {
  const logged = isLoggedIn();
  const social = state.social;
  const config = {
    friends: { title:'Teman', subtitle:'Saling add / saling mengikuti', empty:'Belum ada teman yang saling mengikuti.' },
    following: { title:'Following', subtitle:'Akun yang kamu add atau ikuti', empty:'Kamu belum mengikuti pengguna lain.' },
    followers: { title:'Followers', subtitle:'Akun yang add atau mengikuti kamu', empty:'Belum ada pengguna yang mengikuti kamu.' }
  }[kind] || { title:'Teman', subtitle:'Daftar sosial', empty:'Belum ada data.' };
  const rows = Array.isArray(social[kind]) ? social[kind] : [];
  view.innerHTML = `<div class="page spotify-settings-page utility-page friends-page social-list-page">${socialPageHeader(config.title, logged ? `${rows.length} akun • ${config.subtitle}` : 'Login untuk melihat daftar ini')}
    ${!logged ? `<section class="social-login-empty">${icon('group')}<h2>Daftar sosial akunmu</h2><p>Login untuk melihat Teman, Following, dan Followers.</p><button data-social-login>Login / Register</button></section>` : `<section class="social-section social-list-section"><div class="social-list">${social.loading ? '<div class="social-loading">Memuat daftar...</div>' : rows.length ? rows.map(item => socialProfileRow(item)).join('') : `<div class="social-empty">${esc(config.empty)}</div>`}</div></section>`}
  </div>`;
  bindSocialPageHeader();
  $('[data-social-login]', view)?.addEventListener('click', () => navigate('login'));
  bindSocialRows(view);
  if (logged && !social.loaded && !social.loading) loadSocialGraph(true).then(() => { if (state.route === kind) renderSocialListPage(kind); });
}

function stopPublicProfilePlaylistStream() {
  try { publicProfilePlaylistsUnsubscribe?.(); } catch {}
  publicProfilePlaylistsUnsubscribe = null;
}

function startPublicProfilePlaylistStream(uid, service = firebaseService()) {
  stopPublicProfilePlaylistStream();
  const safeUid = String(uid || '').trim();
  if (!safeUid || !service?.listenProfilePlaylists) return;
  try {
    publicProfilePlaylistsUnsubscribe = service.listenProfilePlaylists(safeUid, payload => {
      if (String(state.publicProfileView?.uid || '') !== safeUid) return;
      const remotePlaylists = normalizePlaylists(Array.isArray(payload?.playlists) ? payload.playlists : [])
        .filter(playlist => playlist.listed && playlist.tracks.length)
        .sort((a, b) => Number(b.updatedAt || 0) - Number(a.updatedAt || 0));
      const ownLocalPlaylists = safeUid === String(state.auth.user?.uid || '') ? activePlaylists() : [];
      const playlists = mergePlaylistsById(ownLocalPlaylists, remotePlaylists)
        .filter(playlist => playlist.listed && playlist.tracks.length)
        .sort((a, b) => Number(b.updatedAt || 0) - Number(a.updatedAt || 0));
      state.publicProfileView = {
        ...state.publicProfileView,
        playlists,
        playlistsReady: Boolean(payload?.ready),
        playlistsError: ''
      };
      if (state.route === 'public-profile' && String(state.publicProfileView.uid) === safeUid) renderPublicProfilePage();
    }, error => {
      if (String(state.publicProfileView?.uid || '') !== safeUid) return;
      state.publicProfileView = {
        ...state.publicProfileView,
        playlistsReady: true,
        playlistsError: error?.message || 'Playlist profil gagal dimuat'
      };
      if (state.route === 'public-profile') renderPublicProfilePage();
    });
  } catch (error) {
    state.publicProfileView = { ...state.publicProfileView, playlistsReady:true, playlistsError:error?.message || 'Playlist profil gagal dimuat' };
  }
}

async function openPublicProfile(uid, options = {}) {
  const safeUid = String(uid || '').trim();
  if (!safeUid) return;
  stopDatzonPlaylistStream();
  stopPublicProfilePlaylistStream();
  stopLeaderboardStream();
  const openingOwnProfile = safeUid === String(state.auth.user?.uid || '');
  const optimisticProfile = openingOwnProfile ? { ...(state.auth.profile || {}), uid:safeUid } : null;
  const optimisticPlaylists = openingOwnProfile ? activePlaylists() : [];
  state.publicProfileView = { uid:safeUid, profile:optimisticProfile, relationship:null, social:null, playlists:optimisticPlaylists, playlistsReady:false, playlistsError:'', loading:!optimisticProfile, error:'' };
  state.route = 'public-profile';
  syncBrowserRoute('public-profile', { uid:safeUid, replace:Boolean(options.replace) });
  render();
  try {
    const service = await ensureFirebaseReady();
    if (!service) throw new Error('Firebase belum siap');
    const [profile, relationship, social] = await Promise.all([
      service.getPublicProfile(safeUid),
      isLoggedIn() && safeUid !== state.auth.user?.uid ? service.getRelationship(safeUid).catch(() => null) : Promise.resolve(null),
      service.loadPublicSocialGraph ? service.loadPublicSocialGraph(safeUid).catch(() => ({ friends:[], following:[], followers:[] })) : Promise.resolve({ friends:[], following:[], followers:[] })
    ]);
    const fallbackPlaylists = profile ? publicPlaylistsFromProfile(profile) : [];
    const localFallback = safeUid === String(state.auth.user?.uid || '') ? activePlaylists() : [];
    state.publicProfileView = { uid:safeUid, profile, relationship, social, playlists:mergePlaylistsById(localFallback, fallbackPlaylists), playlistsReady:false, playlistsError:'', loading:false, error: profile ? '' : 'Profil tidak ditemukan' };
    if (profile) startPublicProfilePlaylistStream(safeUid, service);
  } catch (error) {
    if (openingOwnProfile && optimisticProfile) {
      state.publicProfileView = {
        ...state.publicProfileView,
        uid:safeUid,
        profile:optimisticProfile,
        playlists:activePlaylists(),
        playlistsReady:true,
        playlistsError:error?.message || '',
        loading:false,
        error:''
      };
    } else {
      state.publicProfileView = { uid:safeUid, profile:null, relationship:null, social:null, playlists:[], playlistsReady:true, playlistsError:'', loading:false, error:error?.message || 'Profil gagal dimuat' };
    }
  }
  if (state.route === 'public-profile') renderPublicProfilePage();
}

function publicPlaylistsFromProfile(profile = {}) {
  const remote = normalizePlaylists(Array.isArray(profile.publicPlaylists) ? profile.publicPlaylists : []);
  const self = String(profile.uid || '') === String(state.auth.user?.uid || '');
  const playlists = self ? mergePlaylistsById(activePlaylists(), remote) : remote;
  return playlists
    .filter(playlist => playlist.visibility === 'public')
    .sort((a, b) => Number(b.updatedAt || 0) - Number(a.updatedAt || 0));
}

function publicPlaylistPlaybackContext(playlist = {}, ownerProfile = {}) {
  return {
    eyebrow: playlist.collaborative ? 'MEMAINKAN DARI PLAYLIST KOLABORATIF PUBLIK' : 'MEMAINKAN DARI PLAYLIST PUBLIK',
    label: playlist.name || 'Playlist publik',
    type: 'public-playlist',
    id: playlist.id || '',
    ownerUid: playlist.ownerUid || ownerProfile.uid || ''
  };
}

function isPublicPlaylistPlaybackContext(playlist = {}, ownerProfile = {}) {
  return state.playContext?.type === 'public-playlist'
    && String(state.playContext?.id || '') === String(playlist.id || '')
    && String(state.playContext?.ownerUid || '') === String(playlist.ownerUid || ownerProfile.uid || '');
}

function publicPlaylistAlreadySaved(playlist = {}, ownerProfile = {}) {
  const ownerUid = String(playlist.ownerUid || ownerProfile.uid || '');
  return activePlaylists().some(item => item.id === playlist.id
    || (item.sourcePublicPlaylistId === playlist.id && item.sourceOwnerUid === ownerUid));
}

function savePublicPlaylistToLibrary(playlist = {}, ownerProfile = {}) {
  if (!isLoggedIn()) {
    closeModal(true);
    notify('Masuk ke akun untuk menambahkan playlist publik.');
    navigate('login');
    return null;
  }
  const canonicalOwnerUid = String(playlist.ownerUid || ownerProfile.uid || '');
  const existing = activePlaylists().find(item => item.id === playlist.id
    || (item.sourcePublicPlaylistId === playlist.id && item.sourceOwnerUid === canonicalOwnerUid));
  if (existing) return existing;
  const now = Date.now();
  const copy = normalizePlaylist({
    id: createPlaylistId(),
    name: playlist.name,
    ownerUid: state.auth.user.uid,
    sourceType: 'public-copy',
    sourcePublicPlaylistId: playlist.id,
    sourceOwnerUid: canonicalOwnerUid,
    visibility: 'private',
    collaborative: false,
    createdAt: now,
    updatedAt: now,
    tracks: playlist.tracks || []
  });
  setActivePlaylists([copy, ...activePlaylists()]);
  notify(`“${copy.name}” ditambahkan ke Koleksi Kamu sebagai playlist private.`);
  return copy;
}

function updatePublicPlaylistDetailPlayback() {
  const sheet = $('.public-playlist-detail-player-sheet', modalRoot);
  const playlist = sheet?._datzonPublicPlaylist;
  if (!sheet || !playlist) return;
  const tracks = (playlist.tracks || []).map(normalizeTrack);
  const containsCurrent = Boolean(state.current && tracks.some(track => sameTrackIdentity(track, state.current)));
  $$('[data-public-playlist-track]', sheet).forEach(button => {
    const track = tracks[Number(button.dataset.publicPlaylistTrack)];
    const active = Boolean(track && state.current && sameTrackIdentity(track, state.current));
    const playing = Boolean(active && state.isPlaying);
    button.classList.toggle('is-current', active);
    button.classList.toggle('is-playing', playing);
    button.setAttribute('aria-current', active ? 'true' : 'false');
    const indicator = $('[data-public-track-playback-icon]', button);
    if (indicator) indicator.innerHTML = icon(playing ? 'pause' : 'play', playing ? '' : 'fill');
  });
  const main = $('[data-public-playlist-play]', sheet);
  if (main) {
    const playing = Boolean(containsCurrent && state.isPlaying);
    const preparing = Boolean(containsCurrent && state.resolving);
    main.classList.toggle('is-playing', playing);
    main.classList.toggle('is-loading', preparing);
    main.disabled = preparing || !tracks.length;
    main.setAttribute('aria-label', preparing ? 'Menyiapkan playlist' : playing ? 'Jeda playlist' : containsCurrent ? 'Lanjutkan playlist' : 'Putar playlist');
    main.innerHTML = preparing ? icon('refresh') : icon(playing ? 'pause' : 'play', playing ? '' : 'fill');
  }
}

function showPublicPlaylistDetail(playlist = {}, ownerProfile = {}) {
  const normalized = normalizePlaylist({ ...playlist, visibility:'public', ownerUid:playlist.ownerUid || ownerProfile.uid || '' });
  const tracks = (normalized.tracks || []).map(normalizeTrack);
  const context = publicPlaylistPlaybackContext(normalized, ownerProfile);
  const saved = isLoggedIn() && publicPlaylistAlreadySaved(normalized, ownerProfile);
  const trackRows = tracks.length ? tracks.map((track, index) => {
    const active = Boolean(state.current && sameTrackIdentity(track, state.current));
    const playing = Boolean(active && state.isPlaying);
    return `<button class="public-playlist-track-row ${active ? 'is-current' : ''} ${playing ? 'is-playing' : ''}" data-public-playlist-track="${index}" aria-current="${active ? 'true' : 'false'}">${trackArtworkWithPlayingMarkup(track.thumbnail, 'public-playlist-track-art')}<span><strong>${esc(cleanTitle(track))}</strong><small>${esc(track.artist)}</small></span><em>${esc(track.duration || '')}</em><i data-public-track-playback-icon>${icon(playing ? 'pause' : 'play', playing ? '' : 'fill')}</i></button>`;
  }).join('') : `<div class="empty"><h3>Playlist masih kosong</h3><p>Belum ada lagu yang dapat diputar.</p></div>`;
  const sheet = openPlayerSheet(`<div class="public-playlist-detail-sheet">
    <header>${playlistArtworkMarkup(normalized, 'public-playlist-detail-art')}<div><small>${normalized.collaborative ? 'PLAYLIST KOLABORATIF PUBLIK' : 'PLAYLIST PUBLIK'}</small><h2>${esc(normalized.name)}</h2><p>${tracks.length} lagu • @${esc(ownerProfile.username || 'pengguna')}</p></div><button data-public-playlist-play aria-label="Putar playlist">${icon('play','fill')}</button></header>
    <div class="public-playlist-detail-actions"><button class="${saved ? 'is-saved' : ''}" data-save-public-playlist ${saved ? 'disabled' : ''}>${icon(saved ? 'check-circle' : 'plus-circle')}<span>${saved ? 'Sudah di Koleksi' : 'Tambahkan ke Koleksi'}</span></button><button data-share-public-playlist>${icon('share')}<span>Bagikan</span></button></div>
    ${normalized.snapshotTruncated ? `<p class="public-playlist-limit-note">Menampilkan ${tracks.length} dari ${Number(normalized.totalTracks || tracks.length)} lagu pada snapshot publik.</p>` : ''}
    <div class="public-playlist-track-list">${trackRows}</div>
  </div>`, 'public-playlist-detail-player-sheet', { kind:'menu', initialSnap:'full' });
  sheet._datzonPublicPlaylist = normalized;
  sheet._datzonPublicPlaylistOwner = ownerProfile;
  $('[data-public-playlist-play]', sheet).onclick = async () => {
    if (!tracks.length) return;
    if (state.current && tracks.some(track => sameTrackIdentity(track, state.current))) {
      await togglePlay(); updatePublicPlaylistDetailPlayback(); return;
    }
    await playTrack(tracks[0], tracks, 0, { stayOnRoute:true, playContext:context });
    updatePublicPlaylistDetailPlayback();
  };
  $$('[data-public-playlist-track]', sheet).forEach(button => button.onclick = async () => {
    const index = Number(button.dataset.publicPlaylistTrack);
    const track = tracks[index];
    if (!track) return;
    if (state.current && sameTrackIdentity(track, state.current)) {
      await togglePlay(); updatePublicPlaylistDetailPlayback(); return;
    }
    await playTrack(track, tracks, index, { stayOnRoute:true, playContext:context });
    updatePublicPlaylistDetailPlayback();
  });
  $('[data-save-public-playlist]', sheet)?.addEventListener('click', event => {
    const savedPlaylist = savePublicPlaylistToLibrary(normalized, ownerProfile);
    if (!savedPlaylist) return;
    const button = event.currentTarget;
    button.disabled = true;
    button.classList.add('is-saved');
    button.innerHTML = `${icon('check-circle')}<span>Sudah di Koleksi</span>`;
  });
  $('[data-share-public-playlist]', sheet)?.addEventListener('click', async () => {
    const url = currentOriginUrl(`/u/${encodeURIComponent(ownerProfile.uid || normalized.ownerUid || '')}`);
    if (navigator.share) {
      try {
        await navigator.share({ title:`${normalized.name} di DATZON`, text:`Playlist publik oleh @${ownerProfile.username || 'pengguna'}`, url });
        return;
      } catch (error) {
        if (error?.name === 'AbortError') return;
      }
    }
    if (await copyTextSafely(url)) notify('Link profil pemilik playlist disalin');
    else notify('Link playlist belum dapat disalin di browser ini.');
  });
  updatePublicPlaylistDetailPlayback();
}

function playlistTrackDurationSeconds(track = {}) {
  const durationMs = Number(track.durationMs || track.duration_ms || 0);
  if (Number.isFinite(durationMs) && durationMs > 0) return Math.round(durationMs / 1000);
  const raw = String(track.duration || '').trim();
  if (!raw) return 0;
  const parts = raw.split(':').map(value => Number(value));
  if (!parts.length || parts.some(value => !Number.isFinite(value) || value < 0)) return 0;
  return Math.round(parts.reduce((total, value) => total * 60 + value, 0));
}

function playlistTotalDurationSeconds(playlist = {}) {
  const stored = Number(playlist.durationSeconds || 0);
  if (Number.isFinite(stored) && stored > 0) return Math.round(stored);
  return (playlist.tracks || []).reduce((total, track) => total + playlistTrackDurationSeconds(track), 0);
}

function formatPlaylistTotalDuration(seconds = 0) {
  const total = Math.max(0, Math.round(Number(seconds) || 0));
  if (!total) return '';
  const hours = Math.floor(total / 3600);
  const minutes = Math.floor((total % 3600) / 60);
  const secs = total % 60;
  if (hours) return `${hours} j${minutes ? ` ${minutes} mnt` : ''}`;
  if (minutes) return `${minutes} mnt${secs ? ` ${secs} dtk` : ''}`;
  return `${secs} dtk`;
}

function datzonPlaylistProfiles(playlist = {}, sourceProfile = null) {
  const map = new Map();
  (playlist.participantProfiles || []).forEach(item => {
    const uid = String(item?.uid || '').trim();
    if (!uid || map.has(uid)) return;
    map.set(uid, item);
  });
  const sourceUid = String(sourceProfile?.uid || '').trim();
  if (sourceUid && (playlist.participantUids || []).includes(sourceUid) && !map.has(sourceUid)) map.set(sourceUid, sourceProfile);
  const ownerUid = String(playlist.collabOwnerUid || playlist.ownerUid || '').trim();
  const currentUid = String(state.auth.user?.uid || '').trim();
  if (ownerUid === currentUid && !map.has(ownerUid)) {
    const own = state.auth.profile || {};
    map.set(ownerUid, { uid:ownerUid, fullName:own.fullName || own.username || state.username || 'Pengguna DATZON', username:own.username || '', photoURL:own.photoURL || state.auth.user?.photoURL || '' });
  }
  const profiles = [...map.values()];
  profiles.sort((left, right) => Number(String(right.uid || '') === ownerUid) - Number(String(left.uid || '') === ownerUid));
  return profiles;
}

function normalizeDatzonPlaylistForPage(raw = {}, sourceProfile = null) {
  const normalized = normalizePlaylist(raw);
  const profiles = datzonPlaylistProfiles(normalized, sourceProfile);
  const participantUids = [...new Set([...(normalized.participantUids || []), ...profiles.map(item => String(item.uid || '')).filter(Boolean)])].slice(0, 24);
  return normalizePlaylist({
    ...normalized,
    participantUids,
    profileUids: normalized.profileUids?.length ? normalized.profileUids : participantUids,
    participantProfiles: profiles,
    durationSeconds: playlistTotalDurationSeconds(normalized),
    listed: normalized.listed !== false
  });
}

function stopDatzonPlaylistStream() {
  try { datzonPlaylistUnsubscribe?.(); } catch {}
  datzonPlaylistUnsubscribe = null;
}

function startDatzonPlaylistStream(playlistId, service = firebaseService()) {
  stopDatzonPlaylistStream();
  const id = playlistIdFromValue(playlistId);
  if (!id || !service?.listenSharedPlaylist) return;
  try {
    datzonPlaylistUnsubscribe = service.listenSharedPlaylist(id, record => {
      if (String(state.datzonPlaylistView?.id || '') !== id) return;
      if (!record) {
        Promise.resolve(service?.getPlaylistTombstone?.(id)).then(tombstone => {
          if (String(state.datzonPlaylistView?.id || '') !== id) return;
          if (tombstone?.deleted || tombstone?.status === 'deleted') {
            state.datzonPlaylistView = { id, data:null, loading:false, error:'', deleted:true, sourceProfile:null };
            if (state.route === 'datzon-playlist') renderDatzonPlaylistPage();
            return;
          }
          if (!state.datzonPlaylistView?.data) {
            state.datzonPlaylistView = { ...state.datzonPlaylistView, loading:false, error:'Playlist tidak ditemukan.' };
            if (state.route === 'datzon-playlist') renderDatzonPlaylistPage();
          }
        }).catch(() => {
          if (!state.datzonPlaylistView?.data) {
            state.datzonPlaylistView = { ...state.datzonPlaylistView, loading:false, error:'Playlist tidak ditemukan.' };
            if (state.route === 'datzon-playlist') renderDatzonPlaylistPage();
          }
        });
        return;
      }
      state.datzonPlaylistView = {
        ...state.datzonPlaylistView,
        data: normalizeDatzonPlaylistForPage(record, state.datzonPlaylistView.sourceProfile),
        loading:false,
        error:''
      };
      if (state.route === 'datzon-playlist') renderDatzonPlaylistPage();
    }, error => {
      if (String(state.datzonPlaylistView?.id || '') !== id) return;
      // A private/member-only canonical document can turn into a rules error at
      // the exact moment it is deleted because `resource.data` no longer exists.
      // Check the public, content-free tombstone before retaining cached content.
      Promise.resolve(service?.getPlaylistTombstone?.(id)).then(tombstone => {
        if (String(state.datzonPlaylistView?.id || '') !== id) return;
        if (tombstone?.deleted || tombstone?.status === 'deleted') {
          state.datzonPlaylistView = { id, data:null, loading:false, error:'', deleted:true, sourceProfile:null };
          if (state.route === 'datzon-playlist') renderDatzonPlaylistPage();
          return;
        }
        if (state.datzonPlaylistView?.data) return;
        state.datzonPlaylistView = { ...state.datzonPlaylistView, loading:false, error:error?.message || 'Playlist tidak dapat dibuka.' };
        if (state.route === 'datzon-playlist') renderDatzonPlaylistPage();
      }).catch(() => {
        if (state.datzonPlaylistView?.data) return;
        state.datzonPlaylistView = { ...state.datzonPlaylistView, loading:false, error:error?.message || 'Playlist tidak dapat dibuka.' };
        if (state.route === 'datzon-playlist') renderDatzonPlaylistPage();
      });
    });
  } catch (error) {
    if (!state.datzonPlaylistView?.data) state.datzonPlaylistView = { ...state.datzonPlaylistView, loading:false, error:error?.message || 'Playlist tidak dapat dibuka.' };
  }
}

function openDatzonPlaylistPage(playlist = {}, sourceProfile = {}) {
  const normalized = normalizeDatzonPlaylistForPage(playlist, sourceProfile);
  if (!normalized.id) return;
  stopPublicProfilePlaylistStream();
  stopDatzonPlaylistStream();
  const previousRoute = state.route;
  resetModalRoot();
  state.datzonPlaylistView = { id:normalized.id, data:normalized, loading:false, error:'', deleted:false, sourceProfile };
  state.route = 'datzon-playlist';
  syncBrowserRoute('datzon-playlist', { playlistId:normalized.id, fromRoute:previousRoute });
  resetRouteViewport();
  render();
  startDatzonPlaylistStream(normalized.id);
}

async function loadDatzonPlaylistRoute(playlistId, options = {}) {
  const id = playlistIdFromValue(playlistId);
  if (!id) {
    state.route = 'home';
    syncBrowserRoute('home', { replace:true });
    render();
    return;
  }
  stopPublicProfilePlaylistStream();
  stopDatzonPlaylistStream();
  const previousView = state.datzonPlaylistView || {};
  const cachedData = String(previousView.id || '') === id && previousView.data
    ? normalizeDatzonPlaylistForPage(previousView.data, previousView.sourceProfile)
    : null;
  const cachedSourceProfile = cachedData ? previousView.sourceProfile : null;
  state.route = 'datzon-playlist';
  state.datzonPlaylistView = { id, data:cachedData, loading:!cachedData, error:'', deleted:false, sourceProfile:cachedSourceProfile };
  if (options.replace) syncBrowserRoute('datzon-playlist', { replace:true, playlistId:id });
  render();
  try {
    const service = await ensureFirebaseReady();
    if (!service?.getSharedPlaylist) throw new Error('Firebase belum siap.');
    const tombstone = await service.getPlaylistTombstone?.(id).catch(() => null);
    if (tombstone?.deleted || tombstone?.status === 'deleted') {
      if (String(state.datzonPlaylistView?.id || '') !== id) return;
      state.datzonPlaylistView = { id, data:null, loading:false, error:'', deleted:true, sourceProfile:null };
      render();
      return;
    }
    const record = await service.getSharedPlaylist(id);
    if (!record) throw new Error('Playlist tidak ditemukan atau belum memiliki lagu.');
    if (String(state.datzonPlaylistView?.id || '') !== id) return;
    state.datzonPlaylistView = { id, data:normalizeDatzonPlaylistForPage(record), loading:false, error:'', deleted:false, sourceProfile:null };
    render();
    startDatzonPlaylistStream(id, service);
  } catch (error) {
    if (String(state.datzonPlaylistView?.id || '') !== id) return;
    try {
      const tombstone = await firebaseService()?.getPlaylistTombstone?.(id);
      if (tombstone?.deleted || tombstone?.status === 'deleted') {
        state.datzonPlaylistView = { id, data:null, loading:false, error:'', deleted:true, sourceProfile:null };
        render();
        return;
      }
    } catch {}
    const retained = state.datzonPlaylistView?.data;
    const canRetain = retained && (retained.visibility === 'public' || datzonPlaylistMembership(retained));
    if (canRetain) {
      state.datzonPlaylistView = { ...state.datzonPlaylistView, loading:false, error:'' };
      render();
      startDatzonPlaylistStream(id);
      return;
    }
    const denied = /permission|izin|akses/i.test(String(error?.code || error?.message || ''));
    state.datzonPlaylistView = { id, data:null, loading:false, error:denied ? 'Playlist ini private. Hanya anggota kolaborasi yang dapat membukanya.' : (error?.message || 'Playlist tidak dapat dibuka.'), sourceProfile:null };
    render();
  }
}

function datzonPlaylistPlaybackContext(playlist = {}) {
  return {
    eyebrow: playlist.collaborative
      ? `MEMAINKAN DARI PLAYLIST KOLABORATIF ${playlist.visibility === 'public' ? 'PUBLIK' : 'PRIVATE'}`
      : 'MEMAINKAN DARI PLAYLIST DATZON',
    label: playlist.name || 'Playlist DATZON',
    type: 'datzon-playlist',
    id: playlist.id || '',
    ownerUid: playlist.collabOwnerUid || playlist.ownerUid || ''
  };
}

function datzonPlaylistMembership(playlist = {}) {
  const uid = String(state.auth.user?.uid || '');
  return Boolean(uid && (playlist.participantUids || []).includes(uid));
}

function addDatzonPlaylistToLibrary(playlist = {}, sourceProfile = {}) {
  if (!isLoggedIn()) {
    notify('Masuk ke akun untuk menambahkan playlist ini.');
    navigate('login');
    return null;
  }
  const existing = activePlaylists().find(item => item.id === playlist.id || (item.sourcePublicPlaylistId === playlist.id && item.sourceOwnerUid === playlist.ownerUid));
  if (existing) return existing;
  if (datzonPlaylistMembership(playlist)) {
    const synced = normalizeDatzonPlaylistForPage(playlist, sourceProfile);
    setActivePlaylists([synced, ...activePlaylists()]);
    notify(`“${synced.name}” disinkronkan ke Koleksi Kamu.`);
    return synced;
  }
  return savePublicPlaylistToLibrary(playlist, sourceProfile);
}

async function shareDatzonPlaylist(playlist = {}) {
  if (playlist.visibility !== 'public') {
    notify('Hanya playlist publik yang dapat dibagikan lewat link.');
    return;
  }
  const currentUid = String(state.auth.user?.uid || '');
  const ownerUid = String(playlist.collabOwnerUid || playlist.ownerUid || '');
  if (currentUid && currentUid === ownerUid) {
    try {
      // Pastikan canonical /musicPlaylists dan seluruh index profil sudah ada
      // sebelum link diberikan ke orang lain.
      await firebaseService()?.syncSharedPlaylistDirectory?.(activePlaylists(), []);
    } catch (error) {
      console.warn('[DATZON share playlist publish]', error);
      notify('Playlist belum berhasil disinkronkan ke Firebase. Coba bagikan lagi sebentar lagi.');
      return;
    }
  }
  const url = currentOriginUrl(`/datzon-playlist/${encodeURIComponent(playlist.id || '')}`);
  try {
    if (navigator.share) {
      await navigator.share({ title:`${playlist.name || 'Playlist'} • DATZON Music`, text:'Dengerin playlist publik ini di DATZON Music.', url });
      return;
    }
    if (await copyTextSafely(url)) notify('Link playlist disalin');
  } catch (error) {
    if (error?.name !== 'AbortError') notify('Link playlist belum berhasil dibagikan.');
  }
}

function updateDatzonPlaylistPagePlayback() {
  if (state.route !== 'datzon-playlist') return;
  const playlist = state.datzonPlaylistView?.data;
  if (!playlist) return;
  const tracks = (playlist.tracks || []).map(normalizeTrack);
  const containsCurrent = Boolean(state.current && tracks.some(track => sameTrackIdentity(track, state.current)));
  const playing = Boolean(containsCurrent && state.isPlaying && !audio.paused && !audio.ended);
  const preparing = Boolean(containsCurrent && (state.resolving || state.playerPreparing));
  const main = $('[data-datzon-playlist-play]', view);
  if (main) {
    main.classList.toggle('is-playing', playing);
    main.classList.toggle('is-loading', preparing);
    main.disabled = preparing || !tracks.length;
    main.setAttribute('aria-label', preparing ? 'Menyiapkan playlist' : playing ? 'Jeda playlist' : containsCurrent ? 'Lanjutkan playlist' : 'Putar playlist');
    main.innerHTML = preparing ? icon('refresh') : icon(playing ? 'pause' : 'play', playing ? '' : 'fill');
  }
  $$('[data-datzon-playlist-track]', view).forEach(row => {
    const track = tracks[Number(row.dataset.datzonPlaylistTrack)];
    const active = Boolean(track && state.current && sameTrackIdentity(track, state.current));
    row.classList.toggle('is-current', active);
    row.classList.toggle('is-playing', active && state.isPlaying);
    row.setAttribute('aria-current', active ? 'true' : 'false');
  });
}

function renderDatzonPlaylistPage() {
  const current = state.datzonPlaylistView || {};
  if (current.loading) {
    view.innerHTML = `<div class="page spotify-collection-detail-page datzon-playlist-detail-page is-playlist"><header class="spotify-collection-route-head"><button data-datzon-playlist-back aria-label="Kembali">${icon('arrow-left')}</button><span></span></header><section class="spotify-collection-hero"><span class="skeleton spotify-detail-cover-skeleton"></span><div class="spotify-detail-copy"><span class="skeleton spotify-detail-title-skeleton"></span><span class="skeleton spotify-detail-subtitle-skeleton"></span><span class="skeleton spotify-detail-meta-skeleton"></span></div></section><div class="spotify-track-skeleton-list">${Array.from({length:5},()=>`<div><span class="skeleton"></span><p><b class="skeleton"></b><i class="skeleton"></i></p></div>`).join('')}</div></div>`;
    $('[data-datzon-playlist-back]', view)?.addEventListener('click', () => navigateBack('home'));
    return;
  }
  if (current.deleted) {
    view.innerHTML = `<div class="page spotify-collection-detail-page datzon-playlist-detail-page is-playlist"><header class="spotify-collection-route-head"><button data-datzon-playlist-back aria-label="Kembali">${icon('arrow-left')}</button><span></span></header><div class="spotify-collection-error datzon-playlist-deleted-state"><span>${icon('trash')}</span><h2>Playlist sudah dihapus</h2><p>Playlist ini telah dihapus oleh pembuatnya. Lagu, cover, kolaborator, dan isi playlist sudah tidak tersedia.</p></div></div>`;
    $('[data-datzon-playlist-back]', view)?.addEventListener('click', () => navigateBack('home'));
    return;
  }
  if (current.error || !current.data) {
    view.innerHTML = `<div class="page spotify-collection-detail-page datzon-playlist-detail-page is-playlist"><header class="spotify-collection-route-head"><button data-datzon-playlist-back aria-label="Kembali">${icon('arrow-left')}</button><span></span></header><div class="spotify-collection-error"><span>${icon('lock')}</span><h2>Playlist tidak tersedia</h2><p>${esc(current.error || 'Playlist tidak dapat dibuka.')}</p><button data-retry-datzon-playlist>Coba lagi</button></div></div>`;
    $('[data-datzon-playlist-back]', view)?.addEventListener('click', () => navigateBack('home'));
    $('[data-retry-datzon-playlist]', view)?.addEventListener('click', () => loadDatzonPlaylistRoute(current.id));
    return;
  }
  const playlist = normalizeDatzonPlaylistForPage(current.data, current.sourceProfile);
  const tracks = (playlist.tracks || []).map(normalizeTrack);
  const profiles = datzonPlaylistProfiles(playlist, current.sourceProfile);
  const ownerUid = String(playlist.collabOwnerUid || playlist.ownerUid || '');
  const owner = profiles.find(item => String(item.uid || '') === ownerUid) || current.sourceProfile || profiles[0] || {};
  const duration = formatPlaylistTotalDuration(playlistTotalDurationSeconds(playlist));
  const meta = ['Playlist', `${tracks.length} lagu`, duration].filter(Boolean).join(' • ');
  const existing = isLoggedIn() && publicPlaylistAlreadySaved(playlist, owner);
  const member = datzonPlaylistMembership(playlist);
  const collectionLabel = existing ? 'Sudah di Koleksi' : member ? 'Sinkronkan ke Koleksi' : 'Tambahkan ke Koleksi';
  const kicker = playlist.collaborative
    ? `PLAYLIST KOLABORATIF ${playlist.visibility === 'public' ? 'PUBLIK' : 'PRIVATE'}`
    : 'PLAYLIST PUBLIK';
  view.innerHTML = `<div class="page spotify-collection-detail-page datzon-playlist-detail-page is-playlist" data-datzon-playlist-page>
    <header class="spotify-collection-route-head"><button data-datzon-playlist-back aria-label="Kembali">${icon('arrow-left')}</button><strong>${esc(playlist.name)}</strong></header>
    <section class="spotify-collection-hero datzon-playlist-hero" data-datzon-playlist-hero>
      <div class="spotify-collection-hero-art">${playlistArtworkMarkup(playlist, 'datzon-playlist-hero-artwork')}</div>
      <div class="spotify-detail-copy"><p class="spotify-kicker">${esc(kicker)}</p><h1>${esc(playlist.name)}</h1><div class="datzon-playlist-brand">DATZON</div>
        <div class="datzon-playlist-owner-line"><span>Dibuat oleh</span><button data-open-datzon-profile="${esc(owner.uid || ownerUid)}">${esc(owner.fullName || owner.username || 'Pengguna DATZON')} <small>@${esc(owner.username || 'pengguna')}</small></button></div>
        ${playlist.collaborative && profiles.length ? `<div class="datzon-playlist-participants"><span>Kolaborator</span><div>${profiles.map(profile => `<button data-open-datzon-profile="${esc(profile.uid)}"><img src="${esc(collaboratorAvatar(profile))}" alt="" onerror="this.src='${esc(defaultProfileAvatar(profile.fullName || profile.username || 'D'))}'"><span>${esc(profile.fullName || profile.username || 'Pengguna')}<small>@${esc(profile.username || 'pengguna')}</small></span></button>`).join('')}</div></div>` : ''}
        <p class="spotify-collection-meta">${esc(meta)}</p>
      </div>
    </section>
    <div class="spotify-collection-actions datzon-playlist-actions"><button class="spotify-round-action ${existing ? 'is-saved' : ''}" data-save-datzon-playlist aria-label="${esc(collectionLabel)}" ${existing ? 'disabled' : ''}>${icon(existing ? 'check-circle' : 'plus-circle')}</button><button class="spotify-round-action" data-share-datzon-playlist aria-label="${playlist.visibility === 'public' ? 'Bagikan playlist' : 'Playlist private tidak dapat dibagikan'}" ${playlist.visibility === 'public' ? '' : 'disabled'}>${icon('share')}</button><span></span><button class="spotify-main-play" data-datzon-playlist-play aria-label="Putar playlist">${icon('play','fill')}</button></div>
    <section class="spotify-collection-track-list datzon-playlist-track-list">${tracks.length ? tracks.map((track,index)=>{const active=Boolean(state.current&&sameTrackIdentity(track,state.current));const playing=Boolean(active&&state.isPlaying);return `<button class="spotify-collection-track spotify-playlist-track datzon-playlist-track ${active?'is-current':''} ${playing?'is-playing':''}" data-datzon-playlist-track="${index}" aria-current="${active?'true':'false'}">${trackArtworkWithPlayingMarkup(track.thumbnail,'spotify-playlist-track-art')}<span><strong>${esc(cleanTitle(track))}</strong><small>${esc(track.artist || 'Artis tidak diketahui')}</small></span><em>${esc(track.duration || '')}</em><i data-datzon-playlist-more="${index}" role="button" aria-label="Pilihan lagu">${icon('more')}</i></button>`;}).join('') : `<div class="spotify-collection-empty">Playlist belum memiliki lagu.</div>`}</section>
    <p class="spotify-collection-total">${esc(meta)}</p>
  </div>`;
  $('[data-datzon-playlist-back]', view)?.addEventListener('click', () => navigateBack('home'));
  $$('[data-open-datzon-profile]', view).forEach(button => button.onclick = () => { const uid=String(button.dataset.openDatzonProfile || ''); if(uid) openPublicProfile(uid); });
  $('[data-save-datzon-playlist]', view)?.addEventListener('click', event => {
    const saved = addDatzonPlaylistToLibrary(playlist, owner);
    if (!saved || !isLoggedIn()) return;
    event.currentTarget.disabled = true;
    event.currentTarget.classList.add('is-saved');
    event.currentTarget.innerHTML = icon('check-circle');
  });
  $('[data-share-datzon-playlist]', view)?.addEventListener('click', () => shareDatzonPlaylist(playlist));
  $('[data-datzon-playlist-play]', view)?.addEventListener('click', async () => {
    if (!tracks.length) return;
    if (state.current && tracks.some(track => sameTrackIdentity(track, state.current))) {
      await togglePlay(); updateDatzonPlaylistPagePlayback(); return;
    }
    await playTrack(tracks[0], tracks, 0, { stayOnRoute:true, playContext:datzonPlaylistPlaybackContext(playlist) });
    updateDatzonPlaylistPagePlayback();
  });
  $$('[data-datzon-playlist-track]', view).forEach(row => row.onclick = async event => {
    const index = Number(row.dataset.datzonPlaylistTrack);
    const track = tracks[index];
    if (!track) return;
    if (event.target.closest('[data-datzon-playlist-more]')) { event.stopPropagation(); showTrackMenu(track); return; }
    if (state.current && sameTrackIdentity(track, state.current)) { await togglePlay(); updateDatzonPlaylistPagePlayback(); return; }
    await playTrack(track, tracks, index, { stayOnRoute:true, playContext:datzonPlaylistPlaybackContext(playlist) });
    updateDatzonPlaylistPagePlayback();
  });
  // Halaman playlist DATZON mengikuti --app-accent-rgb global, yaitu warna
  // dominan lagu yang sedang diputar. Jangan override dari cover playlist.
  updateDatzonPlaylistPagePlayback();
}

function renderPublicProfilePage() {
  const data = state.publicProfileView;
  const profile = data.profile || {};
  if (data.loading) {
    view.innerHTML = `<div class="page spotify-settings-page utility-page public-profile-page">${socialPageHeader('Profil Pengguna','Memuat profil publik')}<div class="public-profile-loading">Memuat informasi pengguna...</div></div>`;
    bindSocialPageHeader(); return;
  }
  if (!profile.uid) {
    view.innerHTML = `<div class="page spotify-settings-page utility-page public-profile-page">${socialPageHeader('Profil Pengguna','DATZON Music')}<div class="social-login-empty">${icon('alert')}<h2>Profil tidak tersedia</h2><p>${esc(data.error || 'Pengguna tidak ditemukan.')}</p></div></div>`;
    bindSocialPageHeader(); return;
  }
  const self = String(data.uid || profile.uid || '') === String(state.auth.user?.uid || '');
  const summary = profile.listeningSummary || {};
  const social = data.social || { friends:[], following:[], followers:[] };
  const indexedPlaylists = normalizePlaylists(data.playlists || []);
  const localSelfPlaylists = self ? activePlaylists() : [];
  // Keep the public-profile snapshot as a safety net even after the realtime
  // directory listener reports ready. The server index is authoritative for
  // cross-user collaboration/private membership, while the profile snapshot
  // guarantees an owner's public single playlist never disappears just because
  // an older client/index write was missed.
  const publicPlaylists = mergePlaylistsById(localSelfPlaylists, mergePlaylistsById(indexedPlaylists, publicPlaylistsFromProfile(profile)))
    .filter(playlist => playlist.listed && playlist.tracks.length)
    .filter(playlist => playlist.visibility === 'public' || (playlist.participantUids || []).includes(String(state.auth.user?.uid || '')))
    .sort((a, b) => Number(b.updatedAt || 0) - Number(a.updatedAt || 0));
  const hasPrivateCollaboration = publicPlaylists.some(playlist => playlist.visibility === 'private' && playlist.collaborative);
  const relation = data.relationship;
  let relationshipLabel = 'Tambah teman';
  if (relation?.status === 'friends') relationshipLabel = 'Teman';
  else if ((relation?.followerUids || []).includes(state.auth.user?.uid)) relationshipLabel = relation?.status === 'pending' ? 'Diminta' : 'Mengikuti';
  else if ((relation?.followerUids || []).includes(profile.uid)) relationshipLabel = 'Ikuti balik';
  view.innerHTML = `<div class="page spotify-settings-page utility-page public-profile-page">${socialPageHeader(profile.fullName || 'Profil Pengguna', '@'+(profile.username || 'pengguna'))}
    <section class="public-profile-hero">${publicAvatarMarkup(profile,'public-profile-avatar')}<h1>${esc(profile.fullName || profile.username)}</h1><p>@${esc(profile.username || 'pengguna')}</p><span class="public-status status-${esc(profile.status || 'offline')}"><i></i>${esc(accountStatusLabel(profile.status || 'offline'))}</span></section>
    ${profileSocialStatsMarkup(social)}
    ${profileBioMarkup(profile)}
    <section class="utility-stat-grid"><article><strong>${Number(summary.plays || 0)}</strong><span>Lagu diputar</span></article><article><strong>${esc(formatListeningTime(summary.totalSeconds || 0))}</strong><span>Total mendengarkan</span></article><article><strong>${esc(profile.createdAtIso ? new Date(profile.createdAtIso).getFullYear() : 'DATZON')}</strong><span>Bergabung</span></article></section>
    <section class="public-profile-actions">${self ? `<button data-edit-own-profile>${icon('user')} Edit profil saya</button>` : `<button class="primary" data-public-add="${esc(profile.uid)}">${icon('group')} ${esc(relationshipLabel)}</button>`}<button data-share-public>${icon('share')} Bagikan profil</button></section>
    <section class="public-profile-playlists"><header><div><small>${hasPrivateCollaboration ? 'PLAYLIST PUBLIK & KOLABORASI' : 'PLAYLIST PUBLIK'}</small><h2>Playlist ${esc(profile.fullName || profile.username)}</h2></div><span>${publicPlaylists.length}</span></header>${publicPlaylists.length ? `<div class="public-profile-playlist-grid">${publicPlaylists.map((playlist, index) => `<button data-open-public-playlist="${index}">${playlistArtworkMarkup(playlist, 'public-profile-playlist-art', true)}<span><strong>${esc(playlist.name)}</strong><small>${playlist.collaborative ? `Kolaboratif ${playlist.visibility === 'private' ? 'private' : 'publik'} • ` : 'Publik • '}${Number(playlist.totalTracks || playlist.tracks.length)} lagu</small></span>${playlist.visibility === 'private' ? icon('lock') : icon('chevron')}</button>`).join('')}</div>` : `<div class="public-profile-playlist-empty">${icon('lock')}<p>Belum ada playlist publik yang dibuat.</p></div>`}</section>
  </div>`;
  bindSocialPageHeader();
  bindProfileSocialStats(view, social, profile);
  $('[data-edit-own-profile]', view)?.addEventListener('click', () => navigate('profile'));
  $('[data-public-add]', view)?.addEventListener('click', event => {
    if (relationshipLabel === 'Teman') { showUnfriendConfirm(profile.uid); return; }
    if (['Diminta','Mengikuti'].includes(relationshipLabel)) { showUnfollowConfirm(profile.uid); return; }
    requestFriend(profile.uid, event.currentTarget);
  });
  requestAnimationFrame(() => {
    const avatarUrl = String(profile.photoURL || profile.photoUrl || profile.avatar || profile.image || '').trim();
    if (avatarUrl && !/placeholder/i.test(avatarUrl)) window.DatzonDominantColor?.apply?.($('.public-profile-hero', view), avatarUrl);
  });
  $('[data-share-public]', view)?.addEventListener('click', async () => {
    const url = currentOriginUrl(`/u/${encodeURIComponent(profile.uid)}`);
    try { await navigator.share?.({ title:`${profile.fullName} di DATZON`, url }); }
    catch { await navigator.clipboard?.writeText(url); notify('Link profil disalin'); }
  });
  $$('[data-open-public-playlist]', view).forEach(button => button.onclick = () => {
    const playlist = publicPlaylists[Number(button.dataset.openPublicPlaylist)];
    if (playlist) openDatzonPlaylistPage(playlist, profile);
  });
  if (isLoggedIn() && !state.social.loaded && !state.social.loading) loadSocialGraph(true).catch(() => {});
}

function stopLeaderboardStream() {
  try { leaderboardUnsubscribe?.(); } catch {}
  leaderboardUnsubscribe = null;
}

function startLeaderboardStream(service = firebaseService()) {
  stopLeaderboardStream();
  state.social.leaderboardLoading = true;
  state.social.leaderboard = [];
  if (!service?.listenLeaderboard) {
    loadLeaderboard(true).then(() => { if (state.route === 'leaderboard') renderLeaderboardPage(); });
    return;
  }
  try {
    leaderboardUnsubscribe = service.listenLeaderboard(50, rows => {
      state.social.leaderboard = Array.isArray(rows) ? rows : [];
      state.social.leaderboardLoading = false;
      if (state.route === 'leaderboard') renderLeaderboardPage();
    }, error => {
      state.social.leaderboardLoading = false;
      if (state.route === 'leaderboard') renderLeaderboardPage();
      console.warn('[DATZON leaderboard realtime]', error);
    });
  } catch (error) {
    state.social.leaderboardLoading = false;
    console.warn('[DATZON leaderboard realtime]', error);
  }
}

async function loadLeaderboard(force = false) {
  if (state.social.leaderboardLoading && !force) return;
  if (state.social.leaderboard.length && !force) return;
  state.social.leaderboardLoading = true;
  try {
    const service = await ensureFirebaseReady();
    state.social.leaderboard = service ? await service.getLeaderboard(50) : [];
  } catch (error) {
    notify(firebaseService()?.firebaseErrorMessage?.(error) || error?.message || 'Leaderboard gagal dimuat');
  }
  state.social.leaderboardLoading = false;
}

function renderLeaderboardPage() {
  if (!leaderboardUnsubscribe && !state.social.leaderboardLoading) startLeaderboardStream();
  const rows = state.social.leaderboard || [];
  view.innerHTML = `<div class="page spotify-settings-page utility-page leaderboard-page">${settingsPageHeader('Leaderboard','Peringkat waktu mendengarkan komunitas')}
    <section class="leaderboard-podium">${rows.slice(0,3).map((profile,index)=>`<button data-public-profile="${esc(profile.uid)}" class="podium-${index+1}">${publicAvatarMarkup(profile,'leaderboard-avatar')}<b>#${index+1}</b><strong>${esc(profile.fullName || profile.username)}</strong><span>${esc(formatListeningTime(profile.listeningSummary?.totalSeconds || 0))}</span></button>`).join('')}</section>
    <section class="leaderboard-list">${state.social.leaderboardLoading ? '<div class="social-loading">Memuat leaderboard...</div>' : rows.length ? rows.map((profile,index)=>`<button data-public-profile="${esc(profile.uid)}"><b>${index+1}</b>${publicAvatarMarkup(profile,'leaderboard-row-avatar')}<span><strong>${esc(profile.fullName || profile.username)}</strong><small>@${esc(profile.username || 'pengguna')}</small></span><em>${esc(formatListeningTime(profile.listeningSummary?.totalSeconds || 0))}</em></button>`).join('') : '<div class="social-empty">Leaderboard belum memiliki data.</div>'}</section>
  </div>`;
  bindUtilityHeader();
  bindSocialRows(view);
}


function combinedNotificationItems() {
  const announcements = (state.announcements || []).map(item => ({ ...item, source:'announcement', read:(state.announcementReads || []).includes(item.id) }));
  const personal = (state.globalNotifications || []).map(item => ({ ...item, source:'personal' }));
  return [...personal, ...announcements].sort((a,b) => Number(b.createdAtMs || timestampMillis(b.createdAt)) - Number(a.createdAtMs || timestampMillis(a.createdAt)));
}

function notificationReportAccess(item = {}) {
  const reportId = String(item.actionData?.reportId || item.reportId || '').trim();
  if (!reportId || !isLoggedIn()) return { reportId:'', allowed:false };
  const currentUid = String(state.auth?.user?.uid || '').trim();
  const reporterUid = String(item.actionData?.reporterUid || item.reporterUid || '').trim();
  const personalReporterUpdate = item.source === 'personal' && ['report_confirmed','report_fixed'].includes(String(item.type || ''));
  return {
    reportId,
    allowed: Boolean(currentUid && ((reporterUid && reporterUid === currentUid) || (!reporterUid && personalReporterUpdate)))
  };
}

function globalNotificationMarkup() {
  const items = combinedNotificationItems();
  if (!items.length) return `<div class="global-notification-empty">${icon('bell')}<strong>Belum ada notifikasi</strong><span>Permintaan teman, Dengar Bareng, dan kabar dari admin akan tampil di sini.</span></div>`;
  return items.map(item => {
    const type = item.type || 'notice';
    const request = type === 'friend_request';
    const listenRequest = type === 'listen_together_request';
    const profileUid = item.fromUid || item.actionData?.profileUid || '';
    const reportAccess = notificationReportAccess(item);
    const reportId = reportAccess.reportId;
    const canOpenReport = reportAccess.allowed;
    return `<article class="global-notification-item ${item.read ? '' : 'is-unread'}" data-notification-id="${esc(item.id)}" data-notification-source="${esc(item.source)}">
      ${type.includes('report') ? `<span class="notification-type-icon">${icon('report')}</span>` : item.fromPhotoURL ? `<span class="notification-avatar has-photo"><img src="${esc(item.fromPhotoURL)}" alt=""></span>` : `<span class="notification-type-icon">${icon(type === 'announcement' ? 'info' : type.includes('friend') ? 'group' : type.includes('listen') ? 'music' : 'bell')}</span>`}
      <div><strong>${esc(item.title || 'Notifikasi DATZON')}</strong><p>${esc(item.message || '')}</p><small>${esc(socialTimeText(item.createdAtMs || item.createdAt))}</small>
      ${(request || listenRequest) ? `<div class="notification-actions"><button class="accept" data-notification-accept>Terima</button><button data-notification-reject>Tolak</button></div>` : ''}
      </div>${canOpenReport ? `<button class="notification-open-profile" data-notification-report="${esc(reportId)}">${icon('chevron')}</button>` : (!reportId && profileUid) ? `<button class="notification-open-profile" data-notification-profile="${esc(profileUid)}">${icon('chevron')}</button>` : ''}
    </article>`;
  }).join('');
}

function refreshGlobalNotificationsSheet() {
  const list = $('[data-global-notification-list]', modalRoot);
  if (list) list.innerHTML = globalNotificationMarkup();
  bindGlobalNotificationActions();
}

function bindGlobalNotificationActions() {
  $$('[data-notification-profile]', modalRoot).forEach(button => button.onclick = event => { event.stopPropagation(); closeModal(true); openPublicProfile(button.dataset.notificationProfile); });
  $$('[data-notification-report]', modalRoot).forEach(button => button.onclick = event => { event.stopPropagation(); const id=button.dataset.notificationReport; closeModal(true); setTimeout(()=>showReportDetail(id),80); });
  $$('[data-notification-id]', modalRoot).forEach(card => card.onclick = () => {
    if (card.dataset.notificationSource === 'announcement') {
      if (!state.announcementReads.includes(card.dataset.notificationId)) state.announcementReads.push(card.dataset.notificationId);
      storage.set('announcementReads', state.announcementReads.slice(-100));
      card.classList.remove('is-unread'); updateGlobalNotificationBadge();
      const item = state.announcements.find(entry => entry.id === card.dataset.notificationId);
      const access = notificationReportAccess({ ...(item || {}), source:'announcement' });
      if (access.allowed) { closeModal(true); setTimeout(()=>showReportDetail(access.reportId),80); }
    } else {
      const item = state.globalNotifications.find(entry => entry.id === card.dataset.notificationId);
      Promise.resolve(firebaseService()?.markNotificationRead?.(card.dataset.notificationId)).catch(() => {});
      const access = notificationReportAccess({ ...(item || {}), source:'personal' });
      if (access.allowed) { closeModal(true); setTimeout(()=>showReportDetail(access.reportId),80); }
    }
  });
  $$('[data-notification-accept]', modalRoot).forEach(button => button.onclick = async event => {
    event.stopPropagation();
    const card = event.currentTarget.closest('[data-notification-id]');
    const item = state.globalNotifications.find(entry => entry.id === card?.dataset.notificationId);
    if (!item) return;
    button.disabled = true;
    try {
      const service = await ensureFirebaseReady();
      if (item.type === 'friend_request') {
        await service.acceptFriendRequest(item); state.social.loaded = false; await loadSocialGraph(true); notify('Permintaan teman diterima');
      } else if (item.type === 'listen_together_request') {
        const result = await service.respondListenTogether(item, true);
        closeModal(true);
        if (result?.track) { const togetherTrack = normalizeTrack(result.track); const startAt = Math.max(0, Number(result.track._listenPosition || 0) + Math.max(0, (Date.now() - Number(result.track._listenSentAt || Date.now())) / 1000)); playTrack(togetherTrack, [togetherTrack], 0, { startAt, playContext:{ eyebrow:'DENGAR BARENG', label:item.fromName || 'Teman DATZON' } }); }
        notify('Dengar Bareng dimulai');
      }
    } catch (error) { notify(firebaseService()?.firebaseErrorMessage?.(error) || error?.message || 'Aksi gagal'); }
  });
  $$('[data-notification-reject]', modalRoot).forEach(button => button.onclick = async event => {
    event.stopPropagation();
    const card = event.currentTarget.closest('[data-notification-id]');
    const item = state.globalNotifications.find(entry => entry.id === card?.dataset.notificationId);
    if (!item) return;
    button.disabled = true;
    try {
      const service = await ensureFirebaseReady();
      if (item.type === 'friend_request') { await service.rejectFriendRequest(item); state.social.loaded = false; await loadSocialGraph(true); }
      else if (item.type === 'listen_together_request') await service.respondListenTogether(item, false);
      notify('Permintaan ditolak');
    } catch (error) { notify(firebaseService()?.firebaseErrorMessage?.(error) || error?.message || 'Aksi gagal'); }
  });
}

function showGlobalNotificationsSheet() {
  state.notificationsOpen = true;
  const sheet = openPlayerSheet(`<div class="global-notification-sheet"><header><div><small>NOTIFIKASI</small><h2>Aktivitas terbaru</h2></div><button data-mark-all-read>Tandai dibaca</button></header><div data-global-notification-list>${globalNotificationMarkup()}</div></div>`, 'global-notification-player-sheet', { kind:'menu', initialSnap:'full' });
  $('[data-mark-all-read]', sheet).onclick = async () => {
    state.announcementReads = [...new Set([...(state.announcementReads || []), ...(state.announcements || []).map(item => item.id)])];
    storage.set('announcementReads', state.announcementReads.slice(-100));
    await Promise.all((state.globalNotifications || []).filter(item => !item.read).map(item => Promise.resolve(firebaseService()?.markNotificationRead?.(item.id)).catch(() => {})));
    updateGlobalNotificationBadge(); refreshGlobalNotificationsSheet();
  };
  bindGlobalNotificationActions();
  const observer = new MutationObserver(() => { if (!modalRoot.querySelector('.global-notification-player-sheet')) { state.notificationsOpen = false; observer.disconnect(); } });
  observer.observe(modalRoot,{childList:true});
}

function showListenTogetherFriends(track = state.current, options = {}) {
  if (!isLoggedIn()) { notify('Login untuk memakai Dengar Bareng'); navigate('login'); return; }
  loadSocialGraph(true).then(() => {
    const friends = state.social.friends || [];
    const sheet = openPlayerSheet(`<div class="listen-together-sheet"><header><div><small>DENGAR BARENG</small><h2>Pilih teman</h2><p>${esc(cleanTitle(track))} • ${esc(track?.artist || '')}</p></div><button data-close-listen-friends>${icon('close')}</button></header><div class="listen-friend-list">${friends.length ? friends.map(friend => `<button data-listen-friend="${esc(friend.uid)}">${publicAvatarMarkup(friend,'listen-friend-avatar')}<span><strong>${esc(friend.fullName || friend.username)}</strong><small>@${esc(friend.username || 'pengguna')} • ${esc(accountStatusLabel(friend.status || 'offline'))}</small></span>${icon('arrow-right')}</button>`).join('') : `<div class="social-empty">Belum ada teman. Cari pengguna terlebih dahulu dari halaman Cari pengguna.</div>`}</div></div>`, 'listen-together-player-sheet', {kind:'menu',initialSnap:'half'});
    $('[data-close-listen-friends]',sheet)?.addEventListener('click',()=>closeModal(true));
    $$('[data-listen-friend]',sheet).forEach(button => button.onclick = async () => {
      button.disabled = true;
      try {
        const service = await ensureFirebaseReady();
        let inviteTrack = normalizeTrack(track);
        if (Array.isArray(options.queue) && options.queue.length) {
          const queue = options.queue.map(sanitizePlaybackTrack);
          const queueIndex = Math.max(0, queue.findIndex(item => sameTrackIdentity(item, inviteTrack)));
          await playTrack(queue[queueIndex] || queue[0], queue, queueIndex, {
            playContext: options.playContext || { eyebrow:'DENGAR BARENG', label:'Dari Community', type:'community' },
            stayOnRoute: options.stayOnRoute !== false,
            autoplayImmediately: true
          });
          inviteTrack = normalizeTrack(state.current || inviteTrack);
        }
        const sentAt = Date.now();
        await service.sendListenTogetherRequest(button.dataset.listenFriend, {
          ...firebaseTrackRecord(inviteTrack),
          _listenPosition: Number(audio.currentTime || 0),
          _listenSentAt: sentAt
        });
        closeModal(true); notify('Ajakan Dengar Bareng dikirim');
      } catch (error) { button.disabled = false; notify(firebaseService()?.firebaseErrorMessage?.(error) || error?.message || 'Ajakan gagal dikirim'); }
    });
  });
}

function playlistIdFromValue(value = '') {
  return String(value || '').trim().replace(/[^A-Za-z0-9._-]/g, '-').slice(0, 120);
}

function createPlaylistId() {
  if (window.crypto?.randomUUID) return `playlist-${window.crypto.randomUUID()}`;
  return `playlist-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
}

function normalizePlaylist(raw = {}, index = 0) {
  const createdAt = Number(raw.createdAt || raw.created_at || Date.now() - index) || Date.now();
  const updatedAt = Number(raw.updatedAt || raw.updated_at || createdAt) || createdAt;
  const tracks = mergeTracksByIdentity(Array.isArray(raw.tracks) ? raw.tracks : [], [], 200).map(firebaseTrackRecord);
  const rawName = String(raw.name || raw.title || `Playlist ${index + 1}`).trim();
  return {
    id: playlistIdFromValue(raw.id || raw.firebaseId || createPlaylistId()),
    name: (rawName || `Playlist ${index + 1}`).slice(0, 80),
    createdAt,
    updatedAt,
    ownerUid: String(raw.ownerUid || ''),
    sourceType: String(raw.sourceType || ''),
    spotifyPlaylistId: String(raw.spotifyPlaylistId || ''),
    spotifyPlaylistUrl: String(raw.spotifyPlaylistUrl || ''),
    visibility: String(raw.visibility || (raw.isPublic ? 'public' : 'private')).toLowerCase() === 'public' ? 'public' : 'private',
    collaborative: Boolean(raw.collaborative || raw.sourceType === 'collaborative'),
    collabOwnerUid: String(raw.collabOwnerUid || raw.ownerUid || ''),
    sourcePublicPlaylistId: playlistIdFromValue(raw.sourcePublicPlaylistId || ''),
    sourceOwnerUid: String(raw.sourceOwnerUid || ''),
    totalTracks: Math.max(tracks.length, Number(raw.totalTracks || 0)),
    snapshotTruncated: Boolean(raw.snapshotTruncated),
    participantUids: [...new Set((Array.isArray(raw.participantUids) ? raw.participantUids : []).map(value => String(value || '').trim()).filter(Boolean))].slice(0, 24),
    profileUids: [...new Set((Array.isArray(raw.profileUids) ? raw.profileUids : raw.participantUids || []).map(value => String(value || '').trim()).filter(Boolean))].slice(0, 24),
    participantProfiles: (Array.isArray(raw.participantProfiles) ? raw.participantProfiles : []).slice(0, 24).map(item => ({ uid:String(item?.uid || ''), fullName:String(item?.fullName || item?.username || '').slice(0,100), username:String(item?.username || '').slice(0,50), photoURL:String(item?.photoURL || '').slice(0,1200) })).filter(item => item.uid),
    durationSeconds: Math.max(0, Number(raw.durationSeconds || 0) || 0),
    // V1.62.6: `listed` is derived from the actual local track snapshot. A
    // collaborative playlist is commonly created empty (listed=false) and then
    // filled a moment later. Keeping the old false flag made the owner's own
    // profile hide the playlist even though Firebase's shared index correctly
    // exposed it to the other collaborators.
    listed: tracks.length > 0,
    directorySource: String(raw.directorySource || ''),
    tracks
  };
}

function normalizePlaylists(list = []) {
  const output = [];
  const seen = new Set();
  (Array.isArray(list) ? list : []).forEach((raw, index) => {
    const playlist = normalizePlaylist(raw, index);
    if (!playlist.id || seen.has(playlist.id)) return;
    seen.add(playlist.id);
    output.push(playlist);
  });
  return output.slice(0, 100);
}

function mergePlaylistsById(primary = [], secondary = []) {
  const map = new Map();
  [...normalizePlaylists(secondary), ...normalizePlaylists(primary)].forEach(playlist => {
    const previous = map.get(playlist.id);
    if (!previous) {
      map.set(playlist.id, playlist);
      return;
    }
    const newer = Number(playlist.updatedAt || 0) >= Number(previous.updatedAt || 0) ? playlist : previous;
    map.set(playlist.id, {
      ...previous,
      ...newer,
      // Urutan dan penghapusan lagu mengikuti versi playlist terbaru.
      tracks: (newer.tracks || []).map(firebaseTrackRecord).slice(0, 200)
    });
  });
  return [...map.values()].sort((a, b) => Number(b.updatedAt || 0) - Number(a.updatedAt || 0));
}

function activePlaylists() {
  if (!isLoggedIn()) return normalizePlaylists(state.guestPlaylists);
  const uid = state.auth.user.uid;
  return normalizePlaylists(state.accountPlaylists?.[uid] || []);
}

function setActivePlaylists(list = []) {
  const previous = activePlaylists();
  const normalized = normalizePlaylists(list);
  if (isLoggedIn()) {
    const uid = state.auth.user.uid;
    state.accountPlaylists = { ...(state.accountPlaylists || {}), [uid]: normalized };
  } else {
    state.guestPlaylists = normalized;
  }
  persist();
  if (isLoggedIn() && String(state.publicProfileView?.uid || '') === String(state.auth.user?.uid || '')) {
    state.publicProfileView = {
      ...state.publicProfileView,
      playlists: mergePlaylistsById(normalized, state.publicProfileView?.playlists || [])
    };
    if (state.route === 'public-profile') renderPublicProfilePage();
  }
  if (isLoggedIn() && state.auth.cloudLoaded) {
    try { firebaseService()?.scheduleSync?.(buildFirebaseSnapshot(), 350); } catch {}
    schedulePublicPlaylistSync(normalized, 220, previous);
  }
  return normalized;
}

function playlistVisibility(value = 'private') {
  return String(value || '').toLowerCase() === 'public' ? 'public' : 'private';
}

function playlistVisibilityLabel(value = 'private') {
  return playlistVisibility(value) === 'public' ? 'Publik' : 'Private';
}

function playlistCanChangeVisibility(playlist = {}) {
  if (!isLoggedIn()) return false;
  const uid = String(state.auth.user?.uid || '');
  if (!playlist.collaborative) return !playlist.ownerUid || playlist.ownerUid === uid;
  return String(playlist.collabOwnerUid || playlist.ownerUid || '') === uid;
}

function schedulePublicPlaylistSync(playlists = activePlaylists(), delay = 500, previousPlaylists = null) {
  if (publicPlaylistSyncTimer) window.clearTimeout(publicPlaylistSyncTimer);
  publicPlaylistSyncTimer = null;
  if (!isLoggedIn() || !state.auth.cloudLoaded) return;
  const snapshot = normalizePlaylists(playlists);
  if (Array.isArray(previousPlaylists) && !pendingPublicPlaylistSyncPrevious) {
    pendingPublicPlaylistSyncPrevious = normalizePlaylists(previousPlaylists);
  }
  publicPlaylistSyncTimer = window.setTimeout(async () => {
    publicPlaylistSyncTimer = null;
    const previous = pendingPublicPlaylistSyncPrevious;
    pendingPublicPlaylistSyncPrevious = null;
    try { await firebaseService()?.syncPublicPlaylists?.(snapshot, { previousPlaylists: previous || [] }); }
    catch (error) { console.warn('[DATZON public playlists]', error); }
  }, Math.max(120, Number(delay) || 500));
}

function updatePlaylistVisibility(playlistId, nextVisibility) {
  const visibility = playlistVisibility(nextVisibility);
  let updated = null;
  const playlists = activePlaylists().map(playlist => {
    if (playlist.id !== playlistId) return playlist;
    if (!playlistCanChangeVisibility(playlist)) return playlist;
    updated = { ...playlist, visibility, updatedAt: Date.now() };
    return updated;
  });
  if (!updated) return null;
  const normalized = setActivePlaylists(playlists);
  updated = normalized.find(item => item.id === playlistId) || updated;
  if (updated.collaborative) void broadcastCollaborativePlaylistSnapshot(updated);
  return updated;
}


function playlistCanDelete(playlist = {}) {
  return playlistCanChangeVisibility(playlist);
}

async function deleteOwnedPlaylist(playlistId) {
  const id = playlistIdFromValue(playlistId);
  const before = activePlaylists();
  const playlist = before.find(item => item.id === id);
  if (!playlist || !playlistCanDelete(playlist)) throw new Error('Hanya pembuat playlist yang dapat menghapus playlist ini.');

  const service = isLoggedIn() ? await ensureFirebaseReady() : null;
  if (isLoggedIn() && service) {
    // Shared public/collaborative data is deleted first through the verified
    // Firebase Admin gateway. The server removes canonical/index/member copies
    // and leaves only a content-free tombstone for old shared links.
    await service.deleteSharedPlaylist?.(id);

  }

  const next = before.filter(item => item.id !== id);
  setActivePlaylists(next);

  // Make the owner's private Firebase playlist collection and public profile
  // reflect deletion immediately instead of waiting for the debounce timer.
  if (isLoggedIn() && service && state.auth.cloudLoaded) {
    try { await service.syncSnapshot?.(buildFirebaseSnapshot()); } catch (error) { console.warn('[DATZON playlist delete private sync]', error); }
    try { await service.syncPublicPlaylists?.(next, { previousPlaylists:before }); } catch (error) { console.warn('[DATZON playlist delete profile sync]', error); }
  }

  if (String(state.publicProfileView?.uid || '') === String(state.auth.user?.uid || '')) {
    state.publicProfileView = {
      ...state.publicProfileView,
      playlists:(state.publicProfileView?.playlists || []).filter(item => item.id !== id)
    };
  }
  if (String(state.datzonPlaylistView?.id || '') === id) {
    stopDatzonPlaylistStream();
    state.datzonPlaylistView = { id, data:null, loading:false, error:'', deleted:true, sourceProfile:null };
  }
  return playlist;
}

async function broadcastCollaborativePlaylistSnapshot(playlist) {
  if (!playlist?.collaborative || !isLoggedIn()) return;
  const targets = (playlist.participantUids || []).filter(uid => uid && uid !== state.auth.user?.uid);
  if (!targets.length) return;
  try { await firebaseService()?.sendCollaborativePlaylistSnapshot?.(targets, playlist); } catch (error) { console.warn('[DATZON collab sync]', error); }
}

function applyCollaborativePlaylistNotification(notification = {}) {
  const incomingRaw = notification?.actionData?.playlist;
  const currentUid = String(state.auth.user?.uid || '');
  if (!incomingRaw?.id || !currentUid) return false;
  const incoming = normalizePlaylist(incomingRaw);
  if (!incoming.collaborative || !(incoming.participantUids || []).includes(currentUid)) return false;
  const playlists = activePlaylists();
  const existing = playlists.find(item => item.id === incoming.id);
  if (existing && Number(existing.updatedAt || 0) > Number(incoming.updatedAt || 0)) return true;
  const merged = existing
    ? playlists.map(item => item.id === incoming.id ? incoming : item)
    : [incoming, ...playlists];
  setActivePlaylists(merged);
  return true;
}


function applyCollaborativePlaylistRemoval(notification = {}) {
  const data=notification?.actionData || {};
  const playlistId=String(data.playlistId || data.playlist?.id || '');
  if(!playlistId) return false;
  const before=activePlaylists();
  const next=before.filter(item=>item.id!==playlistId);
  if(next.length===before.length) return true;
  setActivePlaylists(next);
  if(state.route==='library') renderLibrary();
  return true;
}


// V1.62.8: if an old/offline device tries to republish a playlist whose ID has
// a permanent deletion tombstone, the server answers status=deleted. Remove the
// stale local copy immediately so it cannot keep reappearing in Koleksi Kamu.
window.addEventListener('datzon:playlist-deleted', event => {
  const playlistId = playlistIdFromValue(event?.detail?.playlistId || '');
  if (!playlistId) return;
  const before = activePlaylists();
  const next = before.filter(item => item.id !== playlistId);
  if (next.length === before.length) return;
  setActivePlaylists(next);
  if (state.route === 'library') renderLibrary();
  if (state.route === 'public-profile') renderPublicProfilePage();
  if (String(state.datzonPlaylistView?.id || '') === playlistId) {
    stopDatzonPlaylistStream();
    state.datzonPlaylistView = { id:playlistId, data:null, loading:false, error:'', deleted:true, sourceProfile:null };
    if (state.route === 'datzon-playlist') renderDatzonPlaylistPage();
  }
});

function playlistCover(playlist = {}) {
  return playlist.tracks?.find(track => track?.thumbnail)?.thumbnail || 'assets/placeholder.svg';
}

function playlistArtworkSources(playlist = {}) {
  return (playlist.tracks || [])
    .map(track => String(track?.thumbnail || '').trim() || 'assets/placeholder.svg')
    .slice(0, 4);
}

function playlistArtworkMarkup(playlist = {}, className = '', lazy = false) {
  const sources = playlistArtworkSources(playlist);
  const loading = lazy ? ' loading="lazy"' : '';
  const inner = sources.length >= 4
    ? `<span class="playlist-collage-art playlist-collab-inner">${sources.map(source => `<img src="${esc(source)}" alt=""${loading} onerror="this.src='assets/placeholder.svg'">`).join('')}</span>`
    : `<img class="playlist-collab-inner" src="${esc(sources[0] || 'assets/placeholder.svg')}" alt=""${loading} onerror="this.src='assets/placeholder.svg'">`;
  if (!playlist.collaborative) {
    if (sources.length >= 4) return `<span class="playlist-collage-art ${esc(className)}">${sources.map(source => `<img src="${esc(source)}" alt=""${loading} onerror="this.src='assets/placeholder.svg'">`).join('')}</span>`;
    return `<img class="${esc(className)}" src="${esc(sources[0] || 'assets/placeholder.svg')}" alt=""${loading} onerror="this.src='assets/placeholder.svg'">`;
  }
  const profiles=(playlist.participantProfiles || []).filter(item=>item?.uid).slice(0,2);
  const avatars=profiles.map((profile,index)=>`${index?'<b class="collab-avatar-x">×</b>':''}<img src="${esc(collaboratorAvatar(profile))}" alt="${esc(profile.fullName || profile.username || 'Kolaborator')}" onerror="this.src='${esc(defaultProfileAvatar(profile.fullName || profile.username || 'D'))}'">`).join('');
  return `<span class="collaborative-playlist-art ${esc(className)}">${inner}<span class="playlist-collab-capsule" aria-label="${Math.max(1,(playlist.participantProfiles || []).filter(item=>item?.uid).length)} kolaborator"><span class="playlist-collab-avatars">${avatars || icon('group')}</span></span></span>`;
}

function playlistContainsTrack(playlist = {}, track = {}) {
  const key = trackFirebaseId(track) || trackKey(track);
  return Boolean(key && (playlist.tracks || []).some(item => (trackFirebaseId(item) || trackKey(item)) === key));
}

function createUserPlaylist(name, initialTrack = null, options = {}) {
  const now = Date.now();
  const playlists = activePlaylists();
  const playlist = normalizePlaylist({
    id: createPlaylistId(),
    name: String(name || `Playlist ${playlists.length + 1}`).trim() || `Playlist ${playlists.length + 1}`,
    ownerUid: isLoggedIn() ? state.auth.user.uid : '',
    visibility: isLoggedIn() ? playlistVisibility(options.visibility) : 'private',
    createdAt: now,
    updatedAt: now,
    tracks: initialTrack ? [firebaseTrackRecord(initialTrack)] : []
  });
  setActivePlaylists([playlist, ...playlists]);
  if (playlist.collaborative) void broadcastCollaborativePlaylistSnapshot(playlist);
  return playlist;
}

function addTrackToPlaylist(playlistId, track) {
  let added = false;
  const playlists = activePlaylists().map(playlist => {
    if (playlist.id !== playlistId) return playlist;
    if (playlistContainsTrack(playlist, track)) return playlist;
    added = true;
    const tracks = [firebaseTrackRecord(track), ...playlist.tracks].slice(0, 200);
    return { ...playlist, updatedAt: Date.now(), tracks, totalTracks: tracks.length, listed: tracks.length > 0 };
  });
  if (added) {
    const normalized = setActivePlaylists(playlists);
    const changed = normalized.find(item => item.id === playlistId);
    if (changed?.collaborative) void broadcastCollaborativePlaylistSnapshot(changed);
  }
  return added;
}

function updatePlaylistTracks(playlistId, updater) {
  let changed = false;
  let updatedPlaylist = null;
  const playlists = activePlaylists().map(playlist => {
    if (playlist.id !== playlistId) return playlist;
    const currentTracks = (playlist.tracks || []).map(firebaseTrackRecord);
    const nextTracks = updater([...currentTracks]);
    if (!Array.isArray(nextTracks)) return playlist;
    changed = true;
    const tracks = nextTracks.map(firebaseTrackRecord).slice(0, 200);
    updatedPlaylist = { ...playlist, updatedAt: Date.now(), tracks, totalTracks: tracks.length, listed: tracks.length > 0 };
    return updatedPlaylist;
  });
  if (changed) {
    const normalized = setActivePlaylists(playlists);
    updatedPlaylist = normalized.find(item => item.id === playlistId) || updatedPlaylist;
    if (updatedPlaylist?.collaborative) void broadcastCollaborativePlaylistSnapshot(updatedPlaylist);
  }
  return updatedPlaylist;
}

function syncPlaybackAfterPlaylistEdit(playlistId, removedTrack = null) {
  if (!isPlaylistPlaybackContext(playlistId) || !state.current) return;
  const playlist = activePlaylists().find(item => item.id === playlistId);
  const remaining = (playlist?.tracks || []).map(item => sanitizePlaybackTrack(item));
  if (removedTrack && sameTrackIdentity(removedTrack, state.current)) {
    state.queue = [sanitizePlaybackTrack(state.current), ...remaining.filter(item => !sameTrackIdentity(item, state.current))];
    state.currentIndex = 0;
    state.playContext = { eyebrow: 'MEMUTAR DARI ANTREAN', label: 'Antrean setelah playlist diedit', type: 'queue' };
  } else {
    syncPlaylistQueueToSource();
  }
  persist();
}

function movePlaylistTrackOneStep(playlistId, index, direction) {
  let moved = false;
  updatePlaylistTracks(playlistId, tracks => {
    const target = index + direction;
    if (index < 0 || index >= tracks.length || target < 0 || target >= tracks.length) return tracks;
    [tracks[index], tracks[target]] = [tracks[target], tracks[index]];
    moved = true;
    return tracks;
  });
  if (moved) syncPlaybackAfterPlaylistEdit(playlistId);
  return moved;
}

function removeTrackFromPlaylist(playlistId, index) {
  let removed = null;
  updatePlaylistTracks(playlistId, tracks => {
    if (index < 0 || index >= tracks.length) return tracks;
    [removed] = tracks.splice(index, 1);
    return tracks;
  });
  if (removed) syncPlaybackAfterPlaylistEdit(playlistId, removed);
  return removed;
}

function trackFirebaseId(track = {}) {
  const spotify = spotifyTrackIdFromValue(track?.url || track?.id || track?.spotifyUrl || '');
  if (spotify) return spotify;
  return trackKey(track);
}

function firebaseTrackRecord(track = {}) {
  const item = normalizeTrack(track);
  // Simpan metadata beserta URL siap putar dan download. Timestamp tetap dipakai
  // agar URL provider yang sudah kedaluwarsa tidak digunakan tanpa validasi ulang.
  return {
    ...item,
    audioUrl: String(item.audioUrl || ''),
    downloadUrl: String(item.downloadUrl || item.audioUrl || ''),
    sourceUrl: String(item.sourceUrl || ''),
    previewUrl: String(item.previewUrl || ''),
    audioResolvedAt: Number(item.audioResolvedAt || 0),
    metadataResolvedAt: Number(item.metadataResolvedAt || 0),
    spotifyId: trackFirebaseId(item)
  };
}

function sameTrackIdentity(left = {}, right = {}) {
  if (!left || !right) return false;
  const leftId = trackFirebaseId(left);
  const rightId = trackFirebaseId(right);
  if (leftId && rightId && leftId === rightId) return true;
  return Boolean(trackKey(left) && trackKey(left) === trackKey(right));
}

function mergeResolvedTrackRecord(original = {}, resolved = {}) {
  const before = normalizeTrack(original);
  const incoming = normalizeTrack(resolved);
  return mergePrimaryTrackMetadata(before, incoming, {
    audioUrl: incoming.audioUrl || before.audioUrl,
    downloadUrl: incoming.downloadUrl || before.downloadUrl || incoming.audioUrl || before.audioUrl,
    sourceUrl: incoming.sourceUrl || before.sourceUrl,
    previewUrl: incoming.previewUrl || before.previewUrl,
    audioResolvedAt: incoming.audioResolvedAt || before.audioResolvedAt,
    metadataResolvedAt: incoming.metadataResolvedAt || before.metadataResolvedAt,
    source: incoming.source || before.source
  });
}

function updateResolvedTrackReferences(track = {}) {
  const resolved = normalizeTrack(track);
  if (!trackFirebaseId(resolved) && !trackKey(resolved)) return resolved;
  const updateList = list => (Array.isArray(list) ? list : []).map(item => sameTrackIdentity(item, resolved) ? mergeResolvedTrackRecord(item, resolved) : item);
  state.queue = updateList(state.queue);
  state.history = updateList(state.history);
  state.favorites = updateList(state.favorites);
  state.downloads = updateList(state.downloads);
  if (isLoggedIn()) {
    const uid = state.auth.user.uid;
    const playlists = normalizePlaylists(state.accountPlaylists?.[uid] || []).map(playlist => ({
      ...playlist,
      tracks: updateList(playlist.tracks)
    }));
    state.accountPlaylists = { ...(state.accountPlaylists || {}), [uid]: playlists };
  } else {
    state.guestPlaylists = normalizePlaylists(state.guestPlaylists).map(playlist => ({
      ...playlist,
      tracks: updateList(playlist.tracks)
    }));
  }
  if (state.current && sameTrackIdentity(state.current, resolved)) state.current = mergeResolvedTrackRecord(state.current, resolved);
  if (isLoggedIn() && state.auth.cloudLoaded) {
    try { firebaseService()?.scheduleSync?.(buildFirebaseSnapshot(), 650); } catch {}
  }
  return state.current && sameTrackIdentity(state.current, resolved) ? state.current : resolved;
}

function playlistPlaybackContext(playlist = {}) {
  return {
    eyebrow: 'MEMAINKAN DARI PLAYLIST',
    label: String(playlist.name || 'Playlist'),
    type: 'playlist',
    playlistId: String(playlist.id || '')
  };
}

function isPlaylistPlaybackContext(playlistId = '') {
  return state.playContext?.type === 'playlist' && String(state.playContext?.playlistId || '') === String(playlistId || '');
}

function hasPlaylistPlaybackContext() {
  return state.playContext?.type === 'playlist' && Boolean(String(state.playContext?.playlistId || '').trim());
}

function activePlaybackPlaylist() {
  if (!hasPlaylistPlaybackContext()) return null;
  const playlistId = String(state.playContext.playlistId || '');
  return activePlaylists().find(item => String(item.id || '') === playlistId) || null;
}

function syncPlaylistQueueToSource() {
  const playlist = activePlaybackPlaylist();
  if (!playlist || !state.current) return false;
  const tracks = (playlist.tracks || []).map(item => sanitizePlaybackTrack(item));
  if (!tracks.length) return false;
  const currentIndex = tracks.findIndex(item => sameTrackIdentity(item, state.current));
  if (currentIndex < 0) return false;
  tracks[currentIndex] = sanitizePlaybackTrack(mergeResolvedTrackRecord(tracks[currentIndex], state.current));
  state.queue = tracks;
  state.currentIndex = currentIndex;
  return true;
}

function firebaseArtistRecords() {
  const records = new Map();
  const stats = ensureListeningStats();
  const push = track => {
    const item = normalizeTrack(track);
    const name = String(item.artist || '').trim();
    if (!name || isUnknownArtist(name)) return;
    const key = normalizeMatchText(name);
    const stat = Object.values(stats.artists || {}).find(entry => normalizeMatchText(entry?.name || '') === key) || {};
    const record = {
      name,
      thumbnail: item.thumbnail || stat.thumbnail || '',
      selected: (state.preferredArtists || []).some(value => normalizeMatchText(value) === key),
      plays: Number(stat.plays || 0),
      seconds: Number(stat.seconds || 0),
      lastPlayedAt: Number(track?.lastPlayedAt || stat.lastPlayedAt || 0)
    };
    const previous = records.get(key);
    if (!previous || record.lastPlayedAt >= Number(previous.lastPlayedAt || 0)) records.set(key, { ...previous, ...record });
  };
  [...state.history, ...state.favorites, ...state.queue].forEach(push);
  (state.preferredArtists || []).forEach(name => {
    const value = String(name || '').trim();
    if (!value) return;
    const key = normalizeMatchText(value);
    const previous = records.get(key) || {};
    records.set(key, { name: value, thumbnail: previous.thumbnail || '', selected: true, plays: Number(previous.plays || 0), seconds: Number(previous.seconds || 0), lastPlayedAt: Number(previous.lastPlayedAt || 0) });
  });
  return [...records.values()].slice(0, 150);
}

function buildFirebaseSnapshot() {
  const stats = ensureListeningStats();
  return {
    appState: {
      username: state.username,
      searchHistory: state.searchHistory.slice(0, 20),
      queue: state.queue.slice(0, 100).map(firebaseTrackRecord),
      current: state.current ? firebaseTrackRecord(state.current) : null,
      currentIndex: state.currentIndex,
      listeningStats: stats,
      settings: state.settings,
      preferredArtists: state.preferredArtists.slice(0, 30),
      preferredArtistMeta: (state.preferredArtistMeta || []).slice(0, 30),
      shuffle: state.shuffle,
      repeat: state.repeat,
      playContext: state.playContext
    },
    favorites: state.favorites.slice(0, 300).map(firebaseTrackRecord),
    history: state.history.slice(0, Math.max(10, Number(state.settings.historyLimit) || 100)).map((item, index) => ({ ...firebaseTrackRecord(item), order: index, lastPlayedAt: Number(item.lastPlayedAt || 0) })),
    downloads: state.downloads.slice(0, 150).map(item => ({ ...firebaseTrackRecord(item), downloadedAt: Number(item.downloadedAt || 0), fileName: item.fileName || '' })),
    artists: firebaseArtistRecords(),
    playlists: activePlaylists().map(playlist => ({ ...playlist, tracks: playlist.tracks.map(firebaseTrackRecord) })),
    listeningSummary: { totalSeconds: Number(stats.totalSeconds || 0), plays: Number(stats.plays || 0), artists: Object.keys(stats.artists || {}).length }
  };
}

function scheduleFirebaseStateSync(delay = 15000) {
  const service = firebaseService();
  if (!service || !isLoggedIn() || !state.auth.cloudLoaded || state.settings.privateSession) return;
  if (firebaseSyncQueued) return;
  firebaseSyncQueued = true;
  window.setTimeout(() => {
    firebaseSyncQueued = false;
    try { service.scheduleSync(buildFirebaseSnapshot(), 250); } catch {}
  }, Math.max(300, delay));
}

function mergeTracksByIdentity(primary = [], secondary = [], limit = 300) {
  const output = [];
  const seen = new Set();
  [...primary, ...secondary].forEach(raw => {
    if (!raw) return;
    const item = normalizeTrack(raw);
    const key = trackFirebaseId(item) || trackKey(item);
    if (!key || seen.has(key)) return;
    seen.add(key);
    output.push(item);
  });
  return output.slice(0, limit);
}

function applyCloudDataToState(cloud = {}) {
  const appState = cloud.appState || {};
  if (Array.isArray(cloud.favorites)) state.favorites = mergeTracksByIdentity(cloud.favorites, state.favorites, 300);
  if (Array.isArray(cloud.history)) state.history = mergeTracksByIdentity(cloud.history.sort((a,b)=>Number(a.order||0)-Number(b.order||0)), state.history, Math.max(10, Number(state.settings.historyLimit)||100));
  if (Array.isArray(cloud.playlists) && state.auth.user?.uid) {
    const uid = state.auth.user.uid;
    state.accountPlaylists = { ...(state.accountPlaylists || {}), [uid]: mergePlaylistsById(cloud.playlists, state.accountPlaylists?.[uid] || []) };
  }
  if (Array.isArray(cloud.downloads)) state.downloads = mergeTracksByIdentity(cloud.downloads, state.downloads, 150).map(item => {
    const source = cloud.downloads.find(raw => trackFirebaseId(raw) === trackFirebaseId(item)) || {};
    return { ...item, downloadedAt: source.downloadedAt || item.downloadedAt, fileName: source.fileName || item.fileName };
  });
  if (Array.isArray(appState.searchHistory)) state.searchHistory = [...new Set([...appState.searchHistory, ...state.searchHistory])].slice(0,20);
  if (Array.isArray(appState.queue) && appState.queue.length) state.queue = mergeTracksByIdentity(appState.queue, state.queue, 100);
  if (appState.current && !state.current) state.current = normalizeTrack(appState.current);
  if (Number.isInteger(appState.currentIndex) && state.currentIndex < 0) state.currentIndex = appState.currentIndex;
  if (appState.listeningStats && typeof appState.listeningStats === 'object') {
    const local = ensureListeningStats();
    const remote = appState.listeningStats;
    state.listeningStats = Number(remote.totalSeconds || 0) > Number(local.totalSeconds || 0) ? remote : local;
  }
  if (appState.settings && typeof appState.settings === 'object') state.settings = { ...state.settings, ...appState.settings };
  if (Array.isArray(appState.preferredArtists)) state.preferredArtists = [...new Set([...appState.preferredArtists, ...state.preferredArtists])].slice(0,30);
  if (Array.isArray(appState.preferredArtistMeta)) { const map=new Map(); [...appState.preferredArtistMeta,...(state.preferredArtistMeta||[])].forEach(item=>{if(item?.name)map.set(String(item.spotifyArtistId||item.id||normalizeMatchText(item.name)),item);}); state.preferredArtistMeta=[...map.values()].slice(0,30); }
  if (typeof appState.shuffle === 'boolean') state.shuffle = appState.shuffle;
  if (typeof appState.repeat === 'string') state.repeat = appState.repeat;
  if (appState.playContext && typeof appState.playContext === 'object') state.playContext = appState.playContext;
  persist();
  applyExperienceSettings();
  applyGlobalAppTheme(state.current);
}

async function hydrateFirebaseAccount(user, profile) {
  const service = firebaseService();
  if (!service || !user || !profile || state.auth.hydratedUid === user.uid) return;
  state.auth.hydratedUid = user.uid;
  state.auth.cloudLoaded = false;
  try {
    const cloud = await service.loadCloudData();
    applyCloudDataToState(cloud);
    state.auth.cloudLoaded = true;
    scheduleFirebaseStateSync(800);
    schedulePublicPlaylistSync(activePlaylists(), 900);
  } catch (error) {
    state.auth.cloudLoaded = true;
    logSystemActivity('Sinkronisasi Firebase', service.firebaseErrorMessage?.(error) || error?.message || 'Gagal memuat database', 'Firebase', 'warning');
  }
}

async function initializeFirebaseIntegration() {
  const service = firebaseService();
  state.auth.configured = Boolean(service?.isConfigured?.());
  if (!service) {
    state.auth.loading = false;
    return;
  }
  firebaseAuthUnsubscribe?.();
  firebaseAuthUnsubscribe = service.onAuthChanged(async detail => {
    state.auth.configured = Boolean(detail.configured);
    if (Object.prototype.hasOwnProperty.call(detail, 'authResolved') && detail.authResolved === false) {
      state.auth.loading = true;
      return;
    }
    state.auth.ready = Boolean(detail.ready);
    state.auth.loading = false;
    state.auth.user = detail.user || null;
    state.auth.profile = detail.profile || null;
    if (detail.user && detail.profile) {
      state.username = detail.profile.fullName || detail.profile.username || detail.user.displayName || 'Pengguna DATZON';
      state.preferredArtists = Array.isArray(detail.profile.selectedArtists) ? detail.profile.selectedArtists : state.preferredArtists;
      storage.set('username', state.username);
      storage.set('preferredArtists', state.preferredArtists);
  storage.set('preferredArtistMeta', state.preferredArtistMeta || []);
      state.auth.pendingGoogle = null;
      await hydrateFirebaseAccount(detail.user, detail.profile);
      initializeNotificationStream();
      state.social.loaded = false;
      loadSocialGraph(true).catch(() => {});
      if (detail.profile.onboardingCompleted === false && !['register','verify','onboarding'].includes(state.route)) {
        navigate('onboarding', { replace: true });
      } else if (['login','register'].includes(state.route)) {
        navigate('home', { replace: true });
      }
    } else if (detail.user && !detail.profile) {
      state.auth.cloudLoaded = false;
      if (detail.error) {
        logSystemActivity('Memulihkan akun Firebase', service.firebaseErrorMessage?.(detail.error) || detail.error?.message || 'Profil belum dapat dimuat', 'Firebase', 'warning');
        return;
      }
      state.auth.pendingGoogle = {
        needsSetup: true,
        provider: detail.user.providerData?.some(item => item.providerId === 'google.com') ? 'google' : 'password',
        user: detail.user,
        email: detail.user.email || '',
        suggestedFullName: detail.user.displayName || '',
        photoURL: detail.user.photoURL || ''
      };
      if (!['register','verify'].includes(state.route)) navigate('register');
    } else if (!detail.user) {
      if (publicPlaylistSyncTimer) window.clearTimeout(publicPlaylistSyncTimer);
      publicPlaylistSyncTimer = null;
      initializeNotificationStream();
      state.social = { ...state.social, loaded:false, friends:[], following:[], followers:[] };
      state.auth.hydratedUid = '';
      state.auth.cloudLoaded = false;
    }
    if (state.route === 'public-profile' && state.publicProfileView?.uid) startPublicProfilePlaylistStream(state.publicProfileView.uid, service);
    if (state.route === 'datzon-playlist' && state.datzonPlaylistView?.id) startDatzonPlaylistStream(state.datzonPlaylistView.id, service);
    if (['home','search','library','profile','settings','connections','people','friends','following','followers','leaderboard','report','admin-reports','public-profile','datzon-playlist','login','register','verify','onboarding'].includes(state.route)) render();
  });
  try { await service.ready; } catch {}
}

window.addEventListener('datzon-firebase-sync-error', event => {
  const message = event.detail?.message || 'Sinkronisasi Firebase tertunda';
  logSystemActivity('Sinkronisasi Firebase', message, 'Firebase', 'warning');
});

function persist() {
  storage.set('username', state.username);
  if (!state.settings.privateSession) {
    storage.set('queue', state.queue);
    storage.set('queueRecommendations', state.queueRecommendations || []);
    storage.set('queueRecommendationsKey', state.queueRecommendationsKey || '');
    storage.set('currentIndex', state.currentIndex);
    storage.set('current', state.current);
  }
  storage.set('favorites', state.favorites.slice(0, 300));
  storage.set('history', state.history.slice(0, 100));
  storage.set('searchHistory', state.searchHistory.slice(0, 20));
  storage.set('downloads', state.downloads.slice(0, 150));
  storage.set('announcementReads', (state.announcementReads || []).slice(-100));
  storage.set('listeningStats', state.listeningStats);
  storage.set('settings', state.settings);
  storage.set('shuffle', state.shuffle);
  storage.set('repeat', state.repeat);
  storage.set('sleepTimerEndAt', state.sleepTimerEndAt || 0);
  storage.set('sleepTimerMode', state.sleepTimerMode || '');
  storage.set('sleepTimerLabel', state.sleepTimerLabel || '');
  storage.set('playContext', state.playContext);
  storage.set('mixMode', state.mixMode);
  storage.set('hiddenSuggestions', state.hiddenSuggestions);
  storage.set('apiKeyIndex', state.apiKeyIndex);
  storage.set('libraryView', state.libraryView);
  storage.set('librarySort', state.librarySort);
  storage.set('artistProfiles', state.artistProfiles);
  storage.set('artistProfilesAt', state.artistProfilesAt);
  storage.set('spotifyAuth', state.spotifyAuth);
  storage.set('spotifyArtistProfiles', state.spotifyArtistProfiles);
  storage.set('spotifyArtistProfilesAt', state.spotifyArtistProfilesAt);
  storage.set('systemActivity', state.systemActivity.slice(0, 100));
  storage.set('systemActivityUnread', state.systemActivityUnread);
  storage.set('preferredArtists', state.preferredArtists);
  storage.set('guestPlaylists', normalizePlaylists(state.guestPlaylists));
  storage.set('accountPlaylists', state.accountPlaylists || {});
  scheduleFirebaseStateSync();
}

function purgeHiddenSuggestions() {
  const now = Date.now();
  Object.keys(state.hiddenSuggestions || {}).forEach(key => {
    if (!state.hiddenSuggestions[key] || state.hiddenSuggestions[key] <= now) delete state.hiddenSuggestions[key];
  });
}

function isSuggestionHidden(track) {
  if (!track) return false;
  purgeHiddenSuggestions();
  return Boolean(state.hiddenSuggestions[trackKey(track)]);
}

function hideTrackSuggestion(track, days = 30) {
  if (!track) return;
  purgeHiddenSuggestions();
  state.hiddenSuggestions[trackKey(track)] = Date.now() + days * 86400000;
  persist();
}

function filterHiddenSuggestions(list = []) {
  purgeHiddenSuggestions();
  return list.filter(track => !isSuggestionHidden(track));
}

function shuffleList(list = []) {
  const copy = [...list];
  for (let i = copy.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

function cycleRepeatMode() {
  state.repeat = state.repeat === 'off' ? 'all' : state.repeat === 'all' ? 'one' : 'off';
  audio.loop = state.repeat === 'one';
  resetNextTrackPreload();
  if (state.isPlaying && state.repeat !== 'one') scheduleNextTrackPreload(250);
  persist();
  renderPlayerDynamic();
  if (typeof updateQueueControls === 'function') updateQueueControls();
  return state.repeat;
}

function repeatLabel() {
  return state.repeat === 'one' ? 'Ulang Satu Lagu' : state.repeat === 'all' ? 'Ulang' : 'Ulang';
}

function repeatIconMarkup(mode = state.repeat, className = '') {
  return `<span class="repeat-wrap ${mode !== 'off' ? 'active' : ''} ${mode === 'one' ? 'one' : ''}">${icon('repeat', className)}${mode === 'one' ? '<em aria-hidden="true">1</em>' : ''}</span>`;
}

function applyFullLyricsTheme(track) {
  const page = $('.full-lyrics-page', view);
  if (!page || !track) return;
  const key = trackKey(track);
  const fallback = fallbackPlayerAccent(track);
  page.style.setProperty('--lyrics-page-rgb', fallback.join(','));
  resolvePlayerAccent(track).then(color => {
    const currentPage = $('.full-lyrics-page', view);
    if (!currentPage || trackKey(state.current) !== key) return;
    currentPage.style.setProperty('--lyrics-page-rgb', color.join(','));
    currentPage.classList.add('theme-ready');
  });
}


function recommendationBaseList() {
  const catalog = filterHiddenSuggestions(dedupeTracks([...state.catalog, ...FALLBACK_TRACKS]));
  return catalog.filter(track => trackKey(track) !== trackKey(state.current));
}

function buildRelatedRecommendations(currentTrack) {
  const current = normalizeTrack(currentTrack || state.current);
  const pool = recommendationBaseList();
  if (!current) return pool;
  const titleWords = cleanTitle(current).toLowerCase().split(/\W+/).filter(Boolean);
  const related = [];
  const others = [];
  pool.forEach(track => {
    const sameArtist = String(track.artist || '').toLowerCase() === String(current.artist || '').toLowerCase();
    const sameAlbum = track.album && current.album && String(track.album).toLowerCase() === String(current.album).toLowerCase();
    const title = cleanTitle(track).toLowerCase();
    const similarWord = titleWords.some(word => word.length > 2 && title.includes(word));
    (sameArtist || sameAlbum || similarWord ? related : others).push(track);
  });
  return dedupeTracks([...related, ...others]);
}

function ensureQueueSeed() {
  if (!state.current) return;
  if (!Array.isArray(state.queue) || !state.queue.length) {
    state.queue = [normalizeTrack(state.current), ...buildRelatedRecommendations(state.current).slice(0, 12)];
    state.currentIndex = 0;
  }
}

function queueUpcomingList() {
  ensureQueueSeed();
  const upcoming = state.queue.slice(Math.max(0, state.currentIndex + 1)).filter(track => trackKey(track) !== trackKey(state.current));
  if (upcoming.length) return filterHiddenSuggestions(upcoming);
  return buildRelatedRecommendations(state.current).slice(0, 18);
}

function setQueueMode(mode = 'default') {
  if (!state.current) return [];
  if (hasPlaylistPlaybackContext()) {
    state.playContext = { eyebrow: 'COCOK UNTUKMU', label: 'Rekomendasi untukmu', type: 'recommendation' };
    state.queueRecommendations = [];
    state.queueRecommendationsKey = '';
  }
  let source = mode === 'shuffle' ? buildRelatedRecommendations(state.current) : recommendationBaseList();
  if (mode === 'shuffle') source = shuffleList(source);
  else if (mode === 'mix') source = shuffleList(source);
  const nextTracks = dedupeTracks(source).slice(0, 18);
  state.queue = [normalizeTrack(state.current), ...nextTracks];
  state.currentIndex = 0;
  state.mixMode = mode === 'mix';
  state.shuffle = mode === 'shuffle';
  persist();
  return nextTracks;
}

function moveQueueSelectionUp() {
  const selected = [...new Set(state.queueSelection)].sort((a, b) => a - b).filter(index => index > state.currentIndex + 1);
  if (!selected.length) return false;
  selected.forEach(index => {
    const prev = index - 1;
    if (prev > state.currentIndex && !selected.includes(prev)) {
      [state.queue[prev], state.queue[index]] = [state.queue[index], state.queue[prev]];
    }
  });
  state.queueSelection = selected.map(index => Math.max(state.currentIndex + 1, index - 1));
  persist();
  return true;
}

function removeQueueSelection() {
  const selected = [...new Set(state.queueSelection)].sort((a, b) => b - a).filter(index => index > state.currentIndex);
  if (!selected.length) return false;
  selected.forEach(index => state.queue.splice(index, 1));
  state.queueSelection = [];
  persist();
  return true;
}

function reorderQueueItem(fromIndex, toIndex) {
  if (fromIndex === toIndex) return false;
  if (fromIndex <= state.currentIndex || toIndex <= state.currentIndex) return false;
  const item = state.queue[fromIndex];
  if (!item) return false;
  state.queue.splice(fromIndex, 1);
  state.queue.splice(toIndex, 0, item);
  persist();
  return true;
}

function normalizedEndpointPath(path = '') {
  const clean = String(path || '').trim().replace(/\/+$/, '');
  return clean.startsWith('/') ? clean : `/${clean}`;
}

function assertAllowedEndpoint(provider, path, allowed) {
  const endpoint = normalizedEndpointPath(path);
  if (allowed.has(endpoint)) return endpoint;
  const activityId = beginSystemActivity(
    'Endpoint dinonaktifkan',
    `${provider} ${endpoint} tidak dipanggil karena endpoint tersebut sudah dinyatakan tidak berfungsi`,
    provider
  );
  finishSystemActivity(activityId, 'warning', 'Permintaan dihentikan sebelum memakai API key');
  const error = new Error(`${provider} endpoint ${endpoint} dinonaktifkan`);
  error.nonRotatable = true;
  error.endpointDisabled = true;
  throw error;
}

function responseStatusCode(response, data) {
  const payloadCode = Number(data?.statusCode || data?.status_code || data?.code || 0);
  if (payloadCode >= 400) return payloadCode;
  return Number(response?.status || payloadCode || 0);
}

function responseRawMessage(data) {
  return String(data?.message || data?.msg || data?.errorMessage || data?.error?.message || data?.error || '');
}

function isCredentialFailure(status, rawMessage = '') {
  return [401, 403, 429].includes(Number(status))
    || /api.?key|unauthorized|forbidden|invalid key|quota|limit|too many|habis|penuh/i.test(String(rawMessage));
}

function isNoDataFailure(response, data, status, rawMessage = '') {
  if (response?.ok && (data?.status === false || data?.success === false || data?.error === true)) return true;
  return [400, 404, 422].includes(Number(status))
    || /not found|tidak ditemukan|tidak ada hasil|no result|invalid query|query tidak valid|lyrics? (?:not found|tidak ada)|data kosong/i.test(String(rawMessage));
}

function apiFailureMessage(response, payload, provider = 'Provider') {
  const raw = payload?.message || payload?.msg || payload?.errorMessage || payload?.error?.message || payload?.error || '';
  const status = responseStatusCode(response, payload);
  if (status === 429 || /quota|limit|too many|habis|penuh/i.test(String(raw))) return `${provider} sedang sibuk`;
  if ([401, 403].includes(status) || /api.?key|unauthorized|forbidden|invalid key/i.test(String(raw))) return `${provider} menolak kredensial`;
  if (response?.ok && (payload?.status === false || payload?.success === false || payload?.error === true)) return `${provider} tidak menemukan data`;
  if ([400, 404, 422].includes(status)) return `${provider} tidak menemukan data`;
  return status ? `${provider} belum merespons (${status})` : `${provider} belum merespons`;
}

function payloadRejected(response, data) {
  const status = Number(data?.statusCode || data?.status_code || data?.code || response?.status || 0);
  const raw = data?.message || data?.msg || data?.errorMessage || data?.error?.message || data?.error || '';
  return !response?.ok || data?.status === false || data?.success === false || data?.error === true || status >= 400 || /quota exceeded|limit reached|api key.*invalid/i.test(String(raw));
}

async function apiFetch(path, params = {}, timeout = CONFIG.requestTimeout) {
  const endpoint = assertAllowedEndpoint('CMNTY', path, CMNTY_ALLOWED_ENDPOINTS);
  const keys = CONFIG.apiKeys;
  const now = Date.now();
  const naturalOrder = Array.from({ length: keys.length }, (_, index) => index);
  const available = naturalOrder.filter(index => cmntyKeyCooldownUntil[index] <= now);
  if (!available.length) throw new Error('Semua API key CMNTY masih dalam masa cooldown');
  const attempts = available;
  const errors = [];

  for (const index of attempts) {
    for (let retry = 0; retry < 2; retry += 1) {
      const url = new URL(`${CONFIG.apiBase}${endpoint}`);
      Object.entries({ ...params, apikey: keys[index] }).forEach(([key, value]) => {
        if (value !== undefined && value !== null && value !== '') url.searchParams.set(key, value);
      });
      const retryText = retry ? ' • percobaan ulang pada key yang sama' : '';
      const activityId = beginSystemActivity(apiActionLabel(endpoint), `Mencoba CMNTY API #${index + 1}${retryText}`, 'CMNTY', {
        keyNumber: index + 1,
        track: params.q || params.query || params.title || ''
      });
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), timeout);

      try {
        const response = await fetch(url, {
          headers: { Accept: 'application/json' },
          signal: controller.signal,
          cache: 'no-store'
        });
        const raw = await response.text();
        let data = {};
        try { data = raw ? JSON.parse(raw) : {}; } catch { data = { message: raw }; }

        if (!payloadRejected(response, data)) {
          state.apiKeyIndex = index;
          state.apiOnline = true;
          cmntyKeyCooldownUntil[index] = 0;
          storage.set('apiKeyIndex', index);
          storage.set('cmntyKeyCooldownUntil', cmntyKeyCooldownUntil);
          finishSystemActivity(activityId, 'success', `Berhasil memakai CMNTY API #${index + 1}`);
          return data;
        }

        const status = responseStatusCode(response, data);
        const rawMessage = responseRawMessage(data);
        const message = apiFailureMessage(response, data, 'CMNTY');
        const keyRejected = isCredentialFailure(status, rawMessage);
        const noData = isNoDataFailure(response, data, status, rawMessage);
        const transient = status >= 500 || status === 408 || status === 0;

        if (keyRejected) {
          const cooldown = status === 429 || /quota|limit|too many|habis|penuh/i.test(rawMessage)
            ? 5 * 60 * 1000
            : 30 * 60 * 1000;
          cmntyKeyCooldownUntil[index] = Date.now() + cooldown;
          storage.set('cmntyKeyCooldownUntil', cmntyKeyCooldownUntil);
          finishSystemActivity(activityId, 'warning', `${message} pada API #${index + 1}. Baru sekarang beralih ke API berikutnya.`);
          errors.push(message);
          break;
        }

        if (noData) {
          state.apiOnline = true;
          finishSystemActivity(activityId, 'warning', `${message}. Tidak merotasi key karena masalahnya bukan kredensial.`);
          const error = new Error(message);
          error.nonRotatable = true;
          error.noData = true;
          throw error;
        }

        if (transient && retry === 0) {
          finishSystemActivity(activityId, 'warning', `${message}. Mencoba ulang API #${index + 1} tanpa mengganti key.`);
          errors.push(message);
          continue;
        }

        finishSystemActivity(activityId, 'error', `${message}. Rotasi dihentikan agar kuota key lain tidak terbuang.`);
        const error = new Error(message);
        error.nonRotatable = true;
        throw error;
      } catch (error) {
        if (error?.nonRotatable) throw error;
        const message = error?.name === 'AbortError' ? 'CMNTY terlalu lama merespons' : 'Koneksi CMNTY terputus';
        if (retry === 0) {
          finishSystemActivity(activityId, 'warning', `${message} pada API #${index + 1}. Mencoba ulang key yang sama.`);
          errors.push(message);
          continue;
        }
        finishSystemActivity(activityId, 'error', `${message}. Rotasi dihentikan karena gangguan jaringan bukan masalah API key.`);
        const fatal = new Error(message);
        fatal.nonRotatable = true;
        throw fatal;
      } finally {
        clearTimeout(timer);
      }
    }
  }

  state.apiOnline = false;
  throw new Error(errors.at(-1) || 'Semua API key CMNTY yang tersedia sedang dibatasi');
}

async function externalApiFetch(base, path, params = {}, timeout = CONFIG.requestTimeout, provider = 'Provider') {
  const url = new URL(`${base}${path}`);
  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== '') url.searchParams.set(key, value);
  });
  const activityId = beginSystemActivity(apiActionLabel(path), `Menghubungi ${provider}`, provider, { track: params.q || params.query || params.title || params.url || '' });
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);
  try {
    const response = await fetch(url, {
      headers: { Accept: 'application/json' },
      signal: controller.signal,
      cache: 'no-store'
    });
    const raw = await response.text();
    let data = {};
    try { data = raw ? JSON.parse(raw) : {}; } catch { data = { message: raw }; }
    if (payloadRejected(response, data)) throw new Error(apiFailureMessage(response, data, provider));
    finishSystemActivity(activityId, 'success', `${provider} berhasil merespons`);
    return data;
  } catch (error) {
    const message = error?.name === 'AbortError' ? `${provider} terlalu lama merespons` : (error?.message || `${provider} gagal`);
    finishSystemActivity(activityId, 'error', message);
    if (error?.name === 'AbortError') throw new Error(message);
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

async function blackRoseFetch() {
  const error = new Error('BlackRose dinonaktifkan sementara');
  error.disabledProvider = true;
  error.nonRotatable = true;
  throw error;
}

function waitForAudioReady(timeout = 24000, requireCanPlayThrough = false) {
  const targetState = requireCanPlayThrough ? 4 : 2;
  if (audio.readyState >= targetState) return Promise.resolve();
  return new Promise((resolve, reject) => {
    let settled = false;
    const cleanup = () => ['loadedmetadata','canplay','canplaythrough','error'].forEach(type => audio.removeEventListener(type, onEvent));
    const finish = (error = null) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      cleanup();
      if (error) reject(error); else resolve();
    };
    const onEvent = event => {
      if (event.type === 'error') return finish(new Error('Stream audio penuh tidak tersedia'));
      if (audio.readyState >= targetState || (!requireCanPlayThrough && audio.readyState >= 2)) finish();
    };
    const timer = setTimeout(() => finish(), timeout);
    ['loadedmetadata','canplay','canplaythrough','error'].forEach(type => audio.addEventListener(type, onEvent));
  });
}

function pruneFullAudioBlobCache() {
  const protectedUrls = new Set([activePlaybackOriginalUrl, nextTrackPreload?.audioUrl, nextTrackPreload?.value?.audioUrl].filter(Boolean));
  const entries = [...fullAudioBlobCache.entries()].sort((a, b) => Number(a[1]?.at || 0) - Number(b[1]?.at || 0));
  while (entries.length > FULL_AUDIO_CACHE_LIMIT) {
    const removableIndex = entries.findIndex(([url]) => !protectedUrls.has(url));
    if (removableIndex < 0) break;
    const [url, entry] = entries.splice(removableIndex, 1)[0];
    fullAudioBlobCache.delete(url);
    try { if (entry?.objectUrl) URL.revokeObjectURL(entry.objectUrl); } catch {}
  }
}

function cachedFullAudio(url = '') {
  const key = String(url || '').trim();
  const entry = key ? fullAudioBlobCache.get(key) : null;
  if (!entry?.objectUrl || !entry?.blob?.size) return null;
  entry.at = Date.now();
  return entry;
}

function theresavBufferedProxyUrl(track = state.current) {
  const spotifyUrl = spotifyTrackUrl(track);
  return spotifyUrl ? `/api/theresav/audio?url=${encodeURIComponent(spotifyUrl)}` : '';
}

function sylvaticaBufferedProxyUrl(track = state.current) {
  const spotifyUrl = spotifyTrackUrl(track);
  return spotifyUrl && CONFIG.sylvaticaSpotyloaderEnabled
    ? `${CONFIG.sylvaticaSpotyloaderAudioProxyPath}?url=${encodeURIComponent(spotifyUrl)}`
    : '';
}

function bufferedProxyCandidates(track = state.current) {
  return [...new Set([
    sylvaticaBufferedProxyUrl(track),
    theresavBufferedProxyUrl(track)
  ].filter(Boolean))];
}

async function readAudioResponseToBlob(response, onProgress = null) {
  if (!response?.ok) throw new Error(`Audio HTTP ${response?.status || 0}`);
  const contentLength = Number(response.headers.get('content-length') || 0);
  if (contentLength > FULL_AUDIO_MAX_BYTES) throw new Error('Ukuran audio terlalu besar untuk buffer penuh');
  const type = response.headers.get('content-type') || 'audio/mpeg';
  if (!response.body?.getReader) {
    const blob = await response.blob();
    if (!blob.size || blob.size > FULL_AUDIO_MAX_BYTES) throw new Error('Berkas audio penuh tidak valid');
    onProgress?.(1);
    return blob.type ? blob : new Blob([blob], { type });
  }
  const reader = response.body.getReader();
  const chunks = [];
  let received = 0;
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    if (!value?.byteLength) continue;
    received += value.byteLength;
    if (received > FULL_AUDIO_MAX_BYTES) {
      try { await reader.cancel(); } catch {}
      throw new Error('Ukuran audio melewati batas buffer penuh');
    }
    chunks.push(value);
    if (contentLength > 0) onProgress?.(Math.max(0, Math.min(1, received / contentLength)));
  }
  if (!received) throw new Error('Berkas audio penuh kosong');
  onProgress?.(1);
  return new Blob(chunks, { type: /audio|octet-stream/i.test(type) ? type : 'audio/mpeg' });
}

async function fetchFullAudioBlob(sourceUrl, track = state.current, options = {}) {
  const originalUrl = String(sourceUrl || '').trim();
  if (!originalUrl) throw new Error('URL audio penuh tidak tersedia');
  const cached = !options.force ? cachedFullAudio(originalUrl) : null;
  if (cached) return cached;

  const controller = new AbortController();
  const parentSignal = options.signal || null;
  const abortFromParent = () => controller.abort();
  if (parentSignal) {
    if (parentSignal.aborted) controller.abort();
    else parentSignal.addEventListener('abort', abortFromParent, { once:true });
  }
  const timeout = window.setTimeout(() => controller.abort(), Number(options.timeout || 60000));
  const report = progress => {
    if (options.current && state.current && trackKey(state.current) === trackKey(track)) {
      const nextProgress = Math.round(progress * 100);
      if (nextProgress === 100 || nextProgress >= Number(state.audioBufferingProgress || 0) + 5) {
        state.audioBufferingProgress = nextProgress;
        renderPlayerDynamic();
      }
    }
  };
  let response = null;
  let usedProxy = false;
  try {
    try {
      response = await fetch(originalUrl, {
        method: 'GET', mode: 'cors', credentials: 'omit', redirect: 'follow', cache: 'no-store', signal: controller.signal
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
    } catch (directError) {
      let proxyError = directError;
      for (const proxyUrl of bufferedProxyCandidates(track)) {
        try {
          usedProxy = true;
          response = await fetch(proxyUrl, { method: 'GET', redirect: 'follow', cache: 'no-store', signal: controller.signal });
          if (!response.ok) throw new Error(`Proxy audio HTTP ${response.status}`);
          proxyError = null;
          break;
        } catch (error) {
          proxyError = error;
          response = null;
        }
      }
      if (!response?.ok) throw proxyError || directError;
    }
    const blob = await readAudioResponseToBlob(response, report);
    const objectUrl = URL.createObjectURL(blob);
    const previous = fullAudioBlobCache.get(originalUrl);
    if (previous?.objectUrl && previous.objectUrl !== objectUrl) {
      try { URL.revokeObjectURL(previous.objectUrl); } catch {}
    }
    const entry = { objectUrl, blob, size: blob.size, at: Date.now(), sourceUrl: originalUrl, viaProxy: usedProxy };
    fullAudioBlobCache.set(originalUrl, entry);
    pruneFullAudioBlobCache();
    return entry;
  } catch (error) {
    if (error?.name === 'AbortError') throw new Error('Pengunduhan audio penuh terlalu lama');
    throw error;
  } finally {
    clearTimeout(timeout);
    if (parentSignal) parentSignal.removeEventListener('abort', abortFromParent);
  }
}

async function prepareAudioPlaybackSource(sourceUrl, track = state.current, options = {}) {
  const originalUrl = String(sourceUrl || '').trim();
  if (!originalUrl) throw new Error('URL audio penuh tidak tersedia');
  try {
    const full = await fetchFullAudioBlob(originalUrl, track, options);
    return { playbackUrl: full.objectUrl, originalUrl, fullyBuffered: true, blob: full.blob, viaProxy: full.viaProxy };
  } catch (error) {
    // Jika CDN memblokir CORS dan proxy juga tidak tersedia, pertahankan playback streaming sebagai fallback.
    const proxyUrl = bufferedProxyCandidates(track)[0] || '';
    return { playbackUrl: proxyUrl || originalUrl, originalUrl, fullyBuffered: false, blob: null, bufferError: error };
  }
}

function playbackRequestStillActive(token, track) {
  return token === state.playerPrepareToken && Boolean(state.current) && sameTrackIdentity(state.current, track);
}

async function attachFastPlaybackSource(sourceUrl, track, options = {}) {
  const originalUrl = String(sourceUrl || '').trim();
  if (!originalUrl) throw new Error('URL audio penuh tidak tersedia');
  const cached = cachedFullAudio(originalUrl);
  const proxyCandidates = bufferedProxyCandidates(track);
  const audioLabSafe = Boolean(window.DatzonAudioLab?.requiresSameOrigin?.());
  const candidates = [...new Set([
    options.preloadedPlaybackUrl,
    cached?.objectUrl,
    ...(audioLabSafe ? proxyCandidates : [originalUrl]),
    ...(audioLabSafe ? [originalUrl] : proxyCandidates)
  ].filter(Boolean))];
  let lastError = null;
  for (const playbackUrl of candidates) {
    if (options.signal?.aborted) throw new Error('Persiapan audio dibatalkan');
    try {
      audio.src = playbackUrl;
      audio.preload = 'auto';
      audio.load();
      await waitForAudioReady(Number(options.timeout || 15000), false);
      if (audio.error) throw new Error('Stream audio tidak tersedia');
      return {
        playbackUrl,
        originalUrl,
        fullyBuffered: Boolean(cached && playbackUrl === cached.objectUrl) || Boolean(options.preloadedFullyBuffered && playbackUrl === options.preloadedPlaybackUrl)
      };
    } catch (error) {
      lastError = error;
      try { audio.pause(); audio.removeAttribute('src'); audio.load(); } catch {}
    }
  }
  throw lastError || new Error('Audio belum siap diputar');
}

function startCurrentFullBufferInBackground(sourceUrl, track, token, signal) {
  if (!sourceUrl || !playbackRequestStillActive(token, track)) return Promise.resolve(null);
  const cached = cachedFullAudio(sourceUrl);
  if (cached) {
    state.audioFullyBuffered = true;
    state.audioBufferingProgress = 100;
    return Promise.resolve(cached);
  }
  const watchedKey = trackKey(track);
  const task = fetchFullAudioBlob(sourceUrl, track, { current:true, timeout:90000, signal })
    .then(entry => {
      if (!playbackRequestStillActive(token, track) || trackKey(state.current) !== watchedKey) return entry;
      state.audioFullyBuffered = true;
      state.audioBufferingProgress = 100;
      renderPlayerDynamic();
      renderMiniPlayer();
      return entry;
    })
    .catch(error => {
      if (playbackRequestStillActive(token, track) && error?.message && !/dibatalkan/i.test(error.message)) {
        state.audioFullyBuffered = false;
      }
      return null;
    });
  currentFullBufferPromise = task;
  return task;
}

async function upgradeCurrentAudioToBufferedSource(targetSeconds = null) {
  const originalUrl = activePlaybackOriginalUrl || state.currentAudioUrl || state.current?.audioUrl || '';
  const cached = cachedFullAudio(originalUrl);
  if (!cached?.objectUrl || !state.current || String(audio.src || '').startsWith('blob:')) return false;
  const wasPlaying = !audio.paused;
  const position = Number.isFinite(Number(targetSeconds)) ? Number(targetSeconds) : Number(audio.currentTime || 0);
  try {
    audio.pause();
    audio.src = cached.objectUrl;
    audio.preload = 'auto';
    audio.load();
    await waitForAudioReady(8000, false);
    if (position > 0) audio.currentTime = Math.min(position, Math.max(0, (Number(audio.duration) || durationSeconds(state.current.duration)) - .05));
    if (wasPlaying) await audio.play();
    state.audioFullyBuffered = true;
    state.audioBufferingProgress = 100;
    return true;
  } catch {
    return false;
  }
}

function audioTimeAlreadyBuffered(target) {
  try {
    for (let index = 0; index < audio.buffered.length; index += 1) {
      if (target >= audio.buffered.start(index) - .15 && target <= audio.buffered.end(index) + .35) return true;
    }
  } catch {}
  return false;
}

async function switchCurrentAudioToSeekableProxy(target) {
  if (!state.current) return false;
  const watchedKey = trackKey(state.current);
  const token = state.playerPrepareToken;
  const proxy = bufferedProxyCandidates(state.current)[0] || '';
  if (!proxy) return false;
  const absoluteProxy = new URL(proxy, location.origin).href;
  const wasPlaying = !audio.paused;
  try {
    if (String(audio.src || '') !== absoluteProxy) {
      audio.pause();
      audio.src = proxy;
      audio.preload = 'auto';
      audio.load();
      await waitForAudioReady(9000, true);
    }
    if (token !== state.playerPrepareToken || !state.current || trackKey(state.current) !== watchedKey) return false;
    audio.currentTime = target;
    if (wasPlaying) await audio.play();
    updateMediaSessionPosition();
    return true;
  } catch {
    return false;
  }
}

async function seekAudioTo(targetSeconds) {
  const duration = Number(audio.duration) || durationSeconds(state.current?.duration);
  if (!Number.isFinite(targetSeconds) || targetSeconds < 0 || !duration) return;
  const target = Math.max(0, Math.min(Number(targetSeconds), Math.max(0, duration - .05)));
  try {
    const sourceUrl = activePlaybackOriginalUrl || state.currentAudioUrl || state.current?.audioUrl || '';
    if (cachedFullAudio(sourceUrl) && !String(audio.src || '').startsWith('blob:')) {
      const upgraded = await upgradeCurrentAudioToBufferedSource(target);
      if (upgraded) { updateMediaSessionPosition(); return; }
    }

    // Kalau user lompat jauh sebelum buffer penuh selesai, beri buffer background
    // kesempatan singkat. Jika masih belum ada, pindah ke proxy Range/206 agar seek
    // tidak mental lagi ke 0:00 pada CDN yang tidak mendukung random access.
    if (!String(audio.src || '').startsWith('blob:') && !audioTimeAlreadyBuffered(target)) {
      if (currentFullBufferPromise) {
        await Promise.race([
          Promise.resolve(currentFullBufferPromise).catch(() => null),
          new Promise(resolve => setTimeout(resolve, 1600))
        ]);
      }
      if (cachedFullAudio(sourceUrl)) {
        const upgraded = await upgradeCurrentAudioToBufferedSource(target);
        if (upgraded) { updateMediaSessionPosition(); return; }
      }
      const proxied = await switchCurrentAudioToSeekableProxy(target);
      if (proxied) return;
    }

    audio.currentTime = target;
    updateMediaSessionPosition();
  } catch {}
}

function bindSeekControl(seek, track = state.current) {
  if (!seek) return;
  const durationForSeek = () => Number(audio.duration) || durationSeconds(track?.duration) || 0;
  const preview = () => {
    userSeekActive = true;
    const ratio = Math.max(0, Math.min(1, Number(seek.value) / 1000));
    const target = durationForSeek() * ratio;
    pendingSeekSeconds = target;
    seek.style.setProperty('--range-progress', `${ratio * 100}%`);
    const elapsed = $('#elapsed', view);
    if (elapsed) elapsed.textContent = formatTime(target);
  };
  const commit = async () => {
    const target = Number.isFinite(pendingSeekSeconds) ? pendingSeekSeconds : durationForSeek() * (Number(seek.value) / 1000);
    userSeekActive = false;
    pendingSeekSeconds = null;
    await seekAudioTo(target);
    syncPlaybackUI(true);
  };
  seek.onpointerdown = () => { userSeekActive = true; };
  seek.ontouchstart = () => { userSeekActive = true; };
  seek.oninput = preview;
  seek.onchange = () => { void commit(); };
  seek.onblur = () => { if (userSeekActive) void commit(); };
}

function clearAudioStallRecovery() {
  if (audioStallRecoveryTimer) window.clearTimeout(audioStallRecoveryTimer);
  audioStallRecoveryTimer = null;
}

async function recoverPlaybackAfterStall(reason = 'buffering') {
  if (audioRecoveryInFlight || !state.current || audio.paused || audio.ended) return;
  audioRecoveryInFlight = true;
  const watchedKey = trackKey(state.current);
  const resumeAt = Number(audio.currentTime) || 0;
  state.resolving = true;
  renderPlayerDynamic();
  const activityId = beginSystemActivity('Memulihkan audio', `Playback berhenti pada ${formatTime(resumeAt)}. Menyiapkan ulang audio penuh.`, 'Pemutar DATZON', { track: cleanTitle(state.current) });
  try {
    const expectedTrack = normalizeTrack(state.current);
    const freshUrl = await resolveAudio(expectedTrack, { allowPreview: false, force: true, guardTrack: expectedTrack });
    if (!state.current || trackKey(state.current) !== watchedKey) return;
    const preparedSource = await prepareAudioPlaybackSource(freshUrl, state.current, { force: true, current: true, timeout: 65000 });
    if (!state.current || trackKey(state.current) !== watchedKey) return;
    state.current.audioUrl = freshUrl;
    state.current.downloadUrl = state.current.downloadUrl || freshUrl;
    state.current.audioResolvedAt = Date.now();
    state.currentAudioUrl = freshUrl;
    state.audioFullyBuffered = preparedSource.fullyBuffered;
    activePlaybackOriginalUrl = freshUrl;
    audio.src = preparedSource.playbackUrl;
    audio.preload = 'auto';
    audio.load();
    await waitForAudioReady(24000, !preparedSource.fullyBuffered);
    await seekAudioTo(resumeAt);
    await audio.play();
    finishSystemActivity(activityId, 'success', preparedSource.fullyBuffered ? 'Audio dipulihkan dari buffer penuh' : 'Audio dipulihkan melalui stream cadangan');
  } catch (error) {
    finishSystemActivity(activityId, 'error', error?.message || `Gagal memulihkan ${reason}`);
    if (state.settings.notifyFailures !== false) notify('Audio sempat terputus dan belum berhasil dipulihkan. Tekan putar untuk mencoba lagi.');
  } finally {
    state.resolving = false;
    audioRecoveryInFlight = false;
    renderPlayerDynamic();
    renderMiniPlayer();
  }
}

function scheduleAudioStallRecovery(reason = 'buffering') {
  clearAudioStallRecovery();
  if (!state.current || audio.paused || audio.ended) return;
  audioStallRecoveryTimer = window.setTimeout(() => {
    audioStallRecoveryTimer = null;
    if (!audio.paused && !audio.ended && audio.readyState < 3) void recoverPlaybackAfterStall(reason);
  }, 2600);
}

function preloadArtwork(url, timeout = 12000) {
  if (!url) return Promise.resolve();
  return new Promise(resolve => {
    const image = new Image();
    let settled = false;
    const done = () => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      image.onload = null;
      image.onerror = null;
      resolve();
    };
    const timer = setTimeout(done, timeout);
    image.onload = done;
    image.onerror = done;
    image.src = url;
    if (image.complete) done();
  });
}

function completePlayerPreparation(token) {
  if (token !== state.playerPrepareToken) return;
  if (!state.audioReady || !state.lyricsReady || !state.artworkReady) return;
  state.playerPreparing = false;
  if (state.route === 'player') renderPlayer();
  else if (state.route === 'lyrics') renderFullLyrics();
  renderMiniPlayer();
}

function extractPrimarySearchTracks(payload, source) {
  const candidates = collectPrimaryTrackCandidates(payload).map(normalizePrimaryTrackCandidate);
  return dedupeTracks(candidates).map(track => normalizeTrack({
    ...track,
    source: source || track.source || 'Spotify Search',
    previewUrl: '',
    audioUrl: '',
    audioIsPreview: false
  }));
}

function searchProviderOrder() {
  const defaults = ['theresav', 'cmnty', 'ikyy', 'sylvatica', 'sylvatica-spotyloader'];
  const preferred = String(CONFIG.primarySearchProvider || 'theresav').toLowerCase();
  return [preferred, ...defaults.filter(provider => provider !== preferred)];
}

async function fetchSpotifySearchProvider(provider, query) {
  let data;
  let label;
  if (provider === 'theresav') {
    if (!CONFIG.theresavSearchEnabled) throw new Error('Theresav Search dinonaktifkan');
    label = 'Theresav Spotify Search';
    data = await theresavApiFetch('search', { query }, 30000);
  } else if (provider === 'sylvatica') {
    if (!CONFIG.sylvaticaSearchEnabled) throw new Error('Sylvatica Search dinonaktifkan');
    label = 'Sylvatica Spotify Search';
    data = await sylvaticaApiFetch('search', { q: query }, 24000, label);
  } else if (provider === 'sylvatica-spotyloader') {
    if (!CONFIG.sylvaticaSpotyloaderEnabled) throw new Error('Sylvatica Spotyloader Search dinonaktifkan');
    label = 'Sylvatica Spotyloader Search';
    data = await sylvaticaSpotyloaderFetch({ url: query, type:'search' }, 28000, label);
  } else if (provider === 'ikyy') {
    if (!CONFIG.ikyySearchEnabled) throw new Error('Ikyy Search dinonaktifkan');
    label = 'Ikyy Spotify Search';
    data = await externalApiFetch(CONFIG.ikyyApiBase, CONFIG.ikyySearchPath, { query }, 22000, label);
  } else if (provider === 'cmnty') {
    if (!CONFIG.cmntySearchEnabled) throw new Error('CMNTY Search dinonaktifkan');
    label = 'CMNTY Spotify Search';
    data = await apiFetch('/search/spotify', { q: query }, 35000);
  } else {
    throw new Error(`Provider pencarian ${provider} tidak dikenal`);
  }
  const tracks = (provider === 'theresav'
    ? dedupeTracks(collectPrimaryTrackCandidates(data).map(raw => normalizeTheresavTrackCandidate(raw)))
    : provider === 'sylvatica-spotyloader'
      ? dedupeTracks(collectSylvaticaSpotyloaderSearchTracks(data))
      : extractPrimarySearchTracks(data, label))
    .map(track => normalizeTrack({ ...track, source: label }))
    .filter(track => Boolean(spotifyTrackUrl(track)))
    .slice(0, 30);
  if (!tracks.length) {
    const error = new Error(`${label} tidak menemukan lagu`);
    error.noData = true;
    throw error;
  }
  return tracks;
}

function trackHasRealCover(track) {
  const cover = String(track?.thumbnail || '');
  return Boolean(cover && !cover.includes('placeholder.svg'));
}
function searchIdentity(track) {
  return spotifyTrackUrl(track) || `${normalizeMatchText(cleanTitle(track))}|${normalizeMatchText(track?.artist || '')}`;
}
function mergeSearchTracks(base = [], incoming = []) {
  const map = new Map(); const order = [];
  const add = raw => {
    const track = normalizeTrack(raw); const key = searchIdentity(track);
    if (!key || key === '|') return;
    if (!map.has(key)) { map.set(key, track); order.push(key); return; }
    const current = map.get(key);
    map.set(key, normalizeTrack({
      ...current,
      title: current.title !== 'Tanpa Judul' ? current.title : track.title,
      artist: !isUnknownArtist(current.artist) ? current.artist : track.artist,
      thumbnail: trackHasRealCover(current) ? current.thumbnail : track.thumbnail,
      duration: durationSeconds(current.duration) > 20 ? current.duration : track.duration,
      album: current.album || track.album,
      release_date: current.release_date || track.release_date,
      url: spotifyTrackUrl(current) || spotifyTrackUrl(track) || current.url || track.url,
      id: current.id || track.id,
      source: current.source || track.source
    }));
  };
  base.forEach(add); incoming.forEach(add);
  return order.map(key => map.get(key)).filter(Boolean).slice(0,30);
}

async function searchSpotify(query, options = {}) {
  const cleanQuery = String(query || '').trim();
  if (!cleanQuery) return [];
  const cacheKey = normalizeMatchText(cleanQuery);
  const force = Boolean(options.force);
  const cached = spotifySearchCache.get(cacheKey);

  if (!force && cached && Date.now() - cached.at < CONFIG.searchCacheMs) return await cached.value;

  if (!force) {
    const persisted = readPersistentApiCache(SPOTIFY_SEARCH_STORAGE_KEY, cacheKey, CONFIG.searchCacheMs);
    if (Array.isArray(persisted) && persisted.length) {
      const tracks = persisted.map(item => normalizeTrack({ ...item, source: item.source || 'Spotify Search' }));
      spotifySearchCache.set(cacheKey, { at: Date.now(), value: Promise.resolve(tracks) });
      return tracks;
    }
  }

  const request = (async () => {
    const errors = [];
    let combined = [];
    for (const provider of searchProviderOrder()) {
      try {
        const tracks = await fetchSpotifySearchProvider(provider, cleanQuery);
        combined = mergeSearchTracks(combined, tracks);
        state.apiOnline = true;
        if (combined.length >= 20 && !combined.some(track => !trackHasRealCover(track))) break;
      } catch (error) {
        errors.push(error?.message || `${provider} gagal`);
      }
    }
    if (combined.length) {
      const tracks = dedupeTracks(combined).filter(track => Boolean(spotifyTrackUrl(track))).slice(0,30);
      writePersistentApiCache(SPOTIFY_SEARCH_STORAGE_KEY, cacheKey, tracks, 40);
      return tracks;
    }
    state.apiOnline = false;
    const error = new Error('Pencarian lagu sedang tidak tersedia. Theresav, CMNTY, Ikyy, Sylvatica, dan Spotyloader gagal merespons.');
    error.providerErrors = errors;
    throw error;
  })();

  spotifySearchCache.set(cacheKey, { at: Date.now(), value: request });
  try {
    const tracks = await request;
    spotifySearchCache.set(cacheKey, { at: Date.now(), value: Promise.resolve(tracks) });
    return tracks.map(track => normalizeTrack({ ...track }));
  } catch (error) {
    spotifySearchCache.delete(cacheKey);
    throw error;
  }
}

function fetchItunesJsonp(url, timeout = 18000) {
  return new Promise((resolve, reject) => {
    const callbackName = `__datzonItunes_${Date.now()}_${Math.random().toString(36).slice(2)}`;
    const script = document.createElement('script');
    const jsonpUrl = new URL(url);
    jsonpUrl.searchParams.set('callback', callbackName);
    let settled = false;
    const cleanup = () => {
      delete window[callbackName];
      script.remove();
      clearTimeout(timer);
    };
    const finish = (fn, value) => {
      if (settled) return;
      settled = true;
      cleanup();
      fn(value);
    };
    window[callbackName] = data => finish(resolve, data);
    script.onerror = () => finish(reject, new Error('iTunes Search tidak dapat dihubungi'));
    script.src = jsonpUrl.toString();
    script.async = true;
    const timer = setTimeout(() => finish(reject, new Error('iTunes Search melewati batas waktu')), timeout);
    document.head.appendChild(script);
  });
}

async function fetchJson(url, timeout = 18000) {
  const parsedUrl = new URL(url);
  const cacheKey = parsedUrl.toString();
  const cached = publicJsonCache.get(cacheKey);
  if (cached && Date.now() - cached.at < 1000 * 60 * 12) return cached.value;
  const host = parsedUrl.hostname;
  const provider = /marketingtools\.apple/i.test(host) ? 'Apple Music RSS' : /itunes\.apple/i.test(host) ? 'iTunes Search' : /musicbrainz/i.test(host) ? 'MusicBrainz' : /wikipedia/i.test(host) ? 'Wikipedia' : /coverartarchive/i.test(host) ? 'Cover Art Archive' : host;
  const activityId = beginSystemActivity('Memuat katalog dan metadata', `Menghubungi ${provider}`, provider);
  let lastError = null;
  for (let attempt = 0; attempt < 2; attempt += 1) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeout);
    try {
      const response = await fetch(parsedUrl.toString(), {
        headers: { Accept: 'application/json' },
        signal: controller.signal,
        cache: attempt ? 'reload' : 'default',
        credentials: 'omit'
      });
      if (!response.ok) throw new Error(`${provider} merespons HTTP ${response.status}`);
      const data = await response.json();
      publicJsonCache.set(cacheKey, { at: Date.now(), value: data });
      finishSystemActivity(activityId, 'success', `${provider} berhasil dimuat`);
      clearTimeout(timer);
      return data;
    } catch (error) {
      lastError = error;
      clearTimeout(timer);
      if (attempt === 0) await new Promise(resolve => setTimeout(resolve, 320));
    }
  }
  if (/itunes\.apple/i.test(host)) {
    try {
      const data = await fetchItunesJsonp(parsedUrl, timeout);
      publicJsonCache.set(cacheKey, { at: Date.now(), value: data });
      finishSystemActivity(activityId, 'success', 'iTunes Search berhasil dimuat melalui jalur cadangan');
      return data;
    } catch (error) { lastError = error; }
  }
  const detail = lastError?.name === 'AbortError' ? `${provider} melewati batas waktu` : (lastError?.message || `${provider} sedang tidak tersedia`);
  finishSystemActivity(activityId, 'error', detail);
  throw new Error(detail);
}

function spotifyAuthIsReady() { return false; }
function spotifyHasSession() { return false; }
function clearSpotifySession(showNotice = false) {
  state.spotifyAuth = { accessToken:'', refreshToken:'', expiresAt:0 };
  storage.remove('spotifyAuth');
  try {
    ['datzon_spotify_verifier','datzon_spotify_state','datzon_spotify_return_artist','datzon_spotify_return_route'].forEach(key => sessionStorage.removeItem(key));
  } catch {}
  if (showNotice) notify('Spotify digunakan sebagai katalog server-side DATZON.');
}
async function beginSpotifyAuth() {
  notify('Metadata Spotify sudah diproses otomatis oleh server DATZON.');
}
async function exchangeSpotifyCode() { throw new Error('Spotify user OAuth dinonaktifkan.'); }
async function refreshSpotifyAccessToken() { throw new Error('Spotify user OAuth dinonaktifkan.'); }
async function getSpotifyAccessToken() { throw new Error('Spotify token hanya tersedia di server.'); }
async function spotifyApiFetch() { throw new Error('Spotify Web API hanya boleh dipanggil melalui backend DATZON.'); }
async function handleSpotifyCallback() {
  // V1.60.0 tidak menggunakan Spotify OAuth user. Bersihkan callback/token lama bila pernah tersimpan oleh versi sebelumnya.
  clearSpotifySession(false);
  const url = new URL(location.href);
  if (!url.searchParams.has('code') && !url.searchParams.has('error') && !url.searchParams.has('state')) return false;
  ['code','state','error'].forEach(key => url.searchParams.delete(key));
  history.replaceState({}, document.title, `${url.pathname}${url.search}${url.hash}`);
  return true;
}

function largeArtwork(url = '') {
  return enhanceArtworkUrl(url);
}

function normalizeAppleItem(item, rank = 0) {
  return normalizeTrack({
    title: item?.name || item?.trackName || item?.collectionName || 'Tanpa Judul',
    artist: item?.artistName || 'Artis tidak diketahui',
    duration: item?.trackTimeMillis ? formatTime(item.trackTimeMillis / 1000) : '0:00',
    thumbnail: largeArtwork(item?.artworkUrl100 || item?.artworkUrl || item?.artwork || item?.artworkUrl60 || ''),
    album: item?.collectionName || item?.name || '',
    release_date: item?.releaseDate || '',
    url: '',
    sourceUrl: item?.url || item?.trackViewUrl || item?.collectionViewUrl || '',
    previewUrl: item?.previewUrl || '',
    genre: item?.genres?.[0]?.name || item?.primaryGenreName || '',
    source: 'Apple Music',
    rank,
    id: item?.id || item?.trackId || item?.collectionId || ''
  });
}

async function fetchAppleFeed(url) {
  const data = await fetchJson(url, 22000);
  const results = Array.isArray(data?.feed?.results) ? data.feed.results : [];
  return results.map((item, index) => normalizeAppleItem(item, index + 1)).filter(track => track.thumbnail && cleanTitle(track));
}

async function fetchItunesTracks(term, limit = 25, artistOnly = false) {
  const url = new URL(CONFIG.itunesSearchBase);
  url.searchParams.set('term', term);
  url.searchParams.set('country', 'ID');
  url.searchParams.set('media', 'music');
  url.searchParams.set('entity', 'song');
  if (artistOnly) url.searchParams.set('attribute', 'artistTerm');
  url.searchParams.set('limit', String(limit));
  const data = await fetchJson(url, 18000);
  const normalized = dedupeTracks((data?.results || []).map((item, index) => normalizeAppleItem(item, index + 1)));
  if (!artistOnly) return normalized;
  const exact = normalized.filter(track => String(track.artist || '').localeCompare(String(term || ''), 'id', { sensitivity: 'base' }) === 0);
  return exact.length >= Math.min(5, limit) ? exact : normalized;
}

async function fetchItunesArtist(term) {
  const url = new URL(CONFIG.itunesSearchBase);
  url.searchParams.set('term', term);
  url.searchParams.set('country', 'ID');
  url.searchParams.set('media', 'music');
  url.searchParams.set('entity', 'musicArtist');
  url.searchParams.set('limit', '8');
  const data = await fetchJson(url, 18000);
  const results = Array.isArray(data?.results) ? data.results : [];
  return results.find(item => String(item.artistName || '').localeCompare(String(term || ''), 'id', { sensitivity: 'base' }) === 0) || results[0] || null;
}

async function fetchItunesReleases(term, limit = 24) {
  const artist = String(term || '').trim();
  if (!artist) return [];
  const url = new URL(CONFIG.itunesSearchBase);
  url.searchParams.set('term', artist);
  url.searchParams.set('country', 'ID');
  url.searchParams.set('media', 'music');
  url.searchParams.set('entity', 'album');
  url.searchParams.set('attribute', 'artistTerm');
  url.searchParams.set('limit', String(Math.max(8, Math.min(50, Number(limit) || 24))));
  const data = await fetchJson(url, 18000);
  const wanted = normalizeMatchText(artist);
  const rows = Array.isArray(data?.results) ? data.results : [];
  const seen = new Set();
  return rows.filter(item => {
    const exact = normalizeMatchText(item?.artistName || '') === wanted;
    const key = `${item?.collectionName || ''}|${item?.releaseDate || ''}`.toLocaleLowerCase('id');
    if (!exact || !item?.collectionName || seen.has(key)) return false;
    seen.add(key);
    return true;
  }).map(item => ({
    id: String(item?.collectionId || ''),
    title: String(item?.collectionName || '').trim(),
    date: String(item?.releaseDate || '').slice(0, 10),
    type: Number(item?.trackCount || 0) <= 3 ? 'Single / EP' : 'Album',
    cover: enhanceArtworkUrl(item?.artworkUrl100 || item?.artworkUrl60 || 'assets/placeholder.svg'),
    spotifyUrl: '',
    sourceUrl: item?.collectionViewUrl || ''
  })).slice(0, 24);
}

async function fetchMusicBrainzArtist(term) {
  const url = new URL(`${CONFIG.musicBrainzBase}/artist/`);
  url.searchParams.set('query', `artist:"${String(term || '').replace(/"/g, '')}"`);
  url.searchParams.set('fmt', 'json');
  url.searchParams.set('limit', '6');
  const data = await fetchJson(url, 22000);
  const artists = Array.isArray(data?.artists) ? data.artists : [];
  return artists.find(item => String(item.name || '').localeCompare(String(term || ''), 'id', { sensitivity: 'base' }) === 0) || artists[0] || null;
}

async function fetchMusicBrainzSpotifyArtistId(artistId) {
  if (!artistId) return '';
  const url = new URL(`${CONFIG.musicBrainzBase}/artist/${encodeURIComponent(artistId)}`);
  url.searchParams.set('inc', 'url-rels');
  url.searchParams.set('fmt', 'json');
  const data = await fetchJson(url, 22000);
  const relations = Array.isArray(data?.relations) ? data.relations : [];
  for (const relation of relations) {
    const target = relation?.url?.resource || relation?.target || '';
    const spotifyId = String(target).match(/open\.spotify\.com\/artist\/([A-Za-z0-9]{22})/i)?.[1];
    if (spotifyId) return spotifyId;
  }
  return '';
}

async function fetchMusicBrainzReleases(artistId) {
  if (!artistId) return [];
  const url = new URL(`${CONFIG.musicBrainzBase}/release-group/`);
  url.searchParams.set('artist', artistId);
  url.searchParams.set('fmt', 'json');
  url.searchParams.set('limit', '25');
  const data = await fetchJson(url, 24000);
  return (Array.isArray(data?.['release-groups']) ? data['release-groups'] : [])
    .filter(item => item?.title)
    .sort((a,b) => String(b?.['first-release-date'] || '').localeCompare(String(a?.['first-release-date'] || '')))
    .map(item => ({
      id: item.id,
      title: item.title,
      date: item['first-release-date'] || '',
      type: item['primary-type'] || item?.['secondary-types']?.[0] || 'Rilis',
      cover: `${CONFIG.coverArtArchiveBase}/${encodeURIComponent(item.id)}/front-500`
    }));
}

function artistCacheKey(name) {
  return String(name || '').trim().toLocaleLowerCase('id');
}

async function loadArtistProfile(name, force = false) {
  const artist = String(name || '').trim();
  if (!artist) throw new Error('Nama artis tidak tersedia');
  const key = artistCacheKey(artist);
  const cached = state.artistProfiles[key];
  const cachedAt = Number(state.artistProfilesAt[key] || 0);
  if (!force && cached && Date.now() - cachedAt < CONFIG.artistCacheMs) return cached;

  const [itunesArtistResult, tracksResult, itunesReleasesResult, mbArtistResult] = await Promise.allSettled([
    fetchItunesArtist(artist),
    fetchItunesTracks(artist, 30, true),
    fetchItunesReleases(artist, 24),
    fetchMusicBrainzArtist(artist)
  ]);
  const itunesArtist = itunesArtistResult.status === 'fulfilled' ? itunesArtistResult.value : null;
  const tracks = tracksResult.status === 'fulfilled' ? tracksResult.value : [];
  const itunesReleases = itunesReleasesResult.status === 'fulfilled' ? itunesReleasesResult.value : [];
  const mbArtist = mbArtistResult.status === 'fulfilled' ? mbArtistResult.value : null;
  let releases = [];
  if (mbArtist?.id) {
    await new Promise(resolve => setTimeout(resolve, 1050));
    try { releases = await fetchMusicBrainzReleases(mbArtist.id); } catch { releases = []; }
  }
  releases = releases.length ? releases : itunesReleases;
  const profile = {
    name: mbArtist?.name || itunesArtist?.artistName || artist,
    sortName: mbArtist?.['sort-name'] || '',
    country: mbArtist?.country || mbArtist?.area?.name || '',
    type: mbArtist?.type || 'Artis',
    disambiguation: mbArtist?.disambiguation || '',
    genre: itunesArtist?.primaryGenreName || mbArtist?.genres?.[0]?.name || mbArtist?.tags?.[0]?.name || '',
    artistUrl: itunesArtist?.artistLinkUrl || '',
    mbid: mbArtist?.id || '',
    tracks: dedupeTracks(tracks).slice(0, 20),
    releases: releases.slice(0, 20),
    source: [itunesArtist || tracks.length || itunesReleases.length ? 'iTunes Search API' : '', mbArtist ? 'MusicBrainz' : '', mbArtist && releases.length ? 'Cover Art Archive' : ''].filter(Boolean).join(' + ')
  };
  state.artistProfiles[key] = profile;
  state.artistProfilesAt[key] = Date.now();
  persist();
  return profile;
}


function normalizeSpotifyTrack(item) {
  const artistSource = Array.isArray(item?.artists) ? item.artists : [];
  const artistNames = extractArtistNames(artistSource, item?.artistNames, item?.artist);
  const artistIds = extractSpotifyArtistIds(artistSource, item?.artistIds, item?.artistId);
  const artistUrls = extractSpotifyArtistUrls(artistSource, item?.artistUrls, item?.artistDetails, item?.artists_detail);
  return normalizeTrack({
    id: item?.id || '',
    title: item?.name || item?.title || 'Tanpa Judul',
    artist: artistNames.join(', ') || normalizeArtistValue(item?.artist, item?.artistName, item?.artists),
    artistNames,
    artistIds,
    artistId: artistIds[0] || '',
    artistUrls,
    artistDetails: buildArtistDetails(artistNames, artistIds, artistUrls),
    duration: item?.duration_ms ? formatTime(item.duration_ms / 1000) : (item?.duration || item?.durationText || '0:00'),
    thumbnail: item?.album?.images?.[0]?.url || item?.image || item?.thumbnail || 'assets/placeholder.svg',
    album: typeof item?.album === 'object' ? (item?.album?.name || '') : (item?.album || ''),
    release_date: item?.album?.release_date || item?.release_date || item?.releaseDate || '',
    url: item?.external_urls?.spotify || item?.url || (item?.id ? `https://open.spotify.com/track/${item.id}` : ''),
    previewUrl: '',
    audioIsPreview: false,
    source: item?.source || 'Spotify Web API (metadata only)'
  });
}

/* V1.60.0 · Spotify server-side catalog helpers (Client Credentials through DATZON backend). */
function spotifyCatalogAvailable() { return Boolean(CONFIG.spotifyCatalogEnabled && window.DatzonSpotifyCatalog); }

function spotifyCatalogArtistEntity(raw = {}) {
  const image = Array.isArray(raw?.images) ? raw.images.find(item => item?.url)?.url || '' : '';
  return {
    kind:'artist', id:String(raw?.id || ''), name:String(raw?.name || ''), image:enhanceArtworkUrl(image || 'assets/placeholder.svg'),
    spotifyUrl:String(raw?.external_urls?.spotify || ''), uri:String(raw?.uri || ''), followers:Number(raw?.followers?.total || 0),
    genres:Array.isArray(raw?.genres) ? raw.genres.filter(Boolean) : [], popularity:Number(raw?.popularity || 0)
  };
}

function spotifyCatalogAlbumEntity(raw = {}) {
  const artistObjects = Array.isArray(raw?.artists) ? raw.artists.filter(Boolean) : [];
  const artists = artistObjects.map(item => item?.name).filter(Boolean);
  const artistIds = artistObjects.map(item => item?.id).filter(Boolean);
  const artistUrls = artistObjects.map(item => item?.external_urls?.spotify || (item?.id ? `https://open.spotify.com/artist/${item.id}` : '')).filter(Boolean);
  const cover = Array.isArray(raw?.images) ? raw.images.find(item => item?.url)?.url || '' : '';
  return {
    kind:'album', id:String(raw?.id || ''), name:String(raw?.name || ''), artists, artistIds, artistUrls, artist:artists.join(', '), cover:enhanceArtworkUrl(cover || 'assets/placeholder.svg'),
    spotifyUrl:String(raw?.external_urls?.spotify || ''), uri:String(raw?.uri || ''), albumType:String(raw?.album_type || raw?.type || 'album'),
    releaseDate:String(raw?.release_date || ''), releasePrecision:String(raw?.release_date_precision || ''), totalTracks:Number(raw?.total_tracks || 0)
  };
}

function spotifyCatalogPlaylistEntity(raw = {}) {
  const cover = Array.isArray(raw?.images) ? raw.images.find(item => item?.url)?.url || '' : '';
  return {
    kind:'playlist', id:String(raw?.id || ''), name:String(raw?.name || ''), owner:String(raw?.owner?.display_name || raw?.owner?.id || 'Spotify'),
    cover:enhanceArtworkUrl(cover || 'assets/placeholder.svg'), description:String(raw?.description || ''), spotifyUrl:String(raw?.external_urls?.spotify || ''),
    totalTracks:Number(raw?.items?.total ?? raw?.tracks?.total ?? 0)
  };
}

function spotifyCatalogTrackEntity(raw = {}) {
  const track = normalizeSpotifyTrack(raw);
  const isrc = String(raw?.external_ids?.isrc || '');
  const albumCover = raw?.album?.images?.find?.(item => item?.url)?.url || track.thumbnail;
  return normalizeTrack({
    ...track,
    thumbnail: enhanceArtworkUrl(albumCover || track.thumbnail),
    explicit:Boolean(raw?.explicit),
    isrc,
    spotifyTrackId:String(raw?.id || track.id || ''),
    spotifyAlbumId:String(raw?.album?.id || ''),
    spotifyAlbumUrl:String(raw?.album?.external_urls?.spotify || ''),
    spotifyMetadata:{ id:String(raw?.id || ''), isrc, explicit:Boolean(raw?.explicit), albumId:String(raw?.album?.id || ''), albumUrl:String(raw?.album?.external_urls?.spotify || '') },
    source:'Spotify Web API metadata'
  });
}

function trackVersionFingerprint(title = '') {
  const text = normalizeMatchText(title);
  const tags = ['remix','live','instrumental','acoustic','sped up','slowed','karaoke','radio edit','demo','remaster','version'];
  return tags.filter(tag => text.includes(tag)).sort().join('|');
}
function primaryArtistNormalized(track = {}) { return normalizeMatchText(extractArtistNames(track.artistNames, track.artist)[0] || primaryArtistName(track) || track.artist || ''); }
function trackDurationMsValue(track = {}) { return Math.max(0, Math.round((Number(track?.duration_ms || track?.durationMs || 0) || durationSeconds(track?.duration) * 1000))); }
function spotifyIsrc(track = {}) { return String(track?.isrc || track?.spotifyMetadata?.isrc || track?.external_ids?.isrc || '').toUpperCase(); }

function safeSameTrack(a = {}, b = {}) {
  const signature = item => ({ title:cleanTitle(item), primaryArtist:extractArtistNames(item.artistNames,item.artist)[0] || primaryArtistName(item) || item.artist || '', durationMs:trackDurationMsValue(item), isrc:spotifyIsrc(item), spotifyTrackId:spotifyTrackIdFromTrack(item) });
  if (window.DatzonEntityMerger?.sameTrack) return window.DatzonEntityMerger.sameTrack(signature(a), signature(b));
  const isrcA = spotifyIsrc(a), isrcB = spotifyIsrc(b);
  if (isrcA && isrcB) return isrcA === isrcB;
  const idA = spotifyTrackIdFromTrack(a), idB = spotifyTrackIdFromTrack(b);
  if (idA && idB) return idA === idB;
  return normalizeMatchText(cleanTitle(a)) === normalizeMatchText(cleanTitle(b)) && primaryArtistNormalized(a) === primaryArtistNormalized(b) && trackVersionFingerprint(cleanTitle(a)) === trackVersionFingerprint(cleanTitle(b));
}

function enrichExistingTrackWithSpotify(existing, spotifyTrack) {
  const base=normalizeTrack(existing), meta=normalizeTrack(spotifyTrack);
  return normalizeTrack({
    ...base,
    id: base.id || meta.id,
    url: spotifyTrackUrl(base) || spotifyTrackUrl(meta) || base.url,
    thumbnail: trackHasRealCover(base) ? base.thumbnail : meta.thumbnail,
    duration: durationSeconds(base.duration)>5 ? base.duration : meta.duration,
    album: base.album || meta.album,
    artistIds: extractSpotifyArtistIds(base.artistIds, meta.artistIds),
    artistUrls: extractSpotifyArtistUrls(base.artistUrls, meta.artistUrls),
    artistDetails: base.artistDetails?.length ? base.artistDetails : meta.artistDetails,
    isrc: spotifyIsrc(base) || spotifyIsrc(meta),
    explicit: base.explicit ?? meta.explicit,
    spotifyTrackId: spotifyTrackIdFromTrack(meta) || base.spotifyTrackId || '',
    spotifyAlbumId: base.spotifyAlbumId || meta.spotifyAlbumId || '',
    spotifyMetadata: { ...(meta.spotifyMetadata || {}), ...(base.spotifyMetadata || {}) },
    source: base.source || 'Provider DATZON'
  });
}

function mergeExistingAndSpotifyTracks(existing = [], spotifyItems = []) {
  const result=(existing || []).map(normalizeTrack);
  for(const raw of spotifyItems || []){
    const meta=spotifyCatalogTrackEntity(raw);
    const index=result.findIndex(item=>safeSameTrack(item,meta));
    if(index>=0) result[index]=enrichExistingTrackWithSpotify(result[index],meta);
    else result.push(meta);
  }
  return dedupeTracks(result).slice(0,80);
}

function stableMixedSearchFeed(tracks = [], artists = [], albums = [], playlists = []) {
  if (window.DatzonSearchAggregator?.stableInterleave) return window.DatzonSearchAggregator.stableInterleave(tracks, artists, albums, playlists);
  return tracks.map(track => ({ kind:'track', data:track }));
}

async function runUniversalSearch(query, options = {}) {
  const clean=String(query||'').trim(); if(!clean)return {tracks:[],artists:[],albums:[],playlists:[],feed:[]};
  const offset=Math.max(0,Number(options.offset||0));
  const [existingResult,spotifyResult]=await Promise.allSettled([
    offset===0 ? searchSpotify(clean,{force:Boolean(options.force)}) : Promise.resolve([]),
    spotifyCatalogAvailable() ? window.DatzonSpotifyCatalog.search(clean,{offset,limit:10,force:Boolean(options.force)}) : Promise.reject(new Error('Spotify catalog unavailable'))
  ]);
  const existing=existingResult.status==='fulfilled'?existingResult.value:[];
  const spotify=spotifyResult.status==='fulfilled'?spotifyResult.value:null;
  const spotifyTracks=Array.isArray(spotify?.tracks?.items)?spotify.tracks.items:[];
  const tracks=mergeExistingAndSpotifyTracks(existing,spotifyTracks);
  if(!tracks.length && !spotify) throw (existingResult.reason || spotifyResult.reason || new Error('Pencarian sedang tidak tersedia'));
  const unique=(items,keyFn)=>{const seen=new Set();return items.filter(item=>{const key=keyFn(item);if(!key||seen.has(key))return false;seen.add(key);return true;});};
  const artists=unique((spotify?.artists?.items||[]).map(spotifyCatalogArtistEntity).filter(item=>item.id&&item.name),item=>item.id);
  const albums=unique((spotify?.albums?.items||[]).map(spotifyCatalogAlbumEntity).filter(item=>item.id&&item.name),item=>item.id);
  const playlists=unique((spotify?.playlists?.items||[]).filter(Boolean).map(spotifyCatalogPlaylistEntity).filter(item=>item.id&&item.name),item=>item.id);
  return {tracks,artists,albums,playlists,feed:stableMixedSearchFeed(tracks,artists,albums,playlists),spotifyAvailable:Boolean(spotify),hasMore:Boolean(spotify?.tracks?.next||spotify?.artists?.next||spotify?.albums?.next||spotify?.playlists?.next)};
}

function normalizeSpotifyArtistRelease(album = {}) {
  const entity=spotifyCatalogAlbumEntity(album);
  return { id:entity.id,title:entity.name,date:entity.releaseDate,type:entity.albumType==='single'?'Single':entity.albumType==='compilation'?'Compilation':'Album',cover:entity.cover,spotifyUrl:entity.spotifyUrl };
}

async function fetchSpotifyCatalogArtistProfile(name, seedTrack = null, force = false) {
  if(!spotifyCatalogAvailable()) return null;
  const credits=artistCreditEntries(seedTrack||{});
  const wanted=normalizeMatchText(name);
  const credit=credits.find(item=>normalizeMatchText(item.name)===wanted);
  const lookup=credit?.id || name;
  try{
    const payload=await window.DatzonSpotifyCatalog.artist(lookup,{force});
    const artist=payload?.artist; if(!artist?.id)return null;
    if(!credit?.id && normalizeMatchText(artist.name)!==wanted) return null;
    return {
      entity:spotifyCatalogArtistEntity(artist),
      releases:(payload?.albums||[]).map(normalizeSpotifyArtistRelease)
    };
  }catch{return null;}
}

async function enrichArtistTracksWithSpotify(tracks = [], max = 12) {
  if(!spotifyCatalogAvailable()) return dedupeTracks(tracks);
  const input=dedupeTracks(tracks).slice(0,Math.max(1,max));
  const settled=await Promise.allSettled(input.map(async track=>{
    const id=spotifyTrackIdFromTrack(track);
    if(!id)return track;
    try{const payload=await window.DatzonSpotifyCatalog.track(id);return payload?.track?enrichExistingTrackWithSpotify(track,spotifyCatalogTrackEntity(payload.track)):track;}catch{return track;}
  }));
  return settled.map((item,index)=>item.status==='fulfilled'?item.value:input[index]).filter(Boolean);
}

function spotifyCatalogAlbumPayload(album = {}) {
  const entity=spotifyCatalogAlbumEntity(album);
  const albumArtists=Array.isArray(album?.artists)?album.artists.map(a=>a?.name).filter(Boolean):entity.artists;
  const tracks=(album?.tracks?.items||[]).map(item=>({
    id:String(item?.id||''),uri:String(item?.uri||''),title:String(item?.name||''),artists:(item?.artists||[]).map(a=>a?.name).filter(Boolean),artistText:(item?.artists||[]).map(a=>a?.name).filter(Boolean).join(', '),
    album:entity.name,cover:entity.cover,durationMs:Number(item?.duration_ms||0),spotifyUrl:String(item?.external_urls?.spotify|| (item?.id?`https://open.spotify.com/track/${item.id}`:'')),exact:true,explicit:Boolean(item?.explicit),discNumber:Number(item?.disc_number||1),trackNumber:Number(item?.track_number||0),isrc:String(item?.external_ids?.isrc||'')
  }));
  return {ok:true,source:'spotify-catalog',collection:{type:'album',id:entity.id,name:entity.name,description:'',owner:albumArtists.join(', '),artist:albumArtists.join(', '),artists:albumArtists,artistIds:entity.artistIds||[],artistUrls:entity.artistUrls||[],cover:entity.cover,spotifyUrl:entity.spotifyUrl,totalTracks:Number(album?.total_tracks||tracks.length),durationMs:tracks.reduce((s,t)=>s+Number(t.durationMs||0),0),releaseDate:entity.releaseDate,albumType:entity.albumType,upc:String(album?.external_ids?.upc||''),copyrights:Array.isArray(album?.copyrights)?album.copyrights:[]},tracks};
}

function mergeSpotifyPlaylistMetadata(payload, spotify = {}) {
  if(!payload?.collection)return payload;
  const meta=spotifyCatalogPlaylistEntity(spotify);
  return {...payload,collection:{...payload.collection,name:meta.name||payload.collection.name,description:meta.description||payload.collection.description,owner:meta.owner||payload.collection.owner,cover:meta.cover&&!meta.cover.includes('placeholder.svg')?meta.cover:payload.collection.cover,spotifyUrl:meta.spotifyUrl||payload.collection.spotifyUrl,totalTracks:meta.totalTracks||payload.collection.totalTracks,followers:Number(spotify?.followers?.total||payload.collection.followers||0)}};
}

function playlistTrackNeedsSpotifyEnrichment(track = {}, collection = {}) {
  if (!track?.title || !(track?.artistText || track?.artists?.length)) return false;
  const hasExactId = /^[A-Za-z0-9]{22}$/.test(String(track?.id || ''));
  const cover = String(track?.cover || '');
  const collectionCover = String(collection?.cover || '');
  const hasSpecificCover = Boolean(cover && !cover.includes('placeholder.svg') && (!collectionCover || cover !== collectionCover) && track?.coverSource === 'track');
  return !hasExactId || !hasSpecificCover || !Number(track?.durationMs || 0) || !track?.album || !track?.isrc;
}

function spotifyMatchedTrackToPlaylistDetail(raw = {}, existing = {}, collection = {}) {
  if (!raw?.id || !raw?.name) return existing;
  const artists = Array.isArray(raw?.artists) ? raw.artists.map(item => item?.name).filter(Boolean) : [];
  const albumCover = raw?.album?.images?.find?.(item => item?.url)?.url || '';
  const existingCover = String(existing?.cover || '');
  const collectionCover = String(collection?.cover || '');
  const existingSpecificCover = Boolean(existingCover && !existingCover.includes('placeholder.svg') && (!collectionCover || existingCover !== collectionCover) && existing?.coverSource === 'track');
  return {
    ...existing,
    id:String(raw.id),
    uri:String(raw.uri || `spotify:track:${raw.id}`),
    title:String(existing?.title || raw.name),
    artists:Array.isArray(existing?.artists) && existing.artists.length ? existing.artists : artists,
    artistText:String(existing?.artistText || (artists.join(', ') || 'Spotify')),
    album:String(existing?.album || raw?.album?.name || ''),
    cover:existingSpecificCover ? existingCover : enhanceArtworkUrl(albumCover || existingCover || collectionCover || 'assets/placeholder.svg'),
    coverSource:existingSpecificCover ? existing?.coverSource : (albumCover ? 'spotify-album' : existing?.coverSource || 'collection-fallback'),
    durationMs:Number(existing?.durationMs || raw?.duration_ms || 0),
    spotifyUrl:String(raw?.external_urls?.spotify || `https://open.spotify.com/track/${raw.id}`),
    exact:true,
    metadataUnavailable:false,
    explicit:existing?.explicit ?? Boolean(raw?.explicit),
    isrc:String(existing?.isrc || raw?.external_ids?.isrc || ''),
    spotifyAlbumId:String(raw?.album?.id || ''),
    spotifyAlbumUrl:String(raw?.album?.external_urls?.spotify || '')
  };
}

async function enrichResolvedPlaylistTracksWithSpotify(payload) {
  if (!payload?.collection || !Array.isArray(payload?.tracks) || !payload.tracks.length || !spotifyCatalogAvailable() || !window.DatzonSpotifyCatalog?.enrichTracks) return payload;
  const candidates = payload.tracks
    .map((track, index) => ({ track, index }))
    .filter(({ track }) => playlistTrackNeedsSpotifyEnrichment(track, payload.collection))
    .slice(0, 80);
  if (!candidates.length) return payload;
  try {
    const requestItems = candidates.map(({ track }) => ({
      title:String(track?.title || ''),
      artists:Array.isArray(track?.artists) ? track.artists : String(track?.artistText || '').split(/,|&/).map(value=>value.trim()).filter(Boolean),
      primaryArtist:Array.isArray(track?.artists) && track.artists.length ? track.artists[0] : String(track?.artistText || '').split(/,|&/)[0].trim(),
      durationMs:Number(track?.durationMs || 0),
      isrc:String(track?.isrc || ''),
      spotifyTrackId:/^[A-Za-z0-9]{22}$/.test(String(track?.id || '')) ? String(track.id) : ''
    }));
    const result = await window.DatzonSpotifyCatalog.enrichTracks(requestItems);
    const matches = Array.isArray(result?.matches) ? result.matches : [];
    if (!matches.length) return payload;
    const tracks = [...payload.tracks];
    candidates.forEach(({ track, index }, position) => {
      const match = matches[position];
      if (match?.id) tracks[index] = spotifyMatchedTrackToPlaylistDetail(match, track, payload.collection);
    });
    return { ...payload, tracks };
  } catch {
    return payload;
  }
}


async function fetchWikipediaArtistSummary(name) {
  const url = new URL(CONFIG.wikipediaApiBase);
  url.search = new URLSearchParams({
    action: 'query',
    generator: 'search',
    gsrsearch: `${name} penyanyi musik`,
    gsrlimit: '1',
    prop: 'extracts|pageimages|info',
    exintro: '1',
    explaintext: '1',
    inprop: 'url',
    piprop: 'thumbnail',
    pithumbsize: '900',
    origin: '*',
    format: 'json'
  }).toString();
  const data = await fetchJson(url, 18000);
  const page = Object.values(data?.query?.pages || {})[0];
  if (!page) return null;
  return {
    description: String(page.extract || '').trim(),
    image: page?.thumbnail?.source || '',
    url: page?.fullurl || ''
  };
}

async function spotifySearchArtist(name) {
  const data = await spotifyApiFetch('/search', { q: `artist:\"${name}\"`, type: 'artist', market: 'ID', limit: 10 });
  const items = Array.isArray(data?.artists?.items) ? data.artists.items : [];
  return items.find(item => String(item?.name || '').localeCompare(String(name || ''), 'id', { sensitivity: 'base' }) === 0) || items[0] || null;
}

async function spotifyArtistTracks(artist) {
  const collected = [];
  for (let offset = 0; offset < 50; offset += 10) {
    const page = await spotifyApiFetch('/search', { q: `artist:\"${artist.name}\"`, type: 'track', market: 'ID', limit: 10, offset });
    const items = Array.isArray(page?.tracks?.items) ? page.tracks.items : [];
    const exact = items.filter(track => (track?.artists || []).some(item => item?.id === artist.id));
    collected.push(...exact.map(normalizeSpotifyTrack));
    if (!page?.tracks?.next || items.length < 10) break;
  }
  return dedupeTracks(collected).slice(0, 50);
}

async function spotifyArtistAlbums(artistId) {
  const collected = [];
  let offset = 0;
  while (offset < 50) {
    const page = await spotifyApiFetch(`/artists/${encodeURIComponent(artistId)}/albums`, {
      include_groups: 'album,single', market: 'ID', limit: 20, offset
    });
    const items = Array.isArray(page?.items) ? page.items : [];
    collected.push(...items);
    if (!page?.next || items.length < 20) break;
    offset += items.length;
  }
  const seen = new Set();
  return collected.filter(album => {
    const key = `${album?.name || ''}|${album?.release_date || ''}`.toLocaleLowerCase('id');
    if (!album?.name || seen.has(key)) return false;
    seen.add(key);
    return true;
  }).slice(0, 40).map(album => ({
    id: album.id || '',
    title: album.name,
    date: album.release_date || '',
    type: album.album_type === 'single' ? 'Single' : 'Album',
    cover: album?.images?.[0]?.url || 'assets/placeholder.svg',
    spotifyUrl: album?.external_urls?.spotify || ''
  }));
}

async function loadSpotifyArtistProfile(name, force = false) {
  if (!spotifyHasSession()) throw new Error('SPOTIFY_AUTH_REQUIRED');
  const key = artistCacheKey(name);
  const cached = state.spotifyArtistProfiles[key];
  const cachedAt = Number(state.spotifyArtistProfilesAt[key] || 0);
  if (!force && cached && Date.now() - cachedAt < CONFIG.spotifyArtistCacheMs) return cached;
  const artist = await spotifySearchArtist(name);
  if (!artist?.id) throw new Error('Artis tidak ditemukan di Spotify');
  const [tracksResult, albumsResult, wikiResult] = await Promise.allSettled([
    spotifyArtistTracks(artist),
    spotifyArtistAlbums(artist.id),
    fetchWikipediaArtistSummary(artist.name)
  ]);
  const wiki = wikiResult.status === 'fulfilled' ? wikiResult.value : null;
  const profile = {
    name: artist.name || name,
    spotifyId: artist.id,
    image: artist?.images?.[0]?.url || wiki?.image || '',
    genres: Array.isArray(artist?.genres) ? artist.genres : [],
    followers: Number(artist?.followers?.total || 0),
    popularity: Number(artist?.popularity || 0),
    spotifyUrl: artist?.external_urls?.spotify || `https://open.spotify.com/artist/${artist.id}`,
    description: wiki?.description || '',
    descriptionUrl: wiki?.url || '',
    tracks: tracksResult.status === 'fulfilled' ? tracksResult.value : [],
    releases: albumsResult.status === 'fulfilled' ? albumsResult.value : [],
    source: 'Spotify Web API'
  };
  state.spotifyArtistProfiles[key] = profile;
  state.spotifyArtistProfilesAt[key] = Date.now();
  persist();
  return profile;
}

async function fetchAnabotArtistProfile(artistId, force = false) {
  const id = String(artistId || '').trim();
  if (!CONFIG.anabotEnabled || !/^[A-Za-z0-9]{22}$/.test(id)) return null;
  const cached = anabotArtistCache.get(id);
  if (!force && cached && Date.now() - cached.at < ANABOT_CACHE_MS) return cached.value;
  const data = await externalApiFetch(
    CONFIG.anabotApiBase,
    CONFIG.anabotArtistPath,
    { id, apikey: CONFIG.anabotApiKey },
    22000,
    'Anabot Spotify Artist'
  );
  const result = data?.result || data?.data || null;
  if (!result?.id) return null;
  const profile = {
    id: result.id,
    name: result.name || '',
    followers: Number(result.followers || 0),
    monthlyListeners: Number(result.monthly_listeners || result.monthlyListeners || 0),
    verified: result.verified === true,
    genres: Array.isArray(result.genres) ? result.genres : [],
    uri: result.uri || `spotify:artist:${result.id}`
  };
  anabotArtistCache.set(id, { at: Date.now(), value: profile });
  return profile;
}

async function resolveArtistSpotifyId(name, seedTrack = null, spotifyProfile = null, publicProfile = null) {
  const direct = extractSpotifyArtistIds(
    spotifyProfile?.spotifyId,
    seedTrack?.artistId,
    seedTrack?.artistIds,
    seedTrack?.spotifyArtistId,
    seedTrack?.artists
  )[0];
  if (direct) return direct;
  if (publicProfile?.mbid) {
    try {
      await new Promise(resolve => setTimeout(resolve, 1050));
      const musicBrainzSpotifyId = await fetchMusicBrainzSpotifyArtistId(publicProfile.mbid);
      if (musicBrainzSpotifyId) return musicBrainzSpotifyId;
    } catch { /* Lanjut ke hasil pencarian lagu. */ }
  }
  try {
    const wanted = normalizeMatchText(name);
    const candidates = await searchSpotify(name);
    const exact = candidates.find(track => artistParts(track.artist).some(artist => artist === wanted))
      || candidates.find(track => normalizeMatchText(track.artist).includes(wanted))
      || candidates[0];
    return extractSpotifyArtistIds(exact?.artistId, exact?.artistIds)[0] || '';
  } catch {
    return '';
  }
}

async function loadCombinedArtistProfile(name, seedTrack = null, force = false) {
  const artistName=String(name||'').trim();
  const soft=async(promise,timeout=6500)=>{let timer;try{return await Promise.race([Promise.resolve(promise),new Promise(resolve=>{timer=setTimeout(()=>resolve(null),timeout);})]);}catch{return null;}finally{if(timer)clearTimeout(timer);}};

  // Spotify Client Credentials adalah source-of-truth untuk identitas artist + image + discography.
  const spotifyCatalog=await soft(fetchSpotifyCatalogArtistProfile(artistName,seedTrack,force),11000);
  const spotifyEntity=spotifyCatalog?.entity||null;
  const exactSeed=spotifyEntity ? normalizeTrack({
    ...(seedTrack||{}), artist:spotifyEntity.name, artistNames:[spotifyEntity.name], artistId:spotifyEntity.id, artistIds:[spotifyEntity.id],
    artistUrls:[spotifyEntity.spotifyUrl], artistDetails:[{name:spotifyEntity.name,id:spotifyEntity.id,url:spotifyEntity.spotifyUrl}],
    artists_detail:[{name:spotifyEntity.name,id:spotifyEntity.id,external_url:spotifyEntity.spotifyUrl}]
  }) : seedTrack;

  const [sylvaticaProfile, publicProfile, wiki, anabotProfile] = await Promise.all([
    soft(fetchSylvaticaSpotyloaderArtistProfile(spotifyEntity?.name||artistName, exactSeed, force), 18000),
    soft(loadArtistProfile(spotifyEntity?.name||artistName, force), 8500),
    soft(fetchWikipediaArtistSummary(spotifyEntity?.name||artistName), 6000),
    spotifyEntity?.id ? soft(fetchAnabotArtistProfile(spotifyEntity.id, force), 7500) : Promise.resolve(null)
  ]);

  let tracks=dedupeTracks([
    ...(sylvaticaProfile?.tracks||[]),
    ...(publicProfile?.tracks||[]),
    ...(seedTrack?[seedTrack]:[])
  ]).slice(0,30);
  tracks=await soft(enrichArtistTracksWithSpotify(tracks,14),12000) || tracks;

  const releases=(spotifyCatalog?.releases?.length ? spotifyCatalog.releases : (publicProfile?.releases||[])).slice(0,50);
  const image=spotifyEntity?.image && !spotifyEntity.image.includes('placeholder.svg')
    ? spotifyEntity.image
    : (sylvaticaProfile?.image || wiki?.image || 'assets/placeholder.svg');

  return {
    name: spotifyEntity?.name || sylvaticaProfile?.name || publicProfile?.name || artistName,
    image,
    description: wiki?.description || publicProfile?.disambiguation || '',
    descriptionUrl: wiki?.url || '',
    details: [...new Set([...(spotifyEntity?.genres||[]), ...(anabotProfile?.genres||[]), publicProfile?.type, publicProfile?.country, publicProfile?.genre].filter(Boolean))],
    followers: Number(spotifyEntity?.followers || anabotProfile?.followers || 0),
    monthlyListeners: Number(anabotProfile?.monthlyListeners || 0),
    verified: Boolean(anabotProfile?.verified),
    popularity: Number(spotifyEntity?.popularity || 0),
    spotifyId: spotifyEntity?.id || sylvaticaProfile?.spotifyId || '',
    spotifyUrl: spotifyEntity?.spotifyUrl || sylvaticaProfile?.spotifyUrl || '',
    spotifyConnected: false,
    tracks,
    releases,
    source: ['Spotify Catalog', sylvaticaProfile?'Sylvatica Spotyloader':'', anabotProfile?'Anabot':'', publicProfile?.source, wiki?'Wikipedia':''].filter(Boolean).join(' + ')
  };
}

function fillHomeTracks(primary, fallback, count = 10) {
  const result = dedupeTracks([...(primary || []), ...(fallback || [])]);
  return result.slice(0, Math.max(1, count));
}


function spotlightSeedTrack(seed) {
  return normalizeTrack({
    title: seed.title,
    artist: seed.artist,
    duration: '0:00',
    thumbnail: seed.thumbnail || 'assets/placeholder.svg',
    album: '',
    release_date: '',
    url: seed.spotifyUrl || '',
    id: String(seed.spotifyUrl || '').match(/open\.spotify\.com\/track\/([A-Za-z0-9]{22})/i)?.[1] || '',
    source: seed.spotifyUrl ? 'Spotify Spotlight DATZON' : 'Pilihan Spotlight DATZON'
  });
}

function spotlightCandidateScore(track, seed) {
  const title = normalizeMatchText(cleanTitle(track));
  const artist = normalizeMatchText(track.artist);
  const wantedTitle = normalizeMatchText(seed.title);
  const wantedArtist = normalizeMatchText(seed.artist);
  let score = 0;
  if (title === wantedTitle) score += 120;
  else if (title.includes(wantedTitle) || wantedTitle.includes(title)) score += 75;
  const wantedArtistTokens = wantedArtist.split(/\s+/).filter(token => token.length > 2);
  score += wantedArtistTokens.filter(token => artist.includes(token)).length * 14;
  if (artist === wantedArtist) score += 55;
  if (track.thumbnail && !String(track.thumbnail).includes('placeholder.svg')) score += 8;
  return score;
}

async function loadHomeSpotlight(force = false) {
  const cacheMs = 1000 * 60 * 60 * 12;
  if (!force && state.homeSpotlight.length === HOME_SPOTLIGHT_SEEDS.length && Date.now() - state.homeSpotlightAt < cacheMs) return state.homeSpotlight;
  const results = await Promise.allSettled(HOME_SPOTLIGHT_SEEDS.map(seed => fetchItunesTracks(seed.search, 12, false)));
  state.homeSpotlight = HOME_SPOTLIGHT_SEEDS.map((seed, index) => {
    const candidates = results[index]?.status === 'fulfilled' ? results[index].value : [];
    const ranked = [...candidates].sort((a, b) => spotlightCandidateScore(b, seed) - spotlightCandidateScore(a, seed));
    const candidate = ranked[0];
    const seedTrack = spotlightSeedTrack(seed);
    if (!candidate || spotlightCandidateScore(candidate, seed) < 30) return seedTrack;
    const candidateArtwork = String(candidate.thumbnail || '');
    const shouldUseSeedArtwork = Boolean(seed.thumbnail) && (!candidateArtwork || candidateArtwork.includes('placeholder.svg'));
    return normalizeTrack({
      ...candidate,
      title: seed.title,
      artist: seed.artist,
      url: seed.spotifyUrl || candidate.url,
      id: seedTrack.id || candidate.id,
      thumbnail: enhanceArtworkUrl(shouldUseSeedArtwork ? seed.thumbnail : candidate.thumbnail),
      source: seed.spotifyUrl ? 'Spotify + metadata publik untuk Spotlight DATZON' : 'Metadata publik untuk Spotlight DATZON'
    });
  });
  state.homeSpotlightAt = Date.now();
  state.spotlightIndex %= Math.max(1, state.homeSpotlight.length);
  storage.set('homeSpotlight', state.homeSpotlight);
  storage.set('homeSpotlightAt', state.homeSpotlightAt);
  return state.homeSpotlight;
}

function spotlightTracksForHome() {
  const cached = Array.isArray(state.homeSpotlight) ? state.homeSpotlight : [];
  return HOME_SPOTLIGHT_SEEDS.map((seed, index) => {
    const seedTrack = spotlightSeedTrack(seed);
    const cachedTrack = cached[index];
    if (!cachedTrack) return seedTrack;
    const cachedArtwork = String(cachedTrack.thumbnail || '');
    const staleArtwork = !cachedArtwork || cachedArtwork.includes('placeholder.svg');
    return normalizeTrack({
      ...cachedTrack,
      title: seed.title,
      artist: seed.artist,
      url: seed.spotifyUrl || cachedTrack.url || seedTrack.url,
      id: seedTrack.id || cachedTrack.id,
      thumbnail: staleArtwork && seed.thumbnail ? seed.thumbnail : cachedTrack.thumbnail
    });
  });
}

function homeSpotlightMarkup(tracks, registerTrack) {
  const slides = tracks.map((track, index) => {
    const active = Boolean(state.current && sameTrackIdentity(track, state.current));
    const playing = Boolean(active && state.isPlaying);
    return `<article class="home-featured-slide" data-featured-slide="${index}">
      <img src="${esc(enhanceArtworkUrl(track.thumbnail))}" alt="${esc(cleanTitle(track))}" decoding="async" onerror="this.src='assets/placeholder.svg'">
      <div class="home-featured-shade"></div>
      <div class="home-featured-copy"><strong>${esc(cleanTitle(track))}</strong><span>${esc(track.artist)}</span></div>
      <button class="home-featured-play ${active?'is-current':''} ${playing?'is-playing':''}" data-home-featured-play="${registerTrack(track)}" data-playback-track-id="${esc(trackFirebaseId(track)||trackKey(track))}" data-playback-label="${esc(cleanTitle(track))}" aria-label="${playing?'Jeda':active?'Lanjutkan':'Putar'} ${esc(cleanTitle(track))}">${icon(playing?'pause':'play',playing?'':'fill')}</button>
    </article>`;
  }).join('');
  return `<section class="home-featured" data-home-featured>
    <div class="home-featured-heading"><span>${icon('spotlight')}</span><h2>Spotlight</h2></div>
    <div class="home-featured-viewport" data-featured-viewport><div class="home-featured-track" data-featured-track>${slides}</div></div>
    <div class="home-featured-dots">${tracks.map((_, index) => `<button class="${index === state.spotlightIndex ? 'active' : ''}" data-featured-dot="${index}" aria-label="Tampilkan lagu ${index + 1}"></button>`).join('')}</div>
  </section>`;
}

function setHomeSpotlightIndex(index, animate = true) {
  const tracks = spotlightTracksForHome();
  if (!tracks.length) return;
  state.spotlightIndex = ((Number(index) || 0) % tracks.length + tracks.length) % tracks.length;
  storage.set('spotlightIndex', state.spotlightIndex);
  const rail = $('[data-featured-track]', view);
  if (rail) {
    if (!animate) rail.style.transition = 'none';
    rail.style.transform = `translate3d(-${state.spotlightIndex * 100}%,0,0)`;
    if (!animate) requestAnimationFrame(() => rail.style.removeProperty('transition'));
  }
  $$('[data-featured-dot]', view).forEach(dot => dot.classList.toggle('active', Number(dot.dataset.featuredDot) === state.spotlightIndex));
}

function startHomeSpotlightCarousel(delay = 5200) {
  clearInterval(homeSpotlightTimer);
  homeSpotlightTimer = null;
  if (state.route !== 'home' || state.settings.reduceMotion) return;
  setHomeSpotlightIndex(state.spotlightIndex, false);
  homeSpotlightTimer = window.setInterval(() => {
    if (state.route !== 'home' || document.hidden || modalRoot.children.length || Date.now() < state.spotlightManualUntil) return;
    setHomeSpotlightIndex(state.spotlightIndex + 1, true);
  }, Math.max(2600, Number(delay) || 5200));
}

function bindHomeSpotlightGestures() {
  const viewport = $('[data-featured-viewport]', view);
  const rail = $('[data-featured-track]', view);
  if (!viewport || !rail) return;

  let pointerId = null;
  let startX = 0;
  let startY = 0;
  let deltaX = 0;
  let horizontal = false;
  let startedAt = 0;

  const baseOffset = () => -state.spotlightIndex * Math.max(1, viewport.clientWidth);
  const restoreAuto = () => {
    state.spotlightManualUntil = Date.now() + 4200;
    window.setTimeout(() => {
      if (state.route === 'home') startHomeSpotlightCarousel();
    }, 250);
  };

  viewport.addEventListener('pointerdown', event => {
    if (event.pointerType === 'mouse' && event.button !== 0) return;
    if (event.target.closest('button')) return;
    pointerId = event.pointerId;
    startX = event.clientX;
    startY = event.clientY;
    deltaX = 0;
    horizontal = false;
    startedAt = performance.now();
    clearInterval(homeSpotlightTimer);
    homeSpotlightTimer = null;
    try { viewport.setPointerCapture(pointerId); } catch {}
  });

  viewport.addEventListener('pointermove', event => {
    if (pointerId !== event.pointerId) return;
    const dx = event.clientX - startX;
    const dy = event.clientY - startY;
    if (!horizontal && Math.abs(dx) > 8 && Math.abs(dx) > Math.abs(dy) * 1.15) horizontal = true;
    if (!horizontal) return;
    deltaX = dx;
    rail.style.transition = 'none';
    rail.style.transform = `translate3d(${baseOffset() + deltaX}px,0,0)`;
    if (event.cancelable) event.preventDefault();
  }, { passive: false });

  const finish = event => {
    if (pointerId !== event.pointerId) return;
    const width = Math.max(1, viewport.clientWidth);
    const elapsed = Math.max(1, performance.now() - startedAt);
    const velocity = Math.abs(deltaX) / elapsed;
    const shouldMove = horizontal && (Math.abs(deltaX) > width * .16 || velocity > .48);
    rail.style.removeProperty('transition');
    if (shouldMove) setHomeSpotlightIndex(state.spotlightIndex + (deltaX < 0 ? 1 : -1), true);
    else setHomeSpotlightIndex(state.spotlightIndex, true);
    try { viewport.releasePointerCapture(pointerId); } catch {}
    pointerId = null;
    deltaX = 0;
    horizontal = false;
    restoreAuto();
  };

  viewport.addEventListener('pointerup', finish);
  viewport.addEventListener('pointercancel', finish);
}

async function fetchAnabotPlaylist(playlistId, force = false) {
  const id = String(playlistId || '').trim();
  if (!CONFIG.anabotEnabled || !id) return null;
  const cached = anabotPlaylistCache.get(id);
  if (!force && cached && Date.now() - cached.at < ANABOT_CACHE_MS) return cached.value;
  const data = await externalApiFetch(
    CONFIG.anabotApiBase,
    CONFIG.anabotPlaylistPath,
    { id, apikey: CONFIG.anabotApiKey },
    26000,
    'Anabot Spotify Playlist'
  );
  const result = data?.result || data?.data || null;
  if (!result?.id || !Array.isArray(result?.tracks)) return null;
  anabotPlaylistCache.set(id, { at: Date.now(), value: result });
  return result;
}

async function enrichAnabotPlaylistTrack(item) {
  const target = normalizeTrack({
    title: item?.name || item?.title || 'Tanpa Judul',
    artist: item?.artist || item?.artists || 'Artis tidak diketahui',
    source: 'Anabot Spotify Playlist'
  });
  const query = `${cleanTitle(target)} ${isUnknownArtist(target.artist) ? '' : target.artist}`.trim();
  if (!query) return null;
  try {
    const candidates = await searchSpotify(query);
    const ranked = candidates
      .map(candidate => ({ candidate, score: primaryTrackMatchScore(candidate, target) }))
      .sort((a, b) => b.score - a.score);
    const best = ranked[0];
    if (!best || best.score < 45) return null;
    return mergePrimaryTrackMetadata(target, best.candidate, { source: `${best.candidate.source || 'Spotify Search'} + Anabot Playlist` });
  } catch {
    return null;
  }
}

async function loadAnabotFeaturedPlaylist(force = false) {
  const cached = state.homeFeaturedPlaylist;
  const fresh = cached?.tracks?.length >= 6 && Date.now() - state.homeFeaturedPlaylistAt < ANABOT_CACHE_MS;
  if (!force && fresh) return cached;
  if (state.homeFeaturedPlaylistLoading) return cached;
  state.homeFeaturedPlaylistLoading = true;
  try {
    const raw = await fetchAnabotPlaylist(CONFIG.anabotFeaturedPlaylistId, force);
    if (!raw) return cached;
    const sourceTracks = raw.tracks.slice(0, 14);
    const enriched = [];
    for (let offset = 0; offset < sourceTracks.length; offset += 3) {
      const batch = sourceTracks.slice(offset, offset + 3);
      const results = await Promise.allSettled(batch.map(enrichAnabotPlaylistTrack));
      results.forEach(result => {
        if (result.status === 'fulfilled' && result.value && spotifyTrackUrl(result.value)) enriched.push(result.value);
      });
      if (enriched.length >= 10) break;
    }
    if (enriched.length) {
      state.homeFeaturedPlaylist = {
        id: raw.id,
        name: raw.name || 'Playlist Spotify',
        owner: raw.owner || '',
        description: raw.description || '',
        totalTracks: Number(raw.total_tracks || raw.totalTracks || raw.tracks.length || 0),
        tracks: dedupeTracks(enriched).slice(0, 12),
        uri: raw.uri || `spotify:playlist:${raw.id}`,
        source: 'Anabot + Sylvatica/Ikyy Spotify Search'
      };
      state.homeFeaturedPlaylistAt = Date.now();
      storage.set('homeFeaturedPlaylistV1400', state.homeFeaturedPlaylist);
      storage.set('homeFeaturedPlaylistAtV1400', state.homeFeaturedPlaylistAt);
    }
  } catch {
    // Playlist lama tetap dipakai jika API atau salah satu provider pencarian sedang bermasalah.
  } finally {
    state.homeFeaturedPlaylistLoading = false;
    if (state.route === 'home' && !state.homeInitialLoading) renderHome();
  }
  return state.homeFeaturedPlaylist;
}

async function loadHomeDiscovery(force = false) {
  const cachedArtistCatalogs = state.homeDiscovery?.artistCatalogs || {};
  const hasArtistCatalogs = Object.values(cachedArtistCatalogs).filter(list => Array.isArray(list) && list.length >= 8).length >= 3;
  const fresh = state.homeDiscovery?.topSongs?.length && hasArtistCatalogs && Date.now() - state.homeDiscoveryAt < CONFIG.discoveryCacheMs;
  if (!force && fresh) return state.homeDiscovery;
  if (state.homeDiscoveryLoading) return state.homeDiscovery;
  state.homeDiscoveryLoading = true;
  try {
    const [songsResult, albumsResult] = await Promise.allSettled([
      fetchAppleFeed(CONFIG.appleTopSongsFeed),
      fetchAppleFeed(CONFIG.appleTopAlbumsFeed)
    ]);
    let topSongs = songsResult.status === 'fulfilled' ? songsResult.value : [];
    let topAlbums = albumsResult.status === 'fulfilled' ? albumsResult.value : [];
    if (!topSongs.length) {
      const fallbackSearches = await Promise.allSettled(['Tulus', 'Hindia', 'Nadin Amizah', 'Pamungkas', 'Mahalini'].map(name => fetchItunesTracks(name, 8)));
      topSongs = dedupeTracks(fallbackSearches.flatMap(entry => entry.status === 'fulfilled' ? entry.value : []));
    }
    if (!topAlbums.length) topAlbums = topSongs.filter((track, index, list) => list.findIndex(item => item.album === track.album && item.artist === track.artist) === index).slice(0, 25);
    const artistPool = [...new Set(topSongs.map(track => track.artist).filter(Boolean))].slice(0, 14);
    const artistCatalogs = { ...(state.homeDiscovery?.artistCatalogs || {}) };
    const artistRequests = artistPool.slice(0, 6).map(async name => {
      const key = artistCacheKey(name);
      if (Array.isArray(artistCatalogs[key]) && artistCatalogs[key].length >= 10) return;
      try { artistCatalogs[key] = (await fetchItunesTracks(name, 24, true)).slice(0, 20); } catch { artistCatalogs[key] = artistCatalogs[key] || []; }
    });
    await Promise.allSettled(artistRequests);
    if (topSongs.length) {
      state.homeDiscovery = { topSongs, topAlbums, artistPool, artistCatalogs };
      state.homeDiscoveryAt = Date.now();
      state.homeDiscoverySource = songsResult.status === 'fulfilled' ? 'Apple Music RSS + iTunes Search API' : 'iTunes Search API';
      storage.set('homeDiscovery', state.homeDiscovery);
      storage.set('homeDiscoveryAt', state.homeDiscoveryAt);
      storage.set('homeDiscoverySource', state.homeDiscoverySource);
    }
  } catch {
    // Katalog CMNTY dan data lokal tetap menjadi fallback utama.
  } finally {
    state.homeDiscoveryLoading = false;
    if (state.route === 'home') renderHome();
  }
  return state.homeDiscovery;
}

async function loadHome(force = false) {
  const fresh = state.catalog.length && Date.now() - state.catalogAt < CONFIG.cacheMs;
  const activityId = beginSystemActivity(
    'Memuat halaman Home',
    force ? 'Menyegarkan rekomendasi dari sumber metadata publik' : 'Menyiapkan lagu, artis, dan sampul HD tanpa memakai kuota pencarian utama',
    'DATZON Home'
  );
  state.homeError = '';
  state.homeInitialLoading = true;
  state.homeReady = false;
  if (state.route === 'home') renderHomeSkeleton();
  void loadAnabotFeaturedPlaylist(force);
  void loadSpotifyHomeCollections(force);
  void loadHomeSylvaticaSimilar(force);

  try {
    const [discovery] = await Promise.all([loadHomeDiscovery(force), loadHomeSpotlight(force)]);
    if (force || !fresh || !state.catalog.length) {
      const publicTracks = dedupeTracks([
        ...(discovery?.topSongs || []),
        ...(discovery?.topAlbums || []),
        ...state.history,
        ...state.favorites,
        ...FALLBACK_TRACKS
      ])
        .filter(homeDisplayTrackReady)
        .sort((a, b) => Number(b.popularity || b.rank || 0) - Number(a.popularity || a.rank || 0));

      if (!publicTracks.length) throw new Error('Daftar lagu publik kosong');
      state.catalog = publicTracks.slice(0, 140);
      state.catalogAt = Date.now();
      state.apiOnline = true;
      storage.set('catalog', state.catalog);
      storage.set('catalogAt', state.catalogAt);
    }

    if (!state.catalog.length) state.catalog = FALLBACK_TRACKS.map(normalizeTrack).filter(homeDisplayTrackReady);
    finishSystemActivity(activityId, 'success', `Home siap dengan ${state.catalog.length} lagu tanpa memakai kuota endpoint CMNTY`);
  } catch (error) {
    state.homeError = 'Sumber rekomendasi publik sedang sulit dihubungi. Katalog tersimpan tetap ditampilkan.';
    if (!state.catalog.length) state.catalog = FALLBACK_TRACKS.map(normalizeTrack).filter(homeDisplayTrackReady);
    finishSystemActivity(activityId, 'warning', error?.message || 'Home memakai katalog tersimpan');
  } finally {
    state.homeInitialLoading = false;
    state.homeReady = true;
    if (state.route === 'home') renderHome();
    renderMiniPlayer();
  }
}

function findMediaUrl(payload) {
  const candidates = [];
  const seen = new Set();
  function walk(value, key = '') {
    if (value == null || seen.has(value)) return;
    if (typeof value === 'object') {
      seen.add(value);
      if (Array.isArray(value)) value.forEach(v => walk(v, key));
      else Object.entries(value).forEach(([k,v]) => walk(v, k));
      return;
    }
    if (typeof value !== 'string' || !/^https?:\/\//i.test(value)) return;
    const lower = value.toLowerCase();
    const keyLower = String(key).toLowerCase();
    if (/\.(jpg|jpeg|png|webp|gif)(\?|$)/i.test(lower) || lower.includes('i.scdn.co') || lower.includes('open.spotify.com')) return;
    if (lower.includes('audio-ssl.itunes.apple.com') || /(?:^|[\/_-])preview(?:[\/_-]|$)/i.test(lower)) return;
    let score = 0;
    if (/\.(mp3|m4a|aac|ogg|wav|flac)(\?|$)/i.test(lower)) score += 100;
    if (/(mp3|audio|download|dl|play|stream|link|url)/i.test(keyLower)) score += 35;
    if (lower.includes('spotidown') || lower.includes('cdn')) score += 15;
    candidates.push({url: value, score});
  }
  walk(payload);
  return candidates.sort((a,b) => b.score - a.score)[0]?.url || '';
}


function spotifyTrackUrl(track) {
  if (/open\.spotify\.com\/track\//i.test(track?.url || '')) return track.url;
  if (/^[A-Za-z0-9]{22}$/.test(track?.id || '')) return `https://open.spotify.com/track/${track.id}`;
  return '';
}

function applyResolvedTrackToState(track, guardTrack = null) {
  const incoming = normalizeTrack(track);
  if (!state.current) return incoming;
  // Jika operasi async dimulai untuk track tertentu, jangan pernah menulis hasilnya
  // ke state setelah user sudah memilih track lain.
  if (guardTrack && !sameTrackIdentity(state.current, guardTrack)) return incoming;
  const currentUrl = spotifyTrackUrl(state.current);
  const incomingUrl = spotifyTrackUrl(incoming);
  const sameTrack = (currentUrl && incomingUrl && currentUrl === incomingUrl)
    || (!currentUrl && !incomingUrl && normalizeMatchText(cleanTitle(state.current)) === normalizeMatchText(cleanTitle(incoming)) && normalizeMatchText(state.current.artist) === normalizeMatchText(incoming.artist));
  if (!sameTrack) return incoming;
  state.current = mergePrimaryTrackMetadata(state.current, incoming, {
    audioUrl: incoming.audioUrl || state.current.audioUrl,
    audioResolvedAt: incoming.audioResolvedAt || state.current.audioResolvedAt,
    metadataResolvedAt: incoming.metadataResolvedAt || state.current.metadataResolvedAt,
    source: incoming.source || state.current.source
  });
  if (state.queue[state.currentIndex]) state.queue[state.currentIndex] = state.current;
  updateMediaSessionMetadata(state.current);
  return state.current;
}

async function resolveCmntySpotifyAudio(spotifyUrl, options = {}) {
  const packageData = await fetchCmntySpotifyPackage(spotifyUrl, options);
  if (!packageData.audioUrl) throw new Error('CMNTY tidak mengirim URL audio');
  return packageData;
}

function parseCmntySpotifyPlayPackage(data, fallbackTrack) {
  const result = data?.result || data?.data || {};
  const audioUrl = result?.play_url || result?.playUrl || result?.audio || result?.download || result?.url || findMediaUrl(result) || findMediaUrl(data);
  const spotifyUrl = result?.spotify_url || result?.spotifyUrl || result?.spotify || spotifyTrackUrl(fallbackTrack);
  const enriched = mergePrimaryTrackMetadata(fallbackTrack, normalizeTrack({
    title: result?.title || result?.name,
    artist: result?.artists || result?.artist,
    album: result?.album,
    duration: result?.duration,
    thumbnail: result?.cover || result?.thumbnail || result?.image,
    url: spotifyUrl,
    source: 'CMNTY Spotify Play'
  }), {
    audioUrl,
    downloadUrl: audioUrl,
    audioResolvedAt: audioUrl ? Date.now() : 0,
    metadataResolvedAt: Date.now(),
    source: 'CMNTY Spotify Play'
  });
  return { raw: data, url: audioUrl, spotifyUrl: spotifyTrackUrl(enriched) || spotifyUrl, track: enriched };
}

async function resolveCmntySpotifyPlayAudio(track, options = {}) {
  if (!CONFIG.cmntyAudioEnabled) {
    const error = new Error('CMNTY Spotify Play dinonaktifkan sementara');
    error.disabledProvider = true;
    error.nonRotatable = true;
    throw error;
  }
  const normalized = normalizeTrack(track);
  const query = `${cleanTitle(normalized)} ${isUnknownArtist(normalized.artist) ? '' : normalized.artist}`.trim();
  if (!query) throw new Error('Judul lagu untuk audio cadangan tidak tersedia');
  const cacheKey = normalizeMatchText(query);
  const force = Boolean(options.force);
  const cached = cmntyPlayCache.get(cacheKey);
  if (!force && cached && Date.now() - cached.at < CMNTY_PLAY_CACHE_MS) return await cached.value;
  const recentFailure = cmntyPlayFailureCache.get(cacheKey);
  if (!force && recentFailure && Date.now() - recentFailure.at < CMNTY_FAILURE_CACHE_MS) throw recentFailure.error;

  const request = (async () => {
    const data = await apiFetch('/downloader/spotify-play', { q: query }, 55000);
    const parsed = parseCmntySpotifyPlayPackage(data, normalized);
    if (!parsed.url) throw new Error('CMNTY Spotify Play tidak mengirim URL audio');
    return parsed;
  })();

  cmntyPlayCache.set(cacheKey, { at: Date.now(), value: request });
  try {
    const value = await request;
    cmntyPlayFailureCache.delete(cacheKey);
    cmntyPlayCache.set(cacheKey, { at: Date.now(), value: Promise.resolve(value) });
    return value;
  } catch (error) {
    cmntyPlayCache.delete(cacheKey);
    cmntyPlayFailureCache.set(cacheKey, { at: Date.now(), error });
    throw error;
  }
}

async function resolveAudio(track, options = {}) {
  let resolvedTrack = sanitizePlaybackTrack(track);
  const force = Boolean(options.force);
  const storedSourceDisabled = !audioSourceEnabled(resolvedTrack.source);
  const freshStoredAudio = !force && !storedSourceDisabled
    && resolvedTrack.audioUrl
    && Number(resolvedTrack.audioResolvedAt || 0) > 0
    && Date.now() - Number(resolvedTrack.audioResolvedAt) < FRESH_AUDIO_URL_MS;
  if (freshStoredAudio && !resolvedTrack.audioIsPreview) return resolvedTrack.audioUrl;

  resolvedTrack = await resolveTrackMetadataWithPrimary(resolvedTrack, { force });
  resolvedTrack = applyResolvedTrackToState(resolvedTrack, options.guardTrack || null);
  const spotifyUrl = spotifyTrackUrl(resolvedTrack);
  const errors = [];

  if (spotifyUrl) {
    try {
      const packageData = await fetchPrimarySpotifyPackage(spotifyUrl, { force });
      resolvedTrack = applyResolvedTrackToState(mergePrimaryTrackMetadata(resolvedTrack, packageData.track, {
        audioUrl: packageData.audioUrl,
        downloadUrl: packageData.audioUrl,
        audioResolvedAt: Date.now(),
        metadataResolvedAt: Date.now(),
        source: packageData.track?.source || activeAudioProviderLabel(),
        syncedLyricsPayload: packageData.syncedLyricsPayload || packageData.track?.syncedLyricsPayload || '',
        lyricsProvider: packageData.track?.lyricsProvider || ''
      }), options.guardTrack || null);
      return packageData.audioUrl;
    } catch (error) {
      errors.push(error?.message || 'Provider Spotify utama gagal');
    }
  }

  if (CONFIG.cmntyAudioEnabled) {
    try {
      const playResult = await resolveCmntySpotifyPlayAudio(resolvedTrack, { force });
      resolvedTrack = applyResolvedTrackToState(playResult.track, options.guardTrack || null);
      if (playResult.url) return playResult.url;
    } catch (error) {
      errors.push(error?.message || 'CMNTY Spotify Play gagal');
    }
  }

  throw new Error(errors.at(-1) || 'Audio penuh dari provider aktif belum tersedia');
}

async function resolveDownloadUrl(track) {
  const stored = normalizeTrack(track);
  const storedUrl = stored.downloadUrl || stored.audioUrl;
  const storedAt = Number(stored.audioResolvedAt || 0);
  const storedSourceDisabled = !audioSourceEnabled(stored.source);
  if (!storedSourceDisabled && storedUrl && storedAt > 0 && Date.now() - storedAt < FRESH_AUDIO_URL_MS) return storedUrl;
  const prepared = await resolveTrackMetadataWithPrimary(stored, { force: false });
  const spotifyUrl = spotifyTrackUrl(prepared);
  if (!spotifyUrl) throw new Error('Link Spotify untuk download tidak ditemukan');
  const packageData = await fetchPrimarySpotifyPackage(spotifyUrl, { force: false });
  const resolved = applyResolvedTrackToState(mergePrimaryTrackMetadata(prepared, packageData.track, {
    audioUrl: packageData.audioUrl,
    downloadUrl: packageData.audioUrl,
    audioResolvedAt: Date.now(),
    metadataResolvedAt: Date.now(),
    source: packageData.track?.source || activeAudioProviderLabel(),
    syncedLyricsPayload: packageData.syncedLyricsPayload || packageData.track?.syncedLyricsPayload || '',
    lyricsProvider: packageData.track?.lyricsProvider || ''
  }));
  updateResolvedTrackReferences(resolved);
  persist();
  return packageData.audioUrl;
}

async function playTrack(track, queue = null, index = null, routeOptions = {}) {
  if (!track) return;
  const requestedTrack = normalizeTrack(track);
  const playActivityId = beginSystemActivity('Membuka lagu', `${cleanTitle(requestedTrack)} • menyiapkan metadata, audio, sampul, dan lirik`, 'Pemutar DATZON', { track: `${cleanTitle(requestedTrack)} — ${requestedTrack.artist}` });
  clearTimeout(pendingAutoplayTimer);
  pendingAutoplayTimer = null;
  clearPlaybackEndWatchdog();
  if (activePlaybackPrepareController) activePlaybackPrepareController.abort();
  activePlaybackPrepareController = new AbortController();
  const playbackSignal = activePlaybackPrepareController.signal;
  currentFullBufferPromise = null;
  activePlaybackOriginalUrl = '';
  resetNextTrackPreload();
  const routePreparedTrack = routeOptions.preparedTrack ? sanitizePlaybackTrack(routeOptions.preparedTrack) : null;
  const incoming = routePreparedTrack || sanitizePlaybackTrack(track);
  const incomingKey = trackKey(incoming);
  const originRoute = state.route;
  const preserveRoute = Boolean(routeOptions.stayOnRoute || (routeOptions.backgroundAdvance && !['player','lyrics'].includes(originRoute)));
  const deferVisualRender = Boolean(routeOptions.backgroundAdvance && document.hidden);
  if (routeOptions.playContext && typeof routeOptions.playContext === 'object') {
    state.lastPlayerRoute = state.route;
    state.playContext = { ...routeOptions.playContext };
    if (['playlist','spotify-playlist'].includes(state.playContext.type)) {
      state.shuffle = false;
      state.mixMode = false;
      state.queueRecommendations = [];
      state.queueRecommendationsKey = '';
    }
  } else if (!['player','lyrics'].includes(state.route)) {
    state.lastPlayerRoute = state.route;
    if (state.route === 'search') {
      state.playContext = { eyebrow: 'MEMAINKAN DARI PENCARIAN', label: `"${state.searchQuery || cleanTitle(incoming)}" dalam Pencarian` };
    } else if (state.route === 'library') {
      state.playContext = { eyebrow: 'MEMAINKAN DARI KOLEKSI', label: 'Koleksi musik kamu' };
    } else if (state.route === 'artist') {
      state.playContext = { eyebrow: 'MEMAINKAN DARI PROFIL ARTIS', label: incoming.artist };
    } else {
      state.playContext = { eyebrow: 'MEMAINKAN DARI DATZON MUSIC', label: 'Pilihan untukmu' };
    }
  }
  if (queue) {
    state.queue = queue.map(item => sanitizePlaybackTrack(item));
    state.currentIndex = Number.isInteger(index) ? index : Math.max(0, state.queue.findIndex(item => trackKey(item) === incomingKey));
  } else if (!state.queue.length) {
    state.queue = [incoming];
    state.currentIndex = 0;
  }

  const token = ++state.playerPrepareToken;
  Object.assign(state, {
    current: incoming,
    currentAudioUrl: '',
    lyricsKey: incomingKey,
    lyricsLines: [],
    lyricsLoading: true,
    lyricsError: '',
    lyricsSynced: false,
    lyricsSource: '',
    lastLyricIndex: -1,
    playerPreparing: true,
    audioReady: false,
    audioFullyBuffered: false,
    audioBufferingProgress: 0,
    lyricsReady: false,
    artworkReady: false,
    playerPrepareError: '',
    resolving: true,
    isPlaying: false,
    route: preserveRoute ? originRoute : 'player'
  });

  if (!preserveRoute) syncBrowserRoute('player', {
    replace: Boolean(routeOptions.replaceUrl || routeOptions.fromHistory),
    skipUrl: false,
    track: incoming,
    trackId: routeOptions.trackId || spotifyTrackIdFromTrack(incoming)
  });
  applyGlobalAppTheme(incoming);
  updateMediaSessionMetadata(incoming);
  audio.pause();
  audio.removeAttribute('src');
  audio.load();
  resetPlayerViewport();
  persist();
  if (!preserveRoute && !deferVisualRender) {
    render();
    resetPlayerViewport();
  } else {
    renderMiniPlayer();
    renderDesktopContextRail();
    if (originRoute === 'spotify-playlist') updateSpotifyCollectionPlayback();
  }

  const metadataActivityId = beginSystemActivity('Menyiapkan informasi lagu', `${cleanTitle(incoming)} sedang dicocokkan dengan metadata utama`, activeAudioProviderLabel(), { track: cleanTitle(incoming) });
  const prepared = routePreparedTrack
    ? mergePrimaryTrackMetadata(incoming, routePreparedTrack, {
        audioUrl: routeOptions.preloadedAudioUrl || routePreparedTrack.audioUrl,
        downloadUrl: routeOptions.preloadedAudioUrl || routePreparedTrack.downloadUrl || routePreparedTrack.audioUrl,
        audioResolvedAt: routeOptions.preloadedAudioUrl ? Date.now() : routePreparedTrack.audioResolvedAt,
        source: routePreparedTrack.source || activeAudioProviderLabel()
      })
    : await resolveTrackMetadataWithPrimary(incoming);
  if (token !== state.playerPrepareToken) { finishSystemActivity(metadataActivityId, 'warning', 'Proses diganti oleh lagu lain'); finishSystemActivity(playActivityId, 'warning', 'Dibatalkan karena lagu lain dibuka'); return; }
  finishSystemActivity(metadataActivityId, 'success', `${cleanTitle(prepared)} • ${prepared.artist} • ${prepared.duration}`);
  state.current = prepared;
  if (preserveRoute && state.route === 'spotify-playlist') updateSpotifyCollectionPlayback();
  if (!preserveRoute && state.route === 'player') {
    syncBrowserRoute('player', { replace: true, track: prepared, trackId: routeOptions.trackId || spotifyTrackIdFromTrack(prepared) });
  }
  applyGlobalAppTheme(prepared);
  updateMediaSessionMetadata(prepared);
  state.lyricsKey = trackKey(prepared);
  if (state.queue[state.currentIndex]) state.queue[state.currentIndex] = prepared;
  if (!preserveRoute && state.route === 'player') {
    renderPlayer();
    resetPlayerViewport();
  }

  if (!state.settings.privateSession && state.settings.saveHistory !== false) {
    const historyLimit = Math.max(10, Math.min(300, Number(state.settings.historyLimit) || 100));
    const historyEntry = { ...prepared, lastPlayedAt: Date.now() };
    state.history = [historyEntry, ...state.history.filter(item => trackKey(item) !== trackKey(prepared))].slice(0, historyLimit);
    recordTrackStarted(prepared);
    state.homeSimilarGroupsAt = 0;
    persist();
  }

  const lyricsTask = (async () => {
    const activityId = beginSystemActivity('Memproses lirik', `Mencari lirik untuk ${cleanTitle(prepared)}`, 'Theresav • Sylvatica • CMNTY Lyrics', { track: cleanTitle(prepared) });
    try {
      await ensureCurrentLyrics(true, token, prepared);
      finishSystemActivity(activityId, state.lyricsLines.length ? 'success' : 'warning', state.lyricsLines.length ? `${state.lyricsLines.length} baris lirik • ${state.lyricsSource || 'sumber utama'}` : 'Lirik tidak tersedia untuk lagu ini');
    }
    catch (error) { finishSystemActivity(activityId, 'warning', error?.message || 'Lirik tidak tersedia'); }
    finally { if (token === state.playerPrepareToken) state.lyricsReady = true; }
  })();

  const audioTask = (async () => {
    const activityId = beginSystemActivity('Menyiapkan audio penuh', `Menguji jalur audio untuk ${cleanTitle(prepared)}`, activeAudioProviderLabel(), { track: cleanTitle(prepared) });
    try {
      const url = routeOptions.preloadedAudioUrl || await resolveAudio(prepared, { allowPreview: false, guardTrack: prepared });
      if (!playbackRequestStillActive(token, prepared) || playbackSignal.aborted) return;
      state.current.audioUrl = url;
      state.current.downloadUrl = state.current.downloadUrl || url;
      state.current.audioResolvedAt = Number(state.current.audioResolvedAt || Date.now());
      state.current.audioIsPreview = false;
      state.current.previewUrl = '';
      state.currentAudioUrl = url;
      if (state.queue[state.currentIndex] && sameTrackIdentity(state.queue[state.currentIndex], prepared)) {
        state.queue[state.currentIndex].audioUrl = url;
        state.queue[state.currentIndex].downloadUrl = state.queue[state.currentIndex].downloadUrl || url;
        state.queue[state.currentIndex].audioResolvedAt = Number(state.current.audioResolvedAt || Date.now());
        state.queue[state.currentIndex].audioIsPreview = false;
        state.queue[state.currentIndex].previewUrl = '';
      }
      updateResolvedTrackReferences(state.current);
      activePlaybackOriginalUrl = url;

      const attached = await attachFastPlaybackSource(url, state.current, {
        signal: playbackSignal,
        timeout: routeOptions.preloadedPlaybackUrl ? 6500 : 8000,
        preloadedPlaybackUrl: routeOptions.preloadedPlaybackUrl || '',
        preloadedFullyBuffered: Boolean(routeOptions.preloadedFullyBuffered)
      });
      if (!playbackRequestStillActive(token, prepared) || playbackSignal.aborted) return;
      state.audioFullyBuffered = attached.fullyBuffered;
      state.audioBufferingProgress = attached.fullyBuffered ? 100 : Math.max(1, Number(state.audioBufferingProgress || 0));
      audio.loop = state.repeat === 'one';
      const startAt = Math.max(0, Number(routeOptions.startAt || 0));
      if (startAt) await seekAudioTo(startAt);
      if (!playbackRequestStillActive(token, prepared) || playbackSignal.aborted) return;
      state.resolving = false;
      state.audioReady = true;
      renderPlayerDynamic();
      renderMiniPlayer();
      if (audio.paused) {
        try { await audio.play(); } catch { /* Autoplay bisa diblokir browser; tombol Play tetap tersedia. */ }
      }
      if (!playbackRequestStillActive(token, prepared) || playbackSignal.aborted) return;

      if (!attached.fullyBuffered) startCurrentFullBufferInBackground(url, state.current, token, playbackSignal);
      finishSystemActivity(activityId, attached.fullyBuffered ? 'success' : 'warning', attached.fullyBuffered
        ? `${state.current?.source || 'API utama'} • audio penuh sudah siap, seek dan download langsung tersedia`
        : `${state.current?.source || 'API utama'} • playback siap lebih cepat; buffer penuh dilanjutkan di latar belakang`);
    } catch (error) {
      if (!playbackRequestStillActive(token, prepared) || playbackSignal.aborted) { finishSystemActivity(activityId, 'warning', 'Proses diganti oleh lagu lain'); return; }
      state.playerPrepareError = error?.message || 'Audio penuh belum tersedia';
      state.currentAudioUrl = '';
      state.resolving = false;
      renderPlayerDynamic();
      finishSystemActivity(activityId, 'error', state.playerPrepareError);
    } finally {
      if (playbackRequestStillActive(token, prepared) && state.playerPrepareError) state.audioReady = false;
    }
  })();

  const artworkActivityId = beginSystemActivity('Memuat sampul HD', 'Mengambil resolusi terbesar yang tersedia', 'Artwork CDN', { track: cleanTitle(prepared) });
  const artworkTask = preloadArtwork(prepared.thumbnail).then(() => {
    finishSystemActivity(artworkActivityId, 'success', 'Sampul lagu siap ditampilkan tanpa kompresi tambahan');
  }).catch(error => {
    finishSystemActivity(artworkActivityId, 'warning', error?.message || 'Sampul memakai gambar cadangan');
  }).finally(() => {
    if (token === state.playerPrepareToken) state.artworkReady = true;
  });

  await Promise.allSettled([lyricsTask, audioTask, artworkTask]);
  if (token !== state.playerPrepareToken) return;

  state.playerPreparing = false;
  state.resolving = false;
  persist();
  const playerRouteStillActive = !preserveRoute && ['player','lyrics'].includes(state.route);
  if (routeOptions.openLyrics && playerRouteStillActive) {
    state.route = 'lyrics';
    syncBrowserRoute('lyrics', { replace: true, track: state.current, trackId: routeOptions.trackId || spotifyTrackIdFromTrack(state.current) });
    renderFullLyrics();
    resetPlayerViewport();
  } else if (!routeOptions.openLyrics && !preserveRoute && state.route === 'player') {
    renderPlayer();
    resetPlayerViewport();
  }
  renderMiniPlayer();
  renderDesktopContextRail();
  updateSpotifyCollectionPlayback();
  if ($('.queue-player-sheet', modalRoot)) updateQueueSheetContent();

  if (state.playerPrepareError || !audio.src) {
    finishSystemActivity(playActivityId, 'error', state.playerPrepareError || 'Audio penuh belum tersedia');
    notify('Audio penuh belum tersedia. Tekan putar untuk mencoba lagi.', 3600);
    return;
  }

  finishSystemActivity(playActivityId, 'success', `${cleanTitle(state.current)} siap diputar • ${state.current.artist}`);
  pendingAutoplayTimer = window.setTimeout(async () => {
    pendingAutoplayTimer = null;
    if (!playbackRequestStillActive(token, state.current) || !audio.paused) { updateSpotifyCollectionPlayback(); return; }
    try {
      const startAt = Math.max(0, Number(routeOptions.startAt || 0));
      if (startAt && Number.isFinite(audio.duration) && audio.duration > 0) audio.currentTime = Math.min(startAt, Math.max(0, audio.duration - 1));
      await audio.play();
    }
    catch { state.isPlaying = false; renderPlayerDynamic(); renderMiniPlayer(); syncAccountAvatarPlaybackState(); updateSpotifyCollectionPlayback(); }
  }, 500);
  updateSpotifyCollectionPlayback();
}

async function togglePlay() {
  if (!state.current) return;
  if (state.resolving) return notify('Sedang menyiapkan audio...');
  if (!audio.src) {
    state.resolving = true;
    renderPlayerDynamic();
    if (activePlaybackPrepareController) activePlaybackPrepareController.abort();
    activePlaybackPrepareController = new AbortController();
    const retryController = activePlaybackPrepareController;
    const retrySignal = retryController.signal;
    const retryToken = ++state.playerPrepareToken;
    const expectedTrack = normalizeTrack(state.current);
    try {
      const prepared = await resolveTrackMetadataWithPrimary(expectedTrack);
      if (!playbackRequestStillActive(retryToken, expectedTrack) || retrySignal.aborted) return;
      state.current = prepared;
      if (state.queue[state.currentIndex]) state.queue[state.currentIndex] = prepared;
      updateMediaSessionMetadata(prepared);
      const url = await resolveAudio(prepared, { allowPreview: false, guardTrack: prepared });
      if (!playbackRequestStillActive(retryToken, prepared) || retrySignal.aborted) return;
      state.current.audioUrl = url;
      state.current.downloadUrl = state.current.downloadUrl || url;
      state.current.audioResolvedAt = Number(state.current.audioResolvedAt || Date.now());
      state.currentAudioUrl = url;
      state.current.audioIsPreview = false;
      state.current.previewUrl = '';
      updateResolvedTrackReferences(state.current);
      persist();
      state.playerPrepareError = '';
      activePlaybackOriginalUrl = url;
      const attached = await attachFastPlaybackSource(url, state.current, { signal:retrySignal, timeout:15000 });
      if (!playbackRequestStillActive(retryToken, prepared) || retrySignal.aborted) return;
      state.audioFullyBuffered = attached.fullyBuffered;
      state.audioBufferingProgress = attached.fullyBuffered ? 100 : 1;
      state.audioReady = true;
      await audio.play();
      if (!playbackRequestStillActive(retryToken, prepared) || retrySignal.aborted) return;
      state.isPlaying = true;
      if (!attached.fullyBuffered) startCurrentFullBufferInBackground(url, state.current, retryToken, retrySignal);
    } catch (error) {
      if (!retrySignal.aborted && playbackRequestStillActive(retryToken, expectedTrack)) notify(`Gagal memutar: ${error?.message || 'provider tidak tersedia'}`);
    }
    finally {
      if (retryToken === state.playerPrepareToken) state.resolving = false;
      renderPlayerDynamic(); renderMiniPlayer();
    }
    return;
  }
  if (audio.paused) await audio.play(); else audio.pause();
}

function resetNextTrackPreload() {
  if (nextTrackPreloadTimer) window.clearTimeout(nextTrackPreloadTimer);
  nextTrackPreloadTimer = null;
  nextTrackPreload = { signature: '', fromKey: '', index: -1, promise: null, value: null, at: 0 };
  if (nextAudioWarmup) {
    try { nextAudioWarmup.pause(); nextAudioWarmup.removeAttribute('src'); nextAudioWarmup.load(); } catch {}
    nextAudioWarmup = null;
  }
}

function calculateNextTrackIndex(manual = false, reusePlannedShuffle = true) {
  if (!state.queue.length) return -1;
  if (state.repeat === 'one' && !manual) return state.currentIndex;
  const playlistMode = hasPlaylistPlaybackContext();
  let next = state.currentIndex + 1;
  if (state.shuffle && !playlistMode && state.queue.length > 1) {
    if (!manual && reusePlannedShuffle && nextTrackPreload.fromKey === trackKey(state.current) && Number.isInteger(nextTrackPreload.index)) {
      next = nextTrackPreload.index;
    } else {
      do { next = Math.floor(Math.random() * state.queue.length); } while (next === state.currentIndex);
    }
  }
  if (next >= state.queue.length) {
    if (state.repeat === 'all') next = 0;
    else if (!playlistMode && state.settings.autoplay) next = 0;
    else return -1;
  }
  return next;
}

function nextTrackPreloadSignature(index, track) {
  return `${trackKey(state.current)}>${index}:${trackKey(track)}`;
}

function getPreparedNextTrack(index) {
  const value = nextTrackPreload.value;
  const queued = state.queue[index];
  if (!value || !queued) return null;
  if (Date.now() - Number(nextTrackPreload.at || 0) > 1000 * 60 * 30) return null;
  if (nextTrackPreload.fromKey !== trackKey(state.current) || value.index !== index) return null;
  if (trackKey(value.track) !== trackKey(queued)) return null;
  if (!value.audioUrl) return null;
  return value;
}

async function prepareNextTrackInBackground() {
  if (!state.current || !state.queue.length || state.repeat === 'one') return null;
  const nextIndex = calculateNextTrackIndex(false, true);
  if (nextIndex < 0 || nextIndex === state.currentIndex) return null;
  const candidate = sanitizePlaybackTrack(state.queue[nextIndex]);
  const signature = nextTrackPreloadSignature(nextIndex, candidate);
  if (nextTrackPreload.signature === signature) {
    if (nextTrackPreload.value && Date.now() - Number(nextTrackPreload.at || 0) < 1000 * 60 * 30) return nextTrackPreload.value;
    if (nextTrackPreload.promise) return nextTrackPreload.promise;
  }

  const fromKey = trackKey(state.current);
  const request = (async () => {
    let prepared = await resolveTrackMetadataWithPrimary(candidate, { force: false });
    let audioUrl = '';
    const storedAt = Number(prepared.audioResolvedAt || 0);
    if (prepared.audioUrl && storedAt > 0 && Date.now() - storedAt < FRESH_AUDIO_URL_MS) {
      audioUrl = prepared.audioUrl;
    } else {
      const spotifyUrl = spotifyTrackUrl(prepared);
      if (!spotifyUrl) throw new Error('Link Spotify lagu berikutnya belum tersedia');
      const packageData = await fetchPrimarySpotifyPackage(spotifyUrl, { force: false });
      audioUrl = packageData.audioUrl;
      prepared = mergePrimaryTrackMetadata(prepared, packageData.track, {
        audioUrl,
        downloadUrl: audioUrl,
        audioResolvedAt: Date.now(),
        metadataResolvedAt: Date.now(),
        source: packageData.track?.source || activeAudioProviderLabel(),
        syncedLyricsPayload: packageData.syncedLyricsPayload || packageData.track?.syncedLyricsPayload || '',
        lyricsProvider: packageData.track?.lyricsProvider || ''
      });
    }
    if (!audioUrl) throw new Error('Audio lagu berikutnya belum tersedia');
    if (trackKey(state.current) !== fromKey || nextTrackPreload.signature !== signature) return null;

    const currentQueued = state.queue[nextIndex];
    if (!currentQueued || trackKey(currentQueued) !== trackKey(candidate)) return null;
    state.queue[nextIndex] = prepared;

    // Jangan menunggu full-download sebelum menandai next track siap.
    // URL audio + warmup browser disimpan segera; full buffer dilanjutkan paralel.
    const cached = cachedFullAudio(audioUrl);
    nextTrackPreload.value = {
      index: nextIndex,
      track: prepared,
      audioUrl,
      playbackUrl: cached?.objectUrl || audioUrl,
      fullyBuffered: Boolean(cached?.objectUrl)
    };
    nextTrackPreload.at = Date.now();
    persist();

    try {
      nextAudioWarmup = new Audio();
      nextAudioWarmup.preload = 'auto';
      nextAudioWarmup.src = nextTrackPreload.value.playbackUrl;
      nextAudioWarmup.load();
    } catch {}

    if (!cached?.objectUrl) {
      window.setTimeout(() => { void fetchFullAudioBlob(audioUrl, prepared, { current:false, timeout:90000 })
        .then(full => {
          if (!full?.objectUrl) return;
          if (trackKey(state.current) !== fromKey || nextTrackPreload.signature !== signature) return;
          if (!nextTrackPreload.value || nextTrackPreload.value.index !== nextIndex) return;
          nextTrackPreload.value.playbackUrl = full.objectUrl;
          nextTrackPreload.value.fullyBuffered = true;
          nextTrackPreload.at = Date.now();
          try {
            if (nextAudioWarmup) {
              nextAudioWarmup.pause();
              nextAudioWarmup.src = full.objectUrl;
              nextAudioWarmup.preload = 'auto';
              nextAudioWarmup.load();
            }
          } catch {}
        })
        .catch(() => {}); }, 2200);
    }

    nextTrackPreload.promise = null;
    return nextTrackPreload.value;
  })().catch(() => {
    if (nextTrackPreload.signature === signature) nextTrackPreload.promise = null;
    return null;
  });

  nextTrackPreload = { signature, fromKey, index: nextIndex, promise: request, value: null, at: Date.now() };
  return request;
}


function scheduleNextTrackPreload(delay = 250) {
  if (nextTrackPreloadTimer) window.clearTimeout(nextTrackPreloadTimer);
  nextTrackPreloadTimer = window.setTimeout(() => {
    nextTrackPreloadTimer = null;
    prepareNextTrackInBackground().catch(() => {});
  }, Math.max(0, Number(delay) || 0));
}

function clearPlaybackEndWatchdog() {
  if (playbackEndWatchdog) window.clearTimeout(playbackEndWatchdog);
  playbackEndWatchdog = null;
}

function schedulePlaybackEndWatchdog() {
  clearPlaybackEndWatchdog();
  if (!state.current || audio.paused || audio.loop) return;
  const duration = Number(audio.duration);
  const position = Number(audio.currentTime);
  if (!Number.isFinite(duration) || duration <= 1 || !Number.isFinite(position)) return;
  const watchedKey = trackKey(state.current);
  const delay = Math.max(1000, Math.min(2147480000, (duration - position) * 1000 + 1250));
  playbackEndWatchdog = window.setTimeout(() => {
    playbackEndWatchdog = null;
    if (!state.current || trackKey(state.current) !== watchedKey || audio.loop) return;
    const currentDuration = Number(audio.duration);
    const nearEnd = Number.isFinite(currentDuration) && currentDuration > 0 && Number(audio.currentTime) >= currentDuration - .45;
    if (audio.ended || nearEnd) void nextTrack(false);
    else if (!audio.paused) schedulePlaybackEndWatchdog();
  }, delay);
}

async function nextTrack(manual = true) {
  if (!manual && backgroundAdvanceLock) return;
  if (hasPlaylistPlaybackContext()) syncPlaylistQueueToSource();
  if (!state.queue.length) return;
  if (state.repeat === 'one' && !manual) {
    audio.loop = true;
    audio.currentTime = 0;
    try { await audio.play(); } catch {}
    return;
  }
  const next = calculateNextTrackIndex(manual, true);
  if (next < 0) {
    state.isPlaying = false;
    updateMediaSessionPlaybackState();
    renderPlayerDynamic();
    syncAccountAvatarPlaybackState();
    return;
  }
  const preparedNext = !manual ? getPreparedNextTrack(next) : null;
  if (!manual) backgroundAdvanceLock = true;
  clearPlaybackEndWatchdog();
  resetNextTrackPreload();
  try {
    await playTrack(preparedNext?.track || state.queue[next], state.queue, next, {
      preparedTrack: preparedNext?.track || null,
      preloadedAudioUrl: preparedNext?.audioUrl || '',
      preloadedPlaybackUrl: preparedNext?.playbackUrl || '',
      preloadedFullyBuffered: Boolean(preparedNext?.fullyBuffered),
      autoplayImmediately: !manual,
      backgroundAdvance: !manual,
      stayOnRoute: !manual && !['player','lyrics'].includes(state.route)
    });
  } finally {
    if (!manual) backgroundAdvanceLock = false;
  }
}
function previousTrack() {
  if (hasPlaylistPlaybackContext()) syncPlaylistQueueToSource();
  if (audio.currentTime > 4) { audio.currentTime = 0; return; }
  const prev = state.currentIndex > 0 ? state.currentIndex - 1 : state.queue.length - 1;
  if (prev >= 0) playTrack(state.queue[prev], state.queue, prev);
}
function isFavorite(track = state.current) { return state.favorites.some(x => trackKey(x) === trackKey(track)); }
function toggleFavorite(track = state.current) {
  if (!track) return;
  if (isFavorite(track)) {
    state.favorites = state.favorites.filter(x => trackKey(x) !== trackKey(track));
    notify('Dihapus dari Lagu Disukai');
  } else {
    state.favorites.unshift(normalizeTrack(track));
    notify('Ditambahkan ke Lagu Disukai');
  }
  persist(); renderPlayerDynamic(); renderMiniPlayer();
}

function spotifyTrackIdFromValue(value = '') {
  const match = String(value || '').match(/(?:open\.spotify\.com\/track\/|spotify:track:)([A-Za-z0-9]{22})/i);
  return match?.[1] || (/^[A-Za-z0-9]{22}$/.test(String(value || '')) ? String(value) : '');
}

function spotifyTrackIdFromTrack(track = state.current) {
  return spotifyTrackIdFromValue(track?.url || track?.id || '');
}

function routePath(route, options = {}) {
  const track = options.track || state.current;
  const trackId = options.trackId || spotifyTrackIdFromTrack(track);
  const artistName = options.artistName || state.artistView?.name || track?.artist || '';
  const paths = {
    home: '/home',
    search: '/search',
    library: '/library',
    settings: '/settings',
    profile: '/profile',
    statistics: '/statistics',
    downloads: '/downloads',
    connections: '/connections',
    people: '/people',
    friends: '/friends',
    following: '/following',
    followers: '/followers',
    leaderboard: '/leaderboard',
    report: '/report',
    'admin-reports': '/admin/reports',
    login: '/login',
    register: '/register',
    verify: '/verify-email',
    onboarding: '/setup-artists'
  };
  if (route === 'spotify-album' || route === 'spotify-playlist') {
    const type = route === 'spotify-album' ? 'album' : 'playlist';
    const id = options.collectionId || state.spotifyCollectionView?.id || '';
    return validSpotifyCollectionIdentity(type, id) ? `/${type}/${id}` : '/home';
  }
  if (route === 'datzon-playlist') {
    const id = playlistIdFromValue(options.playlistId || state.datzonPlaylistView?.id || '');
    return id ? `/datzon-playlist/${encodeURIComponent(id)}` : '/home';
  }
  if (route === 'player') return trackId ? `/track/${trackId}` : '/player';
  if (route === 'lyrics') return trackId ? `/track/${trackId}/lyrics` : '/lyrics';
  if (route === 'artist') return artistName ? `/artist/${encodeURIComponent(artistName)}` : '/artist';
  if (route === 'public-profile') return options.uid ? `/u/${encodeURIComponent(options.uid)}` : '/people';
  return paths[route] || '/home';
}

function syncBrowserRoute(route = state.route, options = {}) {
  if (options.skipUrl || typeof history === 'undefined') return;
  const target = routePath(route, options);
  if (!target || `${location.pathname}${location.search}` === target) return;
  const method = options.replace ? 'replaceState' : 'pushState';
  history[method]({
    datzonRoute: route,
    fromRoute: options.fromRoute || history.state?.datzonRoute || '',
    trackId: options.trackId || spotifyTrackIdFromTrack(options.track || state.current),
    collectionId: options.collectionId || state.spotifyCollectionView?.id || '',
    collectionType: options.collectionType || state.spotifyCollectionView?.type || '',
    playlistId: options.playlistId || state.datzonPlaylistView?.id || ''
  }, '', target);
}

function parseBrowserRoute(pathname = location.pathname) {
  const clean = decodeURI(String(pathname || '/').replace(/\/{2,}/g, '/')).replace(/\/$/, '') || '/';
  const trackMatch = clean.match(/^\/track\/([A-Za-z0-9]{22})(?:\/(lyrics))?$/i);
  if (trackMatch) return { route: trackMatch[2] ? 'lyrics' : 'player', trackId: trackMatch[1], directTrack: true };
  const spotifyPlaylistMatch = clean.match(/^\/playlist\/([A-Za-z0-9]{22})$/i);
  if (spotifyPlaylistMatch) return { route: 'spotify-playlist', collectionType: 'playlist', collectionId: spotifyPlaylistMatch[1], spotifyCollection: true };
  const datzonPlaylistMatch = clean.match(/^\/datzon-playlist\/([A-Za-z0-9._-]{1,120})$/i);
  if (datzonPlaylistMatch) return { route:'datzon-playlist', playlistId:datzonPlaylistMatch[1], datzonPlaylist:true };
  const spotifyAlbumMatch = clean.match(/^\/album\/([A-Za-z0-9]{22})$/i);
  if (spotifyAlbumMatch) return { route: 'spotify-album', collectionType: 'album', collectionId: spotifyAlbumMatch[1], spotifyCollection: true };
  const publicProfileMatch = clean.match(/^\/u\/([^/]+)$/i);
  if (publicProfileMatch) return { route: 'public-profile', uid: decodeURIComponent(publicProfileMatch[1]) };
  const artistMatch = clean.match(/^\/artist\/(.+)$/i);
  if (artistMatch) return { route: 'artist', artistName: decodeURIComponent(artistMatch[1]) };
  const simple = {
    '/': 'home', '/index.html': 'home', '/home': 'home', '/search': 'search', '/library': 'library', '/collection': 'library',
    '/settings': 'settings', '/profile': 'profile', '/statistics': 'statistics', '/downloads': 'downloads', '/connections': 'connections', '/people': 'people', '/users': 'people', '/friends': 'friends', '/following': 'following', '/followers': 'followers', '/leaderboard': 'leaderboard', '/report': 'report', '/admin/reports': 'admin-reports',
    '/login': 'login', '/register': 'register', '/verify-email': 'verify', '/setup-artists': 'onboarding',
    '/player': 'player', '/lyrics': 'lyrics', '/artist': 'artist'
  };
  return { route: simple[clean.toLowerCase()] || 'home', replaceWithHome: !simple[clean.toLowerCase()] };
}

function directTrackSeed(trackId) {
  return normalizeTrack({
    id: trackId,
    title: 'Memuat lagu...',
    artist: 'Spotify',
    duration: '0:00',
    thumbnail: 'assets/placeholder.svg',
    url: `https://open.spotify.com/track/${trackId}`,
    source: 'Tautan langsung DATZON Music'
  });
}

async function applyBrowserRoute(options = {}) {
  const parsed = parseBrowserRoute();
  const replace = Boolean(options.replace);
  if (parsed.route !== 'public-profile') stopPublicProfilePlaylistStream();
  if (parsed.route !== 'datzon-playlist') stopDatzonPlaylistStream();
  if (parsed.route !== 'leaderboard') stopLeaderboardStream();
  if (isLoggedIn() && ['login','register','verify'].includes(parsed.route)) {
    parsed.route = 'home';
    parsed.replaceWithHome = true;
  }
  if (parsed.directTrack) {
    const sameTrack = spotifyTrackIdFromTrack(state.current) === parsed.trackId;
    if (sameTrack && state.current) {
      state.route = parsed.route;
      render();
      if (replace) syncBrowserRoute(parsed.route, { replace: true, trackId: parsed.trackId });
      return;
    }
    const seed = directTrackSeed(parsed.trackId);
    await playTrack(seed, [seed], 0, { fromHistory: true, replaceUrl: true, trackId: parsed.trackId, openLyrics: parsed.route === 'lyrics' });
    return;
  }
  if (parsed.spotifyCollection && parsed.collectionType && parsed.collectionId) {
    state.route = parsed.route;
    state.spotifyCollectionView = { type: parsed.collectionType, id: parsed.collectionId, data: null, loading: true, error: '' };
    if (replace) syncBrowserRoute(parsed.route, { replace: true, collectionType: parsed.collectionType, collectionId: parsed.collectionId });
    await loadSpotifyCollectionRoute(parsed.collectionType, parsed.collectionId, { skipRender: false });
    return;
  }
  if (parsed.datzonPlaylist && parsed.playlistId) {
    await loadDatzonPlaylistRoute(parsed.playlistId, { replace });
    return;
  }
  if (parsed.route === 'public-profile' && parsed.uid) {
    await openPublicProfile(parsed.uid, { replace });
    return;
  }
  if (parsed.route === 'artist' && parsed.artistName) {
    const sameArtist = normalizeMatchText(state.artistView?.name) === normalizeMatchText(parsed.artistName);
    state.route = 'artist';
    syncBrowserRoute('artist', { replace, artistName: parsed.artistName });
    if (sameArtist && state.artistView?.profile && !state.artistView?.loading) {
      render();
      return;
    }
    state.artistReturnRoute = state.artistReturnRoute || 'home';
    await loadArtistRoute(parsed.artistName, sameArtist ? state.artistView?.seedTrack || null : null, false);
    return;
  }
  if ((parsed.route === 'player' || parsed.route === 'lyrics') && !state.current) {
    state.route = 'home';
    syncBrowserRoute('home', { replace: true });
  } else {
    state.route = parsed.route;
    if (replace || parsed.replaceWithHome || location.pathname === '/') syncBrowserRoute(state.route, { replace: true });
  }
  render();
  if (!replace && parsed.route === 'home' && state.spotifyCollectionReturnScroll?.route === 'home') {
    const restoreY = Number(state.spotifyCollectionReturnScroll.y || 0);
    state.spotifyCollectionReturnScroll = null;
    requestAnimationFrame(() => requestAnimationFrame(() => window.scrollTo({ top: restoreY, behavior: 'auto' })));
  }
}

function navigate(route, options = {}) {
  if (route === 'player' && !state.current) return;
  window.DatzonMusicCode?.close?.();
  const previousRoute = state.route;
  if (route !== 'public-profile') stopPublicProfilePlaylistStream();
  if (route !== 'datzon-playlist') stopDatzonPlaylistStream();
  if (route !== 'leaderboard') stopLeaderboardStream();
  clearInterval(homeSpotlightTimer);
  homeSpotlightTimer = null;
  resetModalRoot();
  unlockPageScroll(true);
  state.route = route;
  syncBrowserRoute(route, { ...options, fromRoute: options.fromRoute || previousRoute, replace: Boolean(options.replace), skipUrl: Boolean(options.fromHistory) });
  resetRouteViewport();
  render();
  resetRouteViewport();
  if (route === 'home') window.setTimeout(() => loadHomeSylvaticaSimilar(false).catch(() => {}), 0);
}

function navigateBack(fallback = 'home') {
  const previousRoute = history.state?.fromRoute;
  if (previousRoute && previousRoute !== state.route && history.length > 1) {
    history.back();
    return;
  }
  navigate(fallback, { replace: true });
}

function renderNav() {
  const items = [
    ['home', 'Home', 'home'],
    ['search', 'Cari', 'search'],
    ['library', 'Koleksi Kamu', 'library'],
    ['create', 'Buat', 'plus-circle']
  ];
  bottomNav.innerHTML = items.map(([route, label, ico]) => `<button class="nav-item ${state.route === route ? 'active' : ''}" data-nav="${route}"><span class="nav-icon-wrap">${icon(ico)}</span><span>${label}</span></button>`).join('');
  bottomNav.classList.toggle('is-hidden', ['player','lyrics','login','register','verify','onboarding'].includes(state.route));
  $$('[data-nav]', bottomNav).forEach(button => button.addEventListener('click', () => {
    if (button.dataset.nav === 'create') showCreateMenu();
    else navigate(button.dataset.nav);
  }));
}

function renderMiniPlayer() {
  if (!state.current || ['player','lyrics','login','register','verify','onboarding'].includes(state.route)) {
    miniPlayer.classList.add('is-hidden');
    view.classList.remove('has-mini');
    return;
  }
  miniPlayer.classList.remove('is-hidden');
  view.classList.add('has-mini');
  const progress = audio.duration ? (audio.currentTime / audio.duration) * 100 : 0;
  miniPlayer.innerHTML = `<div class="mini-progress" style="width:${progress}%"></div>
    <img class="mini-cover" src="${esc(enhanceArtworkUrl(state.current.thumbnail))}" alt="" decoding="async" onerror="this.src='assets/placeholder.svg'">
    <div class="mini-copy"><div class="mini-title">${esc(cleanTitle(state.current))}</div><div class="mini-artist">${esc(state.current.artist)}</div></div>
    <button class="mini-btn" data-mini-device aria-label="Perangkat">${icon('device')}</button>
    <button class="mini-btn ${isFavorite() ? 'active' : ''}" data-mini-fav aria-label="Simpan">${icon(isFavorite() ? 'check-circle' : 'plus-circle')}</button>
    <button class="mini-btn" data-mini-play aria-label="Putar atau jeda">${icon(state.isPlaying ? 'pause' : 'play', state.isPlaying ? '' : 'fill')}</button>`;
  miniPlayer.onclick = event => { if (!event.target.closest('button')) navigate('player'); };
  $('[data-mini-play]', miniPlayer).onclick = event => { event.stopPropagation(); togglePlay(); };
  $('[data-mini-fav]', miniPlayer).onclick = event => { event.stopPropagation(); toggleFavorite(); };
  $('[data-mini-device]', miniPlayer).onclick = event => { event.stopPropagation(); showConnectSheet(); };
}

function cardTemplate(track, index, overlay = true) {
  return `<button class="track-card" data-track-index="${index}">
    <div class="track-cover-wrap"><img class="track-cover" src="${esc(track.thumbnail)}" alt="Sampul ${esc(cleanTitle(track))}" loading="lazy" onerror="this.src='assets/placeholder.svg'">${overlay?`<span class="track-overlay-title">${esc(cleanTitle(track))}</span>`:''}</div>
    ${overlay?'':`<div class="card-meta"><div class="card-title">${esc(cleanTitle(track))}</div><div class="card-artist">${esc(track.artist)}</div></div>`}
  </button>`;
}

function bindTrackCards(root, list) {
  $$('[data-track-index]', root).forEach(el => el.addEventListener('click', () => {
    const i = Number(el.dataset.trackIndex); playTrack(list[i], list, i);
  }));
}

function compactHomeRow(track, index) {
  return `<button class="spotify-home-row" data-home-track="${index}">
    <img src="${esc(track.thumbnail)}" alt="" loading="lazy" onerror="this.src='assets/placeholder.svg'">
    <span><strong>${esc(cleanTitle(track))}</strong><small>${esc(track.artist)}</small></span>
    <span class="home-row-favorite">${isFavorite(track) ? icon('check-circle','home-row-check') : ''}</span>
    <i class="home-row-more" data-home-more="${index}">${icon('more')}</i>
  </button>`;
}

function homeSquareCard(track, playIndex, extra = '') {
  return `<button class="home-square-card" data-home-discovery="${playIndex}">
    <img src="${esc(track.thumbnail)}" alt="" loading="lazy" onerror="this.src='assets/placeholder.svg'">
    <strong>${esc(cleanTitle(track))}</strong>
    <span>${esc(extra || track.artist)}</span>
  </button>`;
}

function roundRobinUniqueTracks(lists = [], limit = 4) {
  const result = [];
  const seen = new Set();
  const maxDepth = Math.max(0, ...lists.map(list => Array.isArray(list) ? list.length : 0));
  for (let depth = 0; depth < maxDepth && result.length < limit; depth += 1) {
    for (const list of lists) {
      const track = Array.isArray(list) ? list[depth] : null;
      if (!track) continue;
      const normalized = normalizeTrack(track);
      const key = spotifyTrackIdFromTrack(normalized) || trackKey(normalized);
      if (!key || seen.has(key)) continue;
      seen.add(key);
      result.push(normalized);
      if (result.length >= limit) break;
    }
  }
  return result;
}

function homeSimilarSeedGroups() {
  const groups = [];
  const seen = new Set();
  const sources = [state.current, ...(state.history || []).slice(0, 14), ...(state.favorites || []).slice(0, 8)].filter(Boolean);
  for (const raw of sources) {
    const seedTrack = sanitizePlaybackTrack(raw);
    if (!spotifyTrackUrl(seedTrack)) continue;
    const rawCredits = artistCreditEntries(seedTrack).filter(item => item?.name).slice(0, 3);
    const signature = rawCredits.length
      ? rawCredits.map(item => `${normalizeMatchText(item.name)}:${item.id || item.url || ''}`).sort().join('|')
      : trackKey(seedTrack);
    if (!signature || seen.has(signature)) continue;
    seen.add(signature);
    groups.push({ label: rawCredits.map(item => item.name).join(', ') || seedTrack.artist, credits: rawCredits, seedTrack });
    if (groups.length >= 3) break;
  }
  return groups;
}

function trackBelongsToArtist(track, artistName) {
  const wanted = normalizeMatchText(artistName);
  if (!wanted) return false;
  const names = extractArtistNames(track?.artistNames, track?.artistDetails, track?.artists, track?.artist);
  return names.some(name => normalizeMatchText(name) === wanted)
    || artistDisplayParts(track?.artist || '').some(name => normalizeMatchText(name) === wanted);
}

function roundRobinArtistTracks(profiles, count = 4) {
  const lists = profiles.map(profile => (profile?.tracks || []).filter(track => trackBelongsToArtist(track, profile?.name || '')));
  return roundRobinUniqueTracks(lists, count);
}

async function loadHomeSylvaticaSimilar(force = false) {
  if (state.homeSimilarGroupsLoading) return state.homeSimilarGroups;
  const groups = homeSimilarSeedGroups();
  const signature = groups.map(group => `${trackKey(group.seedTrack)}:${group.label}`).join('||');
  const cachedSignature = storage.get('homeSimilarSignatureV1500', '');
  const fresh = !force && signature && cachedSignature === signature && Array.isArray(state.homeSimilarGroups) && state.homeSimilarGroups.length && Date.now() - state.homeSimilarGroupsAt < 1000 * 60 * 60 * 6;
  if (fresh || !groups.length) return state.homeSimilarGroups;
  state.homeSimilarGroupsLoading = true;
  try {
    const built = [];
    for (const group of groups.slice(0, 3)) {
      const contextTrack = await resolveExactArtistContextTrack(group.seedTrack, force).catch(() => group.seedTrack);
      const exactCredits = artistCreditEntries(contextTrack)
        .filter(item => item?.name && (item?.url || item?.id))
        .slice(0, 3);
      // Jangan pakai lookup nama longgar di Home. Kalau Spotify Artist URL exact belum ada,
      // lebih baik section dilewati daripada menampilkan lagu artis lain.
      if (!exactCredits.length) continue;

      const profiles = [];
      for (const credit of exactCredits) {
        try {
          const profile = await fetchSylvaticaSpotyloaderArtistProfile(credit.name, contextTrack, force);
          if (profile && normalizeMatchText(profile.name) === normalizeMatchText(credit.name)) profiles.push(profile);
        } catch {}
      }
      if (!profiles.length) continue;

      let tracks = roundRobinArtistTracks(profiles, 4);
      tracks = await enrichTracksWithSpotifyMeta(tracks, 4);
      tracks = dedupeTracks(tracks).slice(0, 4);
      if (!tracks.length) continue;

      built.push({
        label: exactCredits.map(item => item.name).join(', '),
        openArtistName: exactCredits[0]?.name || profiles[0]?.name || group.label,
        avatar: profiles[0]?.image || contextTrack?.thumbnail || tracks[0]?.thumbnail || 'assets/placeholder.svg',
        seedTrack: contextTrack,
        credits: exactCredits,
        tracks
      });
    }
    state.homeSimilarGroups = built;
    state.homeSimilarGroupsAt = Date.now();
    storage.set('homeSimilarGroupsV1500', built);
    storage.set('homeSimilarGroupsAtV1500', state.homeSimilarGroupsAt);
    storage.set('homeSimilarSignatureV1500', signature);
  } finally {
    state.homeSimilarGroupsLoading = false;
    if (state.route === 'home' && !state.homeInitialLoading) renderHome();
  }
  return state.homeSimilarGroups;
}


function homeSimilarBlock(artist, tracks, registerTrack, options = {}) {
  if (!tracks.length) return '';
  const avatar = options.avatar || tracks[0]?.thumbnail || 'assets/placeholder.svg';
  const contextAttr = Number.isInteger(options.contextIndex) ? ` data-home-similar-context="${options.contextIndex}"` : ` data-home-artist="${esc(options.openArtistName || artist)}"`;
  return `<section class="spotify-section similar-home-section">
    <button class="similar-heading"${contextAttr}><img src="${esc(avatar)}" alt="" onerror="this.src='assets/placeholder.svg'"><div><span>Serupa dengan</span><h2>${esc(artist)}</h2></div>${icon('arrow-right')}</button>
    <div class="home-square-carousel">${tracks.slice(0,4).map(track => homeSquareCard(track, registerTrack(track), durationSeconds(track.duration) > 0 ? track.duration : track.artist)).join('')}</div>
  </section>`;
}

function buildCommunityGroups(tracks) {
  const labels = ['Indo Pop Pilihan', 'Chill Malam', 'Lagu untuk Perjalanan', 'Hits yang Lagi Naik'];
  const base = dedupeTracks([...(tracks || []), ...state.catalog, ...FALLBACK_TRACKS]).filter(homeDisplayTrackReady);
  const groups = [];
  if (!base.length) return groups;
  for (let i = 0; i < labels.length; i += 1) {
    const offset = (i * 7) % base.length;
    const rotated = [...base.slice(offset), ...base.slice(0, offset)];
    const items = rotated.slice(0, Math.min(25, rotated.length));
    if (items.length >= 3) groups.push({ title: labels[i], tracks: items });
  }
  return groups;
}

function findCommunityPlaylist(group = {}) {
  const target = String(group.title || '').trim().toLowerCase();
  if (!target) return null;
  return activePlaylists().find(playlist => String(playlist.name || '').trim().toLowerCase() === target) || null;
}

function communityPlaylistSaved(group = {}) {
  // A Community card represents a named playlist. Once that playlist exists in
  // Koleksi Kamu (local/Firebase), keep the saved check even if Home discovery
  // produces a slightly different 25-track snapshot on the next refresh.
  return Boolean(findCommunityPlaylist(group));
}

function saveCommunityPlaylist(group = {}) {
  const tracks = dedupeTracks(group.tracks || []).slice(0, 25).map(firebaseTrackRecord);
  if (!tracks.length) return null;
  const current = findCommunityPlaylist(group);
  const now = Date.now();
  if (current) {
    const merged = mergeTracksByIdentity(current.tracks || [], tracks, 200).map(firebaseTrackRecord);
    const updated = activePlaylists().map(playlist => playlist.id === current.id ? { ...playlist, tracks: merged, updatedAt: now } : playlist);
    setActivePlaylists(updated);
    return updated.find(playlist => playlist.id === current.id) || current;
  }
  const playlist = normalizePlaylist({
    id: createPlaylistId(),
    name: String(group.title || 'From the Community').trim() || 'From the Community',
    ownerUid: isLoggedIn() ? state.auth.user.uid : '',
    createdAt: now,
    updatedAt: now,
    tracks
  });
  setActivePlaylists([playlist, ...activePlaylists()]);
  return playlist;
}

function communityCard(group, groupIndex, registerTrack) {
  const collage = group.tracks.slice(0,4);
  const saved = communityPlaylistSaved(group);
  return `<article class="community-card">
    <div class="community-card-head">
      <div class="community-collage">${collage.map(track => `<img src="${esc(track.thumbnail)}" alt="" loading="lazy" onerror="this.src='assets/placeholder.svg'">`).join('')}</div>
      <div><h3>${esc(group.title)}</h3><span>${group.tracks.length} lagu</span></div>
    </div>
    <div class="community-track-list">${group.tracks.slice(0,3).map((track, trackIndex) => `<button data-community-track="${groupIndex}:${trackIndex}"><img src="${esc(track.thumbnail)}" alt=""><span><strong>${esc(cleanTitle(track))}</strong><small>${esc(track.artist)}</small></span></button>`).join('')}</div>
    <div class="community-actions"><button data-community-play="${groupIndex}" aria-label="Putar playlist">${icon('play','fill')}</button><button data-community-listen="${groupIndex}" aria-label="Dengar bareng">${icon('radio')}</button><button class="${saved ? 'is-saved' : ''}" data-community-save="${groupIndex}" aria-label="${saved ? 'Sudah disimpan' : 'Simpan sebagai playlist'}">${icon(saved ? 'check-circle' : 'plus-circle')}</button></div>
  </article>`;
}

function stringHash(value = '') {
  let hash = 2166136261;
  for (const char of String(value)) {
    hash ^= char.charCodeAt(0);
    hash = Math.imul(hash, 16777619);
  }
  return hash >>> 0;
}

function stableHomeShuffle(list = [], salt = '') {
  const seed = `${state.homeSessionSeed}|${salt}`;
  return [...list].sort((a, b) => stringHash(`${seed}|${trackKey(a)}`) - stringHash(`${seed}|${trackKey(b)}`));
}

function homeDisplayTrackReady(track) {
  const normalized = normalizeTrack(track);
  return cleanTitle(normalized) !== 'Tanpa Judul'
    && !isUnknownArtist(normalized.artist)
    && normalized.thumbnail
    && !String(normalized.thumbnail).includes('placeholder.svg');
}

function homeHeaderMarkup() {
  const count = Math.min(99, notificationUnreadCount());
  const logged = isLoggedIn();
  const status = normalizedAccountStatus();
  return `<header class="spotify-main-head home-main-head home-main-head-clean">
    <div class="home-account-identity">
      ${accountAvatarButtonMarkup('data-open-sidebar')}
      <strong class="home-account-name">${esc(currentAccountName())}</strong>
    </div>
    <div class="home-header-actions">
      ${logged ? `<button class="home-account-status status-${status}" data-account-status aria-label="Status akun ${esc(accountStatusLabel(status))}" title="${esc(accountStatusLabel(status))}"><span></span></button>` : ''}
      <button class="home-notification-btn" data-global-notifications aria-label="Notifikasi">${icon('bell')}<span class="system-activity-badge" ${count ? '' : 'hidden'}>${count || ''}</span></button>
    </div>
  </header>`;
}

function homeSkeletonRowMarkup() {
  return `<div class="home-skeleton-row"><span class="skeleton home-skeleton-cover"></span><span class="home-skeleton-copy"><i class="skeleton"></i><i class="skeleton"></i></span><span class="skeleton home-skeleton-dot"></span></div>`;
}

function homeSkeletonRailMarkup(count = 4, circles = false) {
  return `<div class="home-skeleton-rail">${Array.from({length:count},()=>`<div class="home-skeleton-card ${circles ? 'is-circle' : ''}"><span class="skeleton"></span><i class="skeleton"></i><i class="skeleton"></i></div>`).join('')}</div>`;
}

function renderHomeSkeleton() {
  view.innerHTML = `<div class="page spotify-home-page rich-home-page home-loading-page">
    ${homeHeaderMarkup()}
    <div class="home-shortcuts home-shortcuts-skeleton"><span class="skeleton"></span><span class="skeleton"></span></div>
    <section class="spotify-section home-loading-section"><span class="skeleton skeleton-kicker"></span><span class="skeleton skeleton-home-title"></span><div class="spotify-home-list home-skeleton-list">${Array.from({length:10},homeSkeletonRowMarkup).join('')}</div></section>
    <section class="spotify-section home-loading-section"><span class="skeleton skeleton-section-title"></span>${homeSkeletonRailMarkup(4)}</section>
    <section class="spotify-section home-loading-section"><span class="skeleton skeleton-section-title"></span>${homeSkeletonRailMarkup(4)}</section>
    <section class="spotify-section home-loading-section"><span class="skeleton skeleton-section-title"></span>${homeSkeletonRailMarkup(4,true)}</section>
    <section class="spotify-section home-loading-section"><span class="skeleton skeleton-section-title"></span>${homeSkeletonRailMarkup(4)}</section>
  </div>`;
  const sidebar = $('[data-open-sidebar]', view); if (sidebar) sidebar.onclick = showSideMenu;
  const activity = $('[data-global-notifications]', view); if (activity) activity.onclick = showGlobalNotificationsSheet;
  const accountStatus = $('[data-account-status]', view); if (accountStatus) accountStatus.onclick = showAccountStatusSheet;
}

function systemActivityListMarkup() {
  if (!state.systemActivity.length) return `<div class="system-activity-empty">${icon('bell')}<strong>Belum ada proses</strong><span>Status pencarian, metadata, audio, lirik, katalog, dan provider akan tampil di sini.</span></div>`;
  return state.systemActivity.slice(0,80).map(entry => {
    const status = ['success','warning','error','loading'].includes(entry.status) ? entry.status : 'success';
    const provider = [entry.provider, entry.keyNumber ? `API #${entry.keyNumber}` : ''].filter(Boolean).join(' • ');
    return `<article class="system-activity-item status-${status}">
      <span class="system-activity-status">${status === 'loading' ? '<span class="loading-ring"></span>' : status === 'success' ? icon('check-circle') : status === 'warning' ? icon('alert') : icon('close')}</span>
      <div><strong>${esc(entry.title)}</strong><p>${esc(entry.detail || 'Proses sistem')}</p><small>${esc(provider || 'DATZON Music')} • ${esc(activityTimeText(entry.timestamp))}</small>${entry.track ? `<em>${esc(entry.track)}</em>` : ''}</div>
    </article>`;
  }).join('');
}

function showSystemActivitySheet() {
  state.systemActivityOpen = true;
  state.systemActivityUnread = 0;
  saveSystemActivity();
  updateActivityBadge();
  openPlayerSheet(`<div class="system-activity-sheet">
    <div class="system-activity-head"><div><h2>Status Sistem</h2><p>Riwayat layanan dan proses DATZON Music</p></div><button data-clear-system-activity>Hapus</button></div>
    <div class="system-activity-list" data-system-activity-list>${systemActivityListMarkup()}</div>
  </div>`, 'system-activity-player-sheet', { kind: 'menu', initialSnap: 'full' });
  const clear = $('[data-clear-system-activity]', modalRoot);
  if (clear) clear.onclick = () => {
    state.systemActivity = [];
    state.systemActivityUnread = 0;
    saveSystemActivity();
    refreshSystemActivitySheet();
  };
  const observer = new MutationObserver(() => {
    if (!modalRoot.querySelector('.system-activity-player-sheet')) {
      state.systemActivityOpen = false;
      observer.disconnect();
    }
  });
  observer.observe(modalRoot, { childList: true });
}

function artistExplorerLoading(name) {
  return `<div class="artist-explorer-loading"><div class="artist-explorer-hero"><span class="skeleton skeleton-circle"></span><div><i class="skeleton"></i><i class="skeleton"></i></div></div><p>Memuat profil dan diskografi ${esc(name)}...</p>${Array.from({length:5},()=>'<div class="artist-track-skeleton"><span class="skeleton"></span><span><i class="skeleton"></i><i class="skeleton"></i></span></div>').join('')}</div>`;
}

function artistExplorerBody(profile, seedTrack) {
  const hero = profile.tracks[0]?.thumbnail || seedTrack?.thumbnail || 'assets/placeholder.svg';
  const details = [profile.type, profile.country, profile.genre].filter(Boolean).join(' • ');
  const tracks = fillHomeTracks(profile.tracks, seedTrack ? [seedTrack] : [], 10);
  return `<div class="artist-explorer">
    <div class="artist-explorer-hero"><img src="${esc(hero)}" alt="" onerror="this.src='assets/placeholder.svg'"><div><span>Artis</span><h3>${esc(profile.name)}</h3><p>${esc(details || profile.disambiguation || 'Metadata artis publik')}</p></div></div>
    ${profile.disambiguation ? `<p class="artist-note">${esc(profile.disambiguation)}</p>` : ''}
    <section><h4>Lagu populer</h4><div class="artist-track-list">${tracks.map((track,index)=>{const active=Boolean(state.current&&sameTrackIdentity(track,state.current));const playing=Boolean(active&&state.isPlaying);return `<button class="${active?'is-current':''} ${playing?'is-playing':''}" data-artist-track="${index}" data-playback-track-id="${esc(trackFirebaseId(track)||trackKey(track))}" data-playback-label="${esc(cleanTitle(track))}"><span class="artist-track-rank">${index+1}</span><img src="${esc(track.thumbnail)}" alt="" onerror="this.src='assets/placeholder.svg'"><span><strong>${esc(cleanTitle(track))}</strong><small>${esc(track.album || track.artist)}</small></span>${icon(playing?'pause':'play',playing?'':'fill')}</button>`;}).join('')}</div></section>
    <section><h4>Diskografi publik</h4>${profile.releases.length ? `<div class="artist-release-grid">${profile.releases.slice(0,10).map((release,index)=>`<button data-artist-release="${index}"><img src="${esc(release.cover)}" alt="" loading="lazy" onerror="this.src='assets/placeholder.svg'"><strong>${esc(release.title)}</strong><span>${esc([release.type, release.date].filter(Boolean).join(' • '))}</span></button>`).join('')}</div>` : '<p class="artist-empty">Diskografi belum tersedia dari sumber publik.</p>'}</section>
  </div>`;
}

function bindArtistExplorer(root, profile, seedTrack = null) {
  const tracks = fillHomeTracks(profile.tracks, seedTrack ? [seedTrack] : [], 10);
  $$('[data-artist-track]', root).forEach(button => button.onclick = async () => {
    const index = Number(button.dataset.artistTrack);
    const track = tracks[index];
    if (!track) return;
    if (state.current && sameTrackIdentity(track, state.current)) {
      await togglePlay();
      syncVisibleTrackPlaybackIcons(root);
      return;
    }
    closeModal(true);
    playTrack(track, tracks, index);
  });
  $$('[data-artist-release]', root).forEach(button => button.onclick = async () => {
    const release = profile.releases[Number(button.dataset.artistRelease)];
    if (!release) return;
    button.disabled = true;
    let id = /^[A-Za-z0-9]{22}$/.test(String(release.id || '')) ? String(release.id) : '';
    if (!id) id = String(release.spotifyUrl || release.sourceUrl || '').match(/open\.spotify\.com\/album\/([A-Za-z0-9]{22})/i)?.[1] || '';
    if (!id && spotifyCatalogAvailable()) {
      try { const payload=await window.DatzonSpotifyCatalog.search(`${profile.name} ${release.title}`,{limit:10}); const wanted=normalizeMatchText(release.title); const artist=normalizeMatchText(profile.name); const match=(payload?.albums?.items||[]).find(item=>normalizeMatchText(item?.name||'')===wanted&&(item?.artists||[]).some(value=>normalizeMatchText(value?.name||'')===artist)); id=String(match?.id||''); } catch {}
    }
    button.disabled = false;
    if (!id) return notify('Detail album Spotify belum ditemukan untuk rilis ini.');
    closeModal(true); openSpotifyCollection('album', id);
  });
}

function artistCount(value) {
  const number = Number(value || 0);
  if (!number) return '';
  return new Intl.NumberFormat('id-ID', { notation: 'compact', maximumFractionDigits: 1 }).format(number);
}


function playingBarsMarkup(className='') {
  return `<span class="playing-eq-bars ${esc(className)}" aria-hidden="true"><i></i><i></i><i></i><i></i></span>`;
}

function trackArtworkWithPlayingMarkup(src='', className='') {
  return `<span class="track-art-playing ${esc(className)}"><img src="${esc(src || 'assets/placeholder.svg')}" alt="" loading="lazy" onerror="this.src='assets/placeholder.svg'">${playingBarsMarkup('track-art-eq')}</span>`;
}

function setTrackPlayPauseIcon(button, active, playing) {
  if (!button) return;
  const shouldPause = Boolean(active && playing);
  const directIcon = [...button.children].reverse().find(child => child.matches?.('svg.icon'));
  if (directIcon) directIcon.outerHTML = icon(shouldPause ? 'pause' : 'play', shouldPause ? '' : 'fill');
  button.classList.toggle('is-current', Boolean(active));
  button.classList.toggle('is-playing', shouldPause);
  button.setAttribute('aria-current', active ? 'true' : 'false');
  const label = button.dataset.playbackLabel || '';
  if (label) button.setAttribute('aria-label', `${shouldPause ? 'Jeda' : active ? 'Lanjutkan' : 'Putar'} ${label}`);
}

function syncVisibleTrackPlaybackIcons(root = document) {
  const currentIdentity = state.current ? String(trackFirebaseId(state.current) || trackKey(state.current)) : '';
  $$('[data-playback-track-id]', root).forEach(button => {
    const active = Boolean(currentIdentity && button.dataset.playbackTrackId === currentIdentity);
    setTrackPlayPauseIcon(button, active, active && state.isPlaying);
  });
}

function artistTrackRows(profile) {
  return profile.tracks.map((track, index) => {
    const active = Boolean(state.current && sameTrackIdentity(track, state.current));
    const playing = Boolean(active && state.isPlaying);
    const duration = durationSeconds(track?.duration) > 0 ? track.duration : '';
    return `<button class="artist-page-track ${active ? 'is-current' : ''} ${playing ? 'is-playing' : ''}" data-artist-page-track="${index}" data-artist-track-id="${esc(trackFirebaseId(track) || trackKey(track))}" data-playback-track-id="${esc(trackFirebaseId(track) || trackKey(track))}" data-playback-label="${esc(cleanTitle(track))}" aria-current="${active ? 'true' : 'false'}">
      <span class="artist-page-rank">${index + 1}</span>
      ${trackArtworkWithPlayingMarkup(track.thumbnail,'artist-page-track-art')}
      <span><strong>${esc(cleanTitle(track))}</strong><small>${esc(track.album || track.artist)}${duration ? ` • ${esc(duration)}` : ''}</small></span>
      ${icon(playing ? 'pause' : 'play', playing ? '' : 'fill')}
    </button>`;
  }).join('');
}

function updateArtistPagePlayback() {
  const page = $('.spotify-artist-page', view);
  const profile = state.artistView?.profile;
  if (!page || !profile?.tracks?.length) return;
  $$('[data-artist-page-track]', page).forEach(button => {
    const track = profile.tracks[Number(button.dataset.artistPageTrack)];
    const active = Boolean(track && state.current && sameTrackIdentity(track, state.current));
    button.classList.toggle('is-current', active);
    button.classList.toggle('is-playing', active && state.isPlaying);
    button.setAttribute('aria-current', active ? 'true' : 'false');
    setTrackPlayPauseIcon(button, active, active && state.isPlaying);
  });
}

function renderArtistPage() {
  const data = state.artistView;
  const profile = data.profile;
  if (data.loading || !profile) {
    view.innerHTML = `<div class="page spotify-artist-page"><header class="artist-page-header"><button data-artist-back>${icon('arrow-left')}</button><strong>Profil artis</strong><span></span></header>
      <div class="artist-page-loading"><span class="skeleton artist-hero-skeleton"></span><span class="skeleton artist-name-skeleton"></span><span class="skeleton artist-copy-skeleton"></span>${Array.from({length:7},()=>'<div class="artist-track-skeleton"><span class="skeleton"></span><span><i class="skeleton"></i><i class="skeleton"></i></span></div>').join('')}</div></div>`;
    $('[data-artist-back]', view).onclick = () => navigateBack(state.artistReturnRoute || 'home');
    return;
  }
  const stats = [
    profile.followers ? `${artistCount(profile.followers)} pengikut` : '',
    profile.monthlyListeners ? `${artistCount(profile.monthlyListeners)} pendengar bulanan` : '',
    profile.popularity ? `Popularitas ${profile.popularity}` : ''
  ].filter(Boolean).join(' • ');
  const details = [...new Set(profile.details || [])].slice(0, 6).join(' • ');
  view.innerHTML = `<div class="page spotify-artist-page">
    <header class="artist-page-header"><button data-artist-back>${icon('arrow-left')}</button><strong>Profil artis</strong><button data-artist-refresh aria-label="Segarkan">${icon('refresh')}</button></header>
    <section class="artist-page-hero">
      <img src="${esc(profile.image)}" alt="${esc(profile.name)}" onerror="this.src='assets/placeholder.svg'">
      <div class="artist-page-hero-shade"></div>
      <div class="artist-page-hero-copy"><span>ARTIS</span><h1><b>${esc(profile.name)}</b>${profile.verified ? `<i class="artist-verified-badge" title="Artis terverifikasi" aria-label="Artis terverifikasi">✓</i>` : ''}</h1><p>${esc(stats || details || 'Metadata artis')}</p></div>
    </section>
    ${profile.spotifyUrl ? `<div class="artist-page-actions"><a href="${esc(profile.spotifyUrl)}" target="_blank" rel="noopener">${icon('external')}<span>Buka profil</span></a></div>` : ''}
    ${details ? `<div class="artist-genre-chips">${[...new Set(profile.details || [])].slice(0, 8).map(item => `<span>${esc(item)}</span>`).join('')}</div>` : ''}
    ${Array.isArray(data.collaborators) && data.collaborators.length ? `<section class="artist-page-collaborators"><div class="artist-section-head"><h2>Artis lainnya</h2><span>${data.collaborators.length} artis</span></div><div class="artist-collaborator-list">${data.collaborators.map((artist,index)=>`<button class="artist-collaborator-card ${artist.isCurrent ? 'is-current' : ''}" data-collaborator="${index}"><img src="${esc(artist.image || 'assets/placeholder.svg')}" alt="${esc(artist.name)}" loading="lazy" onerror="this.src='assets/placeholder.svg'"><strong>${esc(artist.name)}</strong></button>`).join('')}</div></section>` : ''}
    <section class="artist-page-about"><div class="artist-section-head"><h2>Tentang</h2>${profile.descriptionUrl ? `<a href="${esc(profile.descriptionUrl)}" target="_blank" rel="noopener">Sumber ${icon('external')}</a>` : ''}</div><p>${esc(profile.description || 'Deskripsi artis belum tersedia dari sumber publik.')}</p></section>
    <section class="artist-page-section"><div class="artist-section-head"><h2>Lagu artis</h2><span>${profile.tracks.length} lagu</span></div><div class="artist-page-track-list">${artistTrackRows(profile)}</div></section>
    <section class="artist-page-section"><div class="artist-section-head"><h2>Album dan single</h2><span>${profile.releases.length} rilis</span></div>
      ${profile.releases.length ? `<div class="artist-page-releases">${profile.releases.map((release,index)=>`<button data-artist-page-release="${index}"><img src="${esc(release.cover)}" alt="" loading="lazy" onerror="this.src='assets/placeholder.svg'"><strong>${esc(release.title)}</strong><span>${esc([release.type,release.date].filter(Boolean).join(' • '))}</span></button>`).join('')}</div>` : '<p class="artist-empty">Diskografi belum tersedia.</p>'}
    </section>
  </div>`;
  $('[data-artist-back]', view).onclick = () => navigateBack(state.artistReturnRoute || 'home');
  $('[data-artist-refresh]', view).onclick = () => loadArtistRoute(data.name, data.seedTrack, true);
  $$('[data-collaborator]', view).forEach(button => button.onclick = () => {
    const artist = data.collaborators?.[Number(button.dataset.collaborator)];
    if (artist?.name && !artist.isCurrent) openArtistExplorer(artist.name, data.seedTrack || artist.seedTrack || null);
  });
  $$('[data-artist-page-track]', view).forEach(button => button.onclick = async () => {
    const index = Number(button.dataset.artistPageTrack);
    const track = profile.tracks[index];
    if (!track) return;
    if (state.current && sameTrackIdentity(track, state.current)) {
      await togglePlay();
      updateArtistPagePlayback();
      return;
    }
    playTrack(track, profile.tracks, index);
  });
  $$('[data-artist-page-release]', view).forEach(button => button.onclick = async () => {
    const release = profile.releases[Number(button.dataset.artistPageRelease)];
    if (!release) return;
    button.disabled = true;
    const candidateUrls = [release?.spotifyUrl, release?.sourceUrl].filter(Boolean);
    let spotifyAlbumId = /^[A-Za-z0-9]{22}$/.test(String(release?.id || '')) ? String(release.id) : '';
    if (!spotifyAlbumId) {
      for (const value of candidateUrls) {
        const match = String(value).match(/open\.spotify\.com\/album\/([A-Za-z0-9]{22})/i);
        if (match) { spotifyAlbumId = match[1]; break; }
      }
    }
    if (!spotifyAlbumId && spotifyCatalogAvailable()) {
      try {
        const query = `${profile.name} ${release?.title || ''}`.trim();
        const payload = await window.DatzonSpotifyCatalog.search(query, { limit:10 });
        const wantedTitle = normalizeMatchText(release?.title || '');
        const wantedArtist = normalizeMatchText(profile.name);
        const albums = Array.isArray(payload?.albums?.items) ? payload.albums.items : [];
        const match = albums.find(item => normalizeMatchText(item?.name || '') === wantedTitle && (item?.artists || []).some(artist => normalizeMatchText(artist?.name || '') === wantedArtist));
        if (match?.id) spotifyAlbumId = String(match.id);
      } catch {}
    }
    button.disabled = false;
    if (spotifyAlbumId) { openSpotifyCollection('album', spotifyAlbumId); return; }
    notify('Detail album Spotify belum ditemukan untuk rilis ini.');
  });
}

async function loadCollaboratorCardProfile(credit, force = false) {
  const fallback = { name:credit?.name || 'Artis', image:'assets/placeholder.svg', spotifyId:credit?.id || '', spotifyUrl:credit?.url || '' };
  if (!credit?.name || !spotifyCatalogAvailable() || !window.DatzonSpotifyCatalog?.artistBasic) return fallback;
  try {
    const payload = await window.DatzonSpotifyCatalog.artistBasic(credit.id || credit.name, { force });
    const entity = payload?.artist ? spotifyCatalogArtistEntity(payload.artist) : null;
    if (!entity?.id || (!credit.id && normalizeMatchText(entity.name) !== normalizeMatchText(credit.name))) return fallback;
    return { name:entity.name || credit.name, image:entity.image || fallback.image, spotifyId:entity.id, spotifyUrl:entity.spotifyUrl || credit.url || '' };
  } catch { return fallback; }
}

async function loadArtistRoute(name, seedTrack = null, force = false) {
  const artist = String(name || '').trim();
  if (!artist) return;
  const originalSeed = seedTrack ? sanitizePlaybackTrack(seedTrack) : null;
  state.artistView = { name: artist, seedTrack: originalSeed, profile: null, collaborators: [], loading: true, error: '' };
  if (state.route !== 'artist') state.route = 'artist';
  render();
  try {
    // Kunci context multi-artist ke ID/URL Spotify exact dari track sebelum profil dimuat.
    // Dengan ini Naykilla/Tenxi/Jemsii tetap merupakan tiga profil terpisah saat berpindah kartu.
    const contextSeed = originalSeed ? await resolveExactArtistContextTrack(originalSeed, force) : null;
    if (state.artistView.name !== artist) return;
    state.artistView.seedTrack = contextSeed || originalSeed;

    const profile = await loadCombinedArtistProfile(artist, contextSeed || originalSeed, force);
    if (state.artistView.name !== artist) return;
    state.artistView = { name: artist, seedTrack: contextSeed || originalSeed, profile, collaborators: [], loading: false, error: '' };
    render();

    const contextCredits = (contextSeed || originalSeed) ? artistCreditEntries(contextSeed || originalSeed).slice(0, 6) : [];
    if (contextCredits.length > 1) {
      const currentName = normalizeMatchText(artist);
      const collaborators = (await Promise.all(contextCredits.map(async credit => {
        const isCurrent = normalizeMatchText(credit.name) === currentName;
        if (isCurrent) {
          return {
            name: profile?.name || credit.name,
            image: profile?.image || 'assets/placeholder.svg',
            spotifyId: profile?.spotifyId || credit.id || '',
            spotifyUrl: profile?.spotifyUrl || credit.url || '',
            seedTrack: contextSeed || originalSeed,
            isCurrent: true
          };
        }
        const collaboratorProfile = await loadCollaboratorCardProfile(credit, force);
        return {
          name: collaboratorProfile?.name || credit.name,
          image: collaboratorProfile?.image || 'assets/placeholder.svg',
          spotifyId: collaboratorProfile?.spotifyId || credit.id || '',
          spotifyUrl: collaboratorProfile?.spotifyUrl || credit.url || '',
          seedTrack: contextSeed || originalSeed,
          isCurrent: false
        };
      }))).filter(Boolean);
      if (state.artistView.name !== artist) return;
      state.artistView = { ...state.artistView, collaborators };
    }
  } catch (error) {
    if (state.artistView.name !== artist) return;
    const seed = state.artistView.seedTrack || originalSeed;
    state.artistView = { name: artist, seedTrack: seed, profile: {
      name: artist, image: seed?.thumbnail || 'assets/placeholder.svg', description: '', details: [], followers: 0, monthlyListeners: 0, verified: false, popularity: 0,
      spotifyUrl: '', spotifyConnected: false, tracks: seed ? [seed] : [], releases: [], source: 'Metadata lokal'
    }, collaborators: [], loading: false, error: error?.message || '' };
  }
  render();
}


function openArtistExplorer(name, seedTrack = null) {
  const artist = String(name || '').trim();
  if (!artist) return;
  state.artistReturnRoute = ['artist','player','lyrics'].includes(state.route) ? (state.lastPlayerRoute || 'home') : state.route;
  resetModalRoot();
  state.route = 'artist';
  syncBrowserRoute('artist', { artistName: artist });
  window.scrollTo({ top: 0, behavior: 'auto' });
  loadArtistRoute(artist, seedTrack, false);
}

/* V1.45.1 · Spotify Playlist playback + themed detail refinements */
const SPOTIFY_COLLECTION_CLIENT_TTL = 6 * 60 * 60 * 1000;
const SPOTIFY_TRACK_META_CLIENT_TTL = 24 * 60 * 60 * 1000;
const spotifyCollectionDetailCache = new Map();
const spotifyCollectionRequestMap = new Map();
const spotifyTrackMetaRequestMap = new Map();
let spotifyHomeCollectionsController = null;
let spotifyCollectionController = null;
let spotifyTrackCoverObserver = null;
let spotifyTrackMetaActive = 0;
const spotifyTrackMetaQueue = [];

function validSpotifyCollectionIdentity(type, id) {
  return ['album', 'playlist'].includes(String(type || '').toLowerCase()) && /^[A-Za-z0-9]{22}$/.test(String(id || ''));
}

function spotifyCollectionCanonicalUrl(type, id) {
  return validSpotifyCollectionIdentity(type, id) ? `https://open.spotify.com/${type}/${id}` : '';
}

function spotifyExactTrackUrl(track) {
  const id = String(track?.id || '').trim();
  if (!track?.exact || !/^[A-Za-z0-9]{22}$/.test(id)) return '';
  const url = String(track?.spotifyUrl || '');
  if (url === `https://open.spotify.com/track/${id}`) return url;
  return `https://open.spotify.com/track/${id}`;
}

function formatSpotifyCollectionDuration(ms = 0) {
  const totalMinutes = Math.max(0, Math.round((Number(ms) || 0) / 60000));
  if (!totalMinutes) return '';
  if (totalMinutes < 60) return `${totalMinutes} mnt`;
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  return `${hours} j${minutes ? ` ${minutes} mnt` : ''}`;
}

async function copyTextSafely(text) {
  const value = String(text || '');
  if (!value) return false;
  try {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(value);
      return true;
    }
  } catch {}
  try {
    const input = document.createElement('textarea');
    input.value = value;
    input.setAttribute('readonly', '');
    input.style.position = 'fixed';
    input.style.opacity = '0';
    document.body.appendChild(input);
    input.select();
    const ok = document.execCommand('copy');
    input.remove();
    return ok;
  } catch { return false; }
}

function spotifyCollectionSubtitle(item) {
  return `Playlist${item?.owner ? ` • ${item.owner}` : ' • Spotify'}`;
}

let spotifyHomePlaylistOrder = [];

function randomizedSpotifyHomePlaylists(items = state.spotifyHomeCollections) {
  const available = (items || []).filter(item => item?.type === 'playlist' && validSpotifyCollectionIdentity('playlist', item?.id) && item?.cover && item?.name);
  if (!available.length) return [];
  const ids = available.map(item => item.id);
  const sameSet = spotifyHomePlaylistOrder.length === ids.length && spotifyHomePlaylistOrder.every(id => ids.includes(id));
  if (!sameSet) spotifyHomePlaylistOrder = shuffleList(ids);
  const byId = new Map(available.map(item => [item.id, item]));
  return spotifyHomePlaylistOrder.map(id => byId.get(id)).filter(Boolean);
}

async function loadSpotifyHomeCollections(force = false) {
  const fresh = state.spotifyHomeCollections?.length && Date.now() - Number(state.spotifyHomeCollectionsAt || 0) < SPOTIFY_COLLECTION_CLIENT_TTL;
  if (!force && fresh) return state.spotifyHomeCollections;
  if (state.spotifyHomeCollectionsLoading) return state.spotifyHomeCollections;
  spotifyHomeCollectionsController?.abort();
  spotifyHomeCollectionsController = new AbortController();
  state.spotifyHomeCollectionsLoading = true;
  state.spotifyHomeCollectionsError = '';
  if (state.route === 'home' && !state.homeInitialLoading) renderHome();
  try {
    const response = await fetch('/api/spotify?action=home-collections', { signal: spotifyHomeCollectionsController.signal, headers: { accept: 'application/json' } });
    const payload = await response.json().catch(() => null);
    if (!response.ok || !payload?.ok || !Array.isArray(payload.items) || !payload.items.length) throw new Error(payload?.error || 'Koleksi Spotify tidak tersedia');
    state.spotifyHomeCollections = payload.items.filter(item => item?.type === 'playlist' && validSpotifyCollectionIdentity('playlist', item?.id));
    spotifyHomePlaylistOrder = [];
    state.spotifyHomeCollectionsAt = Date.now();
    storage.set('spotifyHomeCollectionsV1450', state.spotifyHomeCollections);
    storage.set('spotifyHomeCollectionsAtV1450', state.spotifyHomeCollectionsAt);
    return state.spotifyHomeCollections;
  } catch (error) {
    if (error?.name !== 'AbortError') state.spotifyHomeCollectionsError = 'Informasi Spotify sedang tidak tersedia.';
    return state.spotifyHomeCollections;
  } finally {
    state.spotifyHomeCollectionsLoading = false;
    if (state.route === 'home' && !state.homeInitialLoading) renderHome();
  }
}

function spotifyPlaylistImportHomeCard() {
  return `<button class="spotify-collection-card spotify-collection-import-card" data-home-import-playlist aria-label="Import playlist Spotify">
    <span class="spotify-collection-art spotify-import-art"><span>${icon('plus-circle')}</span></span>
    <strong>Import playlist</strong>
  </button>`;
}

function spotifyHomeCollectionsMarkup() {
  const items = randomizedSpotifyHomePlaylists();
  const importCard = spotifyPlaylistImportHomeCard();
  if (!items.length && state.spotifyHomeCollectionsLoading) {
    return `<section class="spotify-section spotify-collections-home-section"><div class="home-section-inline"><div><p class="spotify-kicker">PLAYLIST SPOTIFY</p><h2>Playlist Untukmu</h2></div></div><div class="spotify-collection-carousel">${importCard}${Array.from({length:5},()=>`<article class="spotify-collection-card is-skeleton"><span class="skeleton spotify-collection-skeleton-art"></span><span class="skeleton spotify-collection-skeleton-line"></span><span class="skeleton spotify-collection-skeleton-line short"></span></article>`).join('')}</div></section>`;
  }
  if (!items.length && state.spotifyHomeCollectionsError) {
    return `<section class="spotify-section spotify-collections-home-section"><div class="home-section-inline"><div><p class="spotify-kicker">PLAYLIST SPOTIFY</p><h2>Playlist Untukmu</h2></div></div><div class="spotify-collection-carousel">${importCard}</div><div class="spotify-collection-home-error"><span>${icon('queue')}</span><div><strong>Playlist Spotify sedang tidak tersedia.</strong><small>Kamu tetap bisa import playlist sendiri lewat link Spotify.</small></div><button data-retry-spotify-collections>Coba lagi</button></div></section>`;
  }
  if (!items.length) return `<section class="spotify-section spotify-collections-home-section"><div class="home-section-inline"><div><p class="spotify-kicker">PLAYLIST SPOTIFY</p><h2>Playlist Untukmu</h2></div></div><div class="spotify-collection-carousel">${importCard}</div></section>`;
  return `<section class="spotify-section spotify-collections-home-section"><div class="home-section-inline"><div><p class="spotify-kicker">PLAYLIST SPOTIFY</p><h2>Playlist Untukmu</h2></div></div><div class="spotify-collection-carousel">${importCard}${items.map(item => `<button class="spotify-collection-card" data-spotify-collection-type="playlist" data-spotify-collection-id="${esc(item.id)}"><span class="spotify-collection-art"><img src="${esc(item.cover)}" alt="Sampul ${esc(item.name)}" loading="lazy" decoding="async" onerror="this.src='assets/placeholder.svg'"><em>Playlist</em></span><strong>${esc(item.name)}</strong><small>${esc(spotifyCollectionSubtitle(item))}</small></button>`).join('')}</div></section>`;
}

function bindSpotifyHomeCollections(root = view) {
  $$('[data-spotify-collection-id]', root).forEach(button => button.onclick = () => {
    openSpotifyCollection(button.dataset.spotifyCollectionType, button.dataset.spotifyCollectionId);
  });
  $('[data-retry-spotify-collections]', root)?.addEventListener('click', () => loadSpotifyHomeCollections(true));
  $('[data-home-import-playlist]', root)?.addEventListener('click', () => {
    state.libraryFilter = 'playlist';
    storage.set('libraryFilter', 'playlist');
    navigate('library');
    window.setTimeout(() => showSpotifyPlaylistImportSheet(), 120);
  });
}

function spotifyPlaylistIdFromInput(value = '') {
  const raw = String(value || '').trim();
  if (/^[A-Za-z0-9]{22}$/.test(raw)) return raw;
  try {
    const url = new URL(raw);
    if (url.protocol !== 'https:' || !['open.spotify.com','play.spotify.com'].includes(url.hostname.toLowerCase())) return '';
    const parts = url.pathname.split('/').filter(Boolean);
    return parts[0]?.toLowerCase() === 'playlist' && /^[A-Za-z0-9]{22}$/.test(parts[1] || '') ? parts[1] : '';
  } catch {
    return '';
  }
}

function showSpotifyPlaylistImportSheet() {
  const sheet = openPlayerSheet(`<div class="spotify-playlist-import-sheet">
    <header><span>${icon('queue')}</span><div><small>KOLEKSI KAMU</small><h2>Import playlist Spotify</h2></div><button data-close-spotify-import aria-label="Tutup">${icon('close')}</button></header>
    <p>Tempel link playlist Spotify. DATZON hanya mengambil ID playlist di perangkat ini, lalu metadata playlist diproses melalui backend.</p>
    <label class="spotify-import-field"><span>LINK PLAYLIST SPOTIFY</span><div><input data-spotify-import-url type="url" inputmode="url" autocomplete="off" spellcheck="false" placeholder="https://open.spotify.com/playlist/..."><button data-spotify-import-paste type="button" aria-label="Tempel">${icon('copy')}</button></div></label>
    <small class="spotify-import-hint" data-spotify-import-hint>Contoh: https://open.spotify.com/playlist/37i9dQZF1DX0018ciYu6bM</small>
    <button class="spotify-import-submit" data-spotify-import-submit type="button">${icon('download')}<span>Import playlist</span></button>
  </div>`, 'spotify-playlist-import-player-sheet', { kind: 'adaptive', initialSnap: 'half' });
  const input = $('[data-spotify-import-url]', sheet);
  const submit = $('[data-spotify-import-submit]', sheet);
  const hint = $('[data-spotify-import-hint]', sheet);
  const setBusy = busy => {
    submit.disabled = busy;
    submit.classList.toggle('is-loading', busy);
    submit.innerHTML = busy ? '<span class="loading-ring" aria-hidden="true"></span><span>Memproses playlist...</span>' : `${icon('download')}<span>Import playlist</span>`;
    input.disabled = busy;
  };
  const process = async () => {
    const id = spotifyPlaylistIdFromInput(input.value);
    if (!id) {
      hint.textContent = 'Masukkan link playlist Spotify yang valid.';
      hint.classList.add('is-error');
      input.focus();
      return;
    }
    hint.classList.remove('is-error');
    hint.textContent = `ID ditemukan: ${id}`;
    setBusy(true);
    try {
      const payload = await requestSpotifyCollection('playlist', id);
      const imported = importSpotifyPlaylistToLibrary(payload.collection, payload.tracks);
      if (!imported) throw new Error('Lagu playlist belum siap ditambahkan');
      closeModal(true);
      openSpotifyCollection('playlist', id);
    } catch (error) {
      console.error('[DATZON import Spotify playlist]', error);
      setBusy(false);
      hint.textContent = 'Playlist belum bisa dimuat. Periksa link lalu coba lagi.';
      hint.classList.add('is-error');
      notify('Gagal memuat playlist Spotify', 'error');
    }
  };
  $('[data-close-spotify-import]', sheet).onclick = () => closeModal();
  $('[data-spotify-import-paste]', sheet).onclick = async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text) input.value = text.trim();
      input.focus();
    } catch {
      input.focus();
    }
  };
  submit.onclick = process;
  input.addEventListener('keydown', event => {
    if (event.key === 'Enter') { event.preventDefault(); process(); }
  });
  input.addEventListener('input', () => { hint.classList.remove('is-error'); });
  setTimeout(() => input.focus(), 80);
}

function spotifyCollectionCacheKey(type, id) { return `${type}:${id}`; }

function spotifyDetailTrackFromDatzon(track, collectionCover = '') {
  const id = spotifyTrackIdFromTrack(track);
  if (!/^[A-Za-z0-9]{22}$/.test(String(id || ''))) return null;
  const spotifyUrl = `https://open.spotify.com/track/${id}`;
  return {
    id,
    uri: `spotify:track:${id}`,
    title: cleanTitle(track),
    artists: String(track?.artist || '').split(/,|&| feat\.? /i).map(value => value.trim()).filter(Boolean),
    artistText: String(track?.artist || 'Spotify'),
    album: String(track?.album || ''),
    cover: String(track?.thumbnail || collectionCover || 'assets/placeholder.svg'),
    coverSource: track?.thumbnail ? 'track' : 'collection-fallback',
    durationMs: Math.max(0, Math.round(durationSeconds(track?.duration) * 1000)),
    spotifyUrl,
    exact: true,
    metadataUnavailable: false
  };
}

function directAnabotSpotifyTrack(item = {}, collectionCover = '') {
  const uri = String(item.uri || item.trackUri || item.track_uri || item?.track?.uri || '');
  const url = String(item.url || item.spotifyUrl || item.external_url || item?.external_urls?.spotify || '');
  const id = String(item.id || item.trackId || item.track_id || uri.match(/^spotify:track:([A-Za-z0-9]{22})$/)?.[1] || url.match(/open\.spotify\.com\/track\/([A-Za-z0-9]{22})/)?.[1] || '');
  if (!/^[A-Za-z0-9]{22}$/.test(id)) return null;
  const artistValue = item.artist || item.artistText || item.artists || item?.track?.artists || 'Spotify';
  const artists = Array.isArray(artistValue) ? artistValue.map(value => typeof value === 'string' ? value : value?.name).filter(Boolean) : String(artistValue).split(/,|&/).map(value => value.trim()).filter(Boolean);
  const durationValue = item.durationMs || item.duration_ms || item.duration || 0;
  const numericDuration = Number(durationValue);
  const durationMs = Number.isFinite(numericDuration) && numericDuration > 0
    ? (numericDuration > 10000 ? numericDuration : numericDuration * 1000)
    : durationSeconds(String(durationValue || '0:00')) * 1000;
  return {
    id,
    uri:`spotify:track:${id}`,
    title:String(item.name || item.title || item?.track?.name || 'Track Spotify'),
    artists,
    artistText:artists.join(', ') || 'Spotify',
    album:String(item.album?.name || item.album || ''),
    cover:String(item.cover || item.image || item.thumbnail || item.album?.images?.[0]?.url || collectionCover || 'assets/placeholder.svg'),
    coverSource:item.cover || item.image || item.thumbnail ? 'track' : 'collection-fallback',
    durationMs:Math.max(0,Math.round(durationMs || 0)),
    spotifyUrl:`https://open.spotify.com/track/${id}`,
    exact:true,
    metadataUnavailable:false
  };
}


function sylvaticaCollectionTrackToDetail(track, collectionCover = '') {
  const normalized = normalizeTrack(track);
  const id = spotifyTrackIdFromTrack(normalized);
  if (!/^[A-Za-z0-9]{22}$/.test(String(id || ''))) return null;
  const artists = extractArtistNames(normalized.artistNames, normalized.artist).length
    ? extractArtistNames(normalized.artistNames, normalized.artist)
    : String(normalized.artist || 'Spotify').split(/,|&/).map(item => item.trim()).filter(Boolean);
  return {
    id,
    uri:`spotify:track:${id}`,
    title:cleanTitle(normalized),
    artists,
    artistText:artists.join(', ') || normalized.artist || 'Spotify',
    album:String(normalized.album || ''),
    cover:String(normalized.thumbnail || collectionCover || 'assets/placeholder.svg'),
    coverSource:normalized.thumbnail ? 'track' : 'collection-fallback',
    durationMs:Math.max(0,Math.round(durationSeconds(normalized.duration) * 1000)),
    spotifyUrl:`https://open.spotify.com/track/${id}`,
    exact:true,
    metadataUnavailable:false
  };
}

async function requestSpotifyCollectionFromSylvatica(type, id) {
  if (!CONFIG.sylvaticaSpotyloaderEnabled || !['playlist','album'].includes(type)) throw new Error('Sylvatica collection tidak aktif');
  const canonical = spotifyCollectionCanonicalUrl(type, id);
  const data = await sylvaticaSpotyloaderFetch({ url:canonical, type }, 36000, `Sylvatica Spotyloader ${type}`);
  const post = data?.result?.post || data?.result || data?.data?.post || data?.data || data || {};
  const candidateTracks = collectSylvaticaSpotyloaderSearchTracks(post);
  const collectionCover = enhanceArtworkUrl(post?.image || post?.thumbnail || post?.cover || candidateTracks[0]?.thumbnail || 'assets/placeholder.svg');
  const tracks = dedupeTracks(candidateTracks).map(track => sylvaticaCollectionTrackToDetail(track, collectionCover)).filter(Boolean);
  if (!tracks.length) throw new Error('Sylvatica tidak mengirim track koleksi');
  const durationMs = tracks.reduce((sum, track) => sum + Number(track.durationMs || 0), 0);
  return {
    ok:true,
    fallback:'sylvatica-spotyloader',
    collection:{
      type,
      id,
      name:String(post?.name || post?.title || `${type === 'album' ? 'Album' : 'Playlist'} Spotify`),
      description:String(post?.description || ''),
      owner:String(post?.owner?.name || post?.owner || post?.artist || post?.author || ''),
      cover:collectionCover,
      spotifyUrl:canonical,
      totalTracks:Number(post?.total || post?.total_tracks || post?.totalTracks || tracks.length),
      durationMs,
      truncated:Number(post?.total || post?.total_tracks || post?.totalTracks || tracks.length) > tracks.length
    },
    tracks
  };
}

async function requestSpotifyCollectionFromAnabot(id) {
  const raw = await fetchAnabotPlaylist(id, true);
  const sourceTracks = Array.isArray(raw?.tracks) ? raw.tracks.slice(0, 100) : [];
  if (!raw || !sourceTracks.length) throw new Error('Metadata playlist tidak tersedia');
  const cover = String(raw.cover || raw.image || raw.thumbnail || raw.coverArt || '');
  const tracks = new Array(sourceTracks.length);
  for (let offset = 0; offset < sourceTracks.length; offset += 5) {
    const batch = sourceTracks.slice(offset, offset + 5);
    const settled = await Promise.allSettled(batch.map(async (item, index) => {
      const direct = directAnabotSpotifyTrack(item, cover);
      if (direct) return direct;
      const enriched = await enrichAnabotPlaylistTrack(item);
      return enriched ? spotifyDetailTrackFromDatzon(enriched, cover) : null;
    }));
    settled.forEach((result, index) => { if (result.status === 'fulfilled') tracks[offset + index] = result.value; });
  }
  const readyTracks = tracks.filter(Boolean);
  if (!readyTracks.length) throw new Error('Track playlist tidak dapat dikenali');
  const finalCover = cover || readyTracks[0]?.cover || 'assets/placeholder.svg';
  const durationMs = readyTracks.reduce((total, track) => total + Number(track.durationMs || 0), 0);
  return {
    ok:true,
    fallback:'anabot',
    collection:{
      type:'playlist', id, name:String(raw.name || raw.title || 'Playlist Spotify'),
      description:String(raw.description || ''), owner:String(raw.owner?.name || raw.owner || raw.creator || ''),
      cover:finalCover, spotifyUrl:spotifyCollectionCanonicalUrl('playlist', id),
      totalTracks:Number(raw.total_tracks || raw.totalTracks || sourceTracks.length), durationMs,
      truncated:Number(raw.total_tracks || raw.totalTracks || sourceTracks.length) > readyTracks.length
    },
    tracks:readyTracks
  };
}

async function requestSpotifyCollection(type, id, signal) {
  if (!['playlist','album'].includes(type)) throw new Error('Tipe koleksi Spotify tidak didukung');
  const key = spotifyCollectionCacheKey(type, id);
  if (spotifyCollectionDetailCache.has(key)) return spotifyCollectionDetailCache.get(key);
  if (spotifyCollectionRequestMap.has(key)) return spotifyCollectionRequestMap.get(key);
  const task = (async () => {
    if (type === 'album') {
      if (!spotifyCatalogAvailable()) throw new Error('Spotify Catalog belum tersedia');
      const payload = await window.DatzonSpotifyCatalog.album(id);
      if (!payload?.album) throw new Error('Album Spotify tidak tersedia');
      const normalized = spotifyCatalogAlbumPayload(payload.album);
      spotifyCollectionDetailCache.set(key, normalized);
      return normalized;
    }

    const metadataPromise = spotifyCatalogAvailable()
      ? window.DatzonSpotifyCatalog.playlist(id).catch(() => null)
      : Promise.resolve(null);
    let payload = null;
    try {
      const response = await fetch(`/api/spotify?action=collection&type=playlist&id=${encodeURIComponent(id)}`, { signal, headers: { accept: 'application/json' } });
      const candidate = await response.json().catch(() => null);
      if (response.ok && candidate?.ok && candidate?.collection && Array.isArray(candidate.tracks) && candidate.tracks.length) payload = candidate;
    } catch (error) {
      if (error?.name === 'AbortError') throw error;
    }
    if (!payload) {
      try { payload = await requestSpotifyCollectionFromSylvatica('playlist', id); }
      catch { payload = null; }
    }
    if (!payload) {
      try { payload = await requestSpotifyCollectionFromAnabot(id); }
      catch { payload = null; }
    }
    if (!payload?.ok || !payload?.collection || !Array.isArray(payload.tracks) || !payload.tracks.length) throw new Error('Gagal memuat tracklist playlist');
    const metadata = await metadataPromise;
    if (metadata?.playlist) payload = mergeSpotifyPlaylistMetadata(payload, metadata.playlist);
    payload = await enrichResolvedPlaylistTracksWithSpotify(payload);
    spotifyCollectionDetailCache.set(key, payload);
    return payload;
  })().finally(() => spotifyCollectionRequestMap.delete(key));
  spotifyCollectionRequestMap.set(key, task);
  return task;
}

async function loadSpotifyCollectionRoute(type, id, options = {}) {
  if (!['playlist','album'].includes(type)) {
    state.route = 'home';
    syncBrowserRoute('home', { replace: true });
    render();
    return;
  }
  if (!validSpotifyCollectionIdentity(type, id)) {
    state.spotifyCollectionView = { type, id, data: null, loading: false, error: 'Tautan Spotify tidak valid.' };
    render();
    return;
  }
  const key = spotifyCollectionCacheKey(type, id);
  const cached = spotifyCollectionDetailCache.get(key);
  if (cached) {
    state.spotifyCollectionView = { type, id, data: cached, loading: false, error: '' };
    state.route = type === 'album' ? 'spotify-album' : 'spotify-playlist';
    render();
    return;
  }
  spotifyCollectionController?.abort();
  spotifyCollectionController = new AbortController();
  state.spotifyCollectionView = { type, id, data: null, loading: true, error: '' };
  state.route = type === 'album' ? 'spotify-album' : 'spotify-playlist';
  if (!options.skipRender) render();
  try {
    const payload = await requestSpotifyCollection(type, id, spotifyCollectionController.signal);
    if (state.spotifyCollectionView.id !== id || state.spotifyCollectionView.type !== type) return;
    state.spotifyCollectionView = { type, id, data: payload, loading: false, error: '' };
    render();
  } catch (error) {
    if (error?.name === 'AbortError') return;
    if (state.spotifyCollectionView.id !== id || state.spotifyCollectionView.type !== type) return;
    state.spotifyCollectionView = { type, id, data: null, loading: false, error: 'Informasi Spotify sedang tidak tersedia.' };
    render();
  }
}

function openSpotifyCollection(type, id) {
  if (!['playlist','album'].includes(type) || !validSpotifyCollectionIdentity(type, id)) return;
  const previousRoute = state.route;
  if (previousRoute === 'home') state.spotifyCollectionReturnScroll = { route: 'home', y: Math.max(0, window.scrollY || document.documentElement.scrollTop || 0) };
  resetModalRoot();
  state.route = type === 'album' ? 'spotify-album' : 'spotify-playlist';
  syncBrowserRoute(state.route, { collectionType: type, collectionId: id, fromRoute: previousRoute });
  resetRouteViewport();
  loadSpotifyCollectionRoute(type, id).catch(() => {});
}

function spotifyCollectionLoadingMarkup(type) {
  return `<div class="page spotify-collection-detail-page ${type === 'playlist' ? 'is-playlist' : 'is-album'}"><header class="spotify-collection-route-head"><button data-spotify-collection-back>${icon('arrow-left')}</button><span></span></header><section class="spotify-collection-hero"><span class="skeleton spotify-detail-cover-skeleton"></span><div class="spotify-detail-copy"><span class="skeleton spotify-detail-title-skeleton"></span><span class="skeleton spotify-detail-subtitle-skeleton"></span><span class="skeleton spotify-detail-meta-skeleton"></span></div></section><div class="spotify-track-skeleton-list">${Array.from({length:8},()=>`<div><span class="skeleton"></span><p><b class="skeleton"></b><i class="skeleton"></i></p></div>`).join('')}</div></div>`;
}

function spotifyCollectionMetaLine(collection) {
  const parts = [];
  if (collection.type === 'album') {
    parts.push('Album');
    if (collection.releaseDate) {
      const date = new Date(collection.releaseDate);
      parts.push(Number.isNaN(date.getTime()) ? String(collection.releaseDate) : date.toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' }));
    }
  } else parts.push('Playlist');
  if (collection.totalTracks) parts.push(`${collection.totalTracks} lagu`);
  const duration = formatSpotifyCollectionDuration(collection.durationMs);
  if (duration) parts.push(duration);
  return parts.join(' • ');
}

function spotifyCollectionIsSaved(type, id) {
  return (state.spotifySavedCollections || []).some(item => item.type === type && item.id === id);
}

function toggleSpotifyCollectionSaved(collection) {
  const list = Array.isArray(state.spotifySavedCollections) ? [...state.spotifySavedCollections] : [];
  const index = list.findIndex(item => item.type === collection.type && item.id === collection.id);
  if (index >= 0) {
    list.splice(index, 1);
    notify('Koleksi Spotify dihapus dari simpanan');
  } else {
    list.unshift({ type: collection.type, id: collection.id, name: collection.name, cover: collection.cover, artist: collection.artist, owner: collection.owner, spotifyUrl: collection.spotifyUrl, savedAt: Date.now() });
    notify('Koleksi Spotify disimpan');
  }
  state.spotifySavedCollections = list.slice(0, 100);
  storage.set('spotifySavedCollectionsV1440', state.spotifySavedCollections);
  renderSpotifyCollectionPage();
}

function spotifyPlaylistTrackToDatzon(track, collection) {
  const exactUrl = spotifyExactTrackUrl(track);
  return normalizeTrack({
    id: track?.id || '',
    title: track?.title || 'Tanpa Judul',
    artist: track?.artistText || (Array.isArray(track?.artists) ? track.artists.join(', ') : '') || 'Spotify',
    duration: track?.durationMs ? formatTime(track.durationMs / 1000) : '0:00',
    thumbnail: track?.cover || collection?.cover || 'assets/placeholder.svg',
    album: track?.album || collection?.name || '',
    url: exactUrl,
    spotifyUrl: exactUrl,
    source: `Spotify Playlist • ${collection?.name || 'DATZON'}`
  });
}

function spotifyPlaylistQueue(collection, tracks = []) {
  return (tracks || []).map(track => spotifyPlaylistTrackToDatzon(track, collection)).filter(track => Boolean(spotifyTrackUrl(track)));
}

function spotifyPlaylistImported(collection) {
  if (!collection?.id) return false;
  return activePlaylists().some(playlist => playlist.spotifyPlaylistId === collection.id);
}

function importSpotifyPlaylistToLibrary(collection, tracks = []) {
  if (!collection?.id) return notify('Playlist Spotify tidak valid', 'error');
  const existing = activePlaylists().find(playlist => playlist.spotifyPlaylistId === collection.id);
  if (existing) {
    notify(`Playlist "${collection.name}" sudah ada di Koleksi Kamu`);
    return existing;
  }
  const importedTracks = spotifyPlaylistQueue(collection, tracks);
  if (!importedTracks.length) {
    notify('Lagu playlist belum siap ditambahkan', 'error');
    return null;
  }
  const now = Date.now();
  const playlist = normalizePlaylist({
    id: createPlaylistId(),
    name: collection.name || 'Playlist Spotify',
    ownerUid: isLoggedIn() ? state.auth.user.uid : '',
    sourceType: 'spotify',
    spotifyPlaylistId: collection.id,
    spotifyPlaylistUrl: spotifyCollectionCanonicalUrl('playlist', collection.id),
    createdAt: now,
    updatedAt: now,
    tracks: importedTracks
  });
  setActivePlaylists([playlist, ...activePlaylists()]);
  notify(`${importedTracks.length} lagu ditambahkan ke "${playlist.name}"`);
  if (state.route === 'spotify-playlist') renderSpotifyCollectionPage();
  else if (state.route === 'library') renderLibrary();
  return playlist;
}

async function shareSpotifyPlaylist(collection) {
  if (!collection?.id) return notify('Playlist tidak dapat dibagikan', 'error');
  const url = currentOriginUrl(`/playlist/${collection.id}`);
  const data = {
    title: `${collection.name || 'Playlist'} • DATZON Music`,
    text: `Dengerin playlist "${collection.name || 'ini'}" bareng di DATZON Music 🎧`,
    url
  };
  try {
    if (navigator.share) await navigator.share(data);
    else if (await copyTextSafely(url)) notify('Link playlist disalin');
  } catch (error) {
    if (error?.name !== 'AbortError') notify('Playlist belum berhasil dibagikan', 'error');
  }
}

async function shareSpotifyAlbum(collection) {
  if (!collection?.id) return notify('Album tidak dapat dibagikan', 'error');
  const url = currentOriginUrl(`/album/${collection.id}`);
  const data = { title:`${collection.name || 'Album'} • DATZON Music`, text:`Dengerin album “${collection.name || 'ini'}” di DATZON Music`, url };
  try { if (navigator.share) await navigator.share(data); else if (await copyTextSafely(url)) notify('Link album disalin'); }
  catch (error) { if (error?.name !== 'AbortError') notify('Album belum berhasil dibagikan', 'error'); }
}

function spotifyPlaylistPlayContext(collection) {
  return {
    eyebrow: 'MEMUTAR DARI PLAYLIST',
    label: collection?.name || 'Playlist Spotify',
    type: 'spotify-playlist',
    collectionId: collection?.id || ''
  };
}

function playSpotifyPlaylistTrack(track, index, collection, tracks = []) {
  const exactUrl = spotifyExactTrackUrl(track);
  if (!exactUrl) return notify('Link Spotify lagu belum tersedia', 'error');
  const queue = spotifyPlaylistQueue(collection, tracks);
  const selectedIndex = Math.max(0, queue.findIndex(item => spotifyTrackIdFromTrack(item) === track.id));
  const selected = queue[selectedIndex] || spotifyPlaylistTrackToDatzon(track, collection);
  playTrack(selected, queue.length ? queue : [selected], queue.length ? selectedIndex : 0, {
    playContext: spotifyPlaylistPlayContext(collection)
  });
}

function spotifyPlaylistPlaybackState(collection, tracks = []) {
  const currentId = spotifyTrackIdFromTrack(state.current);
  const belongs = Boolean(currentId && (tracks || []).some(track => String(track?.id || '') === currentId));
  const preparing = Boolean(belongs && (state.playerPreparing || state.resolving || pendingAutoplayTimer));
  const playing = Boolean(belongs && state.isPlaying && !audio.paused && !audio.ended);
  return { belongs, preparing, playing, currentId };
}

async function toggleSpotifyPlaylistMainPlayback(collection, tracks = []) {
  const playback = spotifyPlaylistPlaybackState(collection, tracks);
  if (playback.preparing) return;
  if (playback.belongs) {
    try {
      await togglePlay();
    } catch (error) {
      notify(error?.message || 'Pemutar belum siap', 'error');
    } finally {
      updateSpotifyCollectionPlayback();
    }
    return;
  }
  playSpotifyPlaylistFromStart(collection, tracks);
}

function playSpotifyPlaylistFromStart(collection, tracks = []) {
  const queue = spotifyPlaylistQueue(collection, tracks);
  if (!queue.length) return notify('Lagu playlist belum siap diputar', 'error');
  playTrack(queue[0], queue, 0, {
    stayOnRoute: true,
    playContext: spotifyPlaylistPlayContext(collection)
  });
}

function spotifyTrackRowMarkup(track, index, collection) {
  const exactUrl = spotifyExactTrackUrl(track);
  const unavailable = !exactUrl;
  const needsMeta = Boolean(track.id && track.coverSource !== 'track');
  const currentId = spotifyTrackIdFromTrack(state.current);
  const active = Boolean(track.id && currentId && track.id === currentId);
  const playing = active && state.isPlaying;
  const art = `<span class="track-art-playing spotify-playlist-track-art"><img src="${esc(track.cover || collection.cover || 'assets/placeholder.svg')}" alt="" loading="lazy" decoding="async" ${needsMeta ? `data-spotify-cover-id="${esc(track.id)}"` : ''} onerror="this.src='assets/placeholder.svg'">${playingBarsMarkup('track-art-eq')}</span>`;
  return `<button class="spotify-collection-track spotify-playlist-track ${unavailable ? 'is-unavailable' : ''} ${active ? 'is-current' : ''} ${playing ? 'is-playing' : ''}" data-spotify-track-index="${index}" data-spotify-track-id="${esc(track.id || '')}" aria-current="${active ? 'true' : 'false'}" ${unavailable ? 'aria-disabled="true"' : ''}>${art}<span><strong>${esc(track.title)}</strong><small>${esc(track.artistText || 'Spotify')}</small></span><em>${track.durationMs ? esc(formatTime(track.durationMs / 1000)) : ''}</em><i data-spotify-track-more="${index}" role="button" aria-label="Pilihan lagu">${icon('more')}</i></button>`;
}

function updateSpotifyPlaylistGradientCenter() {
  const page = $('.spotify-collection-detail-page.is-playlist', view);
  const actions = $('.spotify-collection-actions', page);
  if (!page || !actions) return;
  const pageRect = page.getBoundingClientRect();
  const actionRect = actions.getBoundingClientRect();
  const center = Math.max(260, actionRect.top - pageRect.top + actionRect.height / 2);
  page.style.setProperty('--playlist-gradient-center', `${Math.round(center)}px`);
}

function updateSpotifyCollectionPlayback() {
  const payload = state.spotifyCollectionView?.data;
  const collection = payload?.collection;
  const tracks = payload?.tracks || [];
  const currentId = spotifyTrackIdFromTrack(state.current);

  const albumPage = $('.spotify-collection-detail-page.is-album', view);
  if (albumPage && collection?.type === 'album') {
    let belongs = false;
    $$('[data-spotify-album-track-id]', albumPage).forEach(row => {
      const active = Boolean(currentId && row.dataset.spotifyAlbumTrackId === currentId);
      if (active) belongs = true;
      row.classList.toggle('is-current', active);
      row.classList.toggle('is-playing', active && state.isPlaying);
      row.setAttribute('aria-current', active ? 'true' : 'false');

    });
    const main = $('[data-play-spotify-album]', albumPage);
    if (main) {
      const playing = Boolean(belongs && state.isPlaying);
      const preparing = Boolean(belongs && state.resolving);
      main.classList.toggle('is-playing', playing);
      main.classList.toggle('is-loading', preparing);
      main.disabled = preparing;
      main.setAttribute('aria-busy', preparing ? 'true' : 'false');
      main.setAttribute('aria-label', preparing ? 'Menyiapkan lagu album' : playing ? 'Jeda album' : belongs ? 'Lanjutkan album' : 'Putar album');
      main.innerHTML = preparing ? icon('refresh') : icon(playing ? 'pause' : 'play', playing ? '' : 'fill');
    }
  }

  const page = $('.spotify-collection-detail-page.is-playlist', view);
  if (!page || collection?.type !== 'playlist') return;
  const playback = spotifyPlaylistPlaybackState(collection, tracks);
  $$('[data-spotify-track-id]', page).forEach(row => {
    const active = Boolean(playback.currentId && row.dataset.spotifyTrackId === playback.currentId);
    row.classList.toggle('is-current', active);
    row.classList.toggle('is-playing', active && playback.playing);
    row.setAttribute('aria-current', active ? 'true' : 'false');
  });
  const main = $('[data-play-spotify-playlist]', page);
  if (main) {
    main.classList.toggle('is-playing', playback.playing);
    main.classList.toggle('is-loading', playback.preparing);
    main.disabled = playback.preparing;
    main.setAttribute('aria-busy', playback.preparing ? 'true' : 'false');
    main.setAttribute('aria-label', playback.preparing ? 'Menyiapkan lagu' : playback.playing ? 'Jeda playlist' : playback.belongs ? 'Lanjutkan playlist' : 'Putar playlist');
    main.innerHTML = playback.preparing ? icon('refresh') : icon(playback.playing ? 'pause' : 'play', playback.playing ? '' : 'fill');
  }
}

function spotifyAlbumTrackToDatzon(track, collection) {
  const artists=Array.isArray(track?.artists)?track.artists:[];
  return normalizeTrack({
    id:track?.id||'', title:track?.title||'Track Spotify', artist:track?.artistText||artists.join(', ')||collection?.artist||'Spotify', artistNames:artists,
    duration:track?.durationMs?formatTime(track.durationMs/1000):'', thumbnail:collection?.cover||'assets/placeholder.svg', album:collection?.name||'',
    url:track?.spotifyUrl|| (track?.id?`https://open.spotify.com/track/${track.id}`:''), explicit:Boolean(track?.explicit), isrc:track?.isrc||'', source:'Spotify Album metadata'
  });
}
function playSpotifyAlbumTrack(track,index,collection,tracks=[]){
  const queue=(tracks||[]).map(item=>spotifyAlbumTrackToDatzon(item,collection));
  const selected=queue[index]; if(!selected)return;
  playTrack(selected,queue,index,{playContext:{eyebrow:'MEMAINKAN DARI ALBUM',label:collection?.name||'Album Spotify'}});
}

function renderSpotifyCollectionPage() {
  const current = state.spotifyCollectionView || {};
  const type = current.type === 'album' ? 'album' : 'playlist';
  if (current.loading) {
    view.innerHTML = spotifyCollectionLoadingMarkup(type);
    $('[data-spotify-collection-back]', view)?.addEventListener('click', () => navigateBack('home'));
    return;
  }
  if (current.error || !current.data?.collection || current.data.collection.type !== type) {
    const label=type==='album'?'album':'playlist';
    view.innerHTML = `<div class="page spotify-collection-detail-page is-${label}"><header class="spotify-collection-route-head"><button data-spotify-collection-back>${icon('arrow-left')}</button><span></span></header><div class="spotify-collection-error"><span>${icon('alert')}</span><h2>Gagal memuat ${label}</h2><p>${esc(current.error || 'Informasi Spotify sedang tidak tersedia.')}</p><button data-retry-spotify-detail>Coba lagi</button></div></div>`;
    $('[data-spotify-collection-back]', view)?.addEventListener('click', () => navigateBack('home'));
    $('[data-retry-spotify-detail]', view)?.addEventListener('click', () => loadSpotifyCollectionRoute(type, current.id));
    return;
  }
  const { collection, tracks = [] } = current.data;

  if(type==='album'){
    const albumType=collection.albumType==='single'?'Single':collection.albumType==='compilation'?'Compilation':'Album';
    const release=collection.releaseDate ? collection.releaseDate : '';
    const copyrights=(collection.copyrights||[]).map(item=>item?.text||item).filter(Boolean);
    const albumArtists=(collection.artists||String(collection.artist||collection.owner||'Spotify').split(',')).map(value=>String(value||'').trim()).filter(Boolean);
    const artistIds=Array.isArray(collection.artistIds)?collection.artistIds:[];
    const artistUrls=Array.isArray(collection.artistUrls)?collection.artistUrls:[];
    const currentId=spotifyTrackIdFromTrack(state.current);
    const belongs=Boolean(currentId&&tracks.some(track=>String(track?.id||'')===currentId));
    const playing=Boolean(belongs&&state.isPlaying);
    view.innerHTML=`<div class="page spotify-collection-detail-page is-album">
      <header class="spotify-collection-route-head"><button data-spotify-collection-back aria-label="Kembali">${icon('arrow-left')}</button><strong>${esc(collection.name)}</strong></header>
      <section class="spotify-album-hero" data-album-hero>
        <div class="spotify-album-hero-cover"><img src="${esc(collection.cover||'assets/placeholder.svg')}" alt="Sampul ${esc(collection.name)}" onerror="this.src='assets/placeholder.svg'"></div>
        <div class="spotify-album-copy"><p class="spotify-kicker">${esc(albumType.toUpperCase())}</p><h1>${esc(collection.name)}</h1><div class="spotify-album-artists">${albumArtists.map((name,index)=>`<button type="button" data-open-album-artist="${index}">${esc(name)}</button>`).join('<span> • </span>')}</div><p>${esc([albumType,release,collection.totalTracks?`${collection.totalTracks} lagu`:''].filter(Boolean).join(' • '))}</p></div>
      </section>
      <div class="spotify-collection-actions spotify-album-actions"><button class="spotify-round-action" data-share-spotify-album aria-label="Bagikan album">${icon('share')}</button><button class="spotify-round-action" data-open-spotify-album aria-label="Buka di Spotify">${icon('external')}</button><span></span><button class="spotify-main-play ${playing?'is-playing':''}" data-play-spotify-album aria-label="${playing?'Jeda album':'Putar album'}">${icon(playing?'pause':'play',playing?'':'fill')}</button></div>
      <section class="spotify-album-track-list">${tracks.map((track,index)=>{const active=Boolean(currentId&&String(track?.id||'')===currentId);return `<button class="spotify-album-track-row ${active?'is-current':''} ${active&&state.isPlaying?'is-playing':''}" data-spotify-album-track-index="${index}" data-spotify-album-track-id="${esc(track.id||'')}" data-spotify-album-track-number="${track.trackNumber||index+1}" aria-current="${active?'true':'false'}"><em class="spotify-album-track-number"><span class="album-track-index">${esc(track.trackNumber||index+1)}</span>${playingBarsMarkup('album-playing-bars')}</em><span><strong>${esc(track.title)}</strong><small>${track.explicit?'<b class="explicit-badge">E</b> ':''}${esc(track.artistText||collection.artist||'')}</small></span><time>${track.durationMs?esc(formatTime(track.durationMs/1000)):''}</time><i data-spotify-album-more="${index}">${icon('more')}</i></button>`;}).join('')}</section>
      <footer class="spotify-album-footer">${collection.upc?`<small>UPC ${esc(collection.upc)}</small>`:''}${copyrights.map(text=>`<p>${esc(text)}</p>`).join('')}</footer>
    </div>`;
    $('[data-spotify-collection-back]',view)?.addEventListener('click',()=>navigateBack('home'));
    $('[data-share-spotify-album]',view)?.addEventListener('click',()=>shareSpotifyAlbum(collection));
    $('[data-open-spotify-album]',view)?.addEventListener('click',()=>showSpotifyCollectionConfirmation(collection));
    $('[data-play-spotify-album]',view)?.addEventListener('click',async()=>{
      const activeId=spotifyTrackIdFromTrack(state.current); const activeBelongs=Boolean(activeId&&tracks.some(track=>String(track?.id||'')===activeId));
      if(activeBelongs){await togglePlay();updateSpotifyCollectionPlayback();return;}
      if(tracks[0])playSpotifyAlbumTrack(tracks[0],0,collection,tracks);
    });
    $$('[data-open-album-artist]',view).forEach(button=>button.onclick=()=>{
      const index=Number(button.dataset.openAlbumArtist); const name=albumArtists[index]; if(!name)return;
      const artistId=artistIds[index]||''; const artistUrl=artistUrls[index]||(artistId?`https://open.spotify.com/artist/${artistId}`:'');
      const seed=normalizeTrack({title:collection.name,artist:name,artistNames:[name],artistId,artistIds:artistId?[artistId]:[],artistUrls:artistUrl?[artistUrl]:[],artistDetails:[{name,id:artistId,external_url:artistUrl}],thumbnail:collection.cover||'assets/placeholder.svg',album:collection.name,source:'Spotify album metadata'});
      openArtistExplorer(name,seed);
    });
    $$('[data-spotify-album-track-index]',view).forEach(row=>row.onclick=async event=>{const index=Number(row.dataset.spotifyAlbumTrackIndex);const track=tracks[index];if(!track)return;if(event.target.closest('[data-spotify-album-more]')){event.stopPropagation();showTrackMenu(spotifyAlbumTrackToDatzon(track,collection));return;}const activeId=spotifyTrackIdFromTrack(state.current);if(activeId&&String(track.id||'')===activeId){await togglePlay();updateSpotifyCollectionPlayback();return;}playSpotifyAlbumTrack(track,index,collection,tracks);});
    requestAnimationFrame(()=>{window.DatzonDominantColor?.apply?.($('[data-album-hero]',view),collection.cover);updateSpotifyCollectionPlayback();});
    return;
  }

  const imported = spotifyPlaylistImported(collection);
  const ownerLine = collection.owner || 'Spotify';
  const description = collection.description ? `<p class="spotify-collection-description">${esc(collection.description)}</p>` : '';
  const truncation = collection.truncated ? `<p class="spotify-track-limit-note">Daftar lagu mengikuti hasil resolver playlist DATZON.</p>` : '';
  view.innerHTML = `<div class="page spotify-collection-detail-page is-playlist">
    <header class="spotify-collection-route-head"><button data-spotify-collection-back aria-label="Kembali">${icon('arrow-left')}</button><strong>${esc(collection.name)}</strong></header>
    <section class="spotify-collection-hero">
      <div class="spotify-collection-hero-art"><img src="${esc(collection.cover || 'assets/placeholder.svg')}" alt="Sampul ${esc(collection.name)}" onerror="this.src='assets/placeholder.svg'"></div>
      <div class="spotify-detail-copy"><p class="spotify-kicker">PLAYLIST</p><h1>${esc(collection.name)}</h1><div class="spotify-collection-owner"><strong>${esc(ownerLine)}</strong></div>${description}<p class="spotify-collection-meta">${esc(spotifyCollectionMetaLine(collection))}</p>${collection.followers?`<small>${esc(artistCount(collection.followers))} pengikut</small>`:''}</div>
    </section>
    <div class="spotify-collection-actions"><button class="spotify-round-action ${imported ? 'is-saved' : ''}" data-import-spotify-playlist aria-label="${imported ? 'Sudah di Koleksi Kamu' : 'Tambahkan ke Koleksi Kamu'}">${icon(imported ? 'check-circle' : 'plus-circle')}</button><button class="spotify-round-action" data-share-spotify-playlist aria-label="Bagikan playlist">${icon('share')}</button><span></span><button class="spotify-main-play" data-play-spotify-playlist aria-label="Putar playlist">${icon('play','fill')}</button></div>
    <section class="spotify-collection-track-list">${tracks.length ? tracks.map((track,index)=>spotifyTrackRowMarkup(track,index,collection)).join('') : `<div class="spotify-collection-empty">Track belum tersedia.</div>`}</section>
    ${truncation}
    <p class="spotify-collection-total">${esc([collection.totalTracks ? `${collection.totalTracks} lagu` : '', formatSpotifyCollectionDuration(collection.durationMs)].filter(Boolean).join(' • '))}</p>
  </div>`;
  $('[data-spotify-collection-back]', view)?.addEventListener('click', () => navigateBack('home'));
  $('[data-import-spotify-playlist]', view)?.addEventListener('click', () => importSpotifyPlaylistToLibrary(collection, tracks));
  $('[data-share-spotify-playlist]', view)?.addEventListener('click', () => shareSpotifyPlaylist(collection));
  $('[data-play-spotify-playlist]', view)?.addEventListener('click', () => toggleSpotifyPlaylistMainPlayback(collection, tracks));
  $$('[data-spotify-track-index]', view).forEach(row => row.onclick = event => {
    const index = Number(row.dataset.spotifyTrackIndex); const track = tracks[index]; if (!track) return;
    if (event.target.closest('[data-spotify-track-more]')) { event.stopPropagation(); const datzonTrack=spotifyPlaylistTrackToDatzon(track,collection); if(!spotifyTrackUrl(datzonTrack))return notify('Link Spotify lagu belum tersedia','error'); showTrackMenu(datzonTrack); return; }
    playSpotifyPlaylistTrack(track, index, collection, tracks);
  });
  bindSpotifyPlaylistLazyCovers(view, current.data); updateSpotifyCollectionPlayback(); requestAnimationFrame(() => { updateSpotifyPlaylistGradientCenter(); setTimeout(updateSpotifyPlaylistGradientCenter, 120); });
}

function showSpotifyCollectionConfirmation(collection) {
  const typeLabel = collection?.type === 'album' ? 'album' : 'playlist';
  const url = spotifyCollectionCanonicalUrl(collection.type, collection.id);
  if (!url) return notify('Tautan Spotify belum tersedia', 'error');
  const sheet = openPlayerSheet(`<div class="spotify-external-confirm"><header><img src="${esc(collection.cover || 'assets/placeholder.svg')}" alt=""><div><small>SPOTIFY</small><h2>${esc(collection.name)}</h2><p>${esc(collection.artist || collection.owner || 'Spotify')}</p></div><button data-close-spotify-confirm>${icon('close')}</button></header><p class="spotify-confirm-question">Buka ${typeLabel} ini di Spotify?</p><code>${esc(url)}</code><div class="spotify-confirm-actions"><button data-copy-spotify-link>${icon('copy')} Salin link</button><button data-cancel-spotify-open>Batal</button><button class="primary" data-confirm-spotify-open>Buka Spotify</button></div></div>`, 'spotify-confirm-player-sheet', { kind:'compact', initialSnap:'half' });
  $('[data-close-spotify-confirm]', sheet).onclick = () => closeModal();
  $('[data-cancel-spotify-open]', sheet).onclick = () => closeModal();
  $('[data-copy-spotify-link]', sheet).onclick = async () => { if (await copyTextSafely(url)) notify('Link Spotify disalin'); else notify('Link Spotify tidak dapat disalin', 'error'); };
  $('[data-confirm-spotify-open]', sheet).onclick = () => { window.open(url, '_blank', 'noopener,noreferrer'); closeModal(true); };
}

function trimSpotifyTrackMetaCache() {
  const entries = Object.entries(state.spotifyTrackMetaCache || {}).sort((a,b) => Number(b[1]?.at || 0) - Number(a[1]?.at || 0)).slice(0, 160);
  state.spotifyTrackMetaCache = Object.fromEntries(entries);
  storage.set('spotifyTrackMetaV1440', state.spotifyTrackMetaCache);
}

async function fetchSpotifyTrackMeta(id) {
  if (!/^[A-Za-z0-9]{22}$/.test(String(id || ''))) return null;
  const cached = state.spotifyTrackMetaCache?.[id];
  if (cached?.track && Date.now() - Number(cached.at || 0) < SPOTIFY_TRACK_META_CLIENT_TTL) return cached.track;
  if (spotifyTrackMetaRequestMap.has(id)) return spotifyTrackMetaRequestMap.get(id);
  const task = (async () => {
    const response = await fetch(`/api/spotify?action=track-meta&id=${encodeURIComponent(id)}`, { headers:{ accept:'application/json' } });
    const payload = await response.json().catch(() => null);
    if (!response.ok || !payload?.ok || !payload?.track) throw new Error(payload?.error || 'Metadata track tidak tersedia');
    state.spotifyTrackMetaCache[id] = { at: Date.now(), track: payload.track };
    trimSpotifyTrackMetaCache();
    return payload.track;
  })().catch(() => null).finally(() => spotifyTrackMetaRequestMap.delete(id));
  spotifyTrackMetaRequestMap.set(id, task);
  return task;
}

function enqueueSpotifyTrackMeta(id, callback) {
  spotifyTrackMetaQueue.push({ id, callback });
  pumpSpotifyTrackMetaQueue();
}

function pumpSpotifyTrackMetaQueue() {
  while (spotifyTrackMetaActive < 4 && spotifyTrackMetaQueue.length) {
    const job = spotifyTrackMetaQueue.shift();
    spotifyTrackMetaActive += 1;
    fetchSpotifyTrackMeta(job.id).then(track => job.callback?.(track)).finally(() => {
      spotifyTrackMetaActive -= 1;
      pumpSpotifyTrackMetaQueue();
    });
  }
}

function bindSpotifyPlaylistLazyCovers(root, payload) {
  spotifyTrackCoverObserver?.disconnect();
  const images = $$('img[data-spotify-cover-id]', root);
  if (!images.length) return;
  const applyTrackMeta = (id, meta) => {
    if (!meta) return;
    const currentPayload = state.spotifyCollectionView?.data;
    if (currentPayload?.tracks) {
      const index = currentPayload.tracks.findIndex(track => track.id === id);
      if (index >= 0) currentPayload.tracks[index] = { ...currentPayload.tracks[index], ...meta, cover: meta.cover || currentPayload.tracks[index].cover, coverSource: meta.cover ? 'track' : currentPayload.tracks[index].coverSource };
    }
    if (meta.cover) $$(`img[data-spotify-cover-id="${id}"]`, root).forEach(img => { img.src = meta.cover; img.removeAttribute('data-spotify-cover-id'); });
  };
  if (!('IntersectionObserver' in window)) {
    images.slice(0, 8).forEach(img => enqueueSpotifyTrackMeta(img.dataset.spotifyCoverId, meta => applyTrackMeta(img.dataset.spotifyCoverId, meta)));
    return;
  }
  spotifyTrackCoverObserver = new IntersectionObserver(entries => entries.forEach(entry => {
    if (!entry.isIntersecting) return;
    const img = entry.target;
    spotifyTrackCoverObserver.unobserve(img);
    const id = img.dataset.spotifyCoverId;
    if (!id) return;
    enqueueSpotifyTrackMeta(id, meta => applyTrackMeta(id, meta));
  }), { root: null, rootMargin: '520px 0px', threshold: .01 });
  images.forEach(img => spotifyTrackCoverObserver.observe(img));
}


function renderHome() {
  if (state.homeInitialLoading) { renderHomeSkeleton(); return; }
  const knownFallbacks = FALLBACK_TRACKS.map(normalizeTrack).filter(homeDisplayTrackReady);
  const rawCatalog = filterHiddenSuggestions(state.catalog.length ? state.catalog : knownFallbacks).filter(homeDisplayTrackReady);
  const rawPublicSongs = filterHiddenSuggestions(state.homeDiscovery?.topSongs || []).filter(homeDisplayTrackReady);
  const rawPublicAlbums = filterHiddenSuggestions(state.homeDiscovery?.topAlbums || []).filter(homeDisplayTrackReady);
  const catalog = stableHomeShuffle(dedupeTracks([...rawCatalog, ...knownFallbacks]), 'catalog');
  const publicSongs = stableHomeShuffle(dedupeTracks([...rawPublicSongs, ...catalog]), 'popular');
  const publicAlbums = stableHomeShuffle(dedupeTracks([...rawPublicAlbums, ...publicSongs]), 'albums');
  const discoveryBase = stableHomeShuffle(dedupeTracks([...publicSongs, ...catalog, ...knownFallbacks]), 'discovery');
  const preferredKeys = (state.preferredArtists || []).map(normalizeMatchText).filter(Boolean);
  const preferredTracks = preferredKeys.length ? discoveryBase.filter(track => preferredKeys.some(key => normalizeMatchText(track.artist).includes(key))) : [];
  const listening = fillHomeTracks(dedupeTracks([...preferredTracks, ...catalog]), discoveryBase, 10);
  const trending = fillHomeTracks(publicSongs.length ? publicSongs : discoveryBase, discoveryBase, 12);
  const recentCutoff = Date.now() - 1000 * 60 * 60 * 24 * 365;
  const releaseCandidates = dedupeTracks([...publicAlbums, ...publicSongs, ...catalog])
    .sort((a,b) => new Date(b.release_date || 0) - new Date(a.release_date || 0))
    .filter(track => !track.release_date || new Date(track.release_date).getTime() >= recentCutoff);
  const newReleases = fillHomeTracks(releaseCandidates, discoveryBase, 12);
  const top50Source = publicSongs.length ? publicSongs : discoveryBase;
  const top50 = fillHomeTracks(top50Source.slice(10), top50Source, 20);
  const localRecentArtists = [];
  const localArtistSeen = new Set();
  (state.preferredArtists || []).forEach(name => {
    const value = String(name || '').trim();
    const key = normalizeMatchText(value);
    const track = discoveryBase.find(item => normalizeMatchText(item.artist) === key) || catalog.find(item => normalizeMatchText(item.artist) === key);
    if (!value || !track || localArtistSeen.has(key)) return;
    localArtistSeen.add(key);
    localRecentArtists.push({ name: value, track });
  });
  (state.settings.showRecentArtists === false ? [] : state.history).map(normalizeTrack).forEach(track => {
    const name = String(primaryArtistName(track) || track.artist || '').trim();
    const key = normalizeMatchText(name);
    if (!name || isUnknownArtist(name) || localArtistSeen.has(key)) return;
    localArtistSeen.add(key);
    localRecentArtists.push({ name, track });
  });
  const fallbackArtistNames = stableHomeShuffle([...new Set([
    ...state.homeDiscovery.artistPool || [],
    ...catalog.map(track => track.artist)
  ].filter(name => name && !isUnknownArtist(name) && !localArtistSeen.has(normalizeMatchText(name))))], 'artists').slice(0, 10);
  const continueArtists = [
    ...localRecentArtists,
    ...fallbackArtistNames.map(name => ({ name, track: discoveryBase.find(track => track.artist === name) })).filter(item => item.track)
  ].slice(0, 10);
  const artistNames = continueArtists.map(item => item.name);
  const communityGroups = buildCommunityGroups(discoveryBase);
  const playlistCover = state.history[0]?.thumbnail || catalog[1]?.thumbnail || 'assets/placeholder.svg';
  const playable = [];
  const registerTrack = track => { playable.push(normalizeTrack(track)); return playable.length - 1; };
  const artistCatalogs = state.homeDiscovery?.artistCatalogs || {};
  const featuredPlaylist = state.homeFeaturedPlaylist || {};
  const featuredPlaylistTracks = dedupeTracks(featuredPlaylist.tracks || []).filter(homeDisplayTrackReady).slice(0, 12);
  const featuredPlaylistHtml = featuredPlaylistTracks.length ? `<section class="spotify-section anabot-playlist-section">
    <div class="home-section-inline anabot-playlist-heading"><div><p class="spotify-kicker">PLAYLIST PILIHAN</p><h2>${esc(featuredPlaylist.name || 'Playlist Spotify')}</h2><small>${esc([featuredPlaylist.owner ? `oleh ${featuredPlaylist.owner}` : '', featuredPlaylist.totalTracks ? `${featuredPlaylist.totalTracks} lagu` : ''].filter(Boolean).join(' • '))}</small></div><button data-anabot-playlist-play>${icon('play','fill')} Putar</button></div>
    ${featuredPlaylist.description ? `<p class="anabot-playlist-description">${esc(featuredPlaylist.description)}</p>` : ''}
    <div class="home-square-carousel">${featuredPlaylistTracks.map(track => homeSquareCard(track, registerTrack(track), track.artist)).join('')}</div>
  </section>` : '';
  const sylvaticaSimilarGroups = Array.isArray(state.homeSimilarGroups) ? state.homeSimilarGroups.filter(group => Array.isArray(group?.tracks) && group.tracks.length) : [];
  const exactLocalGroups = artistNames.slice(0,4).map(artist => {
    const exactTracks = dedupeTracks(artistCatalogs[artistCacheKey(artist)] || discoveryBase.filter(track => trackBelongsToArtist(track, artist))).slice(0,4);
    return exactTracks.length ? { label:artist, openArtistName:artist, avatar:exactTracks[0]?.thumbnail || 'assets/placeholder.svg', seedTrack:continueArtists.find(item => normalizeMatchText(item.name) === normalizeMatchText(artist))?.track || null, tracks:exactTracks } : null;
  }).filter(Boolean);
  // Tidak pernah mengisi section "Serupa dengan" menggunakan lagu artis lain hanya demi memenuhi jumlah kartu.
  const similarContextGroups = sylvaticaSimilarGroups.length ? sylvaticaSimilarGroups.slice(0,3) : exactLocalGroups.slice(0,3);
  const similarHtml = similarContextGroups.map((group,index) => homeSimilarBlock(group.label, group.tracks, registerTrack, { avatar:group.avatar, openArtistName:group.openArtistName, contextIndex:index })).join('');

  view.innerHTML = `<div class="page spotify-home-page rich-home-page">
    ${homeHeaderMarkup()}
    <div class="home-shortcuts"><button data-collection="favorites"><span class="liked-art">${icon('heart','fill')}</span><strong>Lagu yang Disukai</strong></button><button data-collection="history"><img src="${esc(playlistCover)}" alt=""><strong>Riwayat</strong></button></div>
    ${homeSpotlightMarkup(spotlightTracksForHome(), registerTrack)}
    ${featuredPlaylistHtml}
    ${state.homeError ? `<div class="spotify-error">Katalog online belum tersedia. Menampilkan pilihan tersimpan.<button data-retry>Segarkan</button></div>` : ''}
    <section class="spotify-section"><p class="spotify-kicker">Nikmati sesi berdasarkan seleramu</p><h1>Mulai mendengarkan</h1><div class="spotify-home-list">${listening.map(compactHomeRow).join('')}</div></section>

    <section class="spotify-section"><div class="home-section-title"><h2>Trending Now</h2>${icon('trending')}</div><div class="home-square-carousel">${trending.map(track => homeSquareCard(track, registerTrack(track), track.artist)).join('')}</div></section>
    <section class="spotify-section"><div class="home-section-title"><h2>New Releases</h2>${icon('sparkles')}</div><div class="home-square-carousel">${newReleases.map(track => homeSquareCard(track, registerTrack(track), track.artist)).join('')}</div></section>

    <section class="spotify-section"><div class="home-section-title community-title"><h2>From the Community</h2>${icon('community')}</div><div class="community-carousel">${communityGroups.map((group,index) => communityCard(group,index,registerTrack)).join('')}</div></section>

    <section class="spotify-section"><div class="home-section-inline"><h2>Tetap Mendengarkan</h2><button data-show-all-artists>Semua ${icon('arrow-right')}</button></div><div class="artist-bubbles">${continueArtists.map(item => `<button data-home-artist="${esc(item.name)}"><img src="${esc(item.track.thumbnail)}" alt="" loading="lazy" onerror="this.src='assets/placeholder.svg'"><strong>${esc(item.name)}</strong><span>Artis</span></button>`).join('')}</div></section>

    ${spotifyHomeCollectionsMarkup()}

    ${similarHtml}

    <section class="spotify-section"><div class="home-section-inline"><h2>Top 50 Indonesia</h2></div><div class="home-square-carousel ranked-carousel">${top50.map((track,index) => `<div class="ranked-card"><span class="rank-number">${track.rank || index + 1}</span>${homeSquareCard(track,registerTrack(track),track.artist)}</div>`).join('')}</div></section>
    ${state.homeDiscoveryLoading ? `<div class="home-source-loading"><span class="skeleton"></span><span>Memperbarui rekomendasi musik...</span></div>` : ''}
  </div>`;

  $('[data-open-sidebar]', view).onclick = showSideMenu;
  $('[data-global-notifications]', view).onclick = showGlobalNotificationsSheet;
  const accountStatusButton = $('[data-account-status]', view); if (accountStatusButton) accountStatusButton.onclick = showAccountStatusSheet;
  $$('[data-collection]', view).forEach(button => button.onclick = () => showCollection(button.dataset.collection));
  bindSpotifyHomeCollections(view);
  $$('[data-home-track]', view).forEach(button => button.onclick = event => {
    const index = Number(button.dataset.homeTrack);
    if (event.target.closest('[data-home-more]')) { event.stopPropagation(); showTrackMenu(listening[index]); return; }
    playTrack(listening[index], listening, index);
  });
  $$('[data-home-discovery]', view).forEach(button => button.onclick = event => {
    event.stopPropagation();
    const index = Number(button.dataset.homeDiscovery);
    playTrack(playable[index], playable, index);
  });
  $$('[data-home-featured-play]', view).forEach(button => button.onclick = async event => {
    event.stopPropagation();
    const index = Number(button.dataset.homeFeaturedPlay);
    if (state.current && sameTrackIdentity(playable[index], state.current)) {
      await togglePlay();
      syncVisibleTrackPlaybackIcons(view);
      return;
    }
    playTrack(playable[index], playable, index);
  });
  $('[data-anabot-playlist-play]', view)?.addEventListener('click', event => {
    event.stopPropagation();
    if (!featuredPlaylistTracks.length) return;
    playTrack(featuredPlaylistTracks[0], featuredPlaylistTracks, 0, {
      playContext: { type: 'playlist', id: `anabot-${featuredPlaylist.id || 'featured'}`, name: featuredPlaylist.name || 'Playlist Spotify' }
    });
  });
  $$('[data-featured-dot]', view).forEach(button => button.onclick = event => {
    event.stopPropagation();
    setHomeSpotlightIndex(Number(button.dataset.featuredDot), true);
    startHomeSpotlightCarousel();
  });
  $$('[data-community-track]', view).forEach(button => button.onclick = event => {
    event.stopPropagation();
    const [groupIndex, trackIndex] = String(button.dataset.communityTrack || '').split(':').map(Number);
    const group = communityGroups[groupIndex];
    if (!group?.tracks?.length || !Number.isInteger(trackIndex) || !group.tracks[trackIndex]) return;
    const queue = group.tracks.map(sanitizePlaybackTrack);
    playTrack(queue[trackIndex], queue, trackIndex, { playContext:{ eyebrow:'MEMUTAR DARI COMMUNITY', label:group.title, type:'community' } });
  });
  $$('[data-community-play]', view).forEach(button => button.onclick = event => {
    event.stopPropagation();
    const group = communityGroups[Number(button.dataset.communityPlay)];
    if (!group?.tracks?.length) return;
    const queue = group.tracks.map(sanitizePlaybackTrack);
    playTrack(queue[0], queue, 0, { playContext:{ eyebrow:'MEMUTAR DARI COMMUNITY', label:group.title, type:'community' } });
  });
  $$('[data-community-listen]', view).forEach(button => button.onclick = event => {
    event.stopPropagation();
    const group = communityGroups[Number(button.dataset.communityListen)];
    if (!group?.tracks?.length) return;
    showListenTogetherFriends(group.tracks[0], {
      queue: group.tracks,
      playContext:{ eyebrow:'DENGAR BARENG DARI COMMUNITY', label:group.title, type:'community' },
      stayOnRoute:true
    });
  });
  $$('[data-community-save]', view).forEach(button => button.onclick = event => {
    event.stopPropagation();
    const group = communityGroups[Number(button.dataset.communitySave)];
    if (!group?.tracks?.length) return;
    saveCommunityPlaylist(group);
    button.classList.add('is-saved');
    button.setAttribute('aria-label','Sudah disimpan');
    button.innerHTML = icon('check-circle');
    notify(`${group.title} ditambahkan ke Playlist`);
  });
  $$('[data-home-artist]', view).forEach(button => button.onclick = event => {
    event.stopPropagation();
    const name = button.dataset.homeArtist;
    const localItem = continueArtists.find(item => normalizeMatchText(item.name) === normalizeMatchText(name));
    openArtistExplorer(name, localItem?.track || discoveryBase.find(track => normalizeMatchText(primaryArtistName(track)) === normalizeMatchText(name)));
  });
  $$('[data-home-similar-context]', view).forEach(button => button.onclick = event => {
    event.stopPropagation();
    const group = similarContextGroups[Number(button.dataset.homeSimilarContext)];
    if (!group?.openArtistName) return;
    openArtistExplorer(group.openArtistName, group.seedTrack || null);
  });
  const retry = $('[data-retry]', view); if (retry) retry.onclick = () => loadHome(true);
  const showAll = $('[data-show-all-artists]', view); if (showAll) showAll.onclick = () => navigate('library');
  bindHomeSpotlightGestures();
  startHomeSpotlightCarousel();
  scheduleDesktopHorizontalRails(view);
}

function rowTemplate(track,index) {
  return `<div class="track-row" data-track-index="${index}"><img class="row-cover" src="${esc(track.thumbnail)}" alt="" loading="lazy" onerror="this.src='assets/placeholder.svg'"><div><div class="row-title">${esc(cleanTitle(track))}</div><div class="row-sub">${esc(track.artist)}${track.album?` • ${esc(track.album)}`:''}</div></div><button class="row-more" data-row-more="${index}" aria-label="Opsi">${icon('more')}</button></div>`;
}

const SEARCH_GENRE_CARDS = Object.freeze([
  { label: 'Pop', query: 'Pop Indonesia', color: '#d9158f', keywords: ['Tulus','Mahalini','Nadin Amizah'] },
  { label: 'Hip Hop', query: 'Hip Hop Indonesia', color: '#8d08e8', keywords: ['Naykilla','Hip Hop','Rap'] },
  { label: 'Hipdut', query: 'Hipdut Indonesia', color: '#9a5bdf', keywords: ['MMG','Naykilla','Hipdut'] },
  { label: 'Indie', query: 'Indie Indonesia', color: '#08735d', keywords: ['Hindia','Pamungkas','Sal Priadi','Lomba Sihir'] },
  { label: 'R&B', query: 'R&B Indonesia', color: '#bc2d73', keywords: ['Pamungkas','Mahalini','R&B'] },
  { label: 'Rock', query: 'Rock Indonesia', color: '#e63200', keywords: ['Lomba Sihir','Rock','Band'] },
  { label: 'Elektronik', query: 'Electronic dance music', color: '#267e96', keywords: ['DJ Ace','Faraone','Black Hole','Electronic'] },
  { label: 'Dangdut', query: 'Dangdut Indonesia', color: '#4f7e00', keywords: ['Naykilla','Dangdut'] },
  { label: 'Jazz', query: 'Jazz Indonesia', color: '#7c5b3d', keywords: ['Tulus','Jazz'] },
  { label: 'K-Pop', query: 'K-Pop hits', color: '#c52562', keywords: ['K-Pop','BTS','BLACKPINK'] },
  { label: 'Lo-fi', query: 'Lo-fi chill', color: '#536f8e', keywords: ['Hindia','Chill','Lo-fi'] },
  { label: 'Akustik', query: 'Akustik Indonesia', color: '#8b6a4b', keywords: ['Sal Priadi','Nadin Amizah','Acoustic'] }
]);

function genreCardCover(catalog, category, index) {
  const list = dedupeTracks([...(catalog || []), ...FALLBACK_TRACKS.map(normalizeTrack)]);
  const keywords = (category.keywords || []).map(normalizeMatchText).filter(Boolean);
  const matched = list.find(track => {
    const haystack = normalizeMatchText([cleanTitle(track), track.artist, track.album, track.genre].filter(Boolean).join(' '));
    return keywords.some(keyword => haystack.includes(keyword));
  });
  const fallback = list[index % Math.max(1, list.length)] || normalizeTrack(FALLBACK_TRACKS[index % FALLBACK_TRACKS.length]);
  return enhanceArtworkUrl((matched || fallback)?.thumbnail || 'assets/placeholder.svg');
}

function searchTrackCardMarkup(track, feedIndex) {
  const duration = durationSeconds(track?.duration) > 1 ? formatTime(durationSeconds(track.duration)) : '';
  return `<button class="spotify-result-row mixed-track-card" data-mixed-feed="${feedIndex}" data-kind="track"><img src="${esc(enhanceArtworkUrl(track.thumbnail || 'assets/placeholder.svg'))}" alt="" loading="lazy" onerror="this.src='assets/placeholder.svg'"><span><strong>${esc(cleanTitle(track))}</strong><small>${track.explicit ? '<b class="explicit-badge">E</b> ' : ''}${esc(track.artist || 'Artis tidak diketahui')}${duration ? ` • ${esc(duration)}` : ''}</small></span><i data-result-more="${feedIndex}">${icon('more')}</i></button>`;
}

function searchArtistCardMarkup(artist, feedIndex) {
  if (window.DatzonCatalogUI?.entityCard) return window.DatzonCatalogUI.entityCard({ ...artist, kind:'artist', followersLabel:artist.followers ? artistCount(artist.followers) : '' }, feedIndex);
  return `<button class="mixed-entity-card mixed-artist-card" data-mixed-feed="${feedIndex}" data-kind="artist"><img src="${esc(artist.image || 'assets/placeholder.svg')}" alt="Foto ${esc(artist.name)}" loading="lazy" onerror="this.src='assets/placeholder.svg'"><span><strong>${esc(artist.name)}</strong><small>Artis${artist.followers ? ` • ${esc(artistCount(artist.followers))} pengikut` : ''}</small></span><i>${icon('chevron')}</i></button>`;
}

function searchAlbumCardMarkup(album, feedIndex) {
  if (window.DatzonCatalogUI?.entityCard) return window.DatzonCatalogUI.entityCard({ ...album, kind:'album' }, feedIndex);
  const release = album.releaseDate ? String(album.releaseDate).slice(0,4) : '';
  const type = album.albumType === 'single' ? 'Single' : album.albumType === 'compilation' ? 'Compilation' : 'Album';
  return `<button class="mixed-entity-card mixed-album-card" data-mixed-feed="${feedIndex}" data-kind="album"><img src="${esc(album.cover || 'assets/placeholder.svg')}" alt="Sampul ${esc(album.name)}" loading="lazy" onerror="this.src='assets/placeholder.svg'"><span><strong>${esc(album.name)}</strong><small>${esc([type, album.artist, release].filter(Boolean).join(' • '))}</small></span><i>${icon('more')}</i></button>`;
}

function searchPlaylistCardMarkup(playlist, feedIndex) {
  if (window.DatzonCatalogUI?.entityCard) return window.DatzonCatalogUI.entityCard({ ...playlist, kind:'playlist' }, feedIndex);
  return `<button class="mixed-entity-card mixed-playlist-card" data-mixed-feed="${feedIndex}" data-kind="playlist"><img src="${esc(playlist.cover || 'assets/placeholder.svg')}" alt="Sampul ${esc(playlist.name)}" loading="lazy" onerror="this.src='assets/placeholder.svg'"><span><strong>${esc(playlist.name)}</strong><small>Playlist${playlist.owner ? ` • ${esc(playlist.owner)}` : ''}${playlist.totalTracks ? ` • ${esc(playlist.totalTracks)} lagu` : ''}</small></span><i>${icon('more')}</i></button>`;
}

function mixedSearchCardMarkup(entry, index) {
  if (entry.kind === 'artist') return searchArtistCardMarkup(entry.data, index);
  if (entry.kind === 'album') return searchAlbumCardMarkup(entry.data, index);
  if (entry.kind === 'playlist') return searchPlaylistCardMarkup(entry.data, index);
  return searchTrackCardMarkup(entry.data, index);
}

function searchLoadingSkeletonMarkup() {
  const row = shape => `<div class="spotify-result-row mixed-search-skeleton-row ${shape === 'circle' ? 'is-artist' : ''}"><span class="skeleton result-cover ${shape === 'circle' ? 'artist-circle-skeleton' : 'entity-square-skeleton'}"></span><span><i class="skeleton"></i><i class="skeleton"></i></span><i class="skeleton skeleton-dot"></i></div>`;
  return `<div class="mixed-search-skeletons">${row('square')}${row('square')}${row('circle')}${row('square')}${row('square')}${row('square')}</div>`;
}

function spotifyArtistSeed(entity) {
  return normalizeTrack({
    id:'', title:entity.name, artist:entity.name, artistNames:[entity.name], artistId:entity.id, artistIds:[entity.id],
    artistUrls:[entity.spotifyUrl], artistDetails:[{ name:entity.name, id:entity.id, external_url:entity.spotifyUrl }],
    thumbnail:entity.image || 'assets/placeholder.svg', source:'Spotify artist metadata'
  });
}

async function executeUniversalSearch(query, { append = false } = {}) {
  const clean = String(query || '').trim();
  if (!clean) return;
  const offset = append ? Math.max(0, Number(state.searchSpotifyOffset || 0) + 10) : 0;
  if (!append) {
    state.searchLoading = true;
    state.searchResults = [];
    state.searchEntities = { artists:[], albums:[], playlists:[] };
    state.searchMixedResults = [];
    state.searchSpotifyOffset = 0;
    renderSearch();
  }
  try {
    const payload = await runUniversalSearch(clean, { offset });
    if (append) {
      state.searchResults = dedupeTracks([...(state.searchResults || []), ...(payload.tracks || [])]);
      const mergeEntity = (oldItems, newItems) => {
        const map = new Map();
        [...(oldItems || []), ...(newItems || [])].forEach(item => { if (item?.id && !map.has(item.id)) map.set(item.id, item); });
        return [...map.values()];
      };
      state.searchEntities = {
        artists: mergeEntity(state.searchEntities?.artists, payload.artists),
        albums: mergeEntity(state.searchEntities?.albums, payload.albums),
        playlists: mergeEntity(state.searchEntities?.playlists, payload.playlists)
      };
      state.searchSpotifyOffset = offset;
      state.searchHasMore = Boolean(payload.hasMore);
      const oldFeed = Array.isArray(state.searchMixedResults) ? state.searchMixedResults : [];
      const pageFeed = payload.feed || stableMixedSearchFeed(payload.tracks || [], payload.artists || [], payload.albums || [], payload.playlists || []);
      const exists = entry => oldFeed.some(current => {
        if (current.kind !== entry.kind) return false;
        if (entry.kind === 'track') return safeSameTrack(current.data, entry.data);
        return Boolean(current.data?.id && entry.data?.id && current.data.id === entry.data.id);
      });
      state.searchMixedResults = [...oldFeed, ...pageFeed.filter(entry => entry?.data && !exists(entry))];
    } else {
      state.searchResults = payload.tracks || [];
      state.searchEntities = { artists:payload.artists || [], albums:payload.albums || [], playlists:payload.playlists || [] };
      state.searchMixedResults = payload.feed || stableMixedSearchFeed(state.searchResults, state.searchEntities.artists, state.searchEntities.albums, state.searchEntities.playlists);
      state.searchSpotifyOffset = 0;
      state.searchHasMore = Boolean(payload.hasMore);
    }
    if (state.settings.saveSearchHistory !== false && !state.settings.privateSession) state.searchHistory = [clean, ...state.searchHistory.filter(item => item.toLowerCase() !== clean.toLowerCase())].slice(0, 12);
    state.apiOnline = true;
  } catch (error) {
    state.apiOnline = false;
    if (!(state.searchMixedResults || []).length) notify(error?.message || 'Pencarian belum tersedia');
  } finally {
    state.searchLoading = false;
    persist();
    renderSearch();
  }
}

function renderSearch() {
  const catalog = filterHiddenSuggestions(state.catalog.length ? state.catalog : FALLBACK_TRACKS.map(normalizeTrack));
  const categories = SEARCH_GENRE_CARDS;
  const feed = Array.isArray(state.searchMixedResults) ? state.searchMixedResults : [];
  view.innerHTML = `<div class="page spotify-search-page">
    <header class="search-title-row">${accountAvatarButtonMarkup('data-search-sidebar')}<h1>Cari</h1><button class="search-camera" data-camera aria-label="Scan Kode Lagu">${icon('camera')}</button></header>
    <div class="search-box-wrap"><form class="spotify-search-box ${String(state.searchQuery||'').trim() ? 'has-query' : ''}" id="searchForm"><span>${icon('search')}</span><input id="searchInput" autocomplete="off" value="${esc(state.searchQuery)}" placeholder="Lagu, artis, album, playlist"><button type="button" class="search-input-clear" data-search-input-clear aria-label="Hapus teks pencarian">${icon('close')}</button><button type="submit" class="search-enter-button" aria-label="Cari">${icon('arrow-up')}</button></form><div class="search-suggestion-panel" id="searchSuggestions" role="listbox" aria-label="Kata pencarian relevan"></div></div>
    ${state.searchLoading ? searchLoadingSkeletonMarkup() :
      feed.length ? `<div class="spotify-results mixed-search-results"><div class="result-heading"><h2>Hasil untuk “${esc(state.searchQuery)}”</h2><button data-clear-search>Hapus</button></div>${feed.map(mixedSearchCardMarkup).join('')}${state.searchHasMore ? `<button class="mixed-search-more" data-search-more>${icon('plus-circle')} Muat hasil lainnya</button>` : ''}</div>` :
      `${state.settings.saveSearchHistory !== false && state.searchHistory.length ? `<section class="recent-search-section"><div class="result-heading"><h2>Pencarian terakhir</h2><button data-clear-recent-search>Hapus semua</button></div><div class="recent-search-chips">${state.searchHistory.slice(0,8).map(query=>`<button data-recent-search="${esc(query)}">${icon('history')}<span>${esc(query)}</span></button>`).join('')}</div></section>` : ''}<section class="browse-section"><h2>Jelajahi genre</h2><div class="browse-grid">${categories.map((category,index)=>`<button class="browse-card" data-category="${esc(category.query)}" style="--browse:${category.color}"><strong>${esc(category.label)}</strong><img src="${esc(genreCardCover(catalog,category,index))}" alt="Sampul ${esc(category.label)}" loading="lazy" onerror="this.src='assets/placeholder.svg'"></button>`).join('')}</div></section>`}
  </div>`;
  $('[data-search-sidebar]', view).onclick = showSideMenu;
  $('[data-camera]', view).onclick = async () => { try { const api=await ensureMusicCodeModule(); api.openScanner(musicCodeHandlers()); } catch (error) { console.warn('[DATZON Music Code scanner loader]',error); notify('Pemindai Kode Lagu gagal dimuat. Coba lagi beberapa detik lagi.', 'error'); } };
  mountSearchSuggestionController();
  const searchFormEl = $('#searchForm', view);
  const searchInputEl = $('#searchInput', view);
  const searchClearEl = $('[data-search-input-clear]', view);
  const syncSearchClearButton = () => {
    const hasText = Boolean(String(searchInputEl?.value || '').length);
    searchFormEl?.classList.toggle('has-query', hasText);
    searchClearEl?.setAttribute('aria-hidden', hasText ? 'false' : 'true');
    if (searchClearEl) searchClearEl.tabIndex = hasText ? 0 : -1;
  };
  searchInputEl?.addEventListener('input', syncSearchClearButton);
  searchClearEl?.addEventListener('click', () => {
    if (!searchInputEl) return;
    searchInputEl.value = '';
    searchInputEl.dispatchEvent(new Event('input', { bubbles:true }));
    searchInputEl.focus({ preventScroll:true });
  });
  syncSearchClearButton();
  $('#searchForm', view).onsubmit = event => {
    event.preventDefault();
    const query = $('#searchInput', view).value.trim();
    if (!query) return;
    state.searchQuery = query;
    executeUniversalSearch(query);
  };
  $$('[data-recent-search]', view).forEach(button => button.onclick = () => {
    state.searchQuery = button.dataset.recentSearch;
    renderSearch();
    setTimeout(() => $('#searchForm', view)?.requestSubmit(), 0);
  });
  const clearRecent = $('[data-clear-recent-search]', view);
  if (clearRecent) clearRecent.onclick = () => { state.searchHistory = []; persist(); renderSearch(); notify('Pencarian terakhir dihapus'); };
  $$('[data-category]', view).forEach(button => button.onclick = () => {
    state.searchQuery = button.dataset.category;
    renderSearch();
    setTimeout(() => $('#searchForm', view)?.requestSubmit(), 0);
  });
  $$('[data-mixed-feed]', view).forEach(button => button.onclick = event => {
    const index = Number(button.dataset.mixedFeed);
    const entry = state.searchMixedResults?.[index];
    if (!entry?.data) return;
    if (entry.kind === 'track') {
      if (event.target.closest('[data-result-more]')) { event.stopPropagation(); showTrackMenu(entry.data); return; }
      const queue = state.searchMixedResults.filter(item => item.kind === 'track').map(item => item.data);
      const queueIndex = Math.max(0, queue.findIndex(item => safeSameTrack(item, entry.data)));
      playTrack(entry.data, queue, queueIndex);
    } else if (entry.kind === 'artist') {
      openArtistExplorer(entry.data.name, spotifyArtistSeed(entry.data));
    } else if (entry.kind === 'album') {
      openSpotifyCollection('album', entry.data.id);
    } else if (entry.kind === 'playlist') {
      openSpotifyCollection('playlist', entry.data.id);
    }
  });
  const more = $('[data-search-more]', view);
  if (more) more.onclick = () => { more.disabled = true; more.textContent = 'Memuat...'; executeUniversalSearch(state.searchQuery, { append:true }); };
  const clear = $('[data-clear-search]', view); if (clear) clear.onclick = () => { state.searchQuery=''; state.searchResults=[]; state.searchEntities={artists:[],albums:[],playlists:[]}; state.searchMixedResults=[]; state.searchHasMore=false; state.searchSpotifyOffset=0; renderSearch(); };
}

function librarySortLabel(value = state.librarySort) {
  return ({ recent: 'Terakhir', added: 'Baru ditambahkan', alphabetical: 'Abjad', creator: 'Kreator' })[value] || 'Terakhir';
}

function libraryItemTimestamp(track, fallback = 0) {
  return Number(track?.playedAt || track?.addedAt || track?.metadataResolvedAt || track?.audioResolvedAt || fallback || 0);
}

function showLibrarySortSheet() {
  const options = [
    ['recent','Terakhir'],
    ['added','Baru ditambahkan'],
    ['alphabetical','Abjad'],
    ['creator','Kreator']
  ];
  const sheet = openPlayerSheet(`<div class="library-sort-sheet-content"><h2>Urutkan menurut</h2><div class="library-sort-options">${options.map(([value,label])=>`<button data-library-sort-option="${value}" class="${state.librarySort === value ? 'selected' : ''}"><span>${esc(label)}</span>${state.librarySort === value ? icon('check') : ''}</button>`).join('')}</div></div>`, 'library-sort-player-sheet', { kind: 'adaptive', initialSnap: 'full' });
  $$('[data-library-sort-option]', sheet).forEach(button => button.onclick = () => {
    state.librarySort = button.dataset.librarySortOption;
    persist();
    closeModal(true);
    renderLibrary();
  });
}

function renderLibrary() {
  const catalog = filterHiddenSuggestions(state.catalog.length ? state.catalog : FALLBACK_TRACKS.map(normalizeTrack));
  const artists = [];
  const seen = new Set();
  [...state.history, ...state.favorites, ...catalog].forEach((track, sourceIndex) => {
    const name = String(track.artist || '').trim();
    const key = normalizeMatchText(name);
    if (!name || !key || seen.has(key)) return;
    seen.add(key);
    const related = [...state.history, ...state.favorites].find(item => normalizeMatchText(item.artist) === key) || track;
    artists.push({ name, thumbnail: track.thumbnail, timestamp: libraryItemTimestamp(related, Date.now() - sourceIndex * 1000), order: sourceIndex + 1000 });
  });
  const playlists = activePlaylists();
  const playlistCoverFallback = state.history[0]?.thumbnail || catalog[1]?.thumbnail || 'assets/placeholder.svg';
  const favoriteTimestamp = Math.max(0, ...state.favorites.map(track => libraryItemTimestamp(track)));
  const historyTimestamp = Math.max(0, ...state.history.map(track => libraryItemTimestamp(track)));
  const favoritesItem = { key:'favorites', action:'collection', value:'favorites', title:'Lagu yang Disukai', subtitle:`📌 Playlist • ${currentAccountName()}`, kind:'playlist', timestamp:favoriteTimestamp || Date.now(), order:0, special:'liked' };
  const playlistItems = playlists.map((playlist, index) => ({
    key:`playlist:${playlist.id}`,
    action:'playlist',
    value:playlist.id,
    title:playlist.name,
    subtitle:`${playlist.tracks.length} lagu • ${playlistVisibilityLabel(playlist.visibility)} • ${isLoggedIn() ? 'Firebase' : 'Lokal'}`,
    kind:'playlist',
    timestamp:Number(playlist.updatedAt || playlist.createdAt || 0),
    order:index + 1,
    thumbnail:playlistCover(playlist),
    playlist
  }));
  const historyItem = { key:'history', action:'collection', value:'history', title:'Riwayat', subtitle:'Lagu terakhir diputar', kind:'playlist', timestamp:historyTimestamp || Date.now()-1, order:500, thumbnail:playlistCoverFallback };
  const artistItems = artists.slice(0,12).map(artist => ({ key:`artist:${artist.name}`, action:'artist', value:artist.name, title:artist.name, subtitle:'Artis', kind:'artist', timestamp:artist.timestamp, order:artist.order, thumbnail:artist.thumbnail }));
  let sorted = [];
  if (state.librarySort === 'recent') {
    sorted = [
      ...playlistItems.sort((a,b) => b.timestamp - a.timestamp || a.order - b.order),
      historyItem,
      ...artistItems.sort((a,b) => b.timestamp - a.timestamp || a.order - b.order)
    ];
  } else {
    sorted = [...playlistItems, historyItem, ...artistItems];
    if (state.librarySort === 'added') sorted.sort((a,b) => a.order - b.order);
    else if (state.librarySort === 'alphabetical') sorted.sort((a,b) => a.title.localeCompare(b.title, 'id'));
    else if (state.librarySort === 'creator') sorted.sort((a,b) => a.subtitle.localeCompare(b.subtitle, 'id') || a.title.localeCompare(b.title, 'id'));
  }
  const utilityItems = [
    { key:'add-artist', action:'add-artist', title:'Tambahkan artis', subtitle:'', kind:'artist', special:'plus-round', filterKind:'artist' },
    { key:'add-events', action:'add-events', title:'Tambahkan acara dan lokasi', subtitle:'', kind:'utility', special:'plus-square' },
    { key:'import-spotify-playlist', action:'import-spotify-playlist', title:'Import playlist', subtitle:'Spotify', kind:'utility', special:'spotify-import', filterKind:'playlist' },
    { key:'import', action:'import', title:'Impor musikmu', subtitle:'', kind:'utility', special:'import', filterKind:'playlist' }
  ];
  const allItems = [favoritesItem, ...sorted, ...utilityItems];
  const items = allItems.filter(item => state.libraryFilter === 'all' || item.kind === state.libraryFilter || item.filterKind === state.libraryFilter);
  const itemMarkup = item => {
    let visual = '';
    if (item.special === 'liked') visual = `<span class="collection-square liked-art">${icon('heart','fill')}</span>`;
    else if (item.special === 'plus-round') visual = `<span class="collection-round utility-icon">${icon('plus-circle')}</span>`;
    else if (item.special === 'plus-square') visual = `<span class="collection-square utility-icon">${icon('plus-circle')}</span>`;
    else if (item.special === 'spotify-import') visual = `<span class="collection-square utility-icon spotify-import-library-icon">${icon('queue')}</span>`;
    else if (item.special === 'import') visual = `<span class="collection-square utility-icon">${icon('download')}</span>`;
    else if (item.action === 'playlist' && item.playlist) visual = playlistArtworkMarkup(item.playlist, 'collection-square', true);
    else visual = `<img class="${item.kind === 'artist' ? 'collection-round' : 'collection-square'}" src="${esc(item.thumbnail || 'assets/placeholder.svg')}" alt="" loading="lazy" onerror="this.src='assets/placeholder.svg'">`;
    return `<button class="collection-row ${item.kind === 'artist' ? 'artist-row' : ''} ${item.action.startsWith('add') || item.action === 'import' || item.action === 'import-spotify-playlist' ? 'utility-row' : ''}" data-library-action="${esc(item.action)}" data-library-value="${esc(item.value || '')}">${visual}<span><strong>${esc(item.title)}</strong>${item.subtitle ? `<small>${esc(item.subtitle)}</small>` : ''}</span></button>`;
  };
  view.innerHTML = `<div class="page spotify-library-page">
    <header class="library-title-row">${accountAvatarButtonMarkup('data-library-sidebar')}<h1>Koleksi Kamu</h1><button data-library-search>${icon('search')}</button><button data-library-create>${icon('plus-circle')}</button></header>
    <div class="library-pills"><button data-library-filter="playlist" class="${state.libraryFilter === 'playlist' ? 'active' : ''}" aria-pressed="${state.libraryFilter === 'playlist'}">Playlist</button><button data-library-filter="artist" class="${state.libraryFilter === 'artist' ? 'active' : ''}" aria-pressed="${state.libraryFilter === 'artist'}">Artis</button></div>
    <div class="library-sort"><button class="library-sort-trigger" data-library-sort><span aria-hidden="true">↕</span><strong>${esc(librarySortLabel())}</strong></button><button class="library-view-toggle" data-library-view aria-label="Ubah tampilan">${icon(state.libraryView === 'grid' ? 'list-view' : 'grid')}</button></div>
    <div class="collection-list ${state.libraryView === 'grid' ? 'is-grid' : 'is-list'}">${items.map(itemMarkup).join('')}</div>
  </div>`;
  $('[data-library-sidebar]', view).onclick = showSideMenu;
  $('[data-library-search]', view).onclick = () => navigate('search');
  $('[data-library-create]', view).onclick = showCreateMenu;
  $$('[data-library-filter]', view).forEach(button => button.onclick = () => {
    const selected = button.dataset.libraryFilter;
    state.libraryFilter = state.libraryFilter === selected ? 'all' : selected;
    storage.set('libraryFilter', state.libraryFilter);
    renderLibrary();
  });
  $('[data-library-sort]', view).onclick = showLibrarySortSheet;
  $('[data-library-view]', view).onclick = () => {
    state.libraryView = state.libraryView === 'grid' ? 'list' : 'grid';
    persist();
    renderLibrary();
  };
  $$('[data-library-action]', view).forEach(button => button.onclick = () => {
    const action = button.dataset.libraryAction;
    const value = button.dataset.libraryValue;
    if (action === 'collection') showCollection(value);
    else if (action === 'playlist') showPlaylistDetail(value);
    else if (action === 'artist') openArtistSearch(value);
    else if (action === 'add-artist') navigate('search');
    else if (action === 'add-events') notify('Acara dan lokasi akan tersedia pada pembaruan berikutnya');
    else if (action === 'import-spotify-playlist') showSpotifyPlaylistImportSheet();
    else if (action === 'import') restoreInput.click();
  });
}

function settingItem(iconName,title,sub,key=null) {
  const trailing=key?`<span class="switch ${state.settings[key]?'on':''}" data-toggle="${key}"></span>`:`${icon('chevron','chev')}`;
  return `<button class="setting-item" ${key?`data-setting-toggle="${key}"`:''}><span>${icon(iconName)}</span><span class="setting-copy"><strong>${title}</strong><span>${sub}</span></span>${trailing}</button>`;
}

function settingsPageHeader(title, subtitle = '') {
  return `<header class="settings-title-row utility-title-row"><button data-back>${icon('arrow-left')}</button><div><h1>${esc(title)}</h1>${subtitle ? `<small>${esc(subtitle)}</small>` : ''}</div><button data-settings-search>${icon('search')}</button></header>`;
}

function bindUtilityHeader() {
  const back = $('[data-back]', view); if (back) back.onclick = () => navigateBack('home');
  const search = $('[data-settings-search]', view); if (search) search.onclick = () => navigate('search');
}

function accountInitial(value = currentAccountName()) {
  return String(value || 'T').trim().slice(0, 1).toUpperCase() || 'T';
}

function accountAvatarMarkup(sizeClass = 'profile-avatar-large') {
  const photo = currentProfilePhoto();
  const listeningClass = accountAvatarPlaybackClass();
  if (photo) return `<span class="${sizeClass} has-photo${listeningClass}"><img src="${esc(photo)}" alt="Foto profil ${esc(currentAccountName())}" onerror="this.parentElement.classList.remove('has-photo');this.remove()"><b>${esc(accountInitial())}</b></span>`;
  return `<span class="${sizeClass}${listeningClass}"><b>${esc(accountInitial())}</b></span>`;
}

function formatAccountDate(profile = state.auth.profile) {
  const iso = profile?.createdAtIso || '';
  const millis = profile?.createdAt?.toMillis?.();
  const date = millis ? new Date(millis) : (iso ? new Date(iso) : null);
  if (!date || Number.isNaN(date.getTime())) return 'Belum tersedia';
  const formatted = new Intl.DateTimeFormat('id-ID', {
    day: '2-digit', month: 'long', year: 'numeric',
    hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false
  }).format(date);
  return `${formatted}.${String(date.getMilliseconds()).padStart(3, '0')}`;
}

function providerHasPassword() {
  return Boolean(state.auth.user?.providerData?.some(item => item.providerId === 'password'));
}

function firebaseUnavailableMessage(explicitMessage = '') {
  if (explicitMessage) return explicitMessage;
  if (!isFirebaseConfigured()) return 'Firebase belum dikonfigurasi. Isi firebase-config.js dan aktifkan Email/Password, Google, serta Firestore terlebih dahulu.';
  const service = firebaseService();
  const initError = service?.initializationError?.();
  return initError
    ? (service.firebaseErrorMessage?.(initError) || initError.message || 'Firebase gagal dimuat.')
    : 'Firebase sedang dimuat. Coba kembali beberapa detik lagi.';
}

function showFirebaseSetupInfo(explicitMessage = '') {
  const configured = isFirebaseConfigured();
  openModal(configured ? 'Firebase belum tersambung' : 'Firebase belum siap', `<div class="firebase-setup-note">${icon('info')}<p>${esc(firebaseUnavailableMessage(explicitMessage))}</p></div><button class="primary-btn" data-firebase-close>Mengerti</button>`, root => $('[data-firebase-close]', root).onclick = closeModal);
}

function renderProfilePage() {
  const stats = ensureListeningStats();
  const logged = isLoggedIn();
  const profile = state.auth.profile || {};
  const social = logged ? state.social : { friends:[], following:[], followers:[] };
  const accountStatusKey = logged ? normalizedAccountStatus(profile) : 'offline';
  const accountStatus = accountStatusLabel(accountStatusKey);
  view.innerHTML = `<div class="page spotify-settings-page utility-page profile-page-v127">${socialPageHeader('Profil Saya', logged ? 'Profil tersinkron dengan Firebase' : 'Mode tamu, data tersimpan lokal')}
    <section class="profile-summary-card">${accountAvatarMarkup()}<div><h2>${esc(currentAccountName())}</h2><p>${logged ? 'Data tersimpan aman di database Firebase' : 'Data tersimpan aman di perangkat ini'}</p></div></section>
    ${logged ? profileSocialStatsMarkup(social) : ''}
    ${logged ? profileBioMarkup(profile) : ''}
    <section class="utility-stat-grid"><article><strong>${state.favorites.length}</strong><span>Lagu disukai</span></article><article><strong>${state.history.length}</strong><span>Riwayat</span></article><article><strong>${stats.plays}</strong><span>Diputar</span></article></section>
    ${logged ? `<section class="account-detail-card">
      <div><span>Username</span><strong>@${esc(profile.username || '')}</strong></div>
      <div><span>Email</span><strong>${esc(profile.email || state.auth.user?.email || '')}</strong></div>
      <div><span>Total mendengarkan</span><strong>${esc(formatListeningTime(stats.totalSeconds))} • ${stats.plays} lagu</strong></div>
      <div><span>Status</span><strong class="account-status ${accountStatusKey}"><i></i>${accountStatus}</strong></div>
      <div><span>Akun dibuat</span><strong>${esc(formatAccountDate(profile))}</strong></div>
      <div><span>Penyimpanan</span><strong>Firebase + perangkat lokal</strong></div>
    </section>` : ''}
    <div class="utility-action-list">
      <button data-edit-profile>${icon('user')}<span><strong>Edit profil</strong><small>${logged ? 'Ubah foto, nama, bio, dan tautan sosial' : 'Ubah nama pengguna lokal'}</small></span>${icon('chevron')}</button>
      ${logged ? `<button data-password-security>${icon('lock')}<span><strong>Password dan keamanan</strong><small>Ganti password atau kirim link reset email</small></span>${icon('chevron')}</button>` : ''}
      <button data-profile-export>${icon('download')}<span><strong>Cadangkan data</strong><small>${logged ? 'Ekspor data lokal atau database Firebase' : 'Ekspor koleksi dan pengaturan ke JSON'}</small></span>${icon('chevron')}</button>
      ${logged ? `<button class="profile-logout-row" data-profile-logout>${icon('external')}<span><strong>Keluar akun</strong><small>Kembali menggunakan DATZON sebagai Tamu</small></span>${icon('chevron')}</button>` : `<button class="profile-auth-row" data-profile-auth>${icon('user')}<span><strong>Register / Login</strong><small>Simpan dan sinkronkan koleksi ke Firebase</small></span>${icon('chevron')}</button>`}
    </div>
  </div>`;
  bindSocialPageHeader();
  if (logged) bindProfileSocialStats(view, social, profile);
  $('[data-edit-profile]', view).onclick = showAccountModal;
  const security = $('[data-password-security]', view); if (security) security.onclick = showPasswordSecuritySheet;
  $('[data-profile-export]', view).onclick = logged ? showExportTargetSheet : backupData;
  const authButton = $('[data-profile-auth]', view); if (authButton) authButton.onclick = () => isFirebaseConfigured() ? navigate('login') : showFirebaseSetupInfo();
  const logout = $('[data-profile-logout]', view); if (logout) logout.onclick = showLogoutConfirm;
  if (logged && !state.social.loaded && !state.social.loading) loadSocialGraph(true).then(() => { if (state.route === 'profile') renderProfilePage(); }).catch(() => {});
}

function authPageShell(title, subtitle, body) {
  return `<div class="page auth-page"><header class="auth-header"><button data-auth-back aria-label="Kembali">${icon('arrow-left')}</button><div><h1>${esc(title)}</h1><p>${esc(subtitle)}</p></div></header><main class="auth-card">${body}</main></div>`;
}

function passwordFieldMarkup(id, label, autocomplete = 'off', placeholder = '') {
  const resolvedPlaceholder = placeholder || (/konfirmasi/i.test(String(label || '')) ? 'Minimal 6 karakter' : '');
  return `<label class="auth-field" data-auth-field="${id}"><span>${esc(label)}</span><div class="password-input-wrap"><input id="${id}" class="datzon-password-input" type="password" autocomplete="${autocomplete}" autocapitalize="none" spellcheck="false" placeholder="${esc(resolvedPlaceholder)}" data-datzon-password="true" required><button type="button" class="datzon-password-toggle" data-password-toggle="${id}" aria-label="Tampilkan password">${icon('eye-off')}</button></div><small class="auth-field-error" data-auth-error="${id}"></small></label>`;
}

function googleButtonMarkup(label = 'Lanjutkan dengan Google') {
  return `<button type="button" class="google-auth-btn" data-google-auth><svg viewBox="0 0 24 24" aria-hidden="true"><path fill="#4285F4" d="M21.6 12.2c0-.7-.1-1.4-.2-2H12v3.8h5.4a4.6 4.6 0 0 1-2 3v2.5h3.2c1.9-1.7 3-4.3 3-7.3Z"/><path fill="#34A853" d="M12 22c2.7 0 5-.9 6.6-2.4l-3.2-2.5c-.9.6-2 1-3.4 1a5.8 5.8 0 0 1-5.5-4H3.2v2.6A10 10 0 0 0 12 22Z"/><path fill="#FBBC05" d="M6.5 14a6 6 0 0 1 0-3.9V7.5H3.2a10 10 0 0 0 0 9.2L6.5 14Z"/><path fill="#EA4335" d="M12 5.9c1.5 0 2.8.5 3.8 1.5l2.9-2.8A9.7 9.7 0 0 0 3.2 7.5l3.3 2.6A5.8 5.8 0 0 1 12 5.9Z"/></svg><span>${esc(label)}</span></button>`;
}

function bindPasswordToggles(root = view) {
  $$('[data-password-toggle]', root).forEach(button => button.onclick = () => {
    const input = document.getElementById(button.dataset.passwordToggle);
    if (!input) return;
    input.type = input.type === 'password' ? 'text' : 'password';
    button.classList.toggle('visible', input.type === 'text');
    button.innerHTML = icon(input.type === 'text' ? 'eye' : 'eye-off');
  });
}

function setAuthFormBusy(form, busy, label = 'Memproses...') {
  if (!form) return;
  const submit = form.querySelector('[type="submit"]');
  form.classList.toggle('busy', busy);
  $$('input,button', form).forEach(element => element.disabled = busy);
  if (submit) {
    if (!submit.dataset.originalLabel) submit.dataset.originalLabel = submit.textContent;
    submit.textContent = busy ? label : submit.dataset.originalLabel;
  }
}

function clearAuthFieldError(root, id) {
  const field = root?.querySelector?.(`[data-auth-field="${id}"]`);
  const error = root?.querySelector?.(`[data-auth-error="${id}"]`);
  field?.classList.remove('has-error');
  if (error) error.textContent = '';
}

function setAuthFieldError(root, id, message) {
  const field = root?.querySelector?.(`[data-auth-field="${id}"]`);
  const error = root?.querySelector?.(`[data-auth-error="${id}"]`);
  field?.classList.add('has-error');
  if (error) error.textContent = String(message || 'Data belum valid.');
}

function bindAuthFieldErrorReset(root = view) {
  $$('[data-auth-field] input', root).forEach(input => input.addEventListener('input', () => clearAuthFieldError(root, input.id)));
}

function normalizedRegisterDraft(root, provider = 'password') {
  const service = firebaseService();
  const fullName = String($('#registerFullName', root)?.value || '').trim().replace(/\s+/g, ' ');
  const usernameRaw = String($('#registerUsername', root)?.value || '');
  const username = service?.normalizeUsername?.(usernameRaw) || usernameRaw.toLowerCase().replace(/[^a-z0-9._]/g, '');
  const email = String($('#registerEmail', root)?.value || '').trim().toLowerCase();
  const password = String($('#registerPassword', root)?.value || '');
  const confirmPassword = String($('#registerConfirmPassword', root)?.value || '');
  return { fullName, username, email, password, confirmPassword, provider };
}

function validateRegisterDraft(root, draft) {
  let ok = true;
  if (draft.fullName.length < 2 || draft.fullName.length > 70) { setAuthFieldError(root, 'registerFullName', 'Nama lengkap harus 2–70 karakter.'); ok = false; }
  try { firebaseService()?.validateUsername?.(draft.username); }
  catch (error) { setAuthFieldError(root, 'registerUsername', error?.message || 'Username belum valid.'); ok = false; }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(draft.email)) { setAuthFieldError(root, 'registerEmail', 'Format email tidak valid.'); ok = false; }
  if (draft.password.length < 6) { setAuthFieldError(root, 'registerPassword', 'Password minimal 6 karakter.'); ok = false; }
  if (draft.password !== draft.confirmPassword) { setAuthFieldError(root, 'registerConfirmPassword', 'Konfirmasi password harus sama persis.'); ok = false; }
  return ok;
}

async function handleGoogleAuth() {
  const service = await ensureFirebaseReady();
  if (!service) return;
  try {
    const result = await service.loginGoogle();
    if (result.needsLink) return showGoogleLinkSheet(result);
    if (result.needsSetup) {
      state.auth.user = result.user;
      state.auth.profile = null;
      state.auth.pendingGoogle = result;
      state.auth.pendingOtp = null;
      state.auth.pendingRegistration = null;
      navigate('register');
      return;
    }
    state.auth.user = result.user; state.auth.profile = result.profile; state.auth.cloudLoaded = false;
    notify('Login Google berhasil');
    navigate(result.profile?.onboardingCompleted === false ? 'onboarding' : 'home');
  } catch (error) {
    notify(service.firebaseErrorMessage?.(error) || error?.message || 'Login Google gagal');
  }
}

function showGoogleLinkSheet(result) {
  openModal('Tautkan akun Google', `<p class="modal-description">${esc(result.message || 'Email sudah terdaftar. Verifikasi password akun lama untuk menautkan Google.')}</p><label class="auth-field"><span>Email</span><input id="linkGoogleEmail" type="email" value="${esc(result.email || '')}" ${result.email ? 'readonly' : ''} placeholder="nama@email.com"></label>${passwordFieldMarkup('linkGooglePassword','Password akun lama')}<button class="primary-btn" data-link-google>Tautkan dan masuk</button>`, root => {
    bindPasswordToggles(root);
    $('[data-link-google]', root).onclick = async () => {
      const button = $('[data-link-google]', root);
      button.disabled = true;
      try {
        await firebaseService().linkPendingGoogle($('#linkGoogleEmail', root).value, $('#linkGooglePassword', root).value);
        closeModal(); notify('Google berhasil ditautkan ke akun yang sama'); navigate('home');
      } catch (error) { notify(firebaseService().firebaseErrorMessage?.(error) || error?.message || 'Penautan Google gagal'); button.disabled = false; }
    };
  });
}

function renderLoginPage() {
  const configured = isFirebaseConfigured();
  view.innerHTML = authPageShell('Login DATZON', configured ? 'Masuk untuk menyinkronkan musikmu' : 'Firebase perlu dikonfigurasi terlebih dahulu', `
    ${!configured ? `<div class="auth-warning">${icon('alert')}<span>Firebase belum siap untuk login.</span></div>` : ''}
    <form id="loginForm" class="auth-form">
      <label class="auth-field" data-auth-field="loginEmail"><span>Email atau username</span><input id="loginEmail" type="text" autocomplete="username" autocapitalize="none" spellcheck="false" placeholder="nama@email.com atau @username" required><small class="auth-field-error" data-auth-error="loginEmail"></small></label>
      ${passwordFieldMarkup('loginPassword','Password','current-password','Minimal 6 karakter')}
      <button class="auth-primary" type="submit">Login</button>
    </form>
    <button class="auth-text-link" data-forgot-password>Lupa password?</button>
    <p class="auth-switch-copy">Belum punya akun? <button data-go-register>Daftar di sini</button></p>
    <div class="auth-divider"><span>atau</span></div>
    ${googleButtonMarkup()}`);
  $('[data-auth-back]', view).onclick = () => navigate('profile');
  bindPasswordToggles(view);
  bindAuthFieldErrorReset(view);
  $('[data-go-register]', view).onclick = () => navigate('register');
  const googleLoginButton = $('[data-google-auth]', view);
  googleLoginButton.onclick = handleGoogleAuth;
  $('[data-forgot-password]', view).onclick = showGuestPasswordResetSheet;
  let isSubmitting = false;
  $('#loginForm', view).onsubmit = async event => {
    event.preventDefault();
    if (isSubmitting) return;
    const form = event.currentTarget;
    const identifierInput = $('#loginEmail', form);
    const passwordInput = $('#loginPassword', form);
    const identifier = String(identifierInput?.value || '').trim();
    const password = String(passwordInput?.value || '');
    clearAuthFieldError(form, 'loginEmail'); clearAuthFieldError(form, 'loginPassword');
    if (!identifier) return setAuthFieldError(form, 'loginEmail', 'Masukkan email atau username.');
    if (password.length < 6) return setAuthFieldError(form, 'loginPassword', 'Password minimal 6 karakter.');
    const service = await ensureFirebaseReady();
    if (!service) return;

    isSubmitting = true;
    setAuthFormBusy(form, true, 'Memeriksa...');
    if (googleLoginButton) googleLoginButton.disabled = true;

    try {
      const challenge = await service.startPasswordOtpLogin(identifier, password, {
        onCredentialValidated: () => setAuthFormBusy(form, true, 'Mengirim kode...')
      });
      state.auth.pendingRegistration = null;
      state.auth.pendingOtp = challenge;
      notify('Kode verifikasi telah dikirim ke email kamu.');
      navigate('verify', { replace:true });
      return;
    } catch (error) {
      isSubmitting = false;
      setAuthFormBusy(form, false);
      if (googleLoginButton) googleLoginButton.disabled = false;
      const message = error?.message || 'Email/username atau password tidak valid.';
      notify(message);
      setAuthFieldError(form, 'loginEmail', /username/i.test(message) ? message : 'Periksa kembali email/username dan password.');
      setAuthFieldError(form, 'loginPassword', 'Credential belum dapat diverifikasi.');
      if (passwordInput) passwordInput.value = '';
    }
  };
}

function showGuestPasswordResetSheet() {
  openModal('Reset password', `<p class="modal-description">Masukkan email akun. Firebase akan mengirimkan tautan reset password.</p><label class="auth-field"><span>Email</span><input id="guestResetEmail" type="email" autocomplete="email" placeholder="nama@email.com"></label><button class="primary-btn" data-send-reset-link>Kirim link reset</button>`, root => $('[data-send-reset-link]', root).onclick = async () => {
    const button = $('[data-send-reset-link]', root); button.disabled = true;
    try { await firebaseService().sendResetEmail($('#guestResetEmail', root).value); closeModal(); notify('Link reset password dikirim ke email'); }
    catch (error) { notify(firebaseService().firebaseErrorMessage?.(error) || error?.message || 'Link reset gagal dikirim'); button.disabled = false; }
  });
}

function showGoogleRegistrationResetConfirm() {
  openModal('Ganti akun Google?', `<p class="modal-description">Data pendaftaran yang sudah kamu isi akan dihapus dan kamu akan diminta memilih akun kembali.</p><div class="auth-confirm-actions"><button class="secondary-btn" data-google-reset-cancel>Batal</button><button class="auth-confirm-primary" data-google-reset-confirm>Konfirmasi</button></div>`, root => {
    $('[data-google-reset-cancel]', root).onclick = closeModal;
    $('[data-google-reset-confirm]', root).onclick = async () => {
      const button = $('[data-google-reset-confirm]', root);
      button.disabled = true;
      try { await firebaseService().cancelPendingGoogleRegistration(); } catch {}
      state.auth.user = null;
      state.auth.profile = null;
      state.auth.pendingGoogle = null;
      state.auth.pendingOtp = null;
      state.auth.pendingRegistration = null;
      closeModal();
      navigate('register', { replace:true });
    };
  });
}

function renderRegisterPage() {
  const pendingSetup = state.auth.pendingGoogle?.needsSetup ? state.auth.pendingGoogle : null;
  const googleSetup = pendingSetup?.provider === 'google' ? pendingSetup : null;
  const configured = isFirebaseConfigured();
  const remembered = state.auth.pendingRegistration || {};
  const emailValue = googleSetup?.email || remembered.email || '';
  const nameValue = remembered.fullName || pendingSetup?.suggestedFullName || '';
  const usernameValue = remembered.username || '';
  view.innerHTML = authPageShell(googleSetup ? 'Lengkapi akun Google' : 'Register DATZON', googleSetup ? 'Lengkapi profil lalu verifikasi email Google kamu' : 'Buat akun Firebase baru', `
    ${!configured ? `<div class="auth-warning">${icon('alert')}<span>Firebase belum siap untuk pendaftaran.</span></div>` : ''}
    <form id="registerForm" class="auth-form">
      <label class="auth-field" data-auth-field="registerFullName"><span>Full Name</span><input id="registerFullName" type="text" maxlength="70" value="${esc(nameValue)}" placeholder="Nama lengkap" autocomplete="name" required><small class="auth-field-error" data-auth-error="registerFullName"></small></label>
      <label class="auth-field" data-auth-field="registerUsername"><span>Username</span><div class="username-input-wrap"><b>@</b><input id="registerUsername" type="text" maxlength="24" autocomplete="username" value="${esc(usernameValue)}" placeholder="usernameunik" required></div><small data-username-status>Huruf kecil, angka, titik, atau garis bawah.</small><small class="auth-field-error" data-auth-error="registerUsername"></small></label>
      <label class="auth-field" data-auth-field="registerEmail"><span>Email</span>${googleSetup ? `<div class="email-input-wrap"><input id="registerEmail" type="email" autocomplete="email" value="${esc(emailValue)}" readonly required><button type="button" class="google-email-reset" data-reset-google-email aria-label="Ganti akun Google">${icon('refresh')}</button></div>` : `<input id="registerEmail" type="email" autocomplete="email" value="${esc(emailValue)}" placeholder="nama@email.com" required>`}<small class="auth-field-error" data-auth-error="registerEmail"></small></label>
      ${passwordFieldMarkup('registerPassword', googleSetup ? 'Buat password akun DATZON' : 'Password', 'new-password', 'Minimal 6 karakter')}
      ${passwordFieldMarkup('registerConfirmPassword','Konfirmasi password','new-password','Minimal 6 karakter')}
      <button class="auth-primary" type="submit">${googleSetup ? 'Simpan dan lanjutkan' : 'Register'}</button>
    </form>
    <p class="auth-switch-copy">Sudah punya akun? <button data-go-login>Login di sini</button></p>
    ${googleSetup ? '' : `<div class="auth-divider"><span>atau</span></div>${googleButtonMarkup('Daftar atau masuk dengan Google')}`}`);
  $('[data-auth-back]', view).onclick = async () => {
    if (googleSetup) { try { await firebaseService()?.cancelPendingGoogleRegistration?.(); } catch {} }
    state.auth.pendingGoogle = null; state.auth.pendingRegistration = null; state.auth.pendingOtp = null; navigate('profile');
  };
  bindPasswordToggles(view);
  bindAuthFieldErrorReset(view);
  $('[data-go-login]', view).onclick = async () => {
    if (googleSetup) { try { await firebaseService()?.cancelPendingGoogleRegistration?.(); } catch {} }
    state.auth.pendingGoogle = null; state.auth.pendingRegistration = null; state.auth.pendingOtp = null; navigate('login');
  };
  $('[data-reset-google-email]', view)?.addEventListener('click', showGoogleRegistrationResetConfirm);
  const google = $('[data-google-auth]', view); if (google) google.onclick = handleGoogleAuth;
  const usernameInput = $('#registerUsername', view);
  let usernameTimer = null;
  usernameInput.oninput = () => {
    usernameInput.value = firebaseService()?.normalizeUsername?.(usernameInput.value) || usernameInput.value.toLowerCase().replace(/[^a-z0-9._]/g,'');
    clearAuthFieldError(view, 'registerUsername');
    clearTimeout(usernameTimer);
    const status = $('[data-username-status]', view);
    if (usernameInput.value.length < 3) { status.textContent = 'Huruf kecil, angka, titik, atau garis bawah.'; status.className = ''; return; }
    status.textContent = 'Memeriksa username...'; status.className = '';
    usernameTimer = setTimeout(async () => {
      try {
        const result = await firebaseService().checkUsername(usernameInput.value);
        status.textContent = result.available ? `@${result.username} tersedia` : `@${result.username} sudah digunakan`;
        status.className = result.available ? 'available' : 'taken';
      } catch (error) { status.textContent = error?.message || 'Username belum valid'; status.className = 'taken'; }
    }, 450);
  };
  $('#registerForm', view).onsubmit = async event => {
    event.preventDefault();
    const service = await ensureFirebaseReady();
    if (!service) return;
    const draft = normalizedRegisterDraft(view, googleSetup ? 'google' : 'password');
    if (!validateRegisterDraft(view, draft)) return;
    setAuthFormBusy(event.currentTarget, true, 'Mengirim kode...');
    try {
      const availability = await service.checkUsername(draft.username);
      if (!availability.available) { setAuthFieldError(view, 'registerUsername', `@${availability.username} sudah digunakan.`); return; }
      const challenge = await service.startRegistrationOtp(draft);
      state.auth.pendingRegistration = draft; // memory only; password is never written to local/session storage.
      state.auth.pendingOtp = challenge;
      notify('Kode verifikasi telah dikirim ke email kamu.');
      navigate('verify');
    } catch (error) {
      const message = error?.message || 'Pendaftaran belum dapat dilanjutkan.';
      if (/username/i.test(message)) setAuthFieldError(view, 'registerUsername', message);
      else if (/email/i.test(message)) setAuthFieldError(view, 'registerEmail', message);
      else notify(message);
    } finally { setAuthFormBusy(event.currentTarget, false); }
  };
}

let authOtpTimer = null;

function otpCodeFromInputs(root = view) {
  return $$('[data-otp-digit]', root).map(input => String(input.value || '').replace(/\D/g, '').slice(0,1)).join('');
}

function setOtpError(root, message) {
  const wrap = $('[data-otp-wrap]', root);
  const messageNode = $('[data-otp-message]', root);
  wrap?.classList.remove('otp-shake');
  void wrap?.offsetWidth;
  wrap?.classList.add('has-error', 'otp-shake');
  if (messageNode) { messageNode.textContent = message; messageNode.className = 'otp-status-message error'; }
}

function clearOtpError(root) {
  $('[data-otp-wrap]', root)?.classList.remove('has-error', 'otp-shake');
  const messageNode = $('[data-otp-message]', root);
  if (messageNode?.classList.contains('error')) { messageNode.textContent = ''; messageNode.className = 'otp-status-message'; }
}

function renderOtpVerificationPage() {
  if (authOtpTimer) { clearInterval(authOtpTimer); authOtpTimer = null; }
  const challenge = state.auth.pendingOtp;
  if (!challenge?.challengeId) {
    view.innerHTML = authPageShell('Verifikasi Email', 'Sesi verifikasi belum tersedia', `<div class="otp-empty-state">${icon('alert')}<p>Mulai ulang proses login atau pendaftaran untuk meminta kode baru.</p><button class="auth-primary" data-otp-restart>Kembali ke Login</button></div>`);
    $('[data-auth-back]', view).onclick = () => navigate('login', { replace:true });
    $('[data-otp-restart]', view).onclick = () => navigate('login', { replace:true });
    return;
  }
  const isRegister = /^register/.test(String(challenge.purpose || ''));
  const email = challenge.email || challenge.maskedEmail || state.auth.pendingRegistration?.email || '';
  view.innerHTML = authPageShell('Verifikasi Email', 'Satu langkah lagi untuk mengamankan akunmu', `
    <section class="otp-panel">
      <div class="otp-mail-icon">${icon('lock')}</div>
      <p class="otp-intro">Kami mengirim kode ke:</p>
      <strong class="otp-email">${esc(email)}</strong>
      <div class="otp-inputs" data-otp-wrap>
        ${Array.from({length:6}, (_, index) => `<input data-otp-digit="${index}" inputmode="numeric" pattern="[0-9]*" maxlength="${index===0?6:1}" ${index===0?'autocomplete="one-time-code"':''} aria-label="Digit kode ${index+1}">`).join('')}
        <span class="otp-success-check" data-otp-success>${icon('check-circle')}</span>
      </div>
      <p class="otp-expiry">Kode berlaku selama 10 menit</p>
      <p class="otp-status-message" data-otp-message></p>
      <button class="otp-resend" type="button" data-otp-resend disabled>Kirim ulang dalam 60 detik</button>
      <button class="auth-primary otp-confirm" type="button" data-otp-confirm>Konfirmasi</button>
    </section>`);
  $('[data-auth-back]', view).onclick = () => navigate(isRegister ? 'register' : 'login');
  const inputs = $$('[data-otp-digit]', view);
  const confirm = $('[data-otp-confirm]', view);
  const resend = $('[data-otp-resend]', view);
  const updateResend = () => {
    const remaining = Math.max(0, Math.ceil((Number(state.auth.pendingOtp?.resendAvailableAt || 0) - Date.now()) / 1000));
    resend.disabled = remaining > 0;
    resend.textContent = remaining > 0 ? `Kirim ulang dalam ${remaining} detik` : 'Kirim Ulang Kode';
  };
  updateResend();
  authOtpTimer = setInterval(() => {
    if (state.route !== 'verify') { clearInterval(authOtpTimer); authOtpTimer = null; return; }
    updateResend();
  }, 500);

  inputs.forEach((input, index) => {
    input.addEventListener('input', () => {
      clearOtpError(view);
      const digits = String(input.value || '').replace(/\D/g, '');
      if (digits.length > 1) {
        const available = digits.slice(0, inputs.length - index);
        available.split('').forEach((digit, offset) => { if (inputs[index + offset]) inputs[index + offset].value = digit; });
        input.value = available[0] || '';
        inputs[Math.min(inputs.length - 1, index + available.length - 1)]?.focus();
        return;
      }
      input.value = digits.slice(-1);
      if (input.value && index < inputs.length - 1) inputs[index + 1].focus();
    });
    input.addEventListener('keydown', event => {
      if (event.key === 'Backspace' && !input.value && index > 0) inputs[index - 1].focus();
      if (event.key === 'ArrowLeft' && index > 0) { event.preventDefault(); inputs[index - 1].focus(); }
      if (event.key === 'ArrowRight' && index < inputs.length - 1) { event.preventDefault(); inputs[index + 1].focus(); }
    });
    input.addEventListener('paste', event => {
      const digits = String(event.clipboardData?.getData('text') || '').replace(/\D/g, '').slice(0, 6);
      if (!digits) return;
      event.preventDefault(); clearOtpError(view);
      inputs.forEach((box, boxIndex) => { box.value = digits[boxIndex] || ''; });
      inputs[Math.min(digits.length, 6) - 1]?.focus();
    });
  });

  resend.onclick = async () => {
    if (resend.disabled) return;
    resend.disabled = true; resend.textContent = 'Mengirim kode...';
    try {
      const next = await firebaseService().resendOtp(challenge.challengeId);
      state.auth.pendingOtp = { ...state.auth.pendingOtp, ...next };
      inputs.forEach(input => { input.value = ''; input.disabled = false; });
      clearOtpError(view);
      inputs[0]?.focus();
      notify('Kode baru berhasil dikirim.');
    } catch (error) { notify(error?.message || 'Kode baru gagal dikirim.'); }
    updateResend();
  };

  confirm.onclick = async () => {
    const code = otpCodeFromInputs(view);
    if (code.length !== 6) { setOtpError(view, 'Masukkan 6 digit kode verifikasi.'); return; }
    confirm.disabled = true; confirm.textContent = 'Memverifikasi...';
    inputs.forEach(input => input.disabled = true);
    try {
      const registration = isRegister ? state.auth.pendingRegistration : null;
      if (isRegister && !registration?.password) throw new Error('Data pendaftaran sudah tidak tersedia. Kembali ke Register lalu kirim kode baru.');
      const result = await firebaseService().verifyOtp({
        challengeId: challenge.challengeId,
        code,
        registration,
        provider: registration?.provider || ''
      });
      const wrap = $('[data-otp-wrap]', view);
      wrap?.classList.remove('has-error'); wrap?.classList.add('is-success');
      $('[data-otp-success]', view)?.classList.add('show');
      const messageNode = $('[data-otp-message]', view);
      if (messageNode) { messageNode.textContent = 'Email berhasil diverifikasi.'; messageNode.className = 'otp-status-message success'; }
      notify('Email berhasil diverifikasi.');
      await new Promise(resolve => setTimeout(resolve, 700));
      state.auth.user = result.user || firebaseService().currentUser();
      state.auth.profile = result.profile || firebaseService().currentProfile();
      state.auth.cloudLoaded = false;
      state.auth.pendingOtp = null;
      state.auth.pendingRegistration = null;
      state.auth.pendingGoogle = null;
      if (result.purpose === 'login') {
        notify('Selamat datang kembali.');
        navigate(state.auth.profile?.onboardingCompleted === false ? 'onboarding' : 'home', { replace:true });
      } else {
        notify('Akun berhasil dibuat.');
        navigate('onboarding', { replace:true });
      }
    } catch (error) {
      inputs.forEach(input => input.disabled = false);
      confirm.disabled = false; confirm.textContent = 'Konfirmasi';
      const codeName = String(error?.code || '');
      if (codeName.includes('expired')) setOtpError(view, 'Kode verifikasi sudah kedaluwarsa.');
      else if (codeName.includes('invalid_code')) setOtpError(view, 'Kode verifikasi tidak valid.');
      else if (codeName.includes('too_many_attempts')) setOtpError(view, 'Terlalu banyak percobaan. Kirim kode baru untuk melanjutkan.');
      else setOtpError(view, error?.message || 'Verifikasi kode gagal.');
      inputs[0]?.focus();
    }
  };
  requestAnimationFrame(() => inputs[0]?.focus({ preventScroll:true }));
}

const ONBOARDING_ARTISTS = Object.freeze(['Tulus','Hindia','Nadin Amizah','Pamungkas','Billie Eilish','Taylor Swift','Olivia Rodrigo','Sabrina Carpenter','Lady Gaga','Bruno Mars','Mahalini','Sal Priadi']);
const onboardingArtistCatalogCache = new Map();

function onboardingArtistCover(name) {
  const saved = (state.preferredArtistMeta || []).find(item => normalizeMatchText(item?.name) === normalizeMatchText(name));
  if (saved?.image) return saved.image;
  return 'assets/placeholder.svg';
}

function onboardingEntityFromSaved(name) {
  const saved = (state.preferredArtistMeta || []).find(item => normalizeMatchText(item?.name) === normalizeMatchText(name));
  if (saved) return { kind:'artist', id:saved.spotifyArtistId || saved.id || '', name:saved.name || name, image:saved.image || 'assets/placeholder.svg', spotifyUrl:saved.externalUrl || saved.spotifyUrl || '' };
  return { kind:'artist', id:'', name, image:onboardingArtistCover(name), spotifyUrl:'' };
}

async function spotifyOnboardingArtistSearch(query, limit = 18) {
  const clean = String(query || '').trim();
  if (!clean || !spotifyCatalogAvailable() || !window.DatzonSpotifyCatalog?.artistSearch) return [];
  const key = normalizeMatchText(clean);
  const cached = onboardingArtistCatalogCache.get(key);
  if (cached && Date.now() - cached.at < 10 * 60 * 1000) return cached.items;
  const payload = await window.DatzonSpotifyCatalog.artistSearch(clean, { limit });
  const items = (payload?.artists?.items || []).map(spotifyCatalogArtistEntity).filter(item => item.id && item.name);
  onboardingArtistCatalogCache.set(key, { at:Date.now(), items });
  return items;
}

async function resolveDefaultOnboardingArtists(onUpdate) {
  if (!spotifyCatalogAvailable()) return;
  const queue = ONBOARDING_ARTISTS.slice();
  const workers = Array.from({ length:3 }, async () => {
    while (queue.length) {
      const name = queue.shift();
      if (!name) continue;
      try {
        const results = await spotifyOnboardingArtistSearch(name, 5);
        const exact = results.find(item => normalizeMatchText(item.name) === normalizeMatchText(name));
        if (exact) onUpdate(exact);
      } catch {}
    }
  });
  await Promise.allSettled(workers);
}

function renderArtistOnboardingPage() {
  if (!state.auth.user) { navigate('login', { replace:true }); return; }
  const selected = new Map();
  const storedMeta = Array.isArray(state.preferredArtistMeta) ? state.preferredArtistMeta : [];
  (state.preferredArtists || []).forEach(name => selected.set(normalizeMatchText(name), onboardingEntityFromSaved(name)));
  storedMeta.forEach(item => { if (item?.name && (state.preferredArtists || []).some(name => normalizeMatchText(name) === normalizeMatchText(item.name))) selected.set(normalizeMatchText(item.name), onboardingEntityFromSaved(item.name)); });
  const defaultEntities = new Map(ONBOARDING_ARTISTS.map(name => [normalizeMatchText(name), onboardingEntityFromSaved(name)]));
  let searchEntities = [];
  let searchLoading = false;
  let currentQuery = '';
  let debounceTimer = 0;
  let requestSerial = 0;

  const mergedEntities = () => {
    const map = new Map();
    [...searchEntities, ...defaultEntities.values(), ...selected.values()].forEach(entity => {
      const key = entity?.id ? `id:${entity.id}` : `name:${normalizeMatchText(entity?.name)}`;
      if (entity?.name && !map.has(key)) map.set(key, entity);
    });
    return [...map.values()].slice(0, 30);
  };

  const saveSelectedState = () => {
    const entities = [...selected.values()];
    state.preferredArtists = entities.map(item => item.name).filter(Boolean);
    state.preferredArtistMeta = entities.map(item => ({ spotifyArtistId:item.id || '', name:item.name, image:item.image || '', externalUrl:item.spotifyUrl || '' }));
  };

  const draw = ({ preserveFocus = false } = {}) => {
    const entities = mergedEntities();
    const inputValue = currentQuery;
    view.innerHTML = `<div class="page onboarding-page spotify-onboarding-page"><header><span>1 dari 1</span><h1>Pilih artis favoritmu</h1><p>Pilih minimal 3 artis. Foto profil artis diprioritaskan dari katalog Spotify agar identitas rekomendasi lebih akurat.</p></header><form id="artistSetupSearch" class="onboarding-search">${icon('search')}<input id="artistSetupInput" placeholder="Cari artis" autocomplete="off" value="${esc(inputValue)}"><button type="submit">Cari</button></form><div class="selected-counter"><strong>${selected.size}</strong><span>artis dipilih</span></div>${searchLoading ? `<div class="onboarding-artist-grid onboarding-artist-skeleton-grid">${Array.from({length:8},()=>'<div class="onboarding-artist-skeleton"><i class="skeleton"></i><span class="skeleton"></span></div>').join('')}</div>` : `<div class="onboarding-artist-grid">${entities.map(entity => { const key=normalizeMatchText(entity.name); const isSelected=selected.has(key); return `<button class="${isSelected?'selected':''}" data-setup-artist="${esc(key)}"><img src="${esc(entity.image || 'assets/placeholder.svg')}" alt="Foto ${esc(entity.name)}" loading="lazy" onerror="this.src='assets/placeholder.svg'"><span>${esc(entity.name)}</span><small>Artis</small><i>${icon('check')}</i></button>`; }).join('')}</div>`}<button class="onboarding-finish" data-finish-onboarding ${selected.size<3?'disabled':''}>Simpan pilihan</button></div>`;

    const input = $('#artistSetupInput', view);
    if (preserveFocus && input) { requestAnimationFrame(() => { input.focus(); input.setSelectionRange(input.value.length, input.value.length); }); }
    $$('[data-setup-artist]', view).forEach(button => button.onclick = () => {
      const key = button.dataset.setupArtist;
      const entity = entities.find(item => normalizeMatchText(item.name) === key);
      if (!entity) return;
      if (selected.has(key)) selected.delete(key); else selected.set(key, entity);
      saveSelectedState();
      draw();
    });

    const runSearch = async query => {
      const clean = String(query || '').trim();
      currentQuery = clean;
      if (!clean) { searchEntities=[]; searchLoading=false; draw({preserveFocus:true}); return; }
      const serial = ++requestSerial;
      searchLoading = true;
      draw({ preserveFocus:true });
      try {
        const spotifyArtists = await spotifyOnboardingArtistSearch(clean, 24);
        if (serial !== requestSerial) return;
        searchEntities = spotifyArtists;
        // If Spotify is unavailable, keep existing provider behavior as fallback but never use track artwork as an artist photo.
        if (!searchEntities.length) {
          try {
            const tracks = await searchSpotify(clean);
            const names = [...new Set(tracks.flatMap(track => extractArtistNames(track.artistNames, track.artist)).filter(Boolean))];
            searchEntities = names.map(name => ({ kind:'artist', id:'', name, image:'assets/placeholder.svg', spotifyUrl:'' }));
          } catch {}
        }
      } catch {
        if (serial !== requestSerial) return;
        searchEntities = [];
        try {
          const tracks = await searchSpotify(clean);
          const names = [...new Set(tracks.flatMap(track => extractArtistNames(track.artistNames, track.artist)).filter(Boolean))];
          searchEntities = names.map(name => ({ kind:'artist', id:'', name, image:'assets/placeholder.svg', spotifyUrl:'' }));
        } catch {}
      } finally {
        if (serial === requestSerial) { searchLoading=false; draw({preserveFocus:true}); }
      }
    };

    input?.addEventListener('input', event => {
      currentQuery = event.target.value;
      clearTimeout(debounceTimer);
      debounceTimer = window.setTimeout(() => runSearch(currentQuery), 420);
    });
    $('#artistSetupSearch', view).onsubmit = event => { event.preventDefault(); clearTimeout(debounceTimer); runSearch($('#artistSetupInput',view)?.value || ''); };
    $('[data-finish-onboarding]', view).onclick = async () => {
      if (selected.size < 3) return notify('Pilih minimal 3 artis');
      const button = $('[data-finish-onboarding]', view); button.disabled=true;
      try {
        saveSelectedState();
        await firebaseService().updateSelectedArtists(state.preferredArtists, state.preferredArtistMeta);
        persist(); await loadHome(true); notify('Rekomendasi artis berhasil disimpan'); navigate('home');
      } catch (error) { notify(firebaseService().firebaseErrorMessage?.(error) || error?.message || 'Pilihan artis gagal disimpan'); button.disabled=false; }
    };
  };

  draw();
  // Progressive enrichment: default cards render immediately, then exact Spotify artist images replace placeholders without blocking onboarding.
  resolveDefaultOnboardingArtists(entity => {
    const key = normalizeMatchText(entity.name);
    defaultEntities.set(key, entity);
    if (selected.has(key)) selected.set(key, entity);
    if (state.route === 'onboarding' && !searchLoading) draw();
  });
}

function profileSocialEditorRow(value = '') {
  const meta = socialLinkMeta(value);
  return `<div class="profile-social-editor-row" data-profile-social-row><span data-profile-social-preview>${socialBrandMarkup(meta)}</span><input type="url" inputmode="url" data-profile-social-input value="${esc(value)}" placeholder="https://instagram.com/username" aria-label="Tautan media sosial"><button type="button" data-remove-profile-social aria-label="Hapus tautan">${icon('trash')}</button></div>`;
}

function bindProfileSocialEditor(root) {
  const list = $('[data-profile-social-editor]', root);
  const bindRow = row => {
    const input = $('[data-profile-social-input]', row);
    const preview = $('[data-profile-social-preview]', row);
    input.addEventListener('input', () => { preview.innerHTML = socialBrandMarkup(socialLinkMeta(input.value)); });
    $('[data-remove-profile-social]', row).onclick = () => row.remove();
  };
  $$('[data-profile-social-row]', list).forEach(bindRow);
  $('[data-add-profile-social]', root).onclick = () => {
    if ($$('[data-profile-social-row]', list).length >= 8) return notify('Maksimal 8 tautan sosial');
    list.insertAdjacentHTML('beforeend', profileSocialEditorRow(''));
    const row = list.lastElementChild;
    bindRow(row);
    $('[data-profile-social-input]', row)?.focus();
  };
}

function showAccountModal() {
  if (!isLoggedIn()) {
    openModal('Edit profil tamu', `<label class="auth-field"><span>Nama pengguna lokal</span><input id="guestNameField" value="${esc(state.username)}" maxlength="40"></label><button class="primary-btn" data-save-guest-name>Simpan</button>`, root => $('[data-save-guest-name]', root).onclick = () => {
      const value = $('#guestNameField', root).value.trim();
      if (!value) return notify('Nama tidak boleh kosong');
      state.username = value.slice(0,40); persist(); closeModal(); render(); notify('Nama tamu diperbarui');
    });
    return;
  }
  const profile = state.auth.profile;
  const existingLinks = normalizedProfileSocialLinks(profile.socialLinks || []);
  openModal('Edit profil', `<div class="profile-edit-avatar">${accountAvatarMarkup('profile-avatar-edit')}<label class="photo-upload-btn">${icon('camera')}<span>Pilih foto</span><input id="profilePhotoFile" type="file" accept="image/jpeg,image/png,image/webp,image/gif" hidden></label></div><label class="auth-field"><span>Full Name</span><input id="editFullName" value="${esc(profile.fullName || '')}" maxlength="70"></label><label class="auth-field"><span>Username</span><div class="username-input-wrap"><b>@</b><input id="editUsername" value="${esc(profile.username || '')}" maxlength="24"></div><small data-edit-username-status>Username harus unik.</small></label><label class="auth-field profile-bio-editor"><span>Bio</span><textarea id="editProfileBio" maxlength="180" rows="4" placeholder="Ceritakan sedikit tentang dirimu...">${esc(profile.bio || '')}</textarea><small>Maksimal 180 karakter. Kosongkan jika tidak ingin ditampilkan.</small></label><section class="profile-social-editor"><header><div><strong>Tautan sosial</strong><small>Instagram, TikTok, YouTube, Spotify, atau website lain akan dideteksi otomatis.</small></div><button type="button" data-add-profile-social>${icon('plus-circle')} Tambah</button></header><div data-profile-social-editor>${existingLinks.map(profileSocialEditorRow).join('')}</div></section><label class="auth-field"><span>Email</span><input value="${esc(profile.email || state.auth.user.email || '')}" readonly></label><button class="primary-btn" data-save-firebase-profile>Simpan perubahan</button>`, root => {
    let photoFile = null;
    bindProfileSocialEditor(root);
    $('#profilePhotoFile', root).onchange = event => {
      photoFile = event.target.files?.[0] || null;
      if (!photoFile) return;
      const img = $('.profile-avatar-edit img', root);
      const url = URL.createObjectURL(photoFile);
      if (img) img.src = url;
      else $('.profile-avatar-edit', root).insertAdjacentHTML('afterbegin', `<img src="${url}" alt="Preview foto">`);
      $('.profile-avatar-edit', root).classList.add('has-photo');
    };
    $('#editUsername', root).oninput = event => event.target.value = firebaseService().normalizeUsername(event.target.value);
    $('[data-save-firebase-profile]', root).onclick = async () => {
      const button = $('[data-save-firebase-profile]', root); button.disabled = true; button.textContent = 'Menyimpan...';
      try {
        let photoURL = profile.photoURL || '';
        if (photoFile) photoURL = await firebaseService().uploadProfileImage(photoFile);
        const socialLinks = normalizedProfileSocialLinks($$('[data-profile-social-input]', root).map(input => input.value));
        const updated = await firebaseService().updateUserProfile({ fullName: $('#editFullName', root).value, username: $('#editUsername', root).value, photoURL, bio: $('#editProfileBio', root).value, socialLinks });
        state.auth.profile = updated; state.username = updated.fullName; persist(); closeModal(); render(); notify('Profil Firebase diperbarui');
      } catch (error) { notify(firebaseService().firebaseErrorMessage?.(error) || error?.message || 'Profil gagal diperbarui'); button.disabled = false; button.textContent = 'Simpan perubahan'; }
    };
  });
}

function showPasswordSecuritySheet() {
  if (!isLoggedIn()) return navigate('login');
  const hasPassword = providerHasPassword();
  openModal('Password dan keamanan', `<p class="modal-description">${hasPassword ? 'Masukkan password lama untuk membuat password baru.' : 'Akun Google ini belum memiliki password. Gunakan link reset email untuk membuat atau memulihkan akses email.'}</p>${hasPassword ? `${passwordFieldMarkup('oldPassword','Password lama','current-password','Minimal 6 karakter')}${passwordFieldMarkup('newPassword','Password baru','new-password','Minimal 6 karakter')}${passwordFieldMarkup('confirmNewPassword','Konfirmasi password baru','new-password','Minimal 6 karakter')}<button class="primary-btn" data-change-password>Ganti password</button>` : ''}<button class="secondary-btn security-email-reset" data-reset-current-email>${icon('external')} Kirim link reset ke ${esc(state.auth.user.email || '')}</button>`, root => {
    bindPasswordToggles(root);
    const change = $('[data-change-password]', root); if (change) change.onclick = async () => {
      const next = $('#newPassword', root).value;
      if (next !== $('#confirmNewPassword', root).value) return notify('Konfirmasi password baru tidak sama');
      change.disabled = true;
      try { await firebaseService().changePassword($('#oldPassword', root).value, next); closeModal(); notify('Password berhasil diganti'); }
      catch (error) { notify(firebaseService().firebaseErrorMessage?.(error) || error?.message || 'Password gagal diganti'); change.disabled = false; }
    };
    $('[data-reset-current-email]', root).onclick = async () => {
      const button = $('[data-reset-current-email]', root); button.disabled = true;
      try { await firebaseService().sendResetEmail(); closeModal(); notify('Link reset dikirim ke email akun'); }
      catch (error) { notify(firebaseService().firebaseErrorMessage?.(error) || error?.message || 'Link reset gagal dikirim'); button.disabled = false; }
    };
  });
}

function topStatEntries(source, limit = 5) {
  return Object.values(source || {}).sort((a,b) => Number(b.seconds || b.plays || 0) - Number(a.seconds || a.plays || 0)).slice(0,limit);
}

function renderStatisticsPage() {
  const stats = ensureListeningStats();
  const topTracks = topStatEntries(stats.tracks, 5);
  const topArtists = topStatEntries(stats.artists, 5);
  const lastDays = Array.from({length:7},(_,offset) => { const d = new Date(); d.setDate(d.getDate() - (6-offset)); const key = listeningDayKey(d); return { key, label: new Intl.DateTimeFormat('id-ID',{weekday:'short'}).format(d), seconds:Number(stats.days[key]?.seconds||0) }; });
  const maxDay = Math.max(1,...lastDays.map(day=>day.seconds));
  view.innerHTML = `<div class="page spotify-settings-page utility-page">${settingsPageHeader('Statistik Mendengarkan','Dihitung dari pemutaran di perangkat ini')}
    <section class="statistics-hero"><article><strong>${formatListeningTime(stats.totalSeconds)}</strong><span>Total waktu</span></article><article><strong>${stats.plays}</strong><span>Total pemutaran</span></article><article><strong>${Object.keys(stats.artists).length}</strong><span>Artis</span></article></section>
    <section class="stats-section"><h2>7 hari terakhir</h2><div class="stats-bars">${lastDays.map(day=>`<div><i style="height:${Math.max(5,Math.round(day.seconds/maxDay*100))}%"></i><span>${esc(day.label)}</span></div>`).join('')}</div></section>
    <section class="stats-section"><h2>Lagu teratas</h2>${topTracks.length ? `<div class="stats-ranked-list">${topTracks.map((item,index)=>`<article><b>${index+1}</b><img src="${esc(item.thumbnail||'assets/placeholder.svg')}" alt=""><span><strong>${esc(item.title||'Lagu')}</strong><small>${esc(item.artist||'')} • ${formatListeningTime(item.seconds)}</small></span></article>`).join('')}</div>` : '<p class="utility-empty-copy">Putar beberapa lagu untuk mulai membangun statistik.</p>'}</section>
    <section class="stats-section"><h2>Artis teratas</h2>${topArtists.length ? `<div class="stats-ranked-list">${topArtists.map((item,index)=>`<article><b>${index+1}</b><img class="round" src="${esc(item.thumbnail||'assets/placeholder.svg')}" alt=""><span><strong>${esc(item.name||'Artis')}</strong><small>${item.plays||0} pemutaran • ${formatListeningTime(item.seconds)}</small></span></article>`).join('')}</div>` : '<p class="utility-empty-copy">Belum ada artis yang tercatat.</p>'}</section>
  </div>`;
  bindUtilityHeader();
}

function renderDownloadsPage() {
  view.innerHTML = `<div class="page spotify-settings-page utility-page">${settingsPageHeader('Unduhan','Riwayat file MP3 yang dikirim ke browser')}
    <div class="utility-toolbar"><span>${state.downloads.length} unduhan</span><button data-clear-downloads ${state.downloads.length?'':'disabled'}>Hapus riwayat</button></div>
    ${state.downloads.length ? `<div class="download-history-list">${state.downloads.map((track,index)=>{const active=Boolean(state.current&&sameTrackIdentity(track,state.current));const playing=Boolean(active&&state.isPlaying);return `<button class="${active?'is-current':''} ${playing?'is-playing':''}" data-download-history="${index}" data-playback-track-id="${esc(trackFirebaseId(track)||trackKey(track))}" data-playback-label="${esc(cleanTitle(track))}"><img src="${esc(enhanceArtworkUrl(track.thumbnail))}" alt=""><span><strong>${esc(cleanTitle(track))}</strong><small>${esc(track.artist)} • ${track.downloadedAt ? new Intl.DateTimeFormat('id-ID',{dateStyle:'medium',timeStyle:'short'}).format(new Date(track.downloadedAt)) : 'Tersimpan'}</small><em>${esc(track.fileName||'MP3')}</em></span>${icon(playing?'pause':'play',playing?'':'fill')}</button>`;}).join('')}</div>` : '<div class="utility-empty-state">'+icon('download')+'<h2>Belum ada unduhan</h2><p>Lagu yang berhasil diunduh akan tercatat di sini tanpa menyimpan URL audio sementara.</p></div>'}
  </div>`;
  bindUtilityHeader();
  $$('[data-download-history]', view).forEach(button => button.onclick = async () => { const index=Number(button.dataset.downloadHistory); const selected=state.downloads[index]; if(state.current&&sameTrackIdentity(selected,state.current)){await togglePlay();syncVisibleTrackPlaybackIcons(view);return;} playTrack(selected, state.downloads, index); });
  const clear = $('[data-clear-downloads]', view); if (clear) clear.onclick = () => { state.downloads=[]; persist(); renderDownloadsPage(); notify('Riwayat unduhan dihapus'); };
}

function firebaseLogoMarkup() {
  return `<img class="firebase-logo firebase-logo-image" src="assets/firebase-logo.png" alt="Firebase" decoding="async">`;
}

function renderConnectionsPage() {
  const logged = isLoggedIn();
  view.innerHTML = `<div class="page spotify-settings-page utility-page">${settingsPageHeader('Koneksi Akun', logged ? 'Sinkronisasi Firebase dan cadangan data' : 'Cadangan data lokal sebelum login')}
    <section class="connection-card connection-card-local"><span>${logged ? firebaseLogoMarkup() : icon('download')}</span><div><h2>${logged ? 'Database Firebase' : 'Cadangan lokal'}</h2><p>${logged ? 'Favorit, riwayat, antrean, unduhan, statistik, artis, dan pengaturan disimpan tanpa data duplikat.' : 'Ekspor atau pulihkan favorit, riwayat, antrean, unduhan, statistik, dan seluruh pengaturan perangkat.'}</p></div></section>
    <div class="connection-actions"><button data-connection-export>${icon('download')} Ekspor data</button><button data-connection-import>${icon('arrow-up')} Impor data</button></div>
    <p class="firebase-note">${logged ? `Terhubung sebagai ${esc(state.auth.profile?.email || state.auth.user?.email || '')}. Data lagu memakai ID Spotify sebagai identitas utama agar tidak tersimpan dua kali.` : 'Login atau register untuk mengaktifkan sinkronisasi lintas perangkat melalui Firebase.'}</p>
    ${logged ? `<button class="connection-sync-now" data-sync-now>${icon('refresh')} Sinkronkan sekarang</button>` : `<button class="connection-login-now" data-connection-login>${icon('user')} Register / Login</button>`}
  </div>`;
  bindUtilityHeader();
  $('[data-connection-export]', view).onclick = logged ? showExportTargetSheet : backupData;
  $('[data-connection-import]', view).onclick = logged ? showImportTargetSheet : () => { state.importTarget='local'; restoreInput.click(); };
  const sync = $('[data-sync-now]', view); if (sync) sync.onclick = async () => {
    sync.disabled = true;
    try { await firebaseService().syncSnapshot(buildFirebaseSnapshot()); notify('Data Firebase sudah sinkron'); }
    catch (error) { notify(firebaseService().firebaseErrorMessage?.(error) || error?.message || 'Sinkronisasi gagal'); }
    finally { sync.disabled = false; }
  };
  const login = $('[data-connection-login]', view); if (login) login.onclick = () => isFirebaseConfigured() ? navigate('login') : showFirebaseSetupInfo();
}

function quickSettingCard(key, iconName, title, activeText, inactiveText='Nonaktif') {
  const active = Boolean(state.settings[key]);
  return `<button class="${active?'active':''}" data-card-toggle="${key}">${icon(iconName)}<strong>${esc(title)}</strong><span>${active?esc(activeText):esc(inactiveText)}</span></button>`;
}

function quickSettingsActionCard(action, iconName, title, subtitle) {
  return `<button class="settings-action-card" data-settings-shortcut="${action}">${icon(iconName)}<strong>${esc(title)}</strong><span>${esc(subtitle)}</span></button>`;
}

function renderSettings() {
  const desktopSettings = desktopModeActive();
  view.innerHTML = `<div class="page spotify-settings-page">${settingsPageHeader('Pengaturan')}
    <div class="spotify-settings-cards ${desktopSettings ? 'desktop-settings-cards' : ''}">
      ${quickSettingCard('dataSaver','bars','Hemat data','192 kbps')}
      ${quickSettingCard('highQuality','wavecode','Kualitas tinggi','320 kbps')}
      ${quickSettingCard('privateSession','eye-off','Sesi pribadi','Aktif')}
      ${desktopSettings ? quickSettingsActionCard('appearance','sparkles','Tampilan dan tema','Warna • Glass • Teks') : ''}
      ${desktopSettings ? quickSettingsActionCard('playback','volume','Playback','Autoplay • Antrean') : ''}
    </div>
    <div class="spotify-settings-list settings-category-list ${desktopSettings ? 'desktop-settings-category-list' : ''}">
      <button data-account-connections>${icon('user')}<span><strong>Akun dan koneksi</strong><small>${isLoggedIn() ? 'Firebase aktif • Profil • Cadangan database' : 'Profil lokal • Login • Cadangan data'}</small></span>${icon('chevron')}</button>
      ${desktopSettings ? '' : `<button data-appearance>${icon('sparkles')}<span><strong>Tampilan dan tema</strong><small>Warna dinamis • Liquid Glass • Ukuran teks</small></span>${icon('chevron')}</button>`}
      ${desktopSettings ? '' : `<button data-playback>${icon('volume')}<span><strong>Playback</strong><small>Autoplay • Antrean • Posisi terakhir</small></span>${icon('chevron')}</button>`}
      <button data-quality>${icon('bars')}<span><strong>Kualitas audio</strong><small>${esc(state.settings.streamingQuality)} • Download ${esc(state.settings.downloadQuality)}</small></span>${icon('chevron')}</button>
      <button data-storage>${icon('history')}<span><strong>Riwayat dan penyimpanan</strong><small>${state.history.length} riwayat • ${localStorageUsageText()}</small></span>${icon('chevron')}</button>
      <button data-privacy>${icon('lock')}<span><strong>Privasi dan personalisasi</strong><small>Sesi pribadi • Rekomendasi • Konten eksplisit</small></span>${icon('chevron')}</button>
      <button data-notification>${icon('bell')}<span><strong>Notifikasi</strong><small>Unduhan • Kegagalan audio • Pembaruan</small></span>${icon('chevron')}</button>
      <button data-device-settings>${icon('device')}<span><strong>Aplikasi dan perangkat</strong><small>Media Android • PWA • Sleep timer</small></span>${icon('chevron')}</button>
      <button data-report-page>${icon('report')}<span><strong>Laporkan masalah</strong><small>Kirim subjek, deskripsi, dan maksimal 3 screenshot</small></span>${icon('chevron')}</button>
      ${isAdminAccount() ? `<button data-admin-panel>${icon('grid')}<span><strong>Admin Panel</strong><small>Khusus admin • Pengguna • Laporan • Notifikasi global</small></span>${icon('chevron')}</button>` : ''}
      ${isAdminAccount() ? `<button data-admin-reports>${icon('history')}<span><strong>Catatan laporan</strong><small>Khusus admin • Konfirmasi dan tandai perbaikan</small></span>${icon('chevron')}</button>` : ''}
      <button data-about>${icon('info')}<span><strong>Tentang dan dukungan</strong><small>Versi 1.62.9 • Playlist UI Polish</small></span>${icon('chevron')}</button>
    </div>
    <button class="spotify-logout" data-logout>${isLoggedIn() ? 'Keluar akun' : 'Reset ke Tamu'}</button>
  </div>`;
  bindUtilityHeader();
  $$('[data-card-toggle]', view).forEach(button => button.onclick = () => {
    const key = button.dataset.cardToggle;
    state.settings[key] = !state.settings[key];
    if (key === 'dataSaver' && state.settings[key]) { state.settings.highQuality=false; state.settings.streamingQuality='Tinggi, 192 kbps'; }
    if (key === 'highQuality' && state.settings[key]) { state.settings.dataSaver=false; state.settings.streamingQuality='Sangat tinggi, 320 kbps'; }
    applyExperienceSettings(); persist(); renderSettings(); notify(`${button.querySelector('strong').textContent} ${state.settings[key] ? 'aktif' : 'nonaktif'}`);
  });
  $('[data-account-connections]', view).onclick = () => navigate('connections');
  $('[data-appearance]', view)?.addEventListener('click', showAppearanceSettings);
  $('[data-playback]', view)?.addEventListener('click', showPlaybackSettings);
  $$('[data-settings-shortcut]', view).forEach(button => button.onclick = () => {
    if (button.dataset.settingsShortcut === 'appearance') showAppearanceSettings();
    if (button.dataset.settingsShortcut === 'playback') showPlaybackSettings();
  });
  $('[data-quality]', view).onclick = showQualitySettings;
  $('[data-storage]', view).onclick = showStorageSettings;
  $('[data-privacy]', view).onclick = showPrivacySettings;
  $('[data-notification]', view).onclick = showNotificationPreferences;
  $('[data-device-settings]', view).onclick = showDeviceSettings;
  $('[data-report-page]', view).onclick = () => navigate('report');
  $('[data-admin-panel]', view)?.addEventListener('click', () => { window.location.href = '/admin'; });
  $('[data-admin-reports]', view)?.addEventListener('click', () => navigate('admin-reports'));
  $('[data-about]', view).onclick = showAboutSupport;
  $('[data-logout]', view).onclick = showLogoutConfirm;
}

function shareDatzonMusic() {
  const data = { title: 'DATZON Music', text: 'Dengarkan musik, lirik, dan kelola koleksimu di DATZON Music.', url: currentOriginUrl('/home') };
  if (navigator.share) navigator.share(data).catch(()=>{});
  else navigator.clipboard?.writeText(data.url).then(()=>notify('Tautan DATZON Music disalin')).catch(()=>notify('Tautan siap dibagikan'));
}

function showHelp() {
  const faqs = [
    ['Kenapa lagu kadang gagal diputar?', 'Audio putar, metadata, cover, dan download memprioritaskan Theresav Spotify. CMNTY dan Sylvatica tetap menjadi fallback; Spotyloader Sylvatica juga dapat mengambil track MP3 dan metadata saat jalur lain bermasalah. Tekan putar lagi agar DATZON menyiapkan URL baru.'],
    ['Kenapa lirik tidak muncul?', 'Tidak semua lagu memiliki lirik. Lirik bertimestamp dari Theresav dipakai langsung jika tersedia; jika tidak ada timestamp, DATZON mencoba Sylvatica lalu CMNTY. Fokus otomatis hanya aktif jika timestamp valid terdeteksi.'],
    ['Bagaimana mengaktifkan fokus lirik otomatis?', 'Fokus aktif otomatis ketika lirik bertimestamp yang cocok ditemukan. Tombol di kartu Lirik dapat dipakai untuk mematikannya, lalu menyalakannya kembali selama timestamp tersedia.'],
    ['Di mana data saya disimpan?', 'Pengguna tamu menyimpan data di perangkat melalui localStorage. Pengguna yang login menyinkronkan koleksi, playlist, riwayat, dan pengaturan ke Firebase.'],
    ['Kenapa data belum muncul di perangkat lain?', 'Pastikan akun yang dipakai sama, koneksi internet aktif, lalu buka Koneksi Akun dan tekan Sinkronkan sekarang.'],
    ['Bagaimana membuat dan mengatur playlist?', 'Buka menu lagu, pilih Tambahkan ke playlist, lalu pilih Playlist baru. Pada detail playlist, tekan titik tiga di setiap lagu untuk menaikkan, menurunkan, atau menghapusnya.'],
    ['Kenapa download MP3 gagal?', 'Provider mungkin sedang sibuk atau link unduhan sudah kedaluwarsa. Coba buka ulang lagu dan tekan Download MP3 sekali lagi.'],
    ['Bagaimana menambahkan teman?', 'Buka halaman Teman, cari nama atau username, lalu tekan Tambah teman. Jika pengguna tersebut menerima permintaan, status berubah menjadi Teman.'],
    ['Apa fungsi status Online, Offline, dan Sibuk?', 'Status membantu teman mengetahui ketersediaan akun. Status dapat diubah melalui tombol bulat di halaman Home saat kamu sudah login.'],
    ['Bagaimana mengganti foto profil?', 'Buka Profil Saya, pilih Edit profil, lalu unggah foto. Foto akan disimpan melalui Cloudinary dan ditampilkan di seluruh bagian akun.'],
    ['Bagaimana mengganti atau mereset password?', 'Buka Profil Saya lalu Password dan keamanan. Kamu bisa mengganti password memakai password lama atau mengirim link reset ke email akun.'],
    ['Kenapa rekomendasi Home berubah?', 'Rekomendasi mengikuti artis pilihan, riwayat dengar, lagu yang disukai, dan koleksi lokal. Sesi pribadi tidak menambah riwayat baru.'],
    ['Apa fungsi Pengatur Waktu Tidur?', 'Fitur ini menjeda musik secara otomatis setelah durasi yang kamu pilih. Pilihan Akhir lagu membiarkan lagu sekarang selesai, lalu menghentikan pemutaran tanpa melanjutkan ke lagu berikutnya. Timer aktif dapat dibatalkan kapan saja.'],
    ['Bagaimana melaporkan bug atau masalah?', 'Tekan tombol Laporkan Masalah di bawah. Isi subjek, deskripsi, dan lampirkan maksimal tiga screenshot agar admin lebih mudah memeriksa masalah.'],
    ['Apakah laporan dapat dikirim tanpa login?', 'Tidak. Login diperlukan agar admin dapat mengetahui akun pengirim, memberi konfirmasi, dan mengirim kabar ketika masalah selesai diperbaiki.'],
    ['Bagaimana mengetahui laporan sudah diterima?', 'Setelah admin menekan Konfirmasi, notifikasi Laporanmu sudah dikonfirmasi akan masuk ke akunmu. Status laporan tetap tersimpan pada sistem admin.'],
    ['Apa yang terjadi setelah masalah diperbaiki?', 'Admin menandai laporan sebagai Selesai. Pengirim menerima notifikasi pribadi dan seluruh pengguna menerima pengumuman perbaikan pada pusat notifikasi.'],
    ['Apa fungsi Hemat data?', 'Hemat data menurunkan preferensi audio satu tingkat ke 192 kbps dan mengurangi pemuatan awal. Kualitas tinggi 320 kbps tetap menjadi pengaturan bawaan.'],
    ['Mengapa foto profil belum berubah?', 'Tunggu proses unggah Cloudinary selesai, lalu buka ulang Profil Saya. Pastikan file berupa JPG, PNG, WEBP, atau GIF dan ukurannya tidak lebih dari 5 MB.'],
    ['Bagaimana mengekspor atau memulihkan data?', 'Buka Pengaturan, pilih Akun dan koneksi, lalu gunakan Ekspor data atau Impor data. Saat login, kamu dapat memilih penyimpanan lokal atau Firebase.'],
    ['Mengapa status akun terlihat Offline padahal saya baru membuka aplikasi?', 'Status diperbarui saat sesi Firebase siap. Koneksi lambat, mode hemat baterai, atau tab yang lama berada di latar belakang dapat menunda pembaruan beberapa saat.'],
    ['Apakah screenshot laporan dapat dilihat pengguna lain?', 'Tidak. Screenshot laporan hanya dapat dibaca oleh akun pengirim dan pengguna dengan role admin melalui aturan keamanan Firestore.']
  ];
  const sheet = openPlayerSheet(`<div class="help-sheet-content"><header><div><small>PUSAT BANTUAN</small><h2>Bantuan</h2></div><button data-close-help aria-label="Tutup">${icon('close')}</button></header><div class="help-list">${faqs.map(([question,answer])=>`<details><summary>${esc(question)}</summary><p>${esc(answer)}</p></details>`).join('')}<button class="primary-btn help-report-button" data-open-report>${icon('report')} Laporkan Masalah</button></div></div>`, 'help-player-sheet', { kind:'adaptive', initialSnap:'half' });
  $('[data-close-help]', sheet).onclick = () => closeModal(true);
  $$('details', sheet).forEach(details => details.addEventListener('toggle', () => {
    if (!details.open) return;
    $$('details', sheet).forEach(other => { if (other !== details) other.open = false; });
  }));
  $('[data-open-report]', sheet).onclick = () => { closeModal(true); navigate('report'); };
}

function copyDiagnostics() {
  const text = [`DATZON Music ${CONFIG.version}`,`Route: ${state.route}`,`Current: ${state.current?`${cleanTitle(state.current)} - ${state.current.artist}`:'Tidak ada'}`,`History: ${state.history.length}`,`Downloads: ${state.downloads.length}`,`Spotify Catalog: ${spotifyCatalogAvailable()?'Server-side aktif':'Fallback provider'}`,`API online: ${state.apiOnline}`].join('\n');
  navigator.clipboard?.writeText(text).then(()=>notify('Diagnostik disalin')).catch(()=>notify('Diagnostik siap disalin'));
}

function reportDiagnosticsPayload() {
  return {
    appVersion: CONFIG.version,
    route: state.route,
    currentTrack: state.current ? `${cleanTitle(state.current)} - ${state.current.artist}` : '',
    historyCount: state.history.length,
    downloadCount: state.downloads.length,
    spotifyCatalogServerSide: spotifyCatalogAvailable(),
    apiOnline: state.apiOnline,
    userAgent: navigator.userAgent,
    viewport: `${window.innerWidth}x${window.innerHeight}`,
    createdAtIso: new Date().toISOString()
  };
}

function reportStatusLabel(status = '') {
  return status === 'fixed' ? 'Selesai' : status === 'confirmed' ? 'Dikonfirmasi' : 'Menunggu konfirmasi';
}

function reportStatusClass(status = '') {
  return status === 'fixed' ? 'is-fixed' : status === 'confirmed' ? 'is-confirmed' : 'is-submitted';
}

function renderReportPage() {
  const logged = isLoggedIn();
  view.innerHTML = `<div class="page spotify-settings-page utility-page report-page">${settingsPageHeader('Laporkan Masalah', logged ? 'Kirim laporan langsung ke admin DATZON' : 'Login diperlukan untuk mengirim laporan')}
    ${!logged ? `<section class="report-login-required">${icon('lock')}<h2>Masuk untuk membuat laporan</h2><p>Laporan disimpan di Firebase dan diteruskan kepada semua akun dengan role admin.</p><button data-report-login>Login / Register</button></section>` : `<form id="reportForm" class="report-form">
      <label><span>Subjek</span><input id="reportSubject" maxlength="120" minlength="4" value="${esc(state.reportDraftSubject)}" placeholder="Contoh: Lagu berhenti saat membuka lirik" required></label>
      <label><span>Deskripsi</span><textarea id="reportDescription" maxlength="5000" minlength="10" rows="7" placeholder="Jelaskan langkah yang dilakukan, hasil yang muncul, dan hasil yang kamu harapkan." required>${esc(state.reportDraftDescription)}</textarea></label>
      <section class="report-upload-section"><div><strong>Screenshot masalah</strong><small>Maksimal 3 gambar, masing-masing 5 MB</small></div><button type="button" data-add-report-images>${icon('camera')} Pilih gambar</button><input id="reportImages" type="file" accept="image/jpeg,image/png,image/webp,image/gif" multiple hidden></section>
      <div class="report-image-previews">${state.reportDraftFiles.map((file,index)=>`<article><img src="${esc(URL.createObjectURL(file))}" alt="Screenshot ${index+1}"><button type="button" data-remove-report-image="${index}" aria-label="Hapus gambar">${icon('close')}</button><small>${esc(file.name)}</small></article>`).join('')}</div>
      <div class="report-form-note">${icon('info')}<p>Informasi versi aplikasi, halaman aktif, perangkat, dan status layanan akan ikut dikirim sebagai diagnostik.</p></div>
      <button class="primary-btn report-submit" type="submit">${icon('report')} Kirim laporan</button>
    </form>`}
  </div>`;
  bindUtilityHeader();
  $('[data-report-login]', view)?.addEventListener('click', () => navigate('login'));
  if (!logged) return;
  $('#reportSubject', view).oninput = event => { state.reportDraftSubject = event.target.value; };
  $('#reportDescription', view).oninput = event => { state.reportDraftDescription = event.target.value; };
  $('[data-add-report-images]', view).onclick = () => $('#reportImages', view).click();
  $('#reportImages', view).onchange = event => {
    const incoming = [...(event.target.files || [])];
    const combined = [...state.reportDraftFiles];
    incoming.forEach(file => {
      const same = combined.some(item => item.name === file.name && item.size === file.size && item.lastModified === file.lastModified);
      if (!same && combined.length < 3) combined.push(file);
    });
    state.reportDraftFiles = combined.slice(0, 3);
    renderReportPage();
  };
  $$('[data-remove-report-image]', view).forEach(button => button.onclick = () => {
    state.reportDraftFiles.splice(Number(button.dataset.removeReportImage), 1);
    renderReportPage();
  });
  $('#reportForm', view).onsubmit = async event => {
    event.preventDefault();
    const submit = $('.report-submit', view);
    const subject = $('#reportSubject', view).value.trim();
    const description = $('#reportDescription', view).value.trim();
    if (subject.length < 4 || description.length < 10) { notify('Lengkapi subjek dan deskripsi laporan'); return; }
    submit.disabled = true;
    submit.innerHTML = '<span class="loading-ring" aria-hidden="true"></span> Mengirim laporan...';
    try {
      const service = await ensureFirebaseReady();
      if (!service) throw new Error('Firebase belum siap.');
      const screenshots = await service.uploadReportImages(state.reportDraftFiles);
      await service.submitReport({ subject, description, screenshots, diagnostics: reportDiagnosticsPayload() });
      state.reportDraftFiles = [];
      state.reportDraftSubject = '';
      state.reportDraftDescription = '';
      notify('Laporan berhasil dikirim kepada admin');
      navigateBack('settings');
    } catch (error) {
      notify(firebaseService()?.firebaseErrorMessage?.(error) || error?.message || 'Laporan gagal dikirim');
      submit.disabled = false;
      submit.innerHTML = `${icon('message')} Kirim laporan`;
    }
  };
}

async function loadAdminReports(force = false) {
  if (!isAdminAccount()) return [];
  if (state.adminReportsLoading) return state.adminReports;
  if (state.adminReportsLoaded && !force) return state.adminReports;
  state.adminReportsLoading = true;
  try {
    const service = await ensureFirebaseReady();
    state.adminReports = service ? await service.loadAdminReports(200) : [];
    state.adminReportsLoaded = true;
  } catch (error) {
    state.adminReportsLoaded = true;
    notify(firebaseService()?.firebaseErrorMessage?.(error) || error?.message || 'Catatan laporan gagal dimuat');
  }
  state.adminReportsLoading = false;
  return state.adminReports;
}

function adminReportRow(report = {}) {
  const time = socialTimeText(report.createdAtMs || report.createdAt);
  return `<button class="admin-report-row" data-admin-report="${esc(report.id)}"><span class="report-status-dot ${reportStatusClass(report.status)}"></span><div><strong>${esc(report.subject || 'Laporan tanpa subjek')}</strong><small>@${esc(report.reporterUsername || 'pengguna')} • ${esc(time)}</small><p>${esc(String(report.description || '').slice(0, 140))}</p></div><em class="${reportStatusClass(report.status)}">${esc(reportStatusLabel(report.status))}</em>${icon('chevron')}</button>`;
}

function renderAdminReportsPage() {
  if (!isAdminAccount()) {
    view.innerHTML = `<div class="page spotify-settings-page utility-page admin-reports-page">${settingsPageHeader('Catatan Laporan','Khusus pengguna dengan role admin')}<section class="report-login-required">${icon('lock')}<h2>Akses admin diperlukan</h2><p>Akun ini tidak memiliki izin untuk membuka catatan laporan.</p></section></div>`;
    bindUtilityHeader();
    return;
  }
  const reports = state.adminReports || [];
  const submitted = reports.filter(item => item.status === 'submitted');
  const confirmed = reports.filter(item => item.status === 'confirmed');
  const fixed = reports.filter(item => item.status === 'fixed');
  view.innerHTML = `<div class="page spotify-settings-page utility-page admin-reports-page">${settingsPageHeader('Catatan Laporan','Konfirmasi laporan dan catat perbaikan')}
    <section class="admin-report-summary"><article><strong>${submitted.length}</strong><span>Menunggu</span></article><article><strong>${confirmed.length}</strong><span>Dikonfirmasi</span></article><article><strong>${fixed.length}</strong><span>Selesai</span></article></section>
    ${state.adminReportsLoading ? '<div class="social-loading">Memuat laporan...</div>' : `<section class="admin-report-section"><h2>Menunggu konfirmasi</h2>${submitted.length ? submitted.map(adminReportRow).join('') : '<div class="social-empty">Tidak ada laporan baru.</div>'}</section><section class="admin-report-section"><h2>Catatan dikonfirmasi</h2>${confirmed.length ? confirmed.map(adminReportRow).join('') : '<div class="social-empty">Belum ada laporan yang dikonfirmasi.</div>'}</section><section class="admin-report-section"><h2>Selesai diperbaiki</h2>${fixed.length ? fixed.map(adminReportRow).join('') : '<div class="social-empty">Belum ada laporan selesai.</div>'}</section>`}
  </div>`;
  bindUtilityHeader();
  $$('[data-admin-report]', view).forEach(button => button.onclick = () => showReportDetail(button.dataset.adminReport));
  if (!state.adminReportsLoaded && !state.adminReportsLoading) loadAdminReports(true).then(() => { if (state.route === 'admin-reports') renderAdminReportsPage(); });
}

async function showReportDetail(reportOrId) {
  let report = typeof reportOrId === 'object' ? reportOrId : state.adminReports.find(item => item.id === reportOrId);
  try {
    const service = await ensureFirebaseReady();
    if (!service) return;
    if (!report || !report.description) report = await service.getReport(typeof reportOrId === 'string' ? reportOrId : reportOrId?.id);
    if (!report) throw new Error('Laporan tidak ditemukan.');
    const canManage = isAdminAccount();
    const screenshots = Array.isArray(report.screenshots) ? report.screenshots : [];
    const sheet = openPlayerSheet(`<div class="report-detail-sheet"><header><div><small>${esc(reportStatusLabel(report.status).toUpperCase())}</small><h2>${esc(report.subject || 'Laporan masalah')}</h2></div><button data-close-report-detail>${icon('close')}</button></header><div class="report-detail-meta"><span>${publicAvatarMarkup({fullName:report.reporterFullName,username:report.reporterUsername,photoURL:report.reporterPhotoURL},'reporter-avatar')}<b>${esc(report.reporterFullName || 'Pengguna DATZON')}<small>@${esc(report.reporterUsername || 'pengguna')} • ${esc(socialTimeText(report.createdAtMs || report.createdAt))}</small></b></span><em class="${reportStatusClass(report.status)}">${esc(reportStatusLabel(report.status))}</em></div><section><h3>Deskripsi</h3><p>${esc(report.description || '')}</p></section>${screenshots.length ? `<section><h3>Screenshot</h3><div class="report-detail-images">${screenshots.map((url,index)=>`<a href="${esc(url)}" target="_blank" rel="noopener"><img src="${esc(url)}" alt="Screenshot ${index+1}"></a>`).join('')}</div></section>` : ''}${canManage ? `<div class="report-admin-actions">${report.status === 'submitted' ? `<button class="primary-btn" data-confirm-report>Konfirmasi laporan</button>` : ''}${report.status === 'confirmed' ? `<button class="primary-btn" data-fix-report>Tandai sudah diperbaiki</button>` : ''}${report.status === 'fixed' ? `<span class="report-complete-note">${icon('check-circle')} Perbaikan sudah diumumkan kepada pengguna.</span>` : ''}</div>` : ''}</div>`, 'report-detail-player-sheet', {kind:'adaptive',initialSnap:'full'});
    $('[data-close-report-detail]', sheet).onclick = () => closeModal(true);
    $('[data-confirm-report]', sheet)?.addEventListener('click', async event => {
      event.currentTarget.disabled = true;
      try { await service.confirmReport(report.id); closeModal(true); state.adminReports=[]; state.adminReportsLoaded=false; await loadAdminReports(true); if (state.route === 'admin-reports') renderAdminReportsPage(); notify('Laporan dikonfirmasi dan pengguna sudah diberi notifikasi'); }
      catch (error) { notify(firebaseService()?.firebaseErrorMessage?.(error) || error?.message || 'Konfirmasi gagal'); event.currentTarget.disabled=false; }
    });
    $('[data-fix-report]', sheet)?.addEventListener('click', async event => {
      event.currentTarget.disabled = true;
      try { await service.markReportFixed(report.id); closeModal(true); state.adminReports=[]; state.adminReportsLoaded=false; await loadAdminReports(true); if (state.route === 'admin-reports') renderAdminReportsPage(); notify('Perbaikan diumumkan kepada seluruh pengguna'); }
      catch (error) { notify(firebaseService()?.firebaseErrorMessage?.(error) || error?.message || 'Pembaruan laporan gagal'); event.currentTarget.disabled=false; }
    });
  } catch (error) {
    notify(firebaseService()?.firebaseErrorMessage?.(error) || error?.message || 'Laporan gagal dibuka');
  }
}

function showLogoutConfirm() {
  const logged = isLoggedIn();
  openModal(logged ? 'Keluar dari akun' : 'Reset profil tamu', `<p class="modal-description">${logged ? 'Sesi Firebase akan dihentikan. Data lokal tetap tersedia dan akun dapat digunakan kembali dengan login.' : 'Nama lokal akan direset menjadi Tamu. Koleksi, riwayat, unduhan, dan pengaturan tidak dihapus.'}</p><button class="danger-btn" data-confirm-logout>${logged ? 'Keluar akun' : 'Reset ke Tamu'}</button>`, root => $('[data-confirm-logout]',root).onclick = async () => {
    const button = $('[data-confirm-logout]',root); button.disabled = true;
    try {
      if (logged) await firebaseService().logout();
      state.username='Tamu'; state.auth.user=null; state.auth.profile=null; state.auth.hydratedUid=''; state.auth.cloudLoaded=false; storage.set('username','Tamu'); persist(); closeModal(); navigate('home'); notify(logged ? 'Berhasil keluar dari akun' : 'Profil direset menjadi Tamu');
    } catch (error) { notify(firebaseService()?.firebaseErrorMessage?.(error) || error?.message || 'Gagal keluar akun'); button.disabled = false; }
  });
}

function showAccountStatusSheet() {
  if (!isLoggedIn()) return;
  const current = normalizedAccountStatus();
  const options = [
    { value: 'online', label: 'Online', detail: 'Tampilkan status aktif', tone: 'green' },
    { value: 'offline', label: 'Offline', detail: 'Sembunyikan status aktif', tone: 'gray' },
    { value: 'busy', label: 'Sibuk', detail: 'Beri tahu bahwa kamu sedang tidak ingin diganggu', tone: 'red' }
  ];
  const sheet = openPlayerSheet(`<div class="account-status-sheet">
    <header><div><small>STATUS AKUN</small><h2>Pilih status</h2></div><button data-close-account-status aria-label="Tutup">${icon('close')}</button></header>
    <div class="account-status-options">${options.map(option => `<button class="${current === option.value ? 'selected' : ''}" data-account-status-choice="${option.value}"><i class="status-${option.tone}"></i><span><strong>${option.label}</strong><small>${option.detail}</small></span>${current === option.value ? icon('check-circle') : ''}</button>`).join('')}</div>
  </div>`, 'account-status-player-sheet', { kind: 'compact', initialSnap: 'half' });
  $('[data-close-account-status]', sheet).onclick = () => closeModal(true);
  $$('[data-account-status-choice]', sheet).forEach(button => button.onclick = async () => {
    const nextStatus = button.dataset.accountStatusChoice;
    if (nextStatus === normalizedAccountStatus()) { closeModal(true); return; }
    $$('[data-account-status-choice]', sheet).forEach(item => item.disabled = true);
    try {
      const service = await ensureFirebaseReady();
      if (!service) return;
      const updated = await service.updateAccountStatus(nextStatus);
      state.auth.profile = updated || { ...(state.auth.profile || {}), preferredStatus: nextStatus, status: nextStatus };
      closeModal(true);
      render();
      notify(`Status diubah menjadi ${accountStatusLabel(nextStatus)}`);
    } catch (error) {
      notify(firebaseService()?.firebaseErrorMessage?.(error) || error?.message || 'Status gagal diperbarui');
      $$('[data-account-status-choice]', sheet).forEach(item => item.disabled = false);
    }
  });
}

function desktopModeActive() {
  return Boolean(window.matchMedia?.('(min-width: 1024px)').matches);
}

function desktopSidebarActiveAction() {
  if (state.route === 'profile') return 'profile';
  if (state.route === 'statistics') return 'stats';
  if (['people','friends','following','followers','public-profile'].includes(state.route)) return 'friends';
  if (state.route === 'leaderboard') return 'leaderboard';
  if (state.route === 'downloads') return 'downloads';
  if (state.route === 'connections') return 'connections';
  if (state.route === 'settings') return 'settings';
  if (state.route === 'report') return 'report';
  if (state.route === 'admin-reports') return 'admin-reports';
  return '';
}

function desktopSidebarButtonClass(action) {
  return desktopSidebarActiveAction() === action ? ' class="active"' : '';
}

function desktopSidebarMarkup() {
  return `<aside class="side-drawer side-drawer-v123 desktop-side-drawer" aria-label="Menu akun desktop">
    <button class="drawer-profile ${state.route === 'profile' ? 'active' : ''}" data-desktop-drawer-action="profile">${currentProfilePhoto() ? `<span class="drawer-avatar has-photo${accountAvatarPlaybackClass()}"><img src="${esc(currentProfilePhoto())}" alt=""></span>` : `<span class="drawer-avatar${accountAvatarPlaybackClass()}">${esc(accountInitial())}</span>`}<div><strong>${esc(currentAccountName())}</strong><small>${isLoggedIn() ? '@'+esc(state.auth.profile?.username || '') : 'Profil Tamu'}</small></div>${icon('chevron')}</button>
    <div class="drawer-section-label">Koleksi dan aktivitas</div>
    <div class="drawer-menu">
      <button data-desktop-drawer-action="recent">${icon('history')}<span>Riwayat Diputar</span></button>
      <button${desktopSidebarButtonClass('stats')} data-desktop-drawer-action="stats">${icon('bars')}<span>Statistik Mendengarkan</span></button>
      <button${desktopSidebarButtonClass('friends')} data-desktop-drawer-action="friends">${icon('group')}<span>Cari pengguna</span><em>${isLoggedIn() ? state.social.friends.length || '' : ''}</em></button>
      <button${desktopSidebarButtonClass('leaderboard')} data-desktop-drawer-action="leaderboard">${icon('trending')}<span>Leaderboard</span></button>
      <button${desktopSidebarButtonClass('downloads')} data-desktop-drawer-action="downloads">${icon('download')}<span>Unduhan</span><em>${state.downloads.length||''}</em></button>
      <button${desktopSidebarButtonClass('connections')} data-desktop-drawer-action="connections">${icon('external')}<span>Koneksi Akun</span><em>${isLoggedIn()?'Firebase':''}</em></button>
      <button data-desktop-drawer-action="system">${icon('alert')}<span>Status Sistem</span><em>${state.systemActivityUnread||''}</em></button>
      <button${desktopSidebarButtonClass('settings')} data-desktop-drawer-action="settings">${icon('settings')}<span>Pengaturan dan Privasi</span></button>
      <button${desktopSidebarButtonClass('report')} data-desktop-drawer-action="report">${icon('report')}<span>Laporkan Masalah</span></button>
      ${isAdminAccount() ? `<button${desktopSidebarButtonClass('admin-reports')} data-desktop-drawer-action="admin-reports">${icon('history')}<span>Catatan Laporan</span></button>` : ''}
    </div>
    <div class="drawer-section-label">DATZON</div>
    <div class="drawer-menu drawer-menu-secondary">
      <button data-desktop-drawer-action="share">${icon('share')}<span>Bagikan DATZON Music</span></button>
      <button data-desktop-drawer-action="help">${icon('info')}<span>Bantuan</span></button>
      <button data-desktop-drawer-action="about">${icon('music')}<span>Tentang DATZON Music</span></button>
      <button class="drawer-logout" data-desktop-drawer-action="logout">${icon('external')}<span>${isLoggedIn()?'Keluar akun':'Reset ke Tamu'}</span></button>
    </div>
  </aside>`;
}

function renderDesktopSidebar() {
  if (!desktopSidebarRoot) return;
  if (!desktopModeActive()) {
    desktopSidebarRoot.innerHTML = '';
    return;
  }
  desktopSidebarRoot.innerHTML = desktopSidebarMarkup();
  $$('[data-desktop-drawer-action]', desktopSidebarRoot).forEach(button => button.onclick = () => {
    const action = button.dataset.desktopDrawerAction;
    if (action === 'profile') navigate('profile');
    else if (action === 'recent') showCollection('history');
    else if (action === 'stats') navigate('statistics');
    else if (action === 'friends') navigate('people');
    else if (action === 'leaderboard') navigate('leaderboard');
    else if (action === 'downloads') navigate('downloads');
    else if (action === 'connections') navigate('connections');
    else if (action === 'system') showSystemActivitySheet();
    else if (action === 'settings') navigate('settings');
    else if (action === 'report') navigate('report');
    else if (action === 'admin-reports') navigate('admin-reports');
    else if (action === 'share') shareDatzonMusic();
    else if (action === 'help') showHelp();
    else if (action === 'about') showAboutSupport();
    else if (action === 'logout') showLogoutConfirm();
  });
}


function desktopRailTrackPool(limit = 12) {
  const source = dedupeTracks([
    ...(state.homeDiscovery?.topSongs || []),
    ...(state.catalog || []),
    ...(state.history || []),
    ...FALLBACK_TRACKS
  ].map(normalizeTrack).filter(homeDisplayTrackReady));
  return source.slice(0, Math.max(1, limit));
}

function desktopSpotlightRailMarkup() {
  const tracks = spotlightTracksForHome();
  return `<section class="desktop-spotlight-panel">
    <header><span>${icon('spotlight')}</span><div><strong>Spotlight</strong><small>Pilihan utama hari ini</small></div></header>
    <div class="desktop-spotlight-list">${tracks.map((track, index) => `<button data-desktop-spotlight="${index}">
      <img src="${esc(enhanceArtworkUrl(track.thumbnail))}" alt="" onerror="this.src='assets/placeholder.svg'">
      <span><strong>${esc(cleanTitle(track))}</strong><small>${esc(track.artist)}</small></span>
    </button>`).join('')}</div>
  </section>`;
}

function renderDesktopSpotlightRail() {
  if (!desktopSpotlightRail) return;
  const visible = desktopModeActive() && state.route === 'home';
  desktopSpotlightRail.classList.toggle('is-visible', visible);
  if (!visible) {
    desktopSpotlightRail.innerHTML = '';
    return;
  }
  const tracks = spotlightTracksForHome();
  desktopSpotlightRail.innerHTML = desktopSpotlightRailMarkup();
  $$('[data-desktop-spotlight]', desktopSpotlightRail).forEach(button => {
    button.onclick = () => {
      const index = Number(button.dataset.desktopSpotlight);
      if (!tracks[index]) return;
      playTrack(tracks[index], tracks, index);
    };
  });
}

function desktopContextHeading() {
  if (state.route === 'player') return ['Antrean', 'Lagu berikutnya'];
  if (state.route === 'lyrics') return ['Sedang diputar', 'Kembali ke pemutar'];
  if (state.route === 'settings') return ['Pilihan untukmu', 'Musik sambil mengatur aplikasi'];
  if (state.route === 'profile') return ['Baru diputar', 'Lanjutkan sesi terakhir'];
  if (state.route === 'library') return ['Rekomendasi', 'Tambahkan ke koleksimu'];
  if (state.route === 'search') return ['Sedang populer', 'Coba dengarkan sekarang'];
  return ['Rekomendasi untukmu', 'Dipilih dari aktivitasmu'];
}

function desktopContextTracks() {
  if (state.route === 'player' || state.route === 'lyrics') {
    const queue = Array.isArray(state.queue) ? state.queue.map(normalizeTrack) : [];
    if (queue.length) return queue.slice(0, 30);
    const fallback = desktopRailTrackPool(30);
    return state.current ? dedupeTracks([normalizeTrack(state.current), ...fallback]).slice(0, 30) : fallback;
  }
  const preferred = (state.history || []).map(normalizeTrack);
  return dedupeTracks([...preferred, ...desktopRailTrackPool(40)]).slice(0, 24);
}

function desktopContextRailMarkup() {
  const [title, subtitle] = desktopContextHeading();
  const tracks = desktopContextTracks();
  const currentKey = state.current ? trackKey(state.current) : '';
  return `<section class="desktop-context-panel">
    <header><div><strong>${esc(title)}</strong><small>${esc(subtitle)}</small></div>${state.route === 'player' ? `<button data-desktop-open-queue aria-label="Buka antrean lengkap">${icon('queue')}</button>` : ''}</header>
    <div class="desktop-context-list">${tracks.map((track, index) => {
      const active = currentKey && trackKey(track) === currentKey;
      return `<button class="${active ? 'active' : ''}" data-desktop-context-track="${index}">
        <img src="${esc(enhanceArtworkUrl(track.thumbnail))}" alt="" onerror="this.src='assets/placeholder.svg'">
        <span><strong>${esc(cleanTitle(track))}</strong><small>${esc(track.artist)}</small></span>
        ${active ? `<i>${state.isPlaying ? icon('pause') : icon('play','fill')}</i>` : `<i>${icon('play','fill')}</i>`}
      </button>`;
    }).join('')}</div>
    ${state.current ? `<footer><span>Sedang diputar</span><strong>${esc(cleanTitle(state.current))}</strong><small>${esc(state.current.artist)}</small></footer>` : ''}
  </section>`;
}

function renderDesktopContextRail() {
  if (!desktopContextRail) return;
  const hiddenRoutes = ['login','register','onboarding'].includes(state.route);
  const visible = desktopModeActive() && !hiddenRoutes;
  desktopContextRail.classList.toggle('is-visible', visible);
  if (!visible) {
    desktopContextRail.innerHTML = '';
    return;
  }
  const tracks = desktopContextTracks();
  desktopContextRail.innerHTML = desktopContextRailMarkup();
  const contextList = $('.desktop-context-list', desktopContextRail);
  if (contextList) {
    contextList.addEventListener('wheel', event => event.stopPropagation(), { passive: true });
    contextList.addEventListener('touchmove', event => event.stopPropagation(), { passive: true });
  }
  $$('[data-desktop-context-track]', desktopContextRail).forEach(button => {
    button.onclick = () => {
      const index = Number(button.dataset.desktopContextTrack);
      const track = tracks[index];
      if (!track) return;
      if (state.current && trackKey(state.current) === trackKey(track)) {
        togglePlay();
        return;
      }
      const activeIndex = state.queue.findIndex(item => trackKey(item) === trackKey(track));
      if ((state.route === 'player' || state.route === 'lyrics') && activeIndex >= 0) playTrack(track, state.queue, activeIndex);
      else playTrack(track, tracks, index);
    };
  });
  const queueButton = $('[data-desktop-open-queue]', desktopContextRail);
  if (queueButton) queueButton.onclick = showQueue;
}

function desktopNavActiveRoute(route) {
  if (route === 'home') return state.route === 'home';
  if (route === 'search') return state.route === 'search';
  if (route === 'library') return state.route === 'library';
  if (route === 'settings') return ['settings','connections'].includes(state.route);
  if (route === 'profile') return ['profile','statistics','friends','leaderboard','downloads','report','admin-reports','public-profile'].includes(state.route);
  return false;
}

function renderDesktopNavRail() {
  if (!desktopNavRail) return;
  if (!desktopModeActive()) {
    desktopNavRail.innerHTML = '';
    desktopNavRail.classList.remove('is-visible');
    return;
  }
  const items = [
    ['home','home','Home'],
    ['search','search','Cari'],
    ['library','library','Koleksi Kamu'],
    ['create','plus-circle','Buat'],
    ['settings','settings','Pengaturan'],
    ['profile','user','Profil']
  ];
  desktopNavRail.classList.add('is-visible');
  desktopNavRail.innerHTML = `<div class="desktop-nav-stack">${items.map(([route, ico, label]) => `<button class="${desktopNavActiveRoute(route) ? 'active' : ''}" data-desktop-nav="${route}" aria-label="${esc(label)}" title="${esc(label)}">${icon(ico)}</button>`).join('')}</div>`;
  $$('[data-desktop-nav]', desktopNavRail).forEach(button => button.onclick = () => {
    const route = button.dataset.desktopNav;
    if (route === 'create') showCreateMenu();
    else navigate(route);
  });
}

function renderDesktopChrome() {
  renderDesktopSidebar();
  const desktop = desktopModeActive();
  document.body.classList.toggle('desktop-mode', desktop);
  document.body.classList.toggle('desktop-route-home', desktop && state.route === 'home');
  document.body.classList.toggle('desktop-route-player', desktop && ['player','lyrics'].includes(state.route));
  document.body.classList.toggle('desktop-route-standard', desktop && !['home','player','lyrics','login','register','verify','onboarding'].includes(state.route));
  renderDesktopSpotlightRail();
  renderDesktopContextRail();
  renderDesktopNavRail();
}

function showSideMenu() {
  if (desktopModeActive()) { renderDesktopSidebar(); return; }
  resetModalRoot();
  modalRoot.innerHTML = `<div class="side-drawer-backdrop" data-drawer-close><aside class="side-drawer side-drawer-v123" role="dialog" aria-label="Menu akun">
    <button class="drawer-profile" data-drawer-action="profile">${currentProfilePhoto() ? `<span class="drawer-avatar has-photo${accountAvatarPlaybackClass()}"><img src="${esc(currentProfilePhoto())}" alt=""></span>` : `<span class="drawer-avatar${accountAvatarPlaybackClass()}">${esc(accountInitial())}</span>`}<div><strong>${esc(currentAccountName())}</strong><small>${isLoggedIn() ? '@'+esc(state.auth.profile?.username || '') : 'Profil Tamu'}</small></div>${icon('chevron')}</button>
    <div class="drawer-section-label">Koleksi dan aktivitas</div>
    <div class="drawer-menu">
      <button data-drawer-action="recent">${icon('history')}<span>Riwayat Diputar</span></button>
      <button data-drawer-action="stats">${icon('bars')}<span>Statistik Mendengarkan</span></button>
      <button data-drawer-action="friends">${icon('group')}<span>Cari pengguna</span><em>${isLoggedIn() ? state.social.friends.length || '' : ''}</em></button>
      <button data-drawer-action="leaderboard">${icon('trending')}<span>Leaderboard</span></button>
      <button data-drawer-action="downloads">${icon('download')}<span>Unduhan</span><em>${state.downloads.length||''}</em></button>
      <button data-drawer-action="connections">${icon('external')}<span>Koneksi Akun</span><em>${isLoggedIn()?'Firebase':''}</em></button>
      <button data-drawer-action="system">${icon('alert')}<span>Status Sistem</span><em>${state.systemActivityUnread||''}</em></button>
      <button data-drawer-action="settings">${icon('settings')}<span>Pengaturan dan Privasi</span></button>
      <button data-drawer-action="report">${icon('report')}<span>Laporkan Masalah</span></button>
      ${isAdminAccount() ? `<button data-drawer-action="admin-reports">${icon('history')}<span>Catatan Laporan</span></button>` : ''}
    </div>
    <div class="drawer-section-label">DATZON</div>
    <div class="drawer-menu drawer-menu-secondary">
      <button data-drawer-action="share">${icon('share')}<span>Bagikan DATZON Music</span></button>
      <button data-drawer-action="help">${icon('info')}<span>Bantuan</span></button>
      <button data-drawer-action="about">${icon('music')}<span>Tentang DATZON Music</span></button>
      <button class="drawer-logout" data-drawer-action="logout">${icon('external')}<span>${isLoggedIn()?'Keluar akun':'Reset ke Tamu'}</span></button>
    </div>
  </aside></div>`;
  const backdrop = $('.side-drawer-backdrop', modalRoot);
  requestAnimationFrame(() => backdrop.classList.add('show'));
  backdrop.onclick = event => { if (event.target === backdrop) resetModalRoot(); };
  $$('[data-drawer-action]', modalRoot).forEach(button => button.onclick = () => {
    const action = button.dataset.drawerAction;
    if (action === 'profile') { resetModalRoot(); navigate('profile'); }
    else if (action === 'recent') { resetModalRoot(); showCollection('history'); }
    else if (action === 'stats') { resetModalRoot(); navigate('statistics'); }
    else if (action === 'friends') { resetModalRoot(); navigate('people'); }
    else if (action === 'leaderboard') { resetModalRoot(); navigate('leaderboard'); }
    else if (action === 'downloads') { resetModalRoot(); navigate('downloads'); }
    else if (action === 'connections') { resetModalRoot(); navigate('connections'); }
    else if (action === 'system') { resetModalRoot(); showSystemActivitySheet(); }
    else if (action === 'settings') { resetModalRoot(); navigate('settings'); }
    else if (action === 'report') { resetModalRoot(); navigate('report'); }
    else if (action === 'admin-reports') { resetModalRoot(); navigate('admin-reports'); }
    else if (action === 'share') { resetModalRoot(); shareDatzonMusic(); }
    else if (action === 'help') { resetModalRoot(); showHelp(); }
    else if (action === 'about') { resetModalRoot(); showAboutSupport(); }
    else if (action === 'logout') { resetModalRoot(); showLogoutConfirm(); }
  });
}

function profileInitial(value='') {
  const text=String(value || '').trim();
  if(!text)return 'D';
  return Array.from(text.replace(/^@+/,''))[0]?.toUpperCase?.() || 'D';
}

function defaultProfileAvatar(value='') {
  const initial=profileInitial(value);
  const cleanInitial=initial.replace(/[&<>"']/g,'');
  // Keep the fallback avatar visually aligned with DATZON's mono display typography.
  // The SVG is self-contained, so it uses a mono stack that remains centered even
  // when the remote Share Tech Mono webfont is not available inside an image resource.
  const svgMarkup=`<svg xmlns="http://www.w3.org/2000/svg" width="128" height="128" viewBox="0 0 128 128"><circle cx="64" cy="64" r="64" fill="#1ed760"/><text x="64" y="64" text-anchor="middle" dominant-baseline="central" alignment-baseline="central" font-family="'Share Tech Mono','Courier New',ui-monospace,monospace" font-size="56" font-weight="700" letter-spacing="0" fill="#0b0b0b">${cleanInitial}</text></svg>`;
  return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(svgMarkup)}`;
}

function collaboratorAvatar(profile={}) {
  return String(profile.photoURL || profile.avatar || '').trim() || defaultProfileAvatar(profile.fullName || profile.displayName || profile.username || 'D');
}

function collaborativeFriendProfile(friend = {}) {
  return { uid:String(friend.uid || ''), fullName:String(friend.fullName || friend.displayName || friend.username || 'Teman'), username:String(friend.username || ''), photoURL:String(friend.photoURL || friend.avatar || '') };
}

async function showCreateCollaborativePlaylistSheet() {
  if (!isLoggedIn()) return notify('Masuk ke akun untuk membuat playlist kolaboratif.');
  closeModal(true);
  await loadSocialGraph(true);
  const friends = (state.social.friends || []).map(collaborativeFriendProfile).filter(item => item.uid && item.uid !== state.auth.user.uid);
  if (!friends.length) return notify('Tambahkan minimal satu teman terlebih dahulu.');
  const sheet = openPlayerSheet(`<div class="collab-create-sheet"><header><div><small>KOLEKSI KAMU</small><h2>Playlist kolaboratif</h2><p>Pilih minimal 1 teman. Semua anggota dapat menambah dan mengatur lagu.</p></div><button data-collab-close aria-label="Tutup">${icon('close')}</button></header><label class="collab-name-field"><span>Nama playlist</span><input data-collab-name maxlength="80" placeholder="Nama playlist kolaboratif"></label>${playlistPrivacyPickerMarkup('private', true, true)}<div class="collab-friend-heading"><span>Pilih kolaborator</span></div><div class="collab-friend-list">${friends.map((friend,index)=>`<button type="button" class="collab-friend-row" data-collab-friend="${index}" aria-pressed="false"><img src="${esc(collaboratorAvatar(friend))}" alt="" onerror="this.src='${esc(defaultProfileAvatar(friend.fullName || friend.username || 'D'))}'"><span><strong>${esc(friend.fullName)}</strong><small>${friend.username ? `@${esc(friend.username)}` : 'Teman DATZON'}</small></span><i>${icon('check')}</i></button>`).join('')}</div><button class="primary-btn collab-create-submit" data-collab-create disabled>Buat playlist</button></div>`, 'collab-create-player-sheet', {kind:'menu', initialSnap:'full'});
  const selected = new Set();
  const getVisibility = bindPlaylistPrivacyPicker(sheet, 'private');
  const submit = $('[data-collab-create]', sheet);
  const syncState = () => { submit.disabled = selected.size < 1; submit.textContent = selected.size ? `Buat dengan ${selected.size} teman` : 'Pilih minimal 1 teman'; };
  $('[data-collab-close]', sheet).onclick = () => closeModal();
  $$('[data-collab-friend]', sheet).forEach(button => button.onclick = () => {
    const friend = friends[Number(button.dataset.collabFriend)]; if (!friend) return;
    if (selected.has(friend.uid)) selected.delete(friend.uid); else selected.add(friend.uid);
    button.classList.toggle('is-selected', selected.has(friend.uid)); button.setAttribute('aria-pressed', selected.has(friend.uid) ? 'true' : 'false'); syncState();
  });
  submit.onclick = async () => {
    const name = String($('[data-collab-name]', sheet)?.value || '').trim();
    if (!name) return notify('Isi nama playlist terlebih dahulu.');
    if (!selected.size) return notify('Pilih minimal satu teman.');
    submit.disabled = true;
    const now = Date.now();
    const currentProfile = state.auth.profile || {};
    const participantProfiles = [
      { uid:state.auth.user.uid, fullName:currentProfile.fullName || currentProfile.username || state.username || 'Kamu', username:currentProfile.username || '', photoURL:currentProfile.photoURL || state.auth.user.photoURL || '' },
      ...friends.filter(friend => selected.has(friend.uid))
    ];
    const playlist = normalizePlaylist({ id:createPlaylistId(), name, ownerUid:state.auth.user.uid, collabOwnerUid:state.auth.user.uid, sourceType:'collaborative', visibility:getVisibility(), collaborative:true, participantUids:participantProfiles.map(item=>item.uid), participantProfiles, createdAt:now, updatedAt:now, tracks:[] });
    setActivePlaylists([playlist, ...activePlaylists()]);
    await broadcastCollaborativePlaylistSnapshot(playlist);
    closeModal(true); notify(`Playlist kolaboratif “${playlist.name}” dibuat ${playlistVisibilityLabel(playlist.visibility).toLowerCase()} untuk ${participantProfiles.length} anggota.`);
    if (state.route === 'library') renderLibrary();
  };
  syncState();
}

function blendTrackPool() {
  const stats = ensureListeningStats();
  const byKey = new Map();
  const add = (raw, baseScore=0) => {
    if (!raw) return; const track=normalizeTrack(raw); const key=trackKey(track); if(!key || cleanTitle(track)==='Tanpa Judul')return;
    const stat=stats.tracks?.[key] || {}; const artistStat=stats.artists?.[track.artist] || {};
    const score=baseScore + Number(stat.plays||0)*8 + Math.min(60,Number(stat.seconds||0)/60) + Number(artistStat.plays||0)*3 + Math.min(30,Number(artistStat.seconds||0)/180) + (Number(raw.lastPlayedAt||stat.lastPlayedAt||0)/1e13);
    const prev=byKey.get(key); if(!prev || score>prev.score)byKey.set(key,{track,score});
  };
  state.favorites.forEach(track=>add(track,70));
  state.history.forEach((track,index)=>add(track,45-Math.min(30,index*.35)));
  state.queue.forEach(track=>add(track,20));
  (state.catalog||[]).forEach(track=>{const preferred=(state.preferredArtists||[]).some(name=>normalizeMatchText(track.artist).includes(normalizeMatchText(name)));if(preferred)add(track,35);});
  if(state.current)add(state.current,85);
  return [...byKey.values()].sort((a,b)=>b.score-a.score).map(item=>item.track).slice(0,30);
}

async function startBlendQueue() {
  const tracks=blendTrackPool();
  if(!tracks.length)return notify('Belum cukup riwayat mendengarkan untuk membuat Blend.');
  const current=state.current ? normalizeTrack(state.current) : null;
  if(current){state.queue=[current,...tracks.filter(track=>!sameTrackIdentity(track,current))].slice(0,30);state.currentIndex=0;state.playContext={eyebrow:'BLEND',label:'Blend selera kamu',type:'blend'};persist();closeModal(true);showQueue();notify('Blend dibuat dari riwayat dan selera musikmu.');return;}
  closeModal(true);
  await playTrack(tracks[0],tracks,0,{playContext:{eyebrow:'BLEND',label:'Blend selera kamu',type:'blend'},stayOnRoute:true});
  window.setTimeout(()=>showQueue(),120);
}

function showCreateMenu() {
  openPlayerSheet(`<div class="create-sheet-title"><h2>Buat</h2></div><div class="create-sheet-list">
    <button data-create-action="playlist">${icon('music')}<span><strong>Playlist</strong><small>Buat playlist berisi lagu atau episode</small></span></button>
    <button data-create-action="collab">${icon('group')}<span><strong>Playlist kolaboratif</strong><small>Buat playlist bersama teman</small></span></button>
    <button data-create-action="mix">${icon('mix')}<span><strong>Playlist mix <em>Beta</em></strong><small>Mix lagu dengan transisi yang mulus</small></span></button>
    <button data-create-action="blend">${icon('album')}<span><strong>Blend</strong><small>Satukan selera musik teman-temanmu</small></span></button>
    <button data-create-action="together">${icon('group')}<span><strong>Dengar Bareng</strong><small>Dengarkan bersama dari mana saja</small></span></button>
  </div>`, 'create-player-sheet', {kind:'menu', initialSnap:'half'});
  $$('[data-create-action]', modalRoot).forEach(button => button.onclick = () => {
    const action = button.dataset.createAction;
    if (action === 'playlist') { closeModal(true); setTimeout(() => showCreatePlaylistSheet(null), 90); }
    else if (action === 'collab') { void showCreateCollaborativePlaylistSheet(); }
    else if (action === 'blend') { void startBlendQueue(); }
    else if (action === 'mix') { closeModal(); if (state.current) { state.mixMode = true; setQueueMode('mix'); showQueue(); } else notify('Putar satu lagu terlebih dahulu'); }
    else if (action === 'together') { closeModal(); if (state.current) showConnectSheet(); else notify('Putar satu lagu terlebih dahulu'); }
    else notify('Fitur belum tersedia pada pembaruan ini');
  });
}

function lyricTextFromItem(item) {
  if (typeof item === 'string') return item.trim();
  if (Array.isArray(item)) {
    const directString = item.find(value => typeof value === 'string' && value.trim());
    if (directString) return directString.trim();
    const joined = item.map(value => lyricTextFromItem(value)).filter(Boolean).join(' ').trim();
    return joined;
  }
  if (!item || typeof item !== 'object') return '';
  const direct = [
    item.words, item.word, item.text, item.line, item.lineText, item.line_text,
    item.lyric, item.lyrics, item.content, item.value, item.label, item.sentence,
    item.caption, item.subtitle
  ];
  for (const value of direct) {
    if (typeof value === 'string' && value.trim()) return value.trim();
    if (Array.isArray(value)) {
      const joined = value
        .map(part => typeof part === 'string' ? part : part?.text ?? part?.word ?? part?.words ?? part?.value ?? '')
        .filter(Boolean)
        .join(' ')
        .trim();
      if (joined) return joined;
    }
    if (value && typeof value === 'object') {
      const nested = value.text ?? value.words ?? value.word ?? value.line ?? value.lineText ?? value.value ?? value.content;
      if (typeof nested === 'string' && nested.trim()) return nested.trim();
    }
  }
  return '';
}

function parseTimestampValue(value, key = '', duration = 0) {
  if (value === null || value === undefined || value === '') return null;
  if (typeof value === 'object') {
    const nestedKeys = [
      'totalMilliseconds','totalMs','milliseconds','millisecond','ms',
      'totalSeconds','seconds','second','secs','sec','total','value','position'
    ];
    for (const nestedKey of nestedKeys) {
      if (value[nestedKey] !== undefined) return parseTimestampValue(value[nestedKey], nestedKey, duration);
    }
    const hours = Number(value.hours ?? value.hour ?? 0);
    const minutes = Number(value.minutes ?? value.minute ?? value.min ?? 0);
    const seconds = Number(value.seconds ?? value.second ?? value.sec ?? 0);
    const milliseconds = Number(value.milliseconds ?? value.millisecond ?? value.ms ?? 0);
    if ([hours, minutes, seconds, milliseconds].some(number => Number.isFinite(number) && number !== 0)) {
      return hours * 3600 + minutes * 60 + seconds + milliseconds / 1000;
    }
    return null;
  }
  if (typeof value === 'string') {
    let clean = value.trim().replace(/^[\[<(]\s*|\s*[\]>)]$/g, '');
    const unitMatch = clean.match(/^(-?\d+(?:\.\d+)?)\s*(ms|milliseconds?|s|sec|seconds?)$/i);
    if (unitMatch) return /ms|millisecond/i.test(unitMatch[2]) ? Number(unitMatch[1]) / 1000 : Number(unitMatch[1]);
    const clock = clean.match(/^(?:(\d+):)?(\d{1,2}):(\d{2}(?:[.,]\d{1,3})?)$/);
    if (clock) return Number(clock[1] || 0) * 3600 + Number(clock[2]) * 60 + Number(clock[3].replace(',', '.'));
    const minuteClock = clean.match(/^(\d{1,3}):(\d{2}(?:[.,]\d{1,3})?)$/);
    if (minuteClock) return Number(minuteClock[1]) * 60 + Number(minuteClock[2].replace(',', '.'));
    if (!/^-?\d+(?:\.\d+)?$/.test(clean)) return null;
    value = Number(clean);
  }
  const numeric = Number(value);
  if (!Number.isFinite(numeric)) return null;
  if (/micro/i.test(key)) return numeric / 1000000;
  if (/ms|millisecond/i.test(key)) return numeric / 1000;
  if (/second|secs?|sec/i.test(key)) return numeric;
  const expectedDuration = Number(duration || 0);
  if (expectedDuration > 0 && numeric >= 250 && numeric > expectedDuration * 1.35) return numeric / 1000;
  if (!expectedDuration && /start|time|timestamp|offset|position|begin|elapsed/i.test(key) && numeric >= 1000) return numeric / 1000;
  if (numeric > Math.max(1000, (expectedDuration || 600) * 8)) return numeric / 1000;
  return numeric;
}

function lyricTimeFromItem(item, duration = 0) {
  if (Array.isArray(item)) {
    for (const value of item) {
      if (typeof value === 'number') {
        const parsed = parseTimestampValue(value, '', duration);
        if (Number.isFinite(parsed)) return parsed;
      }
      if (typeof value === 'string' && /^\s*(?:\d+:)?\d{1,3}:\d{2}(?:[.,]\d+)?\s*$/.test(value)) {
        const parsed = parseTimestampValue(value, '', duration);
        if (Number.isFinite(parsed)) return parsed;
      }
    }
    return null;
  }
  if (!item || typeof item !== 'object') return null;
  const keys = [
    'startTimeMs','start_time_ms','startMs','start_ms','startMilliseconds','start_milliseconds',
    'timestampMs','timestamp_ms','timeMs','time_ms','offsetMs','offset_ms','beginMs','begin_ms',
    'startTime','start_time','start','timestamp','time','timeTag','time_tag','offset','position',
    'begin','beginTime','begin_time','elapsedTime','elapsed_time','startSeconds','start_seconds'
  ];
  for (const key of keys) {
    if (item[key] !== undefined) {
      const time = parseTimestampValue(item[key], key, duration);
      if (Number.isFinite(time)) return time;
    }
  }
  for (const nestedKey of ['line','lyric','content','timing','range','timestampData','timestamp_data']) {
    if (item[nestedKey] && typeof item[nestedKey] === 'object') {
      const nestedTime = lyricTimeFromItem(item[nestedKey], duration);
      if (Number.isFinite(nestedTime)) return nestedTime;
    }
  }
  return null;
}

function findTimedLyricsArray(data) {
  let best = null;
  let bestScore = -1;
  const seen = new Set();
  function walk(value, depth = 0, parentKey = '') {
    if (value === null || value === undefined || depth > 12) return;
    if (typeof value === 'object') {
      if (seen.has(value)) return;
      seen.add(value);
    }
    if (Array.isArray(value)) {
      if (value.length) {
        let textCount = 0;
        let timedCount = 0;
        for (const item of value.slice(0, 250)) {
          if (lyricTextFromItem(item)) textCount += 1;
          if (lyricTimeFromItem(item) !== null) timedCount += 1;
        }
        const keyBonus = /lyric|line|sync|word|subtitle|caption/i.test(parentKey) ? 35 : 0;
        const score = timedCount * 10 + textCount * 2 + keyBonus;
        if (textCount && timedCount && score > bestScore) {
          best = value;
          bestScore = score;
        }
      }
      value.forEach(item => walk(item, depth + 1, parentKey));
      return;
    }
    if (value && typeof value === 'object') {
      Object.entries(value).forEach(([key, child]) => walk(child, depth + 1, key));
    }
  }
  walk(data);
  return best;
}

function stringLooksTimedLyrics(value = '') {
  const text = String(value || '');
  return /(?:^|\n)\s*[\[<](?:\d+:)?\d{1,3}:\d{2}(?:[.,]\d{1,3})?[\]>]/m.test(text)
    || /(?:^|\n)\s*(?:\d+:)?\d{1,3}:\d{2}(?:[.,]\d{1,3})?\s*(?:\||-|–|—|=>)?\s*\S+/m.test(text);
}

function findLyricsText(data) {
  const preferred = [
    'syncedLyrics','synced_lyrics','syncLyrics','sync_lyrics','timedLyrics','timed_lyrics',
    'lyricsWithTimestamps','lyrics_with_timestamps','lrc','lrcLyrics','lrc_lyrics',
    'lyrics','lyric','plainLyrics','plain_lyrics','text','subtitle','subtitles'
  ];
  const seen = new Set();
  let timedFallback = '';
  let plainFallback = '';
  function walk(value, depth = 0, key = '') {
    if (value === null || value === undefined || depth > 12) return;
    if (typeof value === 'string') {
      const trimmed = value.trim();
      if (!trimmed) return;
      if (stringLooksTimedLyrics(trimmed) && !timedFallback) timedFallback = trimmed;
      if ((preferred.includes(key) || /lyric|lrc|subtitle|caption/i.test(key)) && !plainFallback) plainFallback = trimmed;
      return;
    }
    if (typeof value !== 'object' || seen.has(value)) return;
    seen.add(value);
    if (Array.isArray(value)) {
      value.forEach(item => walk(item, depth + 1, key));
      return;
    }
    for (const preferredKey of preferred) {
      if (typeof value[preferredKey] === 'string' && value[preferredKey].trim()) {
        const candidate = value[preferredKey].trim();
        if (stringLooksTimedLyrics(candidate) && !timedFallback) timedFallback = candidate;
        if (!plainFallback) plainFallback = candidate;
      }
    }
    Object.entries(value).forEach(([childKey, child]) => walk(child, depth + 1, childKey));
  }
  walk(data);
  return timedFallback || plainFallback;
}

function extractLyricsPayload(data) {
  if (typeof data === 'string') return data;
  return findTimedLyricsArray(data) || findLyricsText(data) || '';
}

function payloadHasTimestamps(payload, duration = 0) {
  if (Array.isArray(payload)) return payload.some(item => lyricTimeFromItem(item, duration) !== null);
  if (payload && typeof payload === 'object') {
    const nested = extractLyricsPayload(payload);
    return nested !== payload && payloadHasTimestamps(nested, duration);
  }
  return stringLooksTimedLyrics(String(payload || ''));
}

function parseLyricsLines(payload, duration = 0) {
  const parsed = [];
  if (payload && typeof payload === 'object' && !Array.isArray(payload)) payload = extractLyricsPayload(payload);
  if (Array.isArray(payload)) {
    payload.forEach((item, index) => {
      const text = lyricTextFromItem(item);
      if (!text) return;
      parsed.push({ time: lyricTimeFromItem(item, duration), text, index });
    });
  } else {
    let rawPayload = String(payload || '').trim();
    if ((rawPayload.startsWith('{') || rawPayload.startsWith('[')) && rawPayload.length > 2) {
      try {
        const decoded = JSON.parse(rawPayload);
        const nested = extractLyricsPayload(decoded);
        if (nested && nested !== rawPayload) return parseLyricsLines(nested, duration);
      } catch { /* Bukan JSON, lanjut sebagai teks lirik. */ }
    }
    if (!rawPayload.includes('\n') && rawPayload.includes('\\n')) rawPayload = rawPayload.replace(/\\r?\\n/g, '\n');
    rawPayload.replace(/\r/g, '').split('\n').forEach((raw, index) => {
      const line = raw.trim();
      if (!line) return;
      if (/^\[(ar|ti|al|by|offset|length|re):/i.test(line)) return;

      const bracketTags = [...line.matchAll(/\[(?:(\d+):)?(\d{1,3}):(\d{2}(?:[.,]\d{1,3})?)\]/g)];
      if (bracketTags.length) {
        const text = line.replace(/^(?:\[(?:(?:\d+):)?\d{1,3}:\d{2}(?:[.,]\d{1,3})?\])+\s*/, '').trim();
        if (text) bracketTags.forEach((match, tagIndex) => parsed.push({
          time: Number(match[1] || 0) * 3600 + Number(match[2]) * 60 + Number(match[3].replace(',', '.')),
          text,
          index: index + tagIndex / 100
        }));
        return;
      }

      const angle = line.match(/^<(?:(\d+):)?(\d{1,3}):(\d{2}(?:[.,]\d{1,3})?)>\s*(.*)$/);
      if (angle) {
        const text = angle[4].trim();
        if (text) parsed.push({ time: Number(angle[1] || 0) * 3600 + Number(angle[2]) * 60 + Number(angle[3].replace(',', '.')), text, index });
        return;
      }

      const bare = line.match(/^(?:(\d+):)?(\d{1,3}):(\d{2}(?:[.,]\d{1,3})?)\s*(?:\||-|–|—|=>)?\s*(.+)$/);
      if (bare) {
        parsed.push({ time: Number(bare[1] || 0) * 3600 + Number(bare[2]) * 60 + Number(bare[3].replace(',', '.')), text: bare[4].trim(), index });
        return;
      }

      parsed.push({ time: null, text: line, index });
    });
  }
  const clean = parsed.filter(line => line.text && !/^\[?(verse|chorus|bridge|intro|outro|pre-chorus|instrumental).*\]?$/i.test(line.text));
  if (!clean.length) return [];
  const hasSyncedTime = clean.some(line => Number.isFinite(line.time));
  if (!hasSyncedTime) {
    const total = duration || 210;
    const start = Math.min(8, total * .04);
    const usable = Math.max(30, total - start - 8);
    clean.forEach((line, index) => { line.time = start + usable * (index / Math.max(1, clean.length)); });
  } else {
    let last = 0;
    clean.forEach(line => {
      if (!Number.isFinite(line.time)) line.time = last + .01;
      last = Number(line.time);
    });
  }
  const unique = [];
  const seen = new Set();
  clean
    .map((line, index) => ({ time: Math.max(0, Number(line.time) || 0), text: line.text, index }))
    .sort((a, b) => a.time - b.time || a.index - b.index)
    .forEach(line => {
      const key = `${line.time.toFixed(3)}|${line.text}`;
      if (!seen.has(key)) {
        seen.add(key);
        unique.push({ ...line, index: unique.length });
      }
    });
  return unique;
}

function firstMeaningfulValue(...values) {
  for (const value of values) {
    if (Array.isArray(value)) {
      const joined = value
        .map(item => typeof item === 'string' ? item : item?.name || item?.artistName || item?.artist_name || item?.title || '')
        .filter(Boolean)
        .join(', ')
        .trim();
      if (joined) return joined;
      continue;
    }
    if (value && typeof value === 'object') {
      const nested = value.name || value.title || value.artist || value.artistName || value.artist_name || value.trackName || value.track_name || '';
      if (String(nested || '').trim()) return String(nested).trim();
      continue;
    }
    if (String(value ?? '').trim()) return String(value).trim();
  }
  return '';
}

function lyricsCandidateTitle(candidate) {
  return firstMeaningfulValue(
    candidate?.__lyricsTitle,
    candidate?.trackName, candidate?.track_name,
    candidate?.songName, candidate?.song_name,
    candidate?.songTitle, candidate?.song_title,
    candidate?.title, candidate?.name,
    candidate?.track?.title, candidate?.track?.name,
    candidate?.song?.title, candidate?.song?.name,
    candidate?.metadata?.title, candidate?.metadata?.trackName, candidate?.metadata?.track_name,
    candidate?.data?.title, candidate?.data?.trackName
  );
}

function lyricsCandidateArtist(candidate) {
  return firstMeaningfulValue(
    candidate?.__lyricsArtist,
    candidate?.artistName, candidate?.artist_name,
    candidate?.artistsName, candidate?.artists_name,
    candidate?.artistNames, candidate?.artist_names,
    candidate?.artist, candidate?.artists,
    candidate?.author, candidate?.singer, candidate?.performer,
    candidate?.track?.artist, candidate?.track?.artistName, candidate?.track?.artist_name,
    candidate?.song?.artist, candidate?.song?.artistName, candidate?.song?.artist_name,
    candidate?.metadata?.artist, candidate?.metadata?.artistName, candidate?.metadata?.artist_name,
    candidate?.data?.artist, candidate?.data?.artistName
  );
}

function lyricsCandidateDuration(candidate) {
  const milliseconds = Number(
    candidate?.__lyricsDurationMs ??
    candidate?.durationMs ?? candidate?.duration_ms ??
    candidate?.trackTimeMillis ?? candidate?.track_time_millis ??
    candidate?.lengthMs ?? candidate?.length_ms ??
    candidate?.metadata?.durationMs ?? candidate?.metadata?.duration_ms
  );
  if (Number.isFinite(milliseconds) && milliseconds > 0) return milliseconds / 1000;
  const rawDuration =
    candidate?.__lyricsDuration ??
    candidate?.duration ?? candidate?.durationSeconds ?? candidate?.duration_seconds ??
    candidate?.durationInSeconds ?? candidate?.duration_in_seconds ??
    candidate?.length ?? candidate?.track?.duration ?? candidate?.song?.duration ??
    candidate?.metadata?.duration ?? candidate?.data?.duration;
  const numericDuration = Number(rawDuration);
  if (Number.isFinite(numericDuration) && numericDuration > 0) return numericDuration > 10000 ? numericDuration / 1000 : numericDuration;
  return durationSeconds(rawDuration);
}

const SYLVATICA_LYRICS_PAYLOAD_KEYS = [
  'syncedLyrics','synced_lyrics','syncLyrics','sync_lyrics','timedLyrics','timed_lyrics',
  'lyricsWithTimestamps','lyrics_with_timestamps','wordSyncedLyrics','word_synced_lyrics',
  'lrc','lrcLyrics','lrc_lyrics','lyricsLrc','lyrics_lrc',
  'lines','lineSynced','line_synced','lyrics','lyric','plainLyrics','plain_lyrics',
  'text','subtitle','subtitles','captions'
];

function directLyricsPayload(candidate) {
  if (!candidate || typeof candidate !== 'object') return '';
  for (const key of SYLVATICA_LYRICS_PAYLOAD_KEYS) {
    const value = candidate[key];
    if (Array.isArray(value) && value.length) return value;
    if (typeof value === 'string' && value.trim()) return value;
    if (value && typeof value === 'object') {
      const nested = extractLyricsPayload(value);
      if ((Array.isArray(nested) && nested.length) || String(nested || '').trim()) return nested;
    }
  }
  return '';
}

function lyricsPayloadFromCandidate(candidate) {
  return directLyricsPayload(candidate) || extractLyricsPayload(candidate);
}

function collectLyricsCandidates(payload, output = [], depth = 0, seen = new Set(), inherited = {}, orderRef = { value: 0 }) {
  if (payload == null || depth > 12) return output;
  if (typeof payload === 'string') {
    if (stringLooksTimedLyrics(payload)) {
      output.push({
        candidate: { __lyricsTitle: inherited.title, __lyricsArtist: inherited.artist, __lyricsDuration: inherited.duration },
        payload,
        order: orderRef.value++
      });
    }
    return output;
  }
  if (typeof payload !== 'object' || seen.has(payload)) return output;
  seen.add(payload);

  if (Array.isArray(payload)) {
    const timedCount = payload.slice(0, 250).filter(item => lyricTimeFromItem(item, inherited.duration || 0) !== null).length;
    const textCount = payload.slice(0, 250).filter(item => lyricTextFromItem(item)).length;
    if (timedCount && textCount) {
      output.push({
        candidate: { __lyricsTitle: inherited.title, __lyricsArtist: inherited.artist, __lyricsDuration: inherited.duration },
        payload,
        order: orderRef.value++
      });
    }
    payload.forEach(item => collectLyricsCandidates(item, output, depth + 1, seen, inherited, orderRef));
    return output;
  }

  const local = {
    title: lyricsCandidateTitle(payload) || inherited.title || '',
    artist: lyricsCandidateArtist(payload) || inherited.artist || '',
    duration: lyricsCandidateDuration(payload) || inherited.duration || 0
  };
  const directPayload = directLyricsPayload(payload);
  if ((Array.isArray(directPayload) && directPayload.length) || String(directPayload || '').trim()) {
    output.push({
      candidate: {
        ...payload,
        __lyricsTitle: local.title,
        __lyricsArtist: local.artist,
        __lyricsDuration: local.duration
      },
      payload: directPayload,
      order: orderRef.value++
    });
  }
  Object.values(payload).forEach(value => collectLyricsCandidates(value, output, depth + 1, seen, local, orderRef));
  return output;
}

function matchTokenRatio(candidateValue, targetValue) {
  const candidateTokens = normalizeMatchText(candidateValue).split(' ').filter(Boolean);
  const targetTokens = normalizeMatchText(targetValue).split(' ').filter(Boolean);
  if (!candidateTokens.length || !targetTokens.length) return 0;
  const candidateSet = new Set(candidateTokens);
  const shared = targetTokens.filter(token => candidateSet.has(token)).length;
  return shared / Math.max(candidateTokens.length, targetTokens.length);
}

function lyricsTitleMatchScore(candidateTitle, targetTitle) {
  const candidate = normalizeMatchText(candidateTitle);
  const target = normalizeMatchText(targetTitle);
  if (!target) return 0;
  if (!candidate) return 14;
  if (candidate === target) return 90;
  if (candidate.includes(target) || target.includes(candidate)) return 62;
  const ratio = matchTokenRatio(candidate, target);
  if (ratio >= .8) return 54;
  if (ratio >= .6) return 42;
  if (ratio >= .4) return 26;
  return 0;
}

function lyricsArtistMatchScore(candidateArtist, targetArtist) {
  const candidate = normalizeMatchText(candidateArtist);
  const target = normalizeMatchText(targetArtist);
  if (!target || !candidate) return 0;
  if (candidate === target) return 55;
  if (candidate.includes(target) || target.includes(candidate)) return 40;
  const ratio = matchTokenRatio(candidate, target);
  if (ratio >= .75) return 34;
  if (ratio >= .5) return 20;
  const candidateParts = artistParts(candidate);
  const targetParts = artistParts(target);
  if (candidateParts.some(part => targetParts.some(targetPart => part.includes(targetPart) || targetPart.includes(part)))) return 16;
  return -24;
}

function scoreLyricsCandidate(entry, track) {
  const targetTitle = cleanTitle(track);
  const targetArtist = isUnknownArtist(track?.artist) ? '' : track.artist;
  const candidateTitle = lyricsCandidateTitle(entry.candidate);
  const candidateArtist = lyricsCandidateArtist(entry.candidate);
  const titleScore = lyricsTitleMatchScore(candidateTitle, targetTitle);
  const artistScore = lyricsArtistMatchScore(candidateArtist, targetArtist);
  let durationScore = 0;
  let durationDifference = null;
  const candidateDuration = lyricsCandidateDuration(entry.candidate);
  const targetDuration = durationSeconds(track?.duration) || Number(audio.duration || 0);
  if (candidateDuration > 20 && targetDuration > 20) {
    durationDifference = Math.abs(candidateDuration - targetDuration);
    if (durationDifference <= 3) durationScore = 24;
    else if (durationDifference <= 8) durationScore = 16;
    else if (durationDifference <= 15) durationScore = 8;
    else if (durationDifference <= 25) durationScore = 2;
    else if (durationDifference > 45) durationScore = -18;
  }
  const timedScore = payloadHasTimestamps(entry.payload, targetDuration) ? 50 : 0;
  const lines = timedScore ? parseLyricsLines(entry.payload, targetDuration) : [];
  const lineScore = Math.min(18, Math.floor(lines.filter(line => line.text).length / 3));
  return {
    ...entry,
    score: titleScore + artistScore + durationScore + timedScore + lineScore - Math.min(8, entry.order || 0),
    titleScore,
    artistScore,
    durationScore,
    durationDifference,
    timedScore,
    lineScore,
    candidateTitle,
    candidateArtist,
    candidateDuration,
    lines
  };
}

function selectSylvaticaLyricsCandidate(data, track) {
  const targetTitle = cleanTitle(track);
  const targetArtist = isUnknownArtist(track?.artist) ? '' : track.artist;
  let entries = collectLyricsCandidates(data);
  if (!entries.length) {
    const fallbackPayload = extractLyricsPayload(data);
    if (payloadHasTimestamps(fallbackPayload, durationSeconds(track?.duration))) {
      entries = [{
        candidate: { __lyricsTitle: targetTitle, __lyricsArtist: targetArtist, __lyricsDuration: durationSeconds(track?.duration) },
        payload: fallbackPayload,
        order: 0
      }];
    }
  }

  const ranked = entries
    .map(entry => scoreLyricsCandidate(entry, track))
    .filter(item => item.timedScore > 0 && item.lines.length > 0)
    .sort((a, b) => b.score - a.score || b.titleScore - a.titleScore || b.artistScore - a.artistScore || a.order - b.order);

  for (const item of ranked) {
    const hasExplicitTitle = Boolean(normalizeMatchText(item.candidateTitle));
    const hasExplicitArtist = Boolean(normalizeMatchText(item.candidateArtist));
    const titleMatches = item.titleScore >= 26;
    const artistMatches = item.artistScore >= 16;
    const durationMatches = item.durationScore >= 2;
    const onlyTimedResult = ranked.length === 1;
    const metadataMissing = !hasExplicitTitle && !hasExplicitArtist;
    const explicitTitleMismatch = hasExplicitTitle && item.titleScore === 0;

    if (explicitTitleMismatch && !artistMatches && !durationMatches) continue;
    if (!(titleMatches || artistMatches || durationMatches || onlyTimedResult || metadataMissing)) continue;
    if (item.score < 48 && !onlyTimedResult) continue;
    return item;
  }
  return null;
}

async function fetchSylvaticaLyrics(track, options = {}) {
  const normalized = normalizeTrack(track);
  const title = cleanTitle(normalized);
  const artist = isUnknownArtist(normalized.artist) ? '' : normalized.artist;
  if (!title) throw new Error('Judul lagu untuk lirik tidak tersedia');
  const durationKey = Math.round(durationSeconds(normalized.duration) || 0);
  const cacheKey = `${normalizeMatchText(title)}|${normalizeMatchText(artist)}|${durationKey}`;
  const force = Boolean(options.force);
  const cached = sylvaticaLyricsCache.get(cacheKey);

  if (!force && cached && Date.now() - cached.at < CONFIG.lyricsCacheMs) {
    if (cached.value?.selected?.lines?.length) return cached.value;
    if (cached.error && Date.now() - cached.at < 1000 * 45) throw cached.error;
  }

  if (!force) {
    const persisted = readPersistentApiCache(SYLVATICA_LYRICS_STORAGE_KEY, cacheKey, CONFIG.lyricsCacheMs);
    if (persisted) {
      const selected = selectSylvaticaLyricsCandidate(persisted, normalized);
      if (selected?.lines?.length) {
        const value = { data: persisted, selected, query: title, fromCache: true };
        sylvaticaLyricsCache.set(cacheKey, { at: Date.now(), value, hasLyrics: true });
        return value;
      }
      // Cache lama yang gagal diparse sengaja tidak dikembalikan; lanjut meminta data baru.
    }
  }

  const queries = [...new Set([
    title,
    artist ? `${title} ${artist}` : ''
  ].map(value => value.trim()).filter(Boolean))];
  const errors = [];
  let lastData = null;

  for (const query of queries) {
    try {
      const data = await sylvaticaApiFetch('lyrics', { q: query }, 30000, 'Sylvatica Lyrics');
      lastData = data;
      const selected = selectSylvaticaLyricsCandidate(data, normalized);
      if (selected?.lines?.length) {
        const value = { data, selected, query };
        sylvaticaLyricsCache.set(cacheKey, { at: Date.now(), value, hasLyrics: true });
        writePersistentApiCache(SYLVATICA_LYRICS_STORAGE_KEY, cacheKey, data, 40);
        return value;
      }
    } catch (error) {
      errors.push(error);
    }
  }

  if (lastData) {
    const value = { data: lastData, selected: null, query: queries.at(-1) || title };
    sylvaticaLyricsCache.set(cacheKey, { at: Date.now(), value, hasLyrics: false });
    return value;
  }

  const error = errors.at(-1) || new Error('Sylvatica tidak mengirim hasil lirik');
  sylvaticaLyricsCache.set(cacheKey, { at: Date.now(), error, hasLyrics: false });
  throw error;
}


async function fetchCmntySpotifyLyrics(track, options = {}) {
  const normalized = normalizeTrack(track);
  const title = cleanTitle(normalized);
  const artist = isUnknownArtist(normalized.artist) ? '' : normalized.artist;
  if (!title || !artist) throw new Error('Judul atau artis untuk lirik tidak tersedia');
  const cacheKey = `${normalizeMatchText(title)}|${normalizeMatchText(artist)}`;
  const force = Boolean(options.force);
  const cached = timedLyricsCache.get(cacheKey);
  const maxAge = cached?.hasLyrics ? CONFIG.lyricsCacheMs : CONFIG.negativeLyricsCacheMs;

  if (!force && cached && Date.now() - cached.at < maxAge) {
    if (cached.error) throw cached.error;
    return cached.value;
  }

  if (!force) {
    const persisted = readPersistentApiCache(CMNTY_LYRICS_STORAGE_KEY, cacheKey, CONFIG.lyricsCacheMs);
    if (persisted) {
      const payload = extractLyricsPayload(persisted);
      const hasLyrics = Array.isArray(payload) ? payload.length > 0 : Boolean(String(payload || '').trim());
      timedLyricsCache.set(cacheKey, { at: Date.now(), value: persisted, hasLyrics });
      return persisted;
    }
  }

  try {
    const data = await apiFetch('/search/spotify-lyrics', { title, artist }, 40000);
    const payload = extractLyricsPayload(data);
    const hasLyrics = Array.isArray(payload) ? payload.length > 0 : Boolean(String(payload || '').trim());
    timedLyricsCache.set(cacheKey, { at: Date.now(), value: data, hasLyrics });
    writePersistentApiCache(CMNTY_LYRICS_STORAGE_KEY, cacheKey, data, 40);
    return data;
  } catch (error) {
    if (error?.noData) {
      const empty = { status: true, result: { lyrics: [] } };
      timedLyricsCache.set(cacheKey, { at: Date.now(), value: empty, hasLyrics: false });
      return empty;
    }
    timedLyricsCache.set(cacheKey, { at: Date.now(), error, hasLyrics: false });
    throw error;
  }
}

async function ensureCurrentLyrics(force = false, token = state.playerPrepareToken, trackOverride = state.current) {
  let track = normalizeTrack(trackOverride);
  if (!track) return [];

  if (!spotifyTrackUrl(track) || isUnknownArtist(track.artist)) {
    try {
      const enriched = await resolveTrackMetadataWithPrimary(track, { force: isUnknownArtist(track.artist) });
      track = applyResolvedTrackToState(enriched);
    } catch { /* Lirik tetap mencoba jalur yang tersedia. */ }
  }

  const key = trackKey(track);
  if (!force && state.lyricsKey === key && (state.lyricsLoading || state.lyricsLines.length || state.lyricsError)) return state.lyricsLines;
  state.lyricsKey = key;
  state.lyricsLoading = true;
  state.lyricsError = '';
  state.lyricsLines = [];
  state.lyricsSynced = false;
  state.lyricsSource = '';
  if (!state.playerPreparing) renderLyricsPreview(true);

  try {
    let lines = [];
    let synced = false;

    const theresavPayload = track.syncedLyricsPayload || state.current?.syncedLyricsPayload || '';
    if (theresavPayload && payloadHasTimestamps(theresavPayload, durationSeconds(track.duration))) {
      const theresavLines = parseLyricsLines(theresavPayload, audio.duration || durationSeconds(track.duration));
      if (theresavLines.length) {
        lines = theresavLines;
        synced = true;
        state.lyricsSource = track.lyricsProvider || state.current?.lyricsProvider || 'Theresav Synced Lyrics';
      }
    }

    if (!lines.length && cleanTitle(track)) {
      try {
        const sylvaticaData = await fetchSylvaticaLyrics(track);
        if (sylvaticaData?.selected?.lines?.length) {
          lines = sylvaticaData.selected.lines;
          synced = true;
          state.lyricsSource = 'Sylvatica Synced Lyrics';
        }
      } catch { /* CMNTY dipakai sebagai cadangan jika Sylvatica gagal merespons. */ }
    }

    if (!lines.length && !isUnknownArtist(track.artist) && cleanTitle(track)) {
      try {
        const lyricsData = await fetchCmntySpotifyLyrics(track);
        const payload = extractLyricsPayload(lyricsData);
        synced = payloadHasTimestamps(payload, durationSeconds(track.duration));
        lines = parseLyricsLines(payload, audio.duration || durationSeconds(track.duration));
        if (lines.length) state.lyricsSource = synced ? 'CMNTY Spotify Synced Lyrics' : 'CMNTY Spotify Lyrics';
      } catch { /* Lagu tanpa lirik tetap dapat diputar tanpa provider tambahan. */ }
    }

    if (!lines.length) state.lyricsSource = '';

    if (token !== state.playerPrepareToken || trackKey(state.current) !== trackKey(track)) return [];
    state.lyricsKey = trackKey(track);
    state.lyricsLines = lines;
    state.lyricsSynced = synced;
    const shouldAutoFocus = Boolean(lines.length && synced);
    if (state.settings.lyricsAutoFocus !== shouldAutoFocus) {
      state.settings.lyricsAutoFocus = shouldAutoFocus;
      persist();
    }
    if (!lines.length) state.lyricsError = 'Lirik tidak ada';
  } catch {
    if (token !== state.playerPrepareToken) return [];
    state.lyricsError = 'Lirik tidak ada';
  } finally {
    if (token === state.playerPrepareToken) {
      state.lyricsLoading = false;
      state.lastLyricIndex = -1;
      if (!state.playerPreparing) {
        if (state.route === 'player') renderLyricsPreview(true);
        if (state.route === 'lyrics') renderFullLyrics();
        updateLyricsUI(true);
      }
    }
  }
  return state.lyricsLines;
}

function currentLyricIndex() {
  if (!state.settings.lyricsAutoFocus || !state.lyricsLines.length) return -1;
  const current = audio.currentTime || 0;
  let index = 0;
  for (let i = 0; i < state.lyricsLines.length; i += 1) {
    if (state.lyricsLines[i].time <= current + .08) index = i;
    else break;
  }
  return index;
}

function lyricsPreviewMarkup() {
  if (state.lyricsLoading) return `<div class="lyrics-preview-loading">Sedang memproses lirik bertimestamp...</div>`;
  if (state.lyricsError || !state.lyricsLines.length) return `<div class="lyrics-preview-empty">Lirik tidak ada</div>`;
  const active = currentLyricIndex();
  return `<div class="lyrics-preview-track">${state.lyricsLines.map((line, index) => `<div class="lyric-preview-line ${index === active ? 'active' : ''}" data-preview-lyric="${index}">${esc(line.text)}</div>`).join('')}</div>`;
}

function animateLiveLyric(index, force = false) {
  const live = $('#liveLyric', view);
  if (!live) return;
  if (!state.settings.lyricsAutoFocus) {
    live.textContent = state.lyricsLoading ? 'Mencari lirik lagu...' : 'Buka kartu Lirik di bawah untuk melihat lirik lengkap';
    live.dataset.lyricIndex = '-1';
    live.classList.remove('lyric-changing','lyric-entering');
    return;
  }
  const text = state.lyricsLines[index]?.text || (state.lyricsLoading ? 'Mencari lirik lagu...' : 'Lirik tidak ada');
  if (force || state.settings.reduceMotion || live.dataset.lyricIndex === String(index)) {
    live.textContent = text;
    live.dataset.lyricIndex = String(index);
    live.classList.remove('lyric-changing','lyric-entering');
    return;
  }
  clearTimeout(animateLiveLyric.timer);
  live.classList.add('lyric-changing');
  animateLiveLyric.timer = setTimeout(() => {
    if (!document.body.contains(live)) return;
    live.textContent = text;
    live.dataset.lyricIndex = String(index);
    live.classList.remove('lyric-changing');
    live.classList.add('lyric-entering');
    setTimeout(() => live.classList.remove('lyric-entering'), 330);
  }, 135);
}

function scrollPreviewToActive(index, force = false) {
  const body = $('#lyricsPreviewBody', view);
  const target = index >= 0 ? $(`[data-preview-lyric="${index}"]`, body || view) : null;
  if (!body || !target) return;
  const top = Math.max(0, target.offsetTop - body.clientHeight * .46 + target.offsetHeight / 2);
  body.scrollTo({ top, behavior: force || state.settings.reduceMotion ? 'auto' : 'smooth' });
}

function syncLyricsFocusControls() {
  const available = Boolean(state.lyricsSynced && state.lyricsLines.length);
  $$('[data-toggle-lyrics-focus], [data-toggle-full-lyrics-focus]', view).forEach(button => {
    button.disabled = !available;
    button.classList.toggle('active', Boolean(state.settings.lyricsAutoFocus && available));
    button.setAttribute('aria-pressed', state.settings.lyricsAutoFocus && available ? 'true' : 'false');
    button.setAttribute('title', available ? 'Fokus lirik otomatis' : 'Timestamp lirik belum tersedia');
  });
}

function renderLyricsPreview(force = false) {
  syncLyricsFocusControls();
  const body = $('#lyricsPreviewBody', view);
  const key = `${state.lyricsKey}|${state.lyricsLoading}|${state.lyricsLines.length}|${state.lyricsError}`;
  if (body && (force || body.dataset.renderKey !== key)) {
    body.innerHTML = lyricsPreviewMarkup();
    body.dataset.renderKey = key;
  }
  const active = currentLyricIndex();
  if (body) {
    $$('[data-preview-lyric]', body).forEach(el => el.classList.toggle('active', state.settings.lyricsAutoFocus && Number(el.dataset.previewLyric) === active));
    if (state.settings.lyricsAutoFocus) requestAnimationFrame(() => scrollPreviewToActive(active, force));
  }
  animateLiveLyric(active, force);
}

function scrollFullLyricsToActive(index, force = false) {
  const container = $('#fullLyricsScroll', view);
  const active = index >= 0 ? $(`[data-full-lyric="${index}"]`, container || view) : null;
  if (!container || !active) return;
  const top = Math.max(0, active.offsetTop - container.clientHeight * .42 + active.offsetHeight / 2);
  container.scrollTo({ top, behavior: force || state.settings.reduceMotion ? 'auto' : 'smooth' });
}

function updateLyricsUI(force = false) {
  const index = currentLyricIndex();
  if (!state.settings.lyricsAutoFocus) {
    state.lastLyricIndex = -1;
    animateLiveLyric(-1, true);
    $$('[data-preview-lyric], [data-full-lyric]', view).forEach(el => el.classList.remove('active'));
    return;
  }
  if (!force && index === state.lastLyricIndex) return;
  state.lastLyricIndex = index;
  animateLiveLyric(index, force);
  if (state.route === 'player') renderLyricsPreview(false);
  if (state.route === 'lyrics') {
    $$('[data-full-lyric]', view).forEach(el => el.classList.toggle('active', Number(el.dataset.fullLyric) === index));
    requestAnimationFrame(() => scrollFullLyricsToActive(index, force));
  }
}

function toggleLyricsAutoFocus() {
  if (!state.settings.lyricsAutoFocus && (!state.lyricsSynced || !state.lyricsLines.length)) {
    notify('Fokus otomatis hanya tersedia untuk lirik dengan timestamp');
    return;
  }
  state.settings.lyricsAutoFocus = !state.settings.lyricsAutoFocus;
  state.lastLyricIndex = -1;
  persist();
  if (state.route === 'player') renderPlayer();
  else if (state.route === 'lyrics') renderFullLyrics();
  notify(`Fokus otomatis lirik ${state.settings.lyricsAutoFocus ? 'aktif' : 'nonaktif'}`);
}

function playerContextMarkup() {
  const context = state.playContext || { eyebrow: 'MEMAINKAN DARI DATZON MUSIC', label: 'Pilihan untukmu' };
  return `<div class="player-context"><span>${esc(context.eyebrow)}</span><strong>${esc(context.label)}</strong></div>`;
}

function renderPlayerSkeleton() {
  const t = state.current || {};
  view.innerHTML = `<div class="player-page player-loading-page">
    <div class="player-art-bg player-loading-bg" style="background-image:url('${esc(t.thumbnail || '')}')"></div>
    <div class="player-shade"></div>
    <div class="player-content">
      <div class="player-top">
        <button class="player-top-btn" data-minimize aria-label="Tutup pemutar">${icon('chevron')}</button>
        <div class="player-context player-context-skeleton"><span class="skeleton skeleton-line sk-context-top"></span><strong class="skeleton skeleton-line sk-context-bottom"></strong></div>
        <span class="player-top-placeholder skeleton skeleton-circle"></span>
      </div>
      <div class="player-cover player-cover-skeleton skeleton" aria-label="Memuat sampul lagu"></div>
      <div class="live-lyric-line player-live-skeleton"><span class="skeleton skeleton-line sk-live"></span></div>
      <div class="player-info-row">
        <div class="player-track-copy player-copy-skeleton"><span class="skeleton skeleton-line sk-title"></span><span class="skeleton skeleton-line sk-artist"></span></div>
        <span class="save-track-btn skeleton skeleton-circle sk-save"></span>
      </div>
      <div class="progress-wrap player-progress-skeleton"><span class="skeleton skeleton-line sk-progress"></span><div class="time-row"><span class="skeleton skeleton-line sk-time"></span><span class="skeleton skeleton-line sk-time"></span></div></div>
      <div class="player-controls player-controls-skeleton">${Array.from({length:5},(_,index)=>`<span class="skeleton skeleton-circle sk-control ${index===2?'sk-control-main':''}"></span>`).join('')}</div>
      <div class="player-secondary-actions player-secondary-skeleton"><span class="skeleton skeleton-circle sk-secondary"></span><span class="skeleton skeleton-circle sk-secondary"></span><div class="secondary-spacer"></div><span class="skeleton skeleton-circle sk-secondary"></span><span class="skeleton skeleton-circle sk-secondary"></span><span class="skeleton skeleton-circle sk-secondary"></span></div>
      <section class="lyrics-preview-card lyrics-skeleton-card">
        <span class="skeleton skeleton-line sk-lyrics-heading"></span>
        <div class="lyrics-preview-body skeleton-lyrics-lines">
          <span class="skeleton skeleton-line sk-lyrics-line sk-long"></span>
          <span class="skeleton skeleton-line sk-lyrics-line sk-medium"></span>
          <span class="skeleton skeleton-line sk-lyrics-line sk-active"></span>
          <span class="skeleton skeleton-line sk-lyrics-line sk-short"></span>
        </div>
        <span class="skeleton skeleton-pill sk-lyrics-button"></span>
      </section>
    </div>
  </div>`;
  applyPlayerTheme(t);
  $('[data-minimize]', view).onclick = () => navigateBack(state.lastPlayerRoute || 'home');
  resetPlayerViewport();
}

function renderPlayer() {
  const t = state.current;
  if (!t) { navigate('home'); return; }
  view.innerHTML = `<div class="player-page">
    <div class="player-art-bg" style="background-image:url('${esc(t.thumbnail)}')"></div>
    <div class="player-shade"></div>
    <div class="player-content">
      <div class="player-top">
        <button class="player-top-btn" data-minimize aria-label="Tutup pemutar">${icon('chevron')}</button>
        ${playerContextMarkup()}
        <button class="player-top-btn" data-player-more aria-label="Opsi lagu">${icon('more')}</button>
      </div>
      <img class="player-cover" src="${esc(enhanceArtworkUrl(t.thumbnail))}" alt="Sampul ${esc(cleanTitle(t))}" decoding="async" fetchpriority="high" onerror="this.src='assets/placeholder.svg'">
      <div class="live-lyric-line" id="liveLyric">${state.lyricsLoading ? 'Sedang memproses lirik...' : state.settings.lyricsAutoFocus ? 'Lirik bertimestamp siap mengikuti lagu' : 'Buka kartu Lirik di bawah untuk melihat lirik lengkap'}</div>
      <div class="player-info-row">
        <div class="player-track-copy"><h1 class="player-title">${esc(cleanTitle(t))}</h1><button class="player-artist" data-open-artist>${esc(t.artist)}</button></div>
        <div class="player-info-actions">
          <button class="track-hide-btn" data-hide-track aria-label="Jangan sarankan lagu ini">${icon('close')}</button>
          <button class="save-track-btn ${isFavorite() ? 'active' : ''}" data-favorite aria-label="Tambahkan ke lagu disukai">${icon(isFavorite() ? 'check-circle' : 'plus-circle')}</button>
        </div>
      </div>
      <div class="progress-wrap"><input class="range" id="seek" type="range" min="0" max="1000" value="0" aria-label="Posisi lagu"><div class="time-row"><span id="elapsed">0:00</span><span id="total">${esc(t.duration || '0:00')}</span></div></div>
      <div class="player-controls">
        <button class="control-btn small ${state.shuffle ? 'active' : ''}" data-shuffle aria-label="Acak">${icon('shuffle')}</button>
        <button class="control-btn ${state.currentIndex <= 0 && state.queue.length <= 1 ? 'disabled' : ''}" data-prev aria-label="Sebelumnya">${icon('prev')}</button>
        <button class="control-btn main-play" data-main-play aria-label="Putar atau jeda">${state.resolving ? '<span class="loading-ring" aria-hidden="true"></span>' : icon(state.isPlaying ? 'pause' : 'play', state.isPlaying ? '' : 'fill')}</button>
        <button class="control-btn" data-next aria-label="Berikutnya">${icon('next')}</button>
        <button class="control-btn small ${state.repeat !== 'off' ? 'active' : ''}" data-repeat aria-label="Ulang">${repeatIconMarkup()}</button>
      </div>
      <div class="player-secondary-actions">
        <button class="secondary-action" data-device aria-label="Perangkat tersedia">${icon('device')}</button>
        <button class="secondary-action ${state.sleepTimerLabel ? 'active' : ''}" data-timer aria-label="Timer tidur">${icon('timer')}</button>
        <button class="secondary-action" data-audio-lab aria-label="Audio Settings">${icon('sliders')}</button>
        <div class="secondary-spacer"></div>
        <button class="secondary-action" data-player-download aria-label="Download MP3">${icon('download')}</button>
        <button class="secondary-action" data-share aria-label="Bagikan">${icon('share')}</button>
        <button class="secondary-action" data-up-next aria-label="Buka antrean">${icon('queue')}</button>
      </div>
      <section class="lyrics-preview-card" data-open-lyrics>
        <div class="lyrics-card-head"><h2>Lirik</h2><div class="lyrics-card-actions"><button type="button" class="lyrics-focus-toggle ${state.settings.lyricsAutoFocus ? 'active' : ''}" data-toggle-lyrics-focus aria-label="${state.settings.lyricsAutoFocus ? 'Nonaktifkan' : 'Aktifkan'} fokus lirik otomatis" aria-pressed="${state.settings.lyricsAutoFocus ? 'true' : 'false'}" title="${state.lyricsSynced ? 'Fokus lirik otomatis' : 'Timestamp lirik belum tersedia'}" ${state.lyricsSynced && state.lyricsLines.length ? '' : 'disabled'}><span class="lyrics-switch-track"><span></span></span></button><button type="button" data-share-lyrics-card aria-label="Bagikan lirik">${icon('share')}</button><button type="button" data-expand-lyrics-card aria-label="Buka layar lirik penuh">${icon('expand')}</button></div></div>
        <div id="lyricsPreviewBody" class="lyrics-preview-body">${lyricsPreviewMarkup()}</div>
      </section>
    </div>
  </div>`;
  applyPlayerTheme(t);
  $('[data-minimize]', view).onclick = () => navigateBack(state.lastPlayerRoute || 'home');
  $('[data-player-more]', view).onclick = () => showTrackMenu(t, true);
  $('[data-favorite]', view).onclick = () => toggleFavorite();
  $('[data-hide-track]', view).onclick = () => showHideTrackConfirm(t);
  $('[data-open-artist]', view).onclick = () => openArtistSearch(primaryArtistName(t));
  $('[data-main-play]', view).onclick = togglePlay;
  $('[data-prev]', view).onclick = previousTrack;
  $('[data-next]', view).onclick = () => nextTrack(true);
  $('[data-shuffle]', view).onclick = () => {
    state.shuffle = !state.shuffle;
    if (state.shuffle) state.mixMode = false;
    if (hasPlaylistPlaybackContext()) {
      state.queueRecommendationsKey = '';
      buildPlaylistRecommendations(true);
    }
    persist();
    renderPlayerDynamic();
    notify(hasPlaylistPlaybackContext() ? `Acak Cocok untukmu ${state.shuffle ? 'aktif' : 'nonaktif'}` : `Acak ${state.shuffle ? 'aktif' : 'nonaktif'}`);
  };
  $('[data-repeat]', view).onclick = () => { const mode = cycleRepeatMode(); notify(mode === 'one' ? 'Ulang satu lagu aktif' : mode === 'all' ? 'Ulang antrean aktif' : 'Ulang nonaktif'); };
  $('[data-timer]', view).onclick = showTimer;
  $('[data-device]', view).onclick = showConnectSheet;
  $('[data-audio-lab]', view).onclick = () => window.DatzonAudioLab?.open?.();
  $('[data-player-download]', view).onclick = () => downloadTrack(t);
  $('[data-share]', view).onclick = () => shareTrack(t);
  $('[data-up-next]', view).onclick = showQueue;
  $('[data-open-lyrics]', view).onclick = e => { if (!e.target.closest('button')) showLyrics(); };
  $('[data-toggle-lyrics-focus]', view).onclick = e => { e.stopPropagation(); toggleLyricsAutoFocus(); };
  $('[data-share-lyrics-card]', view).onclick = e => { e.stopPropagation(); shareTrack(t); };
  $('[data-expand-lyrics-card]', view).onclick = e => { e.stopPropagation(); showLyrics(); };
  const seek = $('#seek', view);
  bindSeekControl(seek, t);
  renderPlayerDynamic();
  ensureCurrentLyrics().catch(() => {});
}

function renderFullLyrics() {
  const t = state.current;
  if (!t) { navigate('home'); return; }
  const body = state.lyricsLoading
    ? `<div class="full-lyrics-loading">Mencari lirik ${esc(cleanTitle(t))}...</div>`
    : state.lyricsLines.length
      ? state.lyricsLines.map((line, index) => `<p class="full-lyric-line ${index === currentLyricIndex() ? 'active' : ''}" data-full-lyric="${index}">${esc(line.text)}</p>`).join('')
      : `<div class="full-lyrics-loading">Lirik tidak ada</div>`;
  view.innerHTML = `<div class="full-lyrics-page">
    <div class="lyrics-gradient-art" style="background-image:url('${esc(t.thumbnail)}')"></div>
    <header class="full-lyrics-header"><button class="lyrics-header-btn" data-back-player>${icon('chevron')}</button><div><strong>${esc(cleanTitle(t))}</strong><span>${esc(t.artist)}</span></div><span class="lyrics-header-spacer"></span></header>
    <main class="full-lyrics-scroll" id="fullLyricsScroll">${body}</main>
    <footer class="full-lyrics-controls">
      <div class="lyrics-control-icons"><button data-translate aria-label="Terjemahkan">${icon('translate')}</button><button class="lyrics-focus-toggle lyrics-focus-toggle-compact ${state.settings.lyricsAutoFocus ? 'active' : ''}" data-toggle-full-lyrics-focus aria-label="Fokus lirik otomatis" aria-pressed="${state.settings.lyricsAutoFocus ? 'true' : 'false'}" title="${state.lyricsSynced ? 'Fokus lirik otomatis' : 'Timestamp lirik belum tersedia'}" ${state.lyricsSynced && state.lyricsLines.length ? '' : 'disabled'}><span class="lyrics-switch-track"><span></span></span></button><button data-share-lyrics aria-label="Bagikan">${icon('share')}</button><button data-lyrics-more aria-label="Opsi">${icon('more')}</button></div>
      <div class="lyrics-progress"><input class="range" id="seek" type="range" min="0" max="1000" value="0"><div class="time-row"><span id="elapsed">0:00</span><span id="total">${esc(t.duration || '0:00')}</span></div></div>
      <button class="lyrics-main-play" data-main-play>${state.resolving ? '<span class="loading-ring" aria-hidden="true"></span>' : icon(state.isPlaying ? 'pause' : 'play', state.isPlaying ? '' : 'fill')}</button>
    </footer>
  </div>`;
  $('[data-back-player]', view).onclick = () => {
    if (history.state?.fromRoute === 'player' && history.length > 1) history.back();
    else navigate('player', { replace:true });
  };
  $('[data-main-play]', view).onclick = togglePlay;
  $('[data-toggle-full-lyrics-focus]', view).onclick = toggleLyricsAutoFocus;
  $('[data-share-lyrics]', view).onclick = () => shareTrack(t);
  $('[data-translate]', view).onclick = () => notify('Terjemahan lirik belum tersedia untuk lagu ini');
  $('[data-lyrics-more]', view).onclick = () => showTrackMenu(t, true);
  const seek = $('#seek', view);
  bindSeekControl(seek, t);
  applyFullLyricsTheme(t);
  renderPlayerDynamic();
  if (!state.lyricsLines.length && !state.lyricsLoading) ensureCurrentLyrics().catch(() => {});
  setTimeout(() => updateLyricsUI(true), 40);
}

function openArtistSearch(artist) {
  const wanted = normalizeMatchText(artist);
  const credits = artistCreditEntries(state.current);
  const hasCredit = credits.some(item => normalizeMatchText(item.name) === wanted);
  openArtistExplorer(artist, hasCredit ? state.current : null);
}

function renderPlayerDynamic() {
  if (!['player','lyrics'].includes(state.route)) return;
  const main = $('[data-main-play]', view);
  if (main) {
    main.innerHTML = state.resolving ? '<span class="loading-ring" aria-hidden="true"></span>' : icon(state.isPlaying ? 'pause' : 'play', state.isPlaying ? '' : 'fill');
    main.setAttribute('aria-label', state.resolving ? `Memuat audio penuh ${state.audioBufferingProgress || 0}%` : (state.isPlaying ? 'Jeda' : 'Putar'));
    main.title = state.resolving ? `Memuat audio penuh ${state.audioBufferingProgress || 0}%` : '';
  }
  if (state.route === 'player') {
    const fav = $('[data-favorite]', view);
    if (fav) { fav.classList.toggle('active', isFavorite()); fav.innerHTML = icon(isFavorite() ? 'check-circle' : 'plus-circle'); }
    const sh = $('[data-shuffle]', view); if (sh) sh.classList.toggle('active', state.shuffle);
    const repeatBtn = $('[data-repeat]', view); if (repeatBtn) { repeatBtn.classList.toggle('active', state.repeat !== 'off'); repeatBtn.innerHTML = repeatIconMarkup(); }
    const timer = $('[data-timer]', view); if (timer) timer.classList.toggle('active', Boolean(state.sleepTimerLabel));
  }
  const queueToggle = $('[data-queue-toggle]', modalRoot);
  if (queueToggle) queueToggle.innerHTML = icon(state.isPlaying ? 'pause' : 'play', state.isPlaying ? '' : 'fill');
  updateProgress();
  updateLyricsUI();
}

function updateProgress() {
  const duration = audio.duration || durationSeconds(state.current?.duration);
  const current = audio.currentTime || 0;
  const percent = duration ? current / duration : 0;
  const seek = $('#seek', view); if (seek && !userSeekActive) { seek.value = Math.round(percent * 1000); seek.style.setProperty('--range-progress', `${percent * 100}%`); }
  const elapsed = $('#elapsed', view); if (elapsed && !userSeekActive) elapsed.textContent = formatTime(current);
  const total = $('#total', view); if (total) total.textContent = formatTime(duration);
  const mini = $('.mini-progress', miniPlayer); if (mini) mini.style.width = `${percent * 100}%`;
}

function resetViewportX() {
  document.documentElement.scrollLeft = 0;
  document.body.scrollLeft = 0;
  if (view) view.scrollLeft = 0;
  if (window.scrollX) window.scrollTo(0, window.scrollY);
}

const DESKTOP_HORIZONTAL_RAIL_SELECTOR = [
  '.horizontal-scroll',
  '.home-square-carousel',
  '.community-carousel',
  '.artist-bubbles',
  '.radio-carousel',
  '.album-carousel',
  '.artist-page-releases',
  '.spotify-scroll-row',
  '.spotify-collection-carousel'
].join(',');

let desktopRailFrame = 0;

function updateDesktopRailControls(root = view) {
  $$('.desktop-scroll-shell', root).forEach(shell => {
    const scroller = shell.querySelector(DESKTOP_HORIZONTAL_RAIL_SELECTOR);
    if (!scroller) return;
    const maxScroll = Math.max(0, scroller.scrollWidth - scroller.clientWidth);
    const left = $('[data-desktop-rail="left"]', shell);
    const right = $('[data-desktop-rail="right"]', shell);
    shell.classList.toggle('has-overflow', maxScroll > 6);
    left?.classList.toggle('is-unavailable', maxScroll <= 6 || scroller.scrollLeft <= 6);
    right?.classList.toggle('is-unavailable', maxScroll <= 6 || scroller.scrollLeft >= maxScroll - 6);
  });
}

function enhanceDesktopHorizontalRails(root = view) {
  if (!root || !window.matchMedia('(min-width: 1024px)').matches) return;
  $$(DESKTOP_HORIZONTAL_RAIL_SELECTOR, root).forEach(scroller => {
    if (scroller.dataset.desktopRailReady === 'true') return;
    scroller.dataset.desktopRailReady = 'true';
    const shell = document.createElement('div');
    shell.className = 'desktop-scroll-shell';
    scroller.parentNode.insertBefore(shell, scroller);
    shell.appendChild(scroller);
    shell.insertAdjacentHTML('beforeend', `<button class="desktop-rail-control is-left" data-desktop-rail="left" type="button" aria-label="Geser ke kiri">${icon('arrow-right')}</button><button class="desktop-rail-control is-right" data-desktop-rail="right" type="button" aria-label="Geser ke kanan">${icon('arrow-right')}</button>`);
    const move = direction => {
      const distance = Math.max(320, Math.round(scroller.clientWidth * .82));
      scroller.scrollBy({ left: direction * distance, behavior: state.settings.reduceMotion ? 'auto' : 'smooth' });
    };
    $('[data-desktop-rail="left"]', shell).onclick = () => move(-1);
    $('[data-desktop-rail="right"]', shell).onclick = () => move(1);
    scroller.addEventListener('scroll', () => updateDesktopRailControls(root), { passive: true });
    scroller.addEventListener('wheel', event => {
      if (Math.abs(event.deltaY) <= Math.abs(event.deltaX) || !shell.classList.contains('has-overflow')) return;
      scroller.scrollLeft += event.deltaY;
      event.preventDefault();
    }, { passive:false });
  });
  updateDesktopRailControls(root);
}

function scheduleDesktopHorizontalRails(root = view) {
  if (desktopRailFrame) cancelAnimationFrame(desktopRailFrame);
  desktopRailFrame = requestAnimationFrame(() => {
    desktopRailFrame = 0;
    enhanceDesktopHorizontalRails(root);
    requestAnimationFrame(() => updateDesktopRailControls(root));
  });
}

window.addEventListener('resize', () => scheduleDesktopHorizontalRails(view), { passive: true });

function render() {
  if (!modalRoot.children.length) unlockPageScroll(true);
  const routeChanged = Boolean(lastRenderedRoute && lastRenderedRoute !== state.route);
  if (routeChanged) resetRouteViewport();
  resetViewportX();
  applyExperienceSettings();
  applyGlobalAppTheme(state.current);
  view.classList.toggle('has-mini', Boolean(state.current && !['player','lyrics'].includes(state.route)));
  if(state.route==='home')renderHome();
  else if(state.route==='search')renderSearch();
  else if(state.route==='library')renderLibrary();
  else if(state.route==='settings')renderSettings();
  else if(state.route==='profile')renderProfilePage();
  else if(state.route==='statistics')renderStatisticsPage();
  else if(state.route==='downloads')renderDownloadsPage();
  else if(state.route==='connections')renderConnectionsPage();
  else if(state.route==='people')renderPeopleSearchPage();
  else if(state.route==='friends')renderSocialListPage('friends');
  else if(state.route==='following')renderSocialListPage('following');
  else if(state.route==='followers')renderSocialListPage('followers');
  else if(state.route==='leaderboard')renderLeaderboardPage();
  else if(state.route==='report')renderReportPage();
  else if(state.route==='admin-reports')renderAdminReportsPage();
  else if(state.route==='public-profile')renderPublicProfilePage();
  else if(state.route==='datzon-playlist')renderDatzonPlaylistPage();
  else if(state.route==='login')renderLoginPage();
  else if(state.route==='register')renderRegisterPage();
  else if(state.route==='verify')renderOtpVerificationPage();
  else if(state.route==='onboarding')renderArtistOnboardingPage();
  else if(state.route==='artist')renderArtistPage();
  else if(state.route==='spotify-album'||state.route==='spotify-playlist')renderSpotifyCollectionPage();
  else if(state.route==='player')renderPlayer();
  else if(state.route==='lyrics')renderFullLyrics();
  renderNav(); renderMiniPlayer(); renderDesktopChrome();
  syncVisibleTrackPlaybackIcons(view);
  updatePublicPlaylistDetailPlayback();
  scheduleDesktopHorizontalRails(view);
  if (routeChanged) resetRouteViewport();
  lastRenderedRoute = state.route;
}

function resetModalRoot() {
  resetViewportX();
  if (typeof closeQueueMoveMenu === 'function') closeQueueMoveMenu();
  if (activeSheetController?.destroy) activeSheetController.destroy();
  activeSheetController = null;
  modalRoot.innerHTML = '';
  document.documentElement.classList.remove('sheet-open');
  document.body.classList.remove('sheet-open');
  unlockPageScroll(true);
}

function openModal(title, body, afterOpen) {
  const sheet = openPlayerSheet(`<div class="utility-sheet-content"><div class="utility-sheet-head"><h2>${esc(title)}</h2><button class="utility-sheet-close" data-utility-sheet-close aria-label="Tutup">${icon('close')}</button></div><div class="modal-body utility-sheet-body">${body}</div></div>`, 'utility-modal-player-sheet', { kind: 'adaptive', initialSnap: 'full' });
  $('[data-utility-sheet-close]', sheet).onclick = () => closeModal();
  if (afterOpen) afterOpen(sheet);
  return sheet;
}

function closeModal(immediate = false) {
  if (!immediate && activeSheetController?.close) {
    activeSheetController.close();
    return;
  }
  resetModalRoot();
}

function showCollection(type){
  const list=type==='favorites'?state.favorites:state.history;
  openModal(type==='favorites'?'Lagu Disukai':'Riwayat Putar',list.length?`<div class="queue-list">${list.map((t,i)=>`<div class="queue-item" data-modal-track="${i}"><img src="${esc(t.thumbnail)}" alt="" onerror="this.src='assets/placeholder.svg'"><div><strong>${esc(cleanTitle(t))}</strong><span>${esc(t.artist)}</span></div><span>${esc(t.duration||'')}</span></div>`).join('')}</div>`:`<div class="empty"><h3>Masih kosong</h3><p>Belum ada lagu di bagian ini.</p></div>`,root=>{$$('[data-modal-track]',root).forEach(el=>el.onclick=()=>{const i=Number(el.dataset.modalTrack);closeModal(true);playTrack(list[i],list,i);});});
}

function sheetViewportHeight() {
  return Math.max(420, Math.round(window.visualViewport?.height || window.innerHeight || document.documentElement.clientHeight || 720));
}

function setupPlayerSheet(sheet, config = {}) {
  const backdrop = sheet.closest('.player-sheet-backdrop');
  const dragZone = $('[data-sheet-drag]', sheet);
  const scrollRegion = $('[data-sheet-scroll]', sheet);
  const kind = config.kind || 'menu';
  const initialSnap = config.initialSnap || (kind === 'timer' ? 'full' : 'half');
  let destroyed = false;
  let pointerId = null;
  let startY = 0;
  let startHeight = 0;
  let startScrollTop = 0;
  let currentHeight = 0;
  let currentSnap = initialSnap;
  let measurements = null;
  let gestureMode = null;
  let moved = false;
  let frameId = 0;
  let pendingHeight = null;

  const measure = () => {
    const viewport = sheetViewportHeight();
    const contentHeight = Math.ceil((dragZone?.offsetHeight || 32) + (scrollRegion?.scrollHeight || 0));
    const compactKind = kind === 'timer' || kind === 'compact' || kind === 'adaptive';
    const full = compactKind
      ? Math.min(viewport - 12, Math.max(kind === 'timer' ? 400 : 255, contentHeight))
      : viewport - 12;
    const halfRatio = kind === 'queue' ? .55 : .56;
    const half = compactKind ? full : Math.min(full - 82, Math.max(340, Math.round(viewport * halfRatio)));
    // `content` is a near-full snap that tries to reveal the whole sheet body on open,
    // while still leaving a little travel so the handle can be dragged upward to `full`.
    const content = compactKind
      ? full
      : Math.max(half, Math.min(full - 46, Math.max(half, contentHeight + 4)));
    measurements = { viewport, half, content, full };
    return measurements;
  };

  const heightFor = snap => {
    const sizes = measurements || measure();
    if (snap === 'full') return sizes.full;
    if (snap === 'content') return sizes.content;
    return sizes.half;
  };

  const updateBackdrop = height => {
    if (!backdrop || !measurements) return;
    const ratio = Math.max(0, Math.min(1, height / measurements.full));
    backdrop.style.setProperty('--sheet-backdrop-opacity', String(.18 + ratio * .54));
  };

  const writeHeight = height => {
    sheet.style.height = `${height}px`;
    updateBackdrop(height);
  };

  const applyHeight = (height, animate = true) => {
    currentHeight = Math.max(0, height);
    sheet.classList.toggle('is-dragging', !animate);
    sheet.style.transition = animate ? '' : 'none';
    if (animate) {
      if (frameId) cancelAnimationFrame(frameId);
      frameId = 0;
      pendingHeight = null;
      writeHeight(currentHeight);
      return;
    }
    pendingHeight = currentHeight;
    if (!frameId) frameId = requestAnimationFrame(() => {
      frameId = 0;
      if (pendingHeight !== null) writeHeight(pendingHeight);
      pendingHeight = null;
    });
  };

  const applySnap = (snap, animate = true) => {
    currentSnap = snap;
    sheet.dataset.sheetSnap = snap;
    applyHeight(heightFor(snap), animate);
    if (scrollRegion && snap !== 'full') scrollRegion.scrollTop = 0;
  };

  const onResize = () => {
    if (destroyed || pointerId !== null) return;
    measure();
    applySnap(currentSnap, false);
    requestAnimationFrame(() => { if (!destroyed) sheet.style.transition = ''; });
  };

  const finishClose = () => {
    if (destroyed) return;
    destroy();
    modalRoot.innerHTML = '';
    document.documentElement.classList.remove('sheet-open');
    document.body.classList.remove('sheet-open');
    activeSheetController = null;
  };

  const close = () => {
    if (destroyed) return;
    currentSnap = 'closed';
    sheet.dataset.sheetSnap = 'closed';
    sheet.classList.remove('is-dragging');
    sheet.style.transition = '';
    sheet.style.height = '0px';
    if (backdrop) backdrop.style.setProperty('--sheet-backdrop-opacity', '0');
    window.setTimeout(finishClose, state.settings.reduceMotion ? 30 : 260);
  };

  const suppressAccidentalClick = () => {
    if (!moved) return;
    const stop = event => {
      event.preventDefault();
      event.stopImmediatePropagation();
    };
    sheet.addEventListener('click', stop, { capture: true, once: true });
    window.setTimeout(() => sheet.removeEventListener('click', stop, true), 320);
  };

  const releasePointer = () => {
    if (pointerId !== null) {
      try { sheet.releasePointerCapture(pointerId); } catch {}
    }
    pointerId = null;
    sheet.classList.remove('is-dragging');
    sheet.style.transition = '';
  };

  const finishSheetGesture = () => {
    const sizes = measurements || measure();
    const draggedDistance = currentHeight - startHeight;
    if (kind === 'timer' || kind === 'compact' || kind === 'adaptive') {
      if (currentHeight < sizes.full * .74 || draggedDistance < -82) close();
      else applySnap('full');
      return;
    }
    const restingSnap = initialSnap === 'content' ? 'content' : 'half';
    if (currentSnap === 'full') {
      if (currentHeight < sizes.half * .64) close();
      else if (currentHeight < sizes.full - Math.max(68, (sizes.full - sizes[restingSnap]) * .2)) applySnap(restingSnap);
      else applySnap('full');
      return;
    }
    if (currentSnap === 'content') {
      if (currentHeight < sizes.half * .64 || draggedDistance < -124) close();
      else if (currentHeight > sizes.content + Math.max(42, (sizes.full - sizes.content) * .48) || draggedDistance > 54) applySnap('full');
      else applySnap('content');
      return;
    }
    if (currentHeight < sizes.half * .64 || draggedDistance < -112) close();
    else if (currentHeight > sizes.half + Math.max(64, (sizes.full - sizes.half) * .22) || draggedDistance > 84) applySnap('full');
    else applySnap('half');
  };

  const endGesture = event => {
    if (pointerId === null || event.pointerId !== pointerId) return;
    const mode = gestureMode;
    releasePointer();
    suppressAccidentalClick();
    if (mode === 'sheet') finishSheetGesture();
    gestureMode = null;
  };

  const beginGesture = event => {
    if (destroyed || pointerId !== null || event.button > 0) return;
    measure();
    pointerId = event.pointerId;
    startY = event.clientY;
    startHeight = sheet.getBoundingClientRect().height;
    startScrollTop = scrollRegion?.scrollTop || 0;
    currentHeight = startHeight;
    moved = false;
    gestureMode = event.currentTarget === dragZone ? 'sheet' : 'pending';
    if (gestureMode === 'sheet') sheet.classList.add('is-dragging');
    try { sheet.setPointerCapture(pointerId); } catch {}
  };

  const moveGesture = event => {
    if (pointerId === null || event.pointerId !== pointerId) return;
    const deltaY = event.clientY - startY;
    if (!moved && Math.abs(deltaY) > 6) moved = true;
    if (!moved) return;

    if (gestureMode === 'pending') {
      if (kind === 'timer' || kind === 'compact' || currentSnap !== 'full' || (deltaY > 0 && startScrollTop <= 1)) {
        gestureMode = 'sheet';
        sheet.classList.add('is-dragging');
      } else {
        gestureMode = 'content';
      }
    }

    if (gestureMode === 'content' && scrollRegion) {
      const maxScroll = Math.max(0, scrollRegion.scrollHeight - scrollRegion.clientHeight);
      scrollRegion.scrollTop = Math.max(0, Math.min(maxScroll, startScrollTop - deltaY));
    } else if (gestureMode === 'sheet') {
      const max = (measurements || measure()).full;
      applyHeight(Math.max(0, Math.min(max, startHeight - deltaY)), false);
    }
    event.preventDefault();
  };

  const destroy = () => {
    if (destroyed) return;
    destroyed = true;
    if (frameId) cancelAnimationFrame(frameId);
    dragZone?.removeEventListener('pointerdown', beginGesture);
    sheet.removeEventListener('pointermove', moveGesture);
    sheet.removeEventListener('pointerup', endGesture);
    sheet.removeEventListener('pointercancel', endGesture);
    window.removeEventListener('resize', onResize);
    window.visualViewport?.removeEventListener('resize', onResize);
  };

  dragZone?.addEventListener('pointerdown', beginGesture);
  sheet.addEventListener('pointermove', moveGesture, { passive: false });
  sheet.addEventListener('pointerup', endGesture);
  sheet.addEventListener('pointercancel', endGesture);
  window.addEventListener('resize', onResize);
  window.visualViewport?.addEventListener('resize', onResize);

  measure();
  sheet.dataset.sheetKind = kind;
  sheet.dataset.sheetSnap = initialSnap;
  sheet.style.height = '0px';
  if (backdrop) backdrop.style.setProperty('--sheet-backdrop-opacity', '0');
  requestAnimationFrame(() => requestAnimationFrame(() => {
    if (!destroyed) applySnap(initialSnap, true);
  }));

  return { close, destroy, snapTo: applySnap, get snap() { return currentSnap; } };
}

function openPlayerSheet(body, className = '', options = {}) {
  resetModalRoot();
  const footer = options.footer || '';
  const kind = options.kind || (className.includes('queue') ? 'queue' : className.includes('timer') ? 'timer' : 'menu');
  const initialSnap = options.initialSnap || (kind === 'timer' ? 'full' : 'half');
  modalRoot.innerHTML = `<div class="player-sheet-backdrop" data-sheet-backdrop><section class="player-sheet ${className}" role="dialog" aria-modal="true"><div class="player-sheet-drag-zone" data-sheet-drag aria-label="Tarik lembar ke atas atau bawah"><div class="player-sheet-handle"></div></div><div class="player-sheet-scroll" data-sheet-scroll>${body}</div>${footer}</section></div>`;
  document.documentElement.classList.add('sheet-open');
  document.body.classList.add('sheet-open');
  const backdrop = $('[data-sheet-backdrop]', modalRoot);
  const sheet = $('.player-sheet', modalRoot);
  if (!state.settings.reduceMotion) {
    backdrop?.classList.add('is-entering');
    sheet?.classList.add('is-entering');
    window.setTimeout(() => {
      backdrop?.classList.remove('is-entering');
      sheet?.classList.remove('is-entering');
    }, 420);
  }
  activeSheetController = setupPlayerSheet(sheet, { kind, initialSnap });
  $('[data-sheet-backdrop]', modalRoot).onclick = event => {
    if (event.target.dataset.sheetBackdrop !== undefined) activeSheetController?.close();
  };
  return sheet;
}

window.DatzonPlayerSheet = Object.freeze({
  open(body, className = '', options = {}) { return openPlayerSheet(body, className, options); },
  close() { activeSheetController?.close?.(); },
  snapTo(snap) { activeSheetController?.snapTo?.(snap); }
});

function playlistRecommendationStateKey() {
  return [
    String(state.playContext?.playlistId || ''),
    trackKey(state.current),
    state.mixMode ? 'mix' : 'related',
    state.shuffle ? 'shuffle' : 'ordered'
  ].join('::');
}

function buildPlaylistRecommendations(force = false) {
  if (!hasPlaylistPlaybackContext() || !state.current) return [];
  const key = playlistRecommendationStateKey();
  if (!force && state.queueRecommendationsKey === key && Array.isArray(state.queueRecommendations)) {
    return state.queueRecommendations.map(normalizeTrack);
  }
  const playlistTracks = state.queue || [];
  const belongsToPlaylist = track => playlistTracks.some(item => sameTrackIdentity(item, track));
  const pool = filterHiddenSuggestions(dedupeTracks([...state.catalog, ...FALLBACK_TRACKS]))
    .filter(track => !belongsToPlaylist(track) && !sameTrackIdentity(track, state.current));
  let recommendations;
  if (state.mixMode) {
    const differentArtists = pool.filter(track => String(track.artist || '').toLowerCase() !== String(state.current.artist || '').toLowerCase());
    recommendations = differentArtists.length >= 8 ? differentArtists : pool;
  } else {
    const related = buildRelatedRecommendations(state.current).filter(track => !belongsToPlaylist(track));
    recommendations = [...related, ...pool.filter(track => !related.some(item => trackKey(item) === trackKey(track)))];
  }
  if (state.shuffle || state.mixMode) recommendations = shuffleList(recommendations);
  state.queueRecommendations = dedupeTracks(recommendations).slice(0, 14).map(normalizeTrack);
  state.queueRecommendationsKey = key;
  persist();
  return state.queueRecommendations;
}

function combinedUpcomingQueue() {
  const afterCurrent = state.queue.slice(Math.max(0, state.currentIndex + 1));
  return filterHiddenSuggestions(dedupeTracks([...afterCurrent, ...buildRelatedRecommendations(state.current), ...state.catalog, ...FALLBACK_TRACKS]))
    .filter(track => trackKey(track) !== trackKey(state.current))
    .slice(0, 24);
}

function materializeQueue(upcoming = combinedUpcomingQueue()) {
  if (!state.current) return [];
  const list = dedupeTracks(upcoming).filter(track => trackKey(track) !== trackKey(state.current));
  state.queue = [normalizeTrack(state.current), ...list];
  state.currentIndex = 0;
  persist();
  return list;
}

function queueUpcomingFromState() {
  return state.queue.slice(Math.max(0, state.currentIndex + 1));
}

function queueRowsMarkup(upcoming, options = {}) {
  const recommendation = options.recommendation === true;
  const locked = options.locked === true || recommendation;
  return upcoming.map((track, index) => {
    const key = trackKey(track);
    const selected = !locked && state.queueSelection.has(key);
    const playAttribute = recommendation ? `data-queue-recommendation="${index}"` : `data-queue-play="${index}"`;
    return `<div class="queue-sheet-row ${recommendation ? 'recommendation-row' : ''} ${!locked && state.queueEditMode ? 'is-editing' : ''} ${selected ? 'selected' : ''}" data-queue-row data-track-key="${esc(key)}" data-upcoming-index="${index}">
      ${!locked && state.queueEditMode ? `<button class="queue-select ${selected ? 'selected' : ''}" data-queue-select="${index}" aria-label="Pilih lagu"></button>` : ''}
      <button class="queue-row-main" ${playAttribute}><img src="${esc(track.thumbnail)}" alt="" onerror="this.src='assets/placeholder.svg'"><span><strong>${esc(cleanTitle(track))}</strong><small>${esc(track.artist)}</small></span></button>
      ${locked ? `<span class="queue-section-mark" aria-hidden="true">${icon(recommendation ? 'sparkles' : 'queue')}</span>` : `<button class="queue-drag-handle" data-queue-handle="${index}" aria-label="Atur urutan"><span class="queue-handle-icon queue-handle-menu">${icon('queue')}</span><span class="queue-handle-icon queue-handle-close">${icon('close')}</span></button>`}
    </div>`;
  }).join('');
}

function queueSkeletonMarkup(count = 7) {
  return Array.from({length: count}, () => `<div class="queue-sheet-row queue-skeleton-row"><span class="queue-skeleton-cover skeleton"></span><span class="queue-skeleton-copy"><i class="skeleton"></i><i class="skeleton"></i></span><span class="queue-skeleton-handle skeleton"></span></div>`).join('');
}

function queueHeaderMarkup(context) {
  const playlistMode = hasPlaylistPlaybackContext();
  return `<div class="queue-sheet-head compact-head"><div><h2>${state.queueEditMode ? 'Edit Antrean' : 'Antrean'}</h2>${state.queueEditMode ? '' : `<p>Memutar ${esc(context)}</p>`}</div>${playlistMode ? '<span class="queue-context-pill">PLAYLIST</span>' : `<button class="queue-edit-toggle ${state.queueEditMode ? 'cancel-mode' : ''}" data-queue-edit-toggle aria-label="${state.queueEditMode ? 'Batalkan mode edit' : 'Edit antrean'}"><span>${state.queueEditMode ? 'Batal' : 'Edit'}</span></button>`}</div>`;
}


function queueFooterMarkup() {
  const repeatText = state.repeat === 'one' ? 'Ulang Satu Lagu' : hasPlaylistPlaybackContext() ? 'Ulang Antrean' : 'Ulang';
  return `<div class="queue-sheet-actions solid-actions ${state.queueEditMode ? 'is-hidden' : ''}" data-queue-normal-footer>
    <button class="${state.mixMode ? 'active' : ''}" data-queue-mode="mix">${icon('mix')}<span>Mix</span></button>
    <button class="${state.shuffle ? 'active' : ''}" data-queue-mode="shuffle">${icon('shuffle')}<span>Shuffle</span></button>
    <button class="${state.repeat !== 'off' ? 'active' : ''}" data-queue-mode="repeat">${repeatIconMarkup(state.repeat)}<span>${repeatText}</span></button>
    <button data-queue-mode="timer">${icon('timer')}<span>Pengatur Waktu</span></button>
  </div>`;
}

function queueEditFooterMarkup() {
  const enabled = state.queueSelection.size > 0;
  return `<div class="queue-edit-footer ${state.queueEditMode ? 'show' : ''}" data-queue-edit-footer><button ${enabled ? '' : 'disabled'} data-queue-move-up>Naikkan</button><button class="danger" ${enabled ? '' : 'disabled'} data-queue-remove>Hapus</button></div>`;
}

function queueSheetBodyMarkup(context) {
  const upcoming = queueUpcomingFromState();
  const nowPlaying = `<div class="queue-now"><img src="${esc(state.current.thumbnail)}" alt="" onerror="this.src='assets/placeholder.svg'"><div><strong><span class="now-bars"><i></i><i></i><i></i></span> ${esc(cleanTitle(state.current))}</strong><span>${esc(state.current.artist)}</span></div><button data-queue-toggle>${icon(state.isPlaying ? 'pause' : 'play', state.isPlaying ? '' : 'fill')}</button></div>`;
  if (hasPlaylistPlaybackContext()) {
    const recommendations = buildPlaylistRecommendations(false);
    return `${queueHeaderMarkup(context)}
      ${nowPlaying}
      <div class="queue-divider-label queue-section-title">${icon('queue')}<span><strong>Antrean</strong><small>${esc(context)} • sesuai urutan playlist</small></span></div>
      <div class="queue-sheet-list playlist-queue-list" data-queue-list>${upcoming.length ? queueRowsMarkup(upcoming, { locked:true }) : '<div class="queue-empty-note">Tidak ada lagu berikutnya di playlist ini.</div>'}</div>
      <div class="queue-recommendation-block">
        <div class="queue-divider-label queue-section-title recommendation-title">${icon('sparkles')}<span><strong>Cocok untukmu</strong><small>Rekomendasi terpisah dari antrean playlist</small></span></div>
        <div class="queue-sheet-list recommendation-queue-list" data-queue-recommendation-list>${state.queueSheetLoading ? queueSkeletonMarkup(5) : recommendations.length ? queueRowsMarkup(recommendations, { recommendation:true }) : '<div class="queue-empty-note">Rekomendasi belum tersedia.</div>'}</div>
      </div>`;
  }
  return `${queueHeaderMarkup(context)}
    ${nowPlaying}
    <div class="queue-divider-label">${icon(state.mixMode ? 'mix' : 'shuffle')}<span>${state.mixMode ? 'Mix berikutnya:' : state.shuffle ? 'Shuffling dari:' : 'Berikutnya:'}</span></div>
    <div class="queue-sheet-list" data-queue-list>${state.queueSheetLoading ? queueSkeletonMarkup() : queueRowsMarkup(upcoming)}</div>`;
}

function updateQueueNowPlayButton() {
  const button = $('[data-queue-toggle]', modalRoot);
  if (button) button.innerHTML = icon(state.isPlaying ? 'pause' : 'play', state.isPlaying ? '' : 'fill');
}

function updateQueueControls() {
  const mix = $('[data-queue-mode="mix"]', modalRoot);
  const shuffle = $('[data-queue-mode="shuffle"]', modalRoot);
  const repeat = $('[data-queue-mode="repeat"]', modalRoot);
  if (mix) mix.classList.toggle('active', state.mixMode);
  if (shuffle) shuffle.classList.toggle('active', state.shuffle);
  if (repeat) {
    repeat.classList.toggle('active', state.repeat !== 'off');
    const repeatText = state.repeat === 'one' ? 'Ulang Satu Lagu' : hasPlaylistPlaybackContext() ? 'Ulang Antrean' : 'Ulang';
    repeat.innerHTML = `${repeatIconMarkup(state.repeat)}<span>${repeatText}</span>`;
  }
  updateQueueNowPlayButton();
}

function updateQueueSheetContent() {
  closeQueueMoveMenu();
  const sheet = $('.queue-player-sheet', modalRoot);
  if (!sheet) return;
  const scroll = $('[data-sheet-scroll]', sheet);
  const previousScrollTop = scroll?.scrollTop || 0;
  const oldNormal = $('[data-queue-normal-footer]', sheet);
  const oldEdit = $('[data-queue-edit-footer]', sheet);
  const context = state.playContext?.label || 'Pilihan untukmu';
  if (scroll) scroll.innerHTML = queueSheetBodyMarkup(context);
  if (oldNormal) oldNormal.outerHTML = queueFooterMarkup();
  if (oldEdit) oldEdit.outerHTML = queueEditFooterMarkup();
  if (scroll) scroll.scrollTop = previousScrollTop;
  bindQueueSheetEvents();
}

let activeQueueMoveMenu = null;
let activeQueueMoveHandle = null;
let activeQueueMoveRow = null;

function closeQueueMoveMenu() {
  activeQueueMoveHandle?.classList.remove('is-open');
  activeQueueMoveRow?.classList.remove('menu-open');
  activeQueueMoveMenu?.remove();
  activeQueueMoveMenu = null;
  activeQueueMoveHandle = null;
  activeQueueMoveRow = null;
  document.removeEventListener('pointerdown', handleQueueMoveOutside, true);
}

function suppressQueueOutsideClick(target) {
  const blocker = event => {
    const sameTarget = event.target === target || target?.contains?.(event.target) || event.target?.contains?.(target);
    if (sameTarget) {
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();
    }
    document.removeEventListener('click', blocker, true);
  };
  document.addEventListener('click', blocker, true);
  setTimeout(() => document.removeEventListener('click', blocker, true), 420);
}

function handleQueueMoveOutside(event) {
  if (activeQueueMoveMenu?.contains(event.target) || event.target.closest?.('[data-queue-handle]')) return;
  const target = event.target;
  event.preventDefault();
  event.stopPropagation();
  event.stopImmediatePropagation();
  suppressQueueOutsideClick(target);
  closeQueueMoveMenu();
}

function positionQueueMoveMenu(menu, handle) {
  if (!menu || !handle?.isConnected) return;
  const rect = handle.getBoundingClientRect();
  const menuRect = menu.getBoundingClientRect();
  const viewportPadding = 10;
  let left = Math.min(window.innerWidth - menuRect.width - viewportPadding, Math.max(viewportPadding, rect.right - menuRect.width));
  let top = rect.top - menuRect.height - 8;
  if (top < viewportPadding) top = rect.bottom + 8;
  menu.style.left = `${left}px`;
  menu.style.top = `${Math.min(window.innerHeight - menuRect.height - viewportPadding, top)}px`;
}

function moveQueueItemOneStep(upcomingIndex, direction) {
  const upcoming = queueUpcomingFromState();
  const targetIndex = upcomingIndex + direction;
  if (targetIndex < 0 || targetIndex >= upcoming.length) return upcomingIndex;
  const absoluteFrom = state.currentIndex + 1 + upcomingIndex;
  const absoluteTo = state.currentIndex + 1 + targetIndex;
  [state.queue[absoluteFrom], state.queue[absoluteTo]] = [state.queue[absoluteTo], state.queue[absoluteFrom]];
  persist();
  return targetIndex;
}

function openQueueMoveMenu(upcomingIndex, handle) {
  if (activeQueueMoveMenu && activeQueueMoveHandle === handle) {
    closeQueueMoveMenu();
    return;
  }
  closeQueueMoveMenu();
  const upcoming = queueUpcomingFromState();
  const menu = document.createElement('div');
  menu.className = 'queue-move-menu';
  menu.setAttribute('role', 'menu');
  menu.innerHTML = `<button type="button" data-queue-step="-1" ${upcomingIndex <= 0 ? 'disabled' : ''}>${icon('arrow-up')}<span>Naik</span></button><button type="button" data-queue-step="1" ${upcomingIndex >= upcoming.length - 1 ? 'disabled' : ''}>${icon('arrow-down')}<span>Turun</span></button>`;
  document.body.appendChild(menu);
  activeQueueMoveMenu = menu;
  activeQueueMoveHandle = handle;
  activeQueueMoveRow = handle.closest('[data-queue-row]');
  handle.classList.add('is-open');
  activeQueueMoveRow?.classList.add('menu-open');
  requestAnimationFrame(() => positionQueueMoveMenu(menu, handle));
  menu.querySelectorAll('[data-queue-step]').forEach(button => {
    button.onclick = event => {
      event.preventDefault();
      event.stopPropagation();
      if (button.disabled) return;
      const direction = Number(button.dataset.queueStep);
      closeQueueMoveMenu();
      moveQueueItemOneStep(upcomingIndex, direction);
      updateQueueSheetContent();
    };
  });
  setTimeout(() => document.addEventListener('pointerdown', handleQueueMoveOutside, true), 0);
}

function setupQueueMoveButtons() {
  $$('[data-queue-handle]', modalRoot).forEach(handle => {
    handle.onclick = event => {
      event.preventDefault();
      event.stopPropagation();
      if (state.queueSheetLoading) return;
      openQueueMoveMenu(Number(handle.dataset.queueHandle), handle);
    };
  });
}

async function refreshQueueMode(mode) {
  const playlistMode = hasPlaylistPlaybackContext();
  const list = playlistMode ? $('[data-queue-recommendation-list]', modalRoot) : $('[data-queue-list]', modalRoot);
  if (!list || !state.current) return;
  if (mode === 'mix') state.mixMode = !state.mixMode;
  if (mode === 'shuffle') state.shuffle = !state.shuffle;
  if (mode === 'mix' && state.mixMode) state.shuffle = false;
  if (mode === 'shuffle' && state.shuffle) state.mixMode = false;
  persist();
  updateQueueControls();
  state.queueSheetLoading = true;
  list.innerHTML = queueSkeletonMarkup(playlistMode ? 5 : 7);
  await new Promise(resolve => setTimeout(resolve, state.settings.reduceMotion ? 80 : 560));
  if (playlistMode) {
    state.queueRecommendationsKey = '';
    buildPlaylistRecommendations(true);
  } else {
    const pool = filterHiddenSuggestions(dedupeTracks([...state.catalog, ...FALLBACK_TRACKS])).filter(track => trackKey(track) !== trackKey(state.current));
    let next = [];
    if (state.mixMode) {
      const different = pool.filter(track => String(track.artist).toLowerCase() !== String(state.current.artist).toLowerCase());
      next = shuffleList(different.length >= 10 ? different : pool);
    } else {
      const related = buildRelatedRecommendations(state.current);
      next = [...related, ...pool.filter(track => !related.some(item => trackKey(item) === trackKey(track)))];
    }
    if (state.shuffle) next = shuffleList(next);
    state.queue = [state.current, ...dedupeTracks(next).slice(0, 22)];
    state.currentIndex = 0;
    state.queueSelection.clear();
  }
  state.queueSheetLoading = false;
  persist();
  updateQueueSheetContent();
  const scope = playlistMode ? ' Cocok untukmu' : '';
  notify(mode === 'mix' ? `Mix${scope} ${state.mixMode ? 'aktif' : 'nonaktif'}` : `Shuffle${scope} ${state.shuffle ? 'aktif' : 'nonaktif'}`);
}

function bindQueueSheetEvents() {
  const toggle = $('[data-queue-toggle]', modalRoot);
  if (toggle) toggle.onclick = () => { togglePlay(); setTimeout(updateQueueNowPlayButton, 0); };
  const edit = $('[data-queue-edit-toggle]', modalRoot);
  if (edit) edit.onclick = () => {
    state.queueEditMode = !state.queueEditMode;
    state.queueSelection.clear();
    updateQueueSheetContent();
  };
  $$('[data-queue-play]', modalRoot).forEach(button => button.onclick = () => {
    if (state.queueEditMode || state.queueSheetLoading) return;
    const upcomingIndex = Number(button.dataset.queuePlay);
    const absoluteIndex = state.currentIndex + 1 + upcomingIndex;
    const selected = state.queue[absoluteIndex];
    if (!selected) return;
    closeModal(true);
    playTrack(selected, state.queue, absoluteIndex);
  });
  $$('[data-queue-recommendation]', modalRoot).forEach(button => button.onclick = () => {
    if (state.queueSheetLoading) return;
    const recommendations = buildPlaylistRecommendations(false);
    const index = Number(button.dataset.queueRecommendation);
    const selected = recommendations[index];
    if (!selected) return;
    const recommendationQueue = [selected, ...recommendations.filter((_, itemIndex) => itemIndex !== index)];
    closeModal(true);
    playTrack(selected, recommendationQueue, 0, { playContext:{ eyebrow:'COCOK UNTUKMU', label:'Rekomendasi untukmu', type:'recommendation' } });
  });
  $$('[data-queue-select]', modalRoot).forEach(button => button.onclick = event => {
    event.stopPropagation();
    const index = Number(button.dataset.queueSelect);
    const track = queueUpcomingFromState()[index];
    const key = trackKey(track);
    if (state.queueSelection.has(key)) state.queueSelection.delete(key); else state.queueSelection.add(key);
    updateQueueSheetContent();
  });
  $$('[data-queue-mode]', modalRoot).forEach(button => button.onclick = () => {
    const mode = button.dataset.queueMode;
    if (mode === 'timer') { closeModal(true); showTimer(); return; }
    if (mode === 'repeat') {
      const repeatMode = cycleRepeatMode();
      notify(repeatMode === 'one' ? 'Ulang satu lagu aktif' : repeatMode === 'all' ? 'Ulang antrean aktif' : 'Ulang nonaktif');
      updateQueueControls();
      return;
    }
    refreshQueueMode(mode);
  });
  const up = $('[data-queue-move-up]', modalRoot);
  if (up) up.onclick = () => {
    if (!state.queueSelection.size) return;
    const upcoming = queueUpcomingFromState();
    const selected = upcoming.filter(track => state.queueSelection.has(trackKey(track)));
    const rest = upcoming.filter(track => !state.queueSelection.has(trackKey(track)));
    const prefix = state.queue.slice(0, state.currentIndex + 1);
    state.queue = [...prefix, ...selected, ...rest];
    state.queueSelection.clear();
    persist();
    updateQueueSheetContent();
    notify('Lagu pilihan dinaikkan');
  };
  const remove = $('[data-queue-remove]', modalRoot);
  if (remove) remove.onclick = () => {
    if (!state.queueSelection.size) return;
    const prefix = state.queue.slice(0, state.currentIndex + 1);
    state.queue = [...prefix, ...queueUpcomingFromState().filter(track => !state.queueSelection.has(trackKey(track)))];
    state.queueSelection.clear();
    persist();
    updateQueueSheetContent();
    notify('Lagu pilihan dihapus dari antrean');
  };
  setupQueueMoveButtons();
  updateQueueControls();
}

function showQueue() {
  if (!state.current) return;
  state.queueSheetLoading = false;
  state.queueEditMode = false;
  state.queueSelection = new Set();
  if (hasPlaylistPlaybackContext()) {
    syncPlaylistQueueToSource();
    buildPlaylistRecommendations(false);
    persist();
  } else {
    ensureQueueSeed();
    if (!queueUpcomingFromState().length && state.settings.autoplay) {
      const related = buildRelatedRecommendations(state.current).filter(track => !sameTrackIdentity(track, state.current)).slice(0, 18);
      if (related.length) {
        const prefix = state.queue.slice(0, Math.max(1, state.currentIndex + 1));
        state.queue = [...prefix, ...related];
        persist();
      }
    }
  }
  const context = state.playContext?.label || 'Pilihan untukmu';
  openPlayerSheet(queueSheetBodyMarkup(context), 'queue-player-sheet queue-advanced-sheet', {kind:'queue', initialSnap:'half', footer:`${queueFooterMarkup()}${queueEditFooterMarkup()}`});
  bindQueueSheetEvents();
}

function showLyrics() {
  closeModal();
  state.route = 'lyrics';
  syncBrowserRoute('lyrics', { track: state.current });
  render();
  ensureCurrentLyrics().catch(() => {});
}

let sleepTimerSheetTicker = null;

function sleepTimerRemainingMs() {
  return state.sleepTimerMode === 'duration' ? Math.max(0, Number(state.sleepTimerEndAt || 0) - Date.now()) : 0;
}

function formatSleepTimerRemaining(ms = sleepTimerRemainingMs()) {
  if (!Number.isFinite(ms) || ms <= 0) return 'kurang dari 1 menit';
  const totalSeconds = Math.max(0, Math.ceil(ms / 1000));
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  return hours ? `${hours}:${String(minutes).padStart(2,'0')}:${String(seconds).padStart(2,'0')}` : `${minutes}:${String(seconds).padStart(2,'0')}`;
}

function sleepTimerDisplayLabel() {
  if (state.sleepTimerMode === 'end' || state.sleepTimerLabel === 'Akhir lagu') return 'Aktif • berhenti di akhir lagu';
  if (state.sleepTimerMode === 'duration' && sleepTimerRemainingMs() > 0) return `Aktif • tersisa ${formatSleepTimerRemaining()}`;
  return 'Belum aktif';
}

function clearSleepTimer({ notifyUser = false } = {}) {
  clearTimeout(state.sleepTimer);
  state.sleepTimer = null;
  state.sleepTimerLabel = '';
  state.sleepTimerMode = '';
  state.sleepTimerEndAt = 0;
  persist();
  renderPlayerDynamic();
  if (notifyUser) notify('Pengatur waktu tidur dibatalkan');
}

function finishSleepTimer() {
  audio.pause();
  clearTimeout(state.sleepTimer);
  state.sleepTimer = null;
  state.sleepTimerLabel = '';
  state.sleepTimerMode = '';
  state.sleepTimerEndAt = 0;
  persist();
  renderPlayerDynamic();
  notify('Pengatur waktu tidur selesai. Musik dijeda.');
}

function armSleepTimerFromState() {
  clearTimeout(state.sleepTimer);
  state.sleepTimer = null;
  if (state.sleepTimerMode !== 'duration') return;
  const remaining = sleepTimerRemainingMs();
  if (remaining <= 0) {
    state.sleepTimerLabel = '';
    state.sleepTimerMode = '';
    state.sleepTimerEndAt = 0;
    persist();
    return;
  }
  state.sleepTimer = setTimeout(finishSleepTimer, remaining);
}

function setSleepTimer(value, label) {
  clearTimeout(state.sleepTimer);
  state.sleepTimer = null;
  state.sleepTimerLabel = '';
  state.sleepTimerMode = '';
  state.sleepTimerEndAt = 0;
  if (value === 'end') {
    state.repeat = 'off';
    state.sleepTimerMode = 'end';
    state.sleepTimerLabel = 'Akhir lagu';
    notify('Musik akan berhenti setelah lagu ini selesai');
  } else if (Number(value) > 0) {
    const minutes = Number(value);
    state.sleepTimerMode = 'duration';
    state.sleepTimerLabel = label;
    state.sleepTimerEndAt = Date.now() + minutes * 60000;
    armSleepTimerFromState();
    notify(`Pengatur waktu ${label} aktif`);
  }
  persist();
  renderPlayerDynamic();
}

function startSleepTimerSheetTicker() {
  clearInterval(sleepTimerSheetTicker);
  const update = () => {
    const output = $('[data-sleep-remaining]', modalRoot);
    if (!output) { clearInterval(sleepTimerSheetTicker); sleepTimerSheetTicker = null; return; }
    output.textContent = sleepTimerDisplayLabel();
  };
  update();
  sleepTimerSheetTicker = setInterval(update, 1000);
}

function showTimer() {
  const options = [['5 menit', 5], ['10 menit', 10], ['15 menit', 15], ['30 menit', 30], ['45 menit', 45], ['1 jam', 60], ['Akhir lagu', 'end']];
  const active = Boolean(state.sleepTimerMode && (state.sleepTimerMode === 'end' || sleepTimerRemainingMs() > 0));
  openPlayerSheet(`<div class="sleep-timer-sheet"><header><span>${icon('timer')}</span><div><h2>Pengatur waktu tidur</h2><p>Musik akan dijeda otomatis. Pilih durasi, atau gunakan Akhir lagu agar lagu saat ini selesai terlebih dahulu.</p></div></header>${active ? `<section class="sleep-timer-active"><div><small>TIMER AKTIF</small><strong data-sleep-remaining>${esc(sleepTimerDisplayLabel())}</strong></div><button data-cancel-sleep-timer>Batalkan</button></section>` : ''}<div class="timer-options">${options.map(([label, value]) => `<button data-timer-value="${value}" data-timer-label="${label}"><span>${label}</span>${value === 'end' ? '<small>Berhenti sebelum lagu berikutnya</small>' : ''}</button>`).join('')}</div></div>`, 'timer-player-sheet', { kind: 'timer', initialSnap: 'full' });
  $$('[data-timer-value]', modalRoot).forEach(button => button.onclick = () => {
    setSleepTimer(button.dataset.timerValue, button.dataset.timerLabel);
    closeModal();
  });
  $('[data-cancel-sleep-timer]', modalRoot)?.addEventListener('click', () => { clearSleepTimer({ notifyUser: true }); closeModal(); });
  if (active && state.sleepTimerMode === 'duration') startSleepTimerSheetTicker();
}

function addCurrentToQueue(track) {
  if (!state.queue.some(item => trackKey(item) === trackKey(track))) state.queue.push(normalizeTrack(track));
  persist();
  notify('Ditambahkan ke Antrean');
}

function startSongRadio(track) {
  const radio = dedupeTracks([track, ...state.catalog.filter(item => item.artist === track.artist), ...state.catalog]).slice(0, 25);
  state.queue = radio;
  state.currentIndex = 0;
  state.shuffle = true;
  persist();
  notify('Radio lagu dibuat');
}

function showTrackCredits(track) {
  const artist = track.artist || 'Tidak tersedia';
  const album = track.album || 'Tidak tersedia';
  const release = track.release_date || track.releaseDate || track.date || track.year || 'Tidak tersedia';
  openPlayerSheet(`<div class="credit-sheet-content">
      <div class="credit-sheet-head"><h2>Kredit lagu</h2><button type="button" data-credit-close aria-label="Tutup">${icon('close')}</button></div>
      <h3>${esc(cleanTitle(track))}</h3>
      <div class="credit-card">
        <p><strong>Artis</strong><span>${esc(artist)}</span></p>
        <p><strong>Album</strong><span>${esc(album)}</span></p>
        <p><strong>Tanggal rilis</strong><span>${esc(release)}</span></p>
        <p><strong>Sumber</strong><span>Spotify</span></p>
      </div>
    </div>`, 'credit-menu-sheet', { kind: 'compact', initialSnap: 'full' });
  $('[data-credit-close]', modalRoot).onclick = () => closeModal();
}

async function ensureMusicCodeTrackIdentity(track) {
  let normalized=normalizeTrack(track); if(spotifyTrackIdFromTrack(normalized))return normalized;
  if(!spotifyCatalogAvailable())return normalized;
  try{
    const primary=extractArtistNames(normalized.artistNames,normalized.artist)[0]||primaryArtistName(normalized)||normalized.artist||'';
    const query=`track:${cleanTitle(normalized)}${primary?` artist:${primary}`:''}`;
    const payload=await window.DatzonSpotifyCatalog.search(query,{limit:10});
    const candidates=(payload?.tracks?.items||[]).map(spotifyCatalogTrackEntity);
    const match=candidates.find(candidate=>safeSameTrack(normalized,candidate));
    if(match)normalized=enrichExistingTrackWithSpotify(normalized,match);
  }catch{}
  return normalized;
}

function localTrackPoolForMusicCode(){return dedupeTracks([state.current,...(state.queue||[]),...(state.history||[]),...(state.favorites||[]),...(state.catalog||[]),...(state.searchResults||[]),...activePlaylists().flatMap(item=>item.tracks||[])].filter(Boolean));}

async function resolveMusicCodeCanonical(canonical='') {
  const value=String(canonical||'');
  if(/^spotify:[A-Za-z0-9]{22}$/.test(value)){
    const id=value.slice(8); try{const payload=await window.DatzonSpotifyCatalog?.track?.(id);if(payload?.track)return spotifyCatalogTrackEntity(payload.track);}catch{}
    const local=localTrackPoolForMusicCode().find(track=>spotifyTrackIdFromTrack(track)===id); if(local)return local; return null;
  }
  const pool=localTrackPoolForMusicCode(); const api=window.DatzonMusicCode;
  const local=pool.find(track=>api?.canonicalTrackKey?.(track)===value); if(local)return local;
  if(value.startsWith('meta:')){
    try{const raw=value.slice(5).replace(/-/g,'+').replace(/_/g,'/');const padded=raw+'='.repeat((4-raw.length%4)%4);const text=new TextDecoder().decode(Uint8Array.from(atob(padded),ch=>ch.charCodeAt(0)));const [title,artist]=text.split('\\t');if(title){const result=await runUniversalSearch(`${title} ${artist||''}`);const exact=(result.tracks||[]).find(track=>normalizeMatchText(cleanTitle(track))===normalizeMatchText(title)&&(!artist||normalizeMatchText(track.artist).includes(normalizeMatchText(artist))));if(exact)return exact;}}catch{}
  }
  return null;
}

async function openMusicCodeTrack(track){const normalized=normalizeTrack(track);await playTrack(normalized,[normalized],0,{playContext:{eyebrow:'MUSIC CODE',label:'Dipindai dari Kode Lagu',type:'music-code'}});}

let musicCodeModuleLoadPromise=null;
async function ensureMusicCodeModule() {
  if(window.DatzonMusicCode) return window.DatzonMusicCode;
  if(musicCodeModuleLoadPromise) return musicCodeModuleLoadPromise;
  musicCodeModuleLoadPromise=new Promise((resolve,reject)=>{
    const done=()=>window.DatzonMusicCode?resolve(window.DatzonMusicCode):reject(new Error('Modul Music Code gagal dimuat.'));
    const existing=[...document.scripts].find(script=>/\/music-code\.js(?:\?|$)/.test(script.src||''));
    if(existing && !existing.dataset.datzonRetryLoader){
      // The normal script may still be finishing on a slow mobile connection.
      const started=Date.now();
      const poll=()=>{
        if(window.DatzonMusicCode)return resolve(window.DatzonMusicCode);
        if(Date.now()-started<1200)return setTimeout(poll,60);
        inject();
      };
      poll();
      return;
    }
    inject();
    function inject(){
      const script=document.createElement('script');
      script.src=`/music-code.js?v=1.62.9&retry=${Date.now()}`;
      script.async=true;
      script.dataset.datzonRetryLoader='1';
      script.onload=done;
      script.onerror=()=>reject(new Error('File Music Code tidak dapat dimuat.'));
      document.head.appendChild(script);
    }
  }).catch(error=>{musicCodeModuleLoadPromise=null;throw error;});
  return musicCodeModuleLoadPromise;
}

function musicCodeHandlers(){return {resolveIdentity:ensureMusicCodeTrackIdentity,resolveCanonical:resolveMusicCodeCanonical,openTrack:openMusicCodeTrack};}

async function showSpotifyCode(track) {
  try {
    const api=await ensureMusicCodeModule();
    await api.show(normalizeTrack(track),musicCodeHandlers());
  } catch (error) {
    console.warn('[DATZON Music Code loader]',error);
    notify('Music Code gagal dimuat. Coba lagi beberapa detik lagi.','error');
  }
}

function showHideTrackConfirm(track) {
  openPlayerSheet(`<div class="hide-track-sheet">
      <div class="hide-track-top"><img src="${esc(track.thumbnail)}" alt="" onerror="this.src='assets/placeholder.svg'"><button class="cancel-btn" data-hide-cancel>Batalkan</button></div>
      <div class="hide-track-copy"><h3>Sembunyikan lagu ini dari rekomendasi?</h3><p>${esc(cleanTitle(track))} tidak akan ditampilkan di playlist Beranda selama 30 hari.</p></div>
      <button class="confirm-btn" data-hide-confirm>${icon('ban')}<span>Jangan sarankan lagu ini selama 30 hari</span></button>
    </div>`, 'hide-track-menu-sheet', {kind:'compact', initialSnap:'full'});
  $('[data-hide-cancel]', modalRoot).onclick = () => closeModal();
  $('[data-hide-confirm]', modalRoot).onclick = () => {
    hideTrackSuggestion(track, 30);
    closeModal();
    if (state.route === 'home') render();
    notify('Lagu disembunyikan dari rekomendasi Beranda selama 30 hari');
  };
}

async function chooseConnectAudioDevice(sheet) {
  const status = $('[data-connect-status]', sheet);
  const button = $('[data-connect-bluetooth]', sheet);
  if (button) button.disabled = true;
  if (status) status.textContent = 'Membuka pemilih perangkat audio...';
  try {
    if (navigator.mediaDevices?.selectAudioOutput && typeof audio.setSinkId === 'function') {
      const device = await navigator.mediaDevices.selectAudioOutput();
      if (!device?.deviceId) throw new Error('Perangkat audio tidak dipilih');
      await audio.setSinkId(device.deviceId);
      const label = device.label || 'Perangkat audio pilihan';
      storage.set('outputDeviceLabel', label);
      if (status) status.textContent = `${label} aktif sebagai output DATZON Music.`;
      const labelNode = $('[data-connect-device-label]', sheet);
      if (labelNode) labelNode.textContent = label;
      notify(`Audio dialihkan ke ${label}`);
      return;
    }
    if (navigator.bluetooth?.requestDevice) {
      const device = await navigator.bluetooth.requestDevice({ acceptAllDevices: true });
      const label = device?.name || 'Perangkat Bluetooth';
      storage.set('outputDeviceLabel', label);
      if (status) status.textContent = `${label} ditemukan. Aktifkan perangkat ini sebagai output media melalui panel Bluetooth perangkatmu.`;
      const labelNode = $('[data-connect-device-label]', sheet);
      if (labelNode) labelNode.textContent = label;
      notify(`${label} ditemukan`);
      return;
    }
    throw new Error('Browser ini belum mendukung pemilih output audio. Sambungkan Bluetooth melalui pengaturan perangkat.');
  } catch (error) {
    const message = error?.name === 'NotFoundError' || error?.name === 'AbortError'
      ? 'Pemilihan perangkat dibatalkan.'
      : error?.message || 'Perangkat audio tidak dapat dipilih.';
    if (status) status.textContent = message;
    notify(message);
  } finally {
    if (button) button.disabled = false;
  }
}

function showConnectSheet() {
  const current = state.current;
  const deviceLabel = storage.get('outputDeviceLabel', 'Ponsel ini');
  const supportsDirectOutput = Boolean(navigator.mediaDevices?.selectAudioOutput && typeof audio.setSinkId === 'function');
  const supportsBluetoothScan = Boolean(navigator.bluetooth?.requestDevice);
  const initialStatus = supportsDirectOutput
    ? 'Pilih speaker, headset, atau perangkat Bluetooth yang tersedia.'
    : supportsBluetoothScan
      ? 'Browser dapat mencari perangkat Bluetooth. Pemilihan output musik tetap mengikuti pengaturan perangkat.'
      : 'Output audio mengikuti pengaturan Bluetooth atau speaker pada perangkat ini.';
  const sheet = openPlayerSheet(`<div class="connect-sheet">
      <h2>Connect</h2>
      <div class="connect-card"><div><strong data-connect-device-label>${esc(deviceLabel)}</strong><small>${supportsDirectOutput ? 'Output audio aktif' : 'Output sistem'}</small><p>${esc(cleanTitle(current || {}))} – ${esc(current?.artist || '')}</p></div><div class="connect-device">${icon('device')}</div></div>
      <div class="connect-status" data-connect-status>${esc(initialStatus)}</div>
      <div class="connect-actions"><button data-connect-group>${icon('group')}<span>Mulai Dengar Bareng</span></button><button data-connect-bluetooth>${icon('device')}<span>${supportsDirectOutput ? 'Pilih output audio' : 'Temukan perangkat Bluetooth'}</span></button></div>
    </div>`, 'track-menu-sheet connect-menu-sheet', { kind: 'menu', initialSnap: 'half' });
  $('[data-connect-group]', sheet).onclick = () => {
    closeModal(true);
    setTimeout(() => showListenTogetherFriends(current), 90);
  };
  $('[data-connect-bluetooth]', sheet).onclick = () => chooseConnectAudioDevice(sheet);
}

function playlistPrivacyPickerMarkup(selected = 'private', publicEnabled = isLoggedIn(), collaborative = false, options = {}) {
  const value = playlistVisibility(selected);
  const allowDelete = Boolean(options?.allowDelete);
  return `<fieldset class="playlist-privacy-picker"><legend>Privasi playlist</legend>
    <button type="button" data-playlist-visibility-option="private" class="${value === 'private' ? 'selected' : ''}" aria-pressed="${value === 'private'}">${icon('lock')}<span><strong>Private</strong><small>${collaborative ? 'Hanya anggota kolaborasi yang bisa melihat' : 'Hanya kamu yang bisa melihat'}</small></span>${value === 'private' ? `<span class="playlist-privacy-check">${icon('check-circle')}</span>` : ''}</button>
    <button type="button" data-playlist-visibility-option="public" class="${value === 'public' ? 'selected' : ''}" aria-pressed="${value === 'public'}" ${publicEnabled ? '' : 'disabled'}>${icon('public-users')}<span><strong>Publik</strong><small>${publicEnabled ? 'Tampil di profil dan dapat diputar pengguna lain' : 'Masuk ke akun untuk memublikasikan playlist'}</small></span>${value === 'public' ? `<span class="playlist-privacy-check">${icon('check-circle')}</span>` : ''}</button>
    ${allowDelete ? `<button type="button" class="playlist-delete-option" data-playlist-delete-option aria-pressed="false">${icon('trash')}<span><strong>Hapus Playlist</strong><small>Hapus permanen playlist dan seluruh isinya dari Firebase</small></span></button>` : ''}
  </fieldset>`;
}

function bindPlaylistPrivacyPicker(root, initialValue = 'private', onChange = null) {
  let value = playlistVisibility(initialValue);
  const buttons = $$('[data-playlist-visibility-option]', root);
  const refresh = () => buttons.forEach(button => {
    const selected = button.dataset.playlistVisibilityOption === value;
    button.classList.toggle('selected', selected);
    button.setAttribute('aria-pressed', selected ? 'true' : 'false');
    const trailing = button.querySelector(':scope > .playlist-privacy-check');
    if (trailing) trailing.remove();
    if (selected) button.insertAdjacentHTML('beforeend', `<span class="playlist-privacy-check">${icon('check-circle')}</span>`);
  });
  buttons.forEach(button => button.onclick = () => {
    if (button.disabled) return;
    value = playlistVisibility(button.dataset.playlistVisibilityOption);
    refresh();
    onChange?.(value);
  });
  refresh();
  return () => value;
}

function showCreatePlaylistSheet(initialTrack = null) {
  const suggested = `Playlist ${activePlaylists().length + 1}`;
  const sheet = openPlayerSheet(`<div class="playlist-create-sheet-content">
    <header><div><small>PLAYLIST BARU</small><h2>Beri nama playlist-mu</h2></div><button data-cancel-playlist aria-label="Tutup">${icon('close')}</button></header>
    <label class="playlist-name-field" for="newPlaylistName"><span>Nama playlist</span><input id="newPlaylistName" maxlength="80" value="${esc(suggested)}" aria-label="Nama playlist" autocomplete="off" inputmode="text"></label>
    ${playlistPrivacyPickerMarkup('private', isLoggedIn())}
    <div class="playlist-create-actions"><button data-cancel-playlist-secondary>Batal</button><button class="primary" data-confirm-playlist>Buat</button></div>
  </div>`, 'playlist-create-player-sheet', { kind:'adaptive', initialSnap:'full' });
  const input = $('#newPlaylistName', sheet);
  const getVisibility = bindPlaylistPrivacyPicker(sheet, 'private');
  // Tidak melakukan focus otomatis supaya keyboard tidak langsung muncul.
  const closeCreator = () => closeModal(true);
  $('[data-cancel-playlist]', sheet).onclick = closeCreator;
  $('[data-cancel-playlist-secondary]', sheet).onclick = closeCreator;
  $('[data-confirm-playlist]', sheet).onclick = () => {
    const playlist = createUserPlaylist(input?.value || suggested, initialTrack, { visibility:getVisibility() });
    closeModal(true);
    if (state.route === 'library') renderLibrary();
    notify(`${playlist.name} berhasil dibuat sebagai playlist ${playlistVisibilityLabel(playlist.visibility).toLowerCase()}`);
  };
  input?.addEventListener('keydown', event => {
    if (event.key === 'Enter') $('[data-confirm-playlist]', sheet)?.click();
  });
}

function showSaveToPlaylistSheet(track = state.current) {
  if (!track) return;
  const normalized = normalizeTrack(track);
  const playlists = activePlaylists();
  const playlistRows = playlists.map(playlist => {
    const saved = playlistContainsTrack(playlist, normalized);
    return `<button class="save-playlist-row" data-save-playlist="${esc(playlist.id)}">${playlistArtworkMarkup(playlist, 'save-playlist-art')}<span><strong>${esc(playlist.name)}</strong><small>${playlist.tracks.length} lagu • ${esc(playlistVisibilityLabel(playlist.visibility))}</small></span><i class="${saved ? 'saved' : ''}">${icon(saved ? 'check-circle' : 'plus-circle')}</i></button>`;
  }).join('');
  const liked = isFavorite(normalized);
  const sheet = openPlayerSheet(`<div class="save-playlist-sheet-content">
    <header><h2>Simpan di</h2><button data-save-new-playlist>Playlist baru</button></header>
    <div class="save-playlist-list">
      <button class="save-playlist-row" data-save-liked><span class="save-liked-cover">${icon('heart','fill')}</span><span><strong>Lagu yang Disukai</strong><small>${state.favorites.length} lagu</small></span><i class="${liked ? 'saved' : ''}">${icon(liked ? 'check-circle' : 'plus-circle')}</i></button>
      ${playlistRows}
      <button class="save-playlist-row create-row" data-save-create-row><span class="save-new-cover">${icon('plus-circle')}</span><span><strong>Playlist baru</strong><small>${isLoggedIn() ? 'Simpan ke database Firebase' : 'Simpan di perangkat ini'}</small></span><i>${icon('chevron')}</i></button>
    </div>
  </div>`, 'save-playlist-player-sheet', { kind:'menu', initialSnap:'full' });
  const openCreator = () => { closeModal(true); setTimeout(() => showCreatePlaylistSheet(normalized), 90); };
  $('[data-save-new-playlist]', sheet).onclick = openCreator;
  $('[data-save-create-row]', sheet).onclick = openCreator;
  $('[data-save-liked]', sheet).onclick = () => {
    if (liked) { notify('Lagu ini sudah ada di Lagu yang Disukai'); return; }
    toggleFavorite(normalized);
    closeModal(true);
  };
  $$('[data-save-playlist]', sheet).forEach(button => button.onclick = () => {
    const playlist = activePlaylists().find(item => item.id === button.dataset.savePlaylist);
    if (!playlist) return;
    if (playlistContainsTrack(playlist, normalized)) { notify(`Lagu sudah ada di ${playlist.name}`); return; }
    addTrackToPlaylist(playlist.id, normalized);
    closeModal(true);
    if (state.route === 'library') renderLibrary();
    notify(`Ditambahkan ke ${playlist.name}`);
  });
}

function updatePlaylistDetailPlayback() {
  const sheet = $('.playlist-detail-player-sheet', modalRoot);
  if (!sheet) return;
  const playlistId = sheet.dataset.playlistDetailId || '';
  const playlist = activePlaylists().find(item => item.id === playlistId);
  const containsCurrent = Boolean(state.current && playlist?.tracks?.some(track => sameTrackIdentity(track, state.current)));
  const headerButton = $('[data-playlist-primary-action]', sheet);
  if (headerButton && sheet.dataset.collabTab !== 'users') {
    const shouldPause = containsCurrent && state.isPlaying;
    headerButton.innerHTML = icon(shouldPause ? 'pause' : 'play', shouldPause ? '' : 'fill');
    headerButton.setAttribute('aria-label', shouldPause ? 'Jeda playlist' : containsCurrent ? 'Lanjutkan playlist' : 'Putar playlist');
    headerButton.classList.toggle('is-playing', shouldPause);
  }
  $$('[data-playlist-track]', sheet).forEach(button => {
    const trackId = button.dataset.trackIdentity || '';
    const currentId = state.current ? (trackFirebaseId(state.current) || trackKey(state.current)) : '';
    const active = Boolean(trackId && currentId && trackId === currentId);
    const row = button.closest('.playlist-detail-row') || button;
    row.classList.toggle('is-current', active);
    row.classList.toggle('is-playing', active && state.isPlaying);
    button.setAttribute('aria-current', active ? 'true' : 'false');
  });
}

let activePlaylistTrackMenu = null;
let activePlaylistTrackHandle = null;
let activePlaylistTrackOutsideHandler = null;

function closePlaylistTrackMenu() {
  if (activePlaylistTrackOutsideHandler) document.removeEventListener('pointerdown', activePlaylistTrackOutsideHandler, true);
  activePlaylistTrackHandle?.classList.remove('is-open');
  activePlaylistTrackMenu?.remove();
  activePlaylistTrackMenu = null;
  activePlaylistTrackHandle = null;
  activePlaylistTrackOutsideHandler = null;
}

function reopenPlaylistDetail(playlistId) {
  const tab=$('.playlist-detail-player-sheet',modalRoot)?.dataset?.collabTab || 'tracks';
  closePlaylistTrackMenu();
  closeCollaboratorUserMenu?.();
  closeModal(true);
  window.setTimeout(() => showPlaylistDetail(playlistId,{tab}), 90);
}

function openPlaylistTrackMenu(playlistId, trackIndex, handle) {
  if (activePlaylistTrackMenu && activePlaylistTrackHandle === handle) {
    closePlaylistTrackMenu();
    return;
  }
  closePlaylistTrackMenu();
  const playlist = activePlaylists().find(item => item.id === playlistId);
  if (!playlist) return;
  const trackCount = playlist.tracks?.length || 0;
  const menu = document.createElement('div');
  menu.className = 'queue-move-menu playlist-track-action-menu';
  menu.setAttribute('role', 'menu');
  menu.innerHTML = `<button type="button" data-playlist-step="-1" ${trackIndex <= 0 ? 'disabled' : ''}>${icon('arrow-up')}<span>Naik</span></button><button type="button" data-playlist-step="1" ${trackIndex >= trackCount - 1 ? 'disabled' : ''}>${icon('arrow-down')}<span>Turun</span></button><button type="button" class="danger" data-playlist-remove>${icon('trash')}<span>Hapus</span></button>`;
  document.body.appendChild(menu);
  activePlaylistTrackMenu = menu;
  activePlaylistTrackHandle = handle;
  handle.classList.add('is-open');
  requestAnimationFrame(() => positionQueueMoveMenu(menu, handle));

  menu.querySelectorAll('[data-playlist-step]').forEach(button => {
    button.onclick = event => {
      event.preventDefault();
      event.stopPropagation();
      if (button.disabled) return;
      const moved = movePlaylistTrackOneStep(playlistId, trackIndex, Number(button.dataset.playlistStep));
      if (moved) {
        notify(Number(button.dataset.playlistStep) < 0 ? 'Lagu dinaikkan satu posisi' : 'Lagu diturunkan satu posisi');
        reopenPlaylistDetail(playlistId);
      }
    };
  });
  menu.querySelector('[data-playlist-remove]')?.addEventListener('click', event => {
    event.preventDefault();
    event.stopPropagation();
    const removed = removeTrackFromPlaylist(playlistId, trackIndex);
    if (removed) {
      notify(`${cleanTitle(removed)} dihapus dari playlist`);
      reopenPlaylistDetail(playlistId);
    }
  });

  activePlaylistTrackOutsideHandler = event => {
    if (menu.contains(event.target) || handle.contains(event.target)) return;
    closePlaylistTrackMenu();
  };
  window.setTimeout(() => document.addEventListener('pointerdown', activePlaylistTrackOutsideHandler, true), 0);
}


function collaborativeParticipantCount(playlist={}) {
  return (playlist.participantProfiles || []).filter(item=>item?.uid).length;
}

async function removeCollaborativePlaylistForUser(targetUids=[], playlist={}) {
  if(!isLoggedIn() || !playlist?.id) return;
  try {
    await firebaseService()?.sendCollaborativePlaylistRemoval?.(targetUids, {
      id:playlist.id,
      name:playlist.name,
      updatedAt:Number(playlist.updatedAt || Date.now())
    });
  } catch (error) { console.warn('[DATZON collab remove]', error); }
}

function currentCollaborativeProfile() {
  const currentUid=String(state.auth.user?.uid || '');
  const profile=state.auth.profile || {};
  return {
    uid:currentUid,
    fullName:String(profile.fullName || profile.username || state.username || 'Kamu'),
    username:String(profile.username || ''),
    photoURL:String(profile.photoURL || state.auth.user?.photoURL || '')
  };
}

function canManageCollaborativePlaylist(playlist={}) {
  if(!playlist?.collaborative || !isLoggedIn()) return false;
  return String(playlist.collabOwnerUid || playlist.ownerUid || '') === String(state.auth.user?.uid || '');
}

async function commitCollaborativeParticipants(playlist, participantProfiles=[]) {
  if(!playlist?.collaborative || !isLoggedIn()) return playlist;
  const currentUid=String(state.auth.user?.uid || '');
  const previous=new Set((playlist.participantUids || []).filter(Boolean));
  const deduped=new Map();
  [currentCollaborativeProfile(), ...participantProfiles].forEach(profile=>{
    const uid=String(profile?.uid || '').trim();
    if(!uid || deduped.has(uid)) return;
    deduped.set(uid,{uid,fullName:String(profile.fullName || profile.username || 'Pengguna'),username:String(profile.username || ''),photoURL:String(profile.photoURL || '')});
  });
  const profiles=[...deduped.values()];
  const nextUids=profiles.map(item=>item.uid);
  const removed=[...previous].filter(uid=>uid && !nextUids.includes(uid));
  const updated=normalizePlaylist({...playlist,participantUids:nextUids,participantProfiles:profiles,updatedAt:Date.now()});
  setActivePlaylists(activePlaylists().map(item=>item.id===playlist.id?updated:item));
  if(removed.length) await removeCollaborativePlaylistForUser(removed,updated);
  await broadcastCollaborativePlaylistSnapshot(updated);
  if(state.route==='library') renderLibrary();
  return updated;
}

async function showAddCollaboratorSheet(playlistId) {
  const playlist=activePlaylists().find(item=>item.id===playlistId);
  if(!playlist?.collaborative) return;
  if(!isLoggedIn()) return notify('Masuk ke akun untuk menambahkan kolaborator.');
  if(!canManageCollaborativePlaylist(playlist)) return notify('Hanya pembuat playlist yang dapat menambahkan kolaborator.');
  await loadSocialGraph(true);
  const used=new Set((playlist.participantUids || []).filter(Boolean));
  const friends=(state.social.friends || []).map(collaborativeFriendProfile).filter(item=>item.uid && !used.has(item.uid));
  const sheet=openPlayerSheet(`<div class="collab-add-sheet"><header><div><small>PLAYLIST KOLABORATIF</small><h2>Tambahkan teman</h2><p>Pilih satu teman. Playlist akan langsung muncul di Koleksi mereka.</p></div><button data-close-collab-add aria-label="Tutup">${icon('close')}</button></header><div class="collab-friend-list">${friends.length?friends.map((friend,index)=>`<button type="button" class="collab-friend-row" data-collab-add-friend="${index}"><img src="${esc(collaboratorAvatar(friend))}" alt="" onerror="this.src='${esc(defaultProfileAvatar(friend.fullName || friend.username || 'D'))}'"><span><strong>${esc(friend.fullName)}</strong><small>${friend.username?`@${esc(friend.username)}`:'Teman DATZON'}</small></span><i>${icon('plus-circle')}</i></button>`).join(''):'<div class="collab-edit-empty">Semua teman yang tersedia sudah menjadi kolaborator.</div>'}</div></div>`, 'collab-add-player-sheet', {kind:'queue',initialSnap:'half'});
  $('[data-close-collab-add]',sheet).onclick=()=>{closeModal(true);window.setTimeout(()=>showPlaylistDetail(playlistId,{tab:'users'}),90);};
  $$('[data-collab-add-friend]',sheet).forEach(button=>button.onclick=async()=>{
    const friend=friends[Number(button.dataset.collabAddFriend)];
    if(!friend)return;
    button.disabled=true;
    try{
      const latest=activePlaylists().find(item=>item.id===playlistId) || playlist;
      const updated=await commitCollaborativeParticipants(latest,[...(latest.participantProfiles || []),friend]);
      closeModal(true);
      notify(`${friend.fullName || friend.username} ditambahkan sebagai kolaborator.`);
      window.setTimeout(()=>showPlaylistDetail(updated.id,{tab:'users'}),90);
    }catch(error){button.disabled=false;notify(error?.message || 'Gagal menambahkan kolaborator.');}
  });
}

let activeCollaboratorUserMenu=null;
let activeCollaboratorUserHandle=null;
let activeCollaboratorOutsideHandler=null;
function closeCollaboratorUserMenu(){
  if(activeCollaboratorOutsideHandler) document.removeEventListener('pointerdown',activeCollaboratorOutsideHandler,true);
  activeCollaboratorUserHandle?.classList.remove('is-open');
  activeCollaboratorUserMenu?.remove();
  activeCollaboratorUserMenu=null;activeCollaboratorUserHandle=null;activeCollaboratorOutsideHandler=null;
}
function openCollaboratorUserMenu(playlistId, uid, handle){
  closeCollaboratorUserMenu();
  const playlist=activePlaylists().find(item=>item.id===playlistId);
  if(!playlist || !canManageCollaborativePlaylist(playlist) || uid===String(state.auth.user?.uid||''))return;
  const profile=(playlist.participantProfiles || []).find(item=>item.uid===uid);
  if(!profile)return;
  const menu=document.createElement('div');
  menu.className='queue-move-menu playlist-track-action-menu collab-user-action-menu';
  menu.setAttribute('role','menu');
  menu.innerHTML=`<button type="button" class="danger" data-collab-user-kick>${icon('trash')}<span>Kick</span></button>`;
  document.body.appendChild(menu);activeCollaboratorUserMenu=menu;activeCollaboratorUserHandle=handle;handle.classList.add('is-open');
  requestAnimationFrame(()=>positionQueueMoveMenu(menu,handle));
  menu.querySelector('[data-collab-user-kick]').onclick=async event=>{
    event.preventDefault();event.stopPropagation();
    const latest=activePlaylists().find(item=>item.id===playlistId) || playlist;
    const remaining=(latest.participantProfiles || []).filter(item=>item.uid!==uid);
    try{
      const updated=await commitCollaborativeParticipants(latest,remaining);
      closeCollaboratorUserMenu();closeModal(true);
      notify(`${profile.fullName || profile.username || 'Pengguna'} dikeluarkan dari playlist.`);
      window.setTimeout(()=>showPlaylistDetail(updated.id,{tab:'users'}),90);
    }catch(error){notify(error?.message || 'Gagal mengeluarkan kolaborator.');}
  };
  activeCollaboratorOutsideHandler=event=>{if(menu.contains(event.target)||handle.contains(event.target))return;closeCollaboratorUserMenu();};
  window.setTimeout(()=>document.addEventListener('pointerdown',activeCollaboratorOutsideHandler,true),0);
}

function collaborativeUsersMarkup(playlist={}){
  const currentUid=String(state.auth.user?.uid || '');
  const ownerUid=String(playlist.collabOwnerUid || playlist.ownerUid || '');
  const canManage=canManageCollaborativePlaylist(playlist);
  const profiles=(playlist.participantProfiles || []).filter(item=>item?.uid);
  return profiles.length?profiles.map(profile=>{
    const isMe=profile.uid===currentUid;
    const isOwner=profile.uid===ownerUid;
    return `<div class="collab-user-row ${isMe?'is-me':''}"><div class="collab-user-avatar"><img src="${esc(collaboratorAvatar(profile))}" alt="" onerror="this.src='${esc(defaultProfileAvatar(profile.fullName || profile.username || 'D'))}'"></div><span><strong>${esc(profile.fullName || profile.username || 'Pengguna')}${isMe?'<em>Kamu</em>':''}</strong><small>${profile.username?`@${esc(profile.username)}`:'Pengguna DATZON'}${isOwner?' • Pembuat':''}</small></span>${isMe?`<i class="collab-me-indicator" aria-label="Akun kamu">${icon('check-circle')}</i>`:canManage?`<button class="playlist-detail-more collab-user-more" data-collab-user-menu="${esc(profile.uid)}" aria-label="Pilihan ${esc(profile.fullName || profile.username || 'kolaborator')}">${icon('more')}</button>`:''}</div>`;
  }).join(''):'<div class="empty"><h3>Belum ada kolaborator</h3></div>';
}

function showPlaylistDeleteConfirmation(playlistId) {
  const playlist = activePlaylists().find(item => item.id === playlistId);
  if (!playlist || !playlistCanDelete(playlist)) return notify('Hanya pembuat playlist yang dapat menghapus playlist ini.');
  closeModal(true);
  window.setTimeout(() => {
    const sheet = openPlayerSheet(`<div class="playlist-delete-confirm-sheet"><header><span>${icon('trash')}</span><div><small>HAPUS PLAYLIST PERMANEN</small><h2>Hapus “${esc(playlist.name)}”?</h2></div></header><p>Playlist akan dihapus dari Firebase, Koleksi Kamu, profil, dan seluruh anggota kolaborasi. Lagu, cover, serta isi playlist tidak dapat dipulihkan.</p><div class="playlist-delete-confirm-actions"><button data-cancel-playlist-delete>Batal</button><button class="danger" data-confirm-playlist-delete>Konfirmasi penghapusan</button></div></div>`, 'playlist-delete-confirm-player-sheet', {kind:'queue', initialSnap:'half'});
    $('[data-cancel-playlist-delete]', sheet).onclick = () => {
      closeModal(true);
      window.setTimeout(() => showPlaylistVisibilitySheet(playlist.id), 80);
    };
    $('[data-confirm-playlist-delete]', sheet).onclick = async event => {
      const button = event.currentTarget;
      button.disabled = true;
      button.textContent = 'Menghapus playlist…';
      try {
        const removed = await deleteOwnedPlaylist(playlist.id);
        closeModal(true);
        if (state.route === 'library') renderLibrary();
        else if (state.route === 'public-profile') renderPublicProfilePage();
        else render();
        notify(`Playlist “${removed.name}” sudah dihapus permanen.`);
      } catch (error) {
        button.disabled = false;
        button.textContent = 'Konfirmasi penghapusan';
        notify(firebaseService()?.firebaseErrorMessage?.(error) || error?.message || 'Playlist gagal dihapus.');
      }
    };
  }, 70);
}

function showPlaylistVisibilitySheet(playlistId) {
  const playlist = activePlaylists().find(item => item.id === playlistId);
  if (!playlist || !playlistCanChangeVisibility(playlist)) return notify('Hanya pembuat playlist yang dapat mengubah privasi.');
  closeModal(true);
  window.setTimeout(() => {
    const sheet = openPlayerSheet(`<div class="playlist-visibility-sheet"><header><div><small>PENGATURAN PLAYLIST</small><h2>Privasi “${esc(playlist.name)}”</h2><p>Pilih siapa yang dapat menemukan dan membuka playlist ini.</p></div><button data-visibility-close aria-label="Tutup">${icon('close')}</button></header>${playlistPrivacyPickerMarkup(playlist.visibility, true, playlist.collaborative, {allowDelete:true})}<button class="primary-btn" data-save-playlist-visibility>Simpan privasi</button></div>`, 'playlist-visibility-player-sheet', {kind:'menu', initialSnap:'half'});
    let deleteMode = false;
    const saveButton = $('[data-save-playlist-visibility]', sheet);
    const deleteButton = $('[data-playlist-delete-option]', sheet);
    const visibilityButtons = $$('[data-playlist-visibility-option]', sheet);
    const updateDeleteMode = enabled => {
      deleteMode = Boolean(enabled);
      deleteButton?.classList.toggle('selected-delete', deleteMode);
      deleteButton?.setAttribute('aria-pressed', deleteMode ? 'true' : 'false');
      deleteButton?.querySelector(':scope > .playlist-privacy-check')?.remove();
      if (deleteMode) {
        visibilityButtons.forEach(button => {
          button.classList.remove('selected');
          button.setAttribute('aria-pressed', 'false');
          button.querySelector(':scope > .playlist-privacy-check')?.remove();
        });
        deleteButton?.insertAdjacentHTML('beforeend', `<span class="playlist-privacy-check playlist-delete-check">${icon('check-circle')}</span>`);
      }
      if (saveButton) {
        saveButton.classList.toggle('is-delete-mode', deleteMode);
        saveButton.textContent = deleteMode ? 'Konfirmasi hapus playlist' : 'Simpan privasi';
      }
    };
    const getVisibility = bindPlaylistPrivacyPicker(sheet, playlist.visibility, () => updateDeleteMode(false));
    deleteButton?.addEventListener('click', () => updateDeleteMode(true));
    $('[data-visibility-close]', sheet).onclick = () => closeModal();
    saveButton.onclick = () => {
      if (deleteMode) {
        showPlaylistDeleteConfirmation(playlist.id);
        return;
      }
      const updated = updatePlaylistVisibility(playlist.id, getVisibility());
      if (!updated) return notify('Privasi playlist gagal diperbarui.');
      closeModal(true);
      notify(`Playlist “${updated.name}” sekarang ${playlistVisibilityLabel(updated.visibility).toLowerCase()}.`);
      if (state.route === 'library') renderLibrary();
      window.setTimeout(() => showPlaylistDetail(updated.id), 90);
    };
  }, 70);
}

function showPlaylistDetail(playlistId, options={}) {
  const playlist = activePlaylists().find(item => item.id === playlistId);
  if (!playlist) return notify('Playlist tidak ditemukan');
  closeCollaboratorUserMenu();
  const tracks = playlist.tracks.map(normalizeTrack);
  const containsCurrent = Boolean(state.current && tracks.some(track => sameTrackIdentity(track, state.current)));
  const tab = playlist.collaborative && options?.tab === 'users' ? 'users' : 'tracks';
  const trackRows = tracks.length ? tracks.map((track,index)=>{
    const identity = trackFirebaseId(track) || trackKey(track);
    const active = state.current ? sameTrackIdentity(track, state.current) : false;
    return `<div class="playlist-detail-row ${active ? 'is-current' : ''} ${active && state.isPlaying ? 'is-playing' : ''}"><button class="playlist-detail-main" data-playlist-track="${index}" data-track-identity="${esc(identity)}" aria-current="${active ? 'true' : 'false'}">${trackArtworkWithPlayingMarkup(track.thumbnail,'playlist-detail-track-art')}<span><strong>${esc(cleanTitle(track))}</strong><small>${esc(track.artist)}</small></span><em>${esc(track.duration || '')}</em></button><button class="playlist-detail-more" data-playlist-menu="${index}" aria-label="Pilihan ${esc(cleanTitle(track))}">${icon('more')}</button></div>`;
  }).join('') : `<div class="empty"><h3>Playlist masih kosong</h3><p>Tambahkan lagu dari menu pilihan lainnya.</p></div>`;
  const primaryIcon = tab === 'users' ? icon('plus-circle') : icon(containsCurrent && state.isPlaying ? 'pause' : 'play', containsCurrent && state.isPlaying ? '' : 'fill');
  const sheet = openPlayerSheet(`<div class="playlist-detail-sheet ${playlist.collaborative?'is-collaborative':''}">
    <header>${playlistArtworkMarkup(playlist, 'playlist-detail-art')}<div><small>${playlist.collaborative ? 'PLAYLIST KOLABORATIF' : isLoggedIn() ? 'PLAYLIST FIREBASE' : 'PLAYLIST LOKAL'}</small><h2>${esc(playlist.name)}</h2><p>${tracks.length} lagu${playlist.collaborative ? ` • ${collaborativeParticipantCount(playlist)} user` : ''}</p><button class="playlist-visibility-chip is-${esc(playlist.visibility)}" data-playlist-visibility-chip ${playlistCanChangeVisibility(playlist) ? '' : 'disabled'}>${icon(playlist.visibility === 'public' ? 'public-users' : 'lock')}<span>${esc(playlistVisibilityLabel(playlist.visibility))}</span></button></div>${playlist.collaborative || tracks.length ? `<button data-playlist-primary-action aria-label="${tab==='users'?'Tambah kolaborator':containsCurrent&&state.isPlaying?'Jeda playlist':containsCurrent?'Lanjutkan playlist':'Putar playlist'}">${primaryIcon}</button>` : ''}</header>
    ${playlist.collaborative ? `<div class="playlist-collab-tabs" role="tablist"><button data-collab-tab="tracks" class="${tab==='tracks'?'active':''}" role="tab" aria-selected="${tab==='tracks'}">${icon('music')}<span>Track</span></button><button data-collab-tab="users" class="${tab==='users'?'active':''}" role="tab" aria-selected="${tab==='users'}">${icon('group')}<span>Users</span></button></div><div class="playlist-collab-section-label" data-collab-section-label>${tab==='users'?`${icon('group')}<span>Kolaborator</span>`:`${icon('music')}<span>Track</span>`}</div>` : ''}
    <div class="playlist-detail-list" data-collab-panel="tracks" ${tab==='users'?'hidden':''}>${trackRows}</div>
    ${playlist.collaborative ? `<div class="playlist-collab-users" data-collab-panel="users" ${tab==='tracks'?'hidden':''}>${collaborativeUsersMarkup(playlist)}</div>` : ''}
  </div>`, 'playlist-detail-player-sheet', { kind:'menu', initialSnap:'full' });
  sheet.dataset.playlistDetailId = playlist.id;
  sheet.dataset.collabTab = tab;
  const context = playlistPlaybackContext(playlist);
  const primary = $('[data-playlist-primary-action]',sheet);
  const setTab = nextTab => {
    if(!playlist.collaborative)return;
    sheet.dataset.collabTab=nextTab;
    $$('[data-collab-tab]',sheet).forEach(button=>{const active=button.dataset.collabTab===nextTab;button.classList.toggle('active',active);button.setAttribute('aria-selected',active?'true':'false');});
    $$('[data-collab-panel]',sheet).forEach(panel=>panel.hidden=panel.dataset.collabPanel!==nextTab);
    const label=$('[data-collab-section-label]',sheet);
    if(label)label.innerHTML=nextTab==='users'?`${icon('group')}<span>Kolaborator</span>`:`${icon('music')}<span>Track</span>`;
    if(primary){
      if(nextTab==='users'){primary.innerHTML=icon('plus-circle');primary.setAttribute('aria-label','Tambah kolaborator');primary.classList.remove('is-playing');}
      else updatePlaylistDetailPlayback();
    }
  };
  $$('[data-collab-tab]',sheet).forEach(button=>button.onclick=()=>setTab(button.dataset.collabTab));
  if(primary) primary.onclick=async()=>{
    if(playlist.collaborative && sheet.dataset.collabTab==='users'){
      closeModal(true);
      window.setTimeout(()=>showAddCollaboratorSheet(playlist.id),80);
      return;
    }
    if(!tracks.length)return;
    if (state.current && tracks.some(track => sameTrackIdentity(track, state.current))) {
      await togglePlay();updatePlaylistDetailPlayback();return;
    }
    closeModal(true);playTrack(tracks[0], tracks, 0, { playContext: context });
  };
  $$('[data-playlist-track]', sheet).forEach(button => button.onclick = async () => {
    closePlaylistTrackMenu();
    const index = Number(button.dataset.playlistTrack);
    const selected = tracks[index];
    if (state.current && sameTrackIdentity(selected, state.current)) {await togglePlay();updatePlaylistDetailPlayback();return;}
    closeModal(true);playTrack(selected, tracks, index, { playContext: context });
  });
  $$('[data-playlist-menu]', sheet).forEach(button => button.onclick = event => {event.preventDefault();event.stopPropagation();openPlaylistTrackMenu(playlist.id, Number(button.dataset.playlistMenu), button);});
  $$('[data-collab-user-menu]',sheet).forEach(button=>button.onclick=event=>{event.preventDefault();event.stopPropagation();openCollaboratorUserMenu(playlist.id,button.dataset.collabUserMenu,button);});
  $('[data-playlist-visibility-chip]', sheet)?.addEventListener('click', () => showPlaylistVisibilitySheet(playlist.id));
  updatePlaylistDetailPlayback();
  const playlistSheetObserver = new MutationObserver(() => {
    if (!modalRoot.querySelector('.playlist-detail-player-sheet')) {closePlaylistTrackMenu();closeCollaboratorUserMenu();playlistSheetObserver.disconnect();}
  });
  playlistSheetObserver.observe(modalRoot, { childList:true });
}

function showTrackMenu(track, inPlayer = false) {
  const items = [
    ['share', 'Bagikan', 'share'],
    ['code', 'Tampilkan Kode Lagu', 'wavecode'],
    ['lyrics', 'Lirik • Aktif', 'device'],
    ['download', 'Download MP3', 'download'],
    ['favorite', isFavorite(track) ? 'Hapus dari Lagu yang Disukai' : 'Tambahkan ke Lagu yang Disukai', 'heart'],
    ['playlist', 'Tambahkan ke playlist', 'plus-circle'],
    ['addqueue', 'Tambahkan ke Antrean', 'list-plus'],
    ['queue', 'Buka Antrean', 'queue'],
    ['album', 'Buka album', 'album'],
    ['artist', 'Buka artis', 'artist'],
    ['group', 'Mulai Dengar Bareng', 'group'],
    ['exclude', 'Kecualikan lagu dari taste profile-mu', 'ban'],
    ['timer', 'Pengatur waktu tidur', 'timer'],
    ['credits', 'Lihat kredit lagu', 'credit']
  ];
  openPlayerSheet(`<div class="track-sheet-head"><img src="${esc(track.thumbnail)}" alt="" onerror="this.src='assets/placeholder.svg'"><div><strong>${esc(cleanTitle(track))}</strong><span>${esc(track.artist)}</span></div></div>
    <div class="track-sheet-divider"></div>
    <div class="track-menu-list">${items.map(([key, label, iconName]) => `<button data-track-action="${key}" aria-label="${esc(label)}"><span class="track-menu-icon ${key === 'favorite' ? 'favorite-tile' : ''}">${icon(iconName, key === 'favorite' && isFavorite(track) ? 'fill' : '')}</span><span>${esc(label)}</span>${key === 'group' ? '<small class="datzon-premium">DATZON</small>' : ''}</button>`).join('')}</div>`, 'track-menu-sheet', { kind: 'menu', initialSnap: 'half' });
  $$('[data-track-action]', modalRoot).forEach(button => button.onclick = async () => {
    const action = button.dataset.trackAction;
    if (action === 'share') { closeModal(); shareTrack(track); }
    else if (action === 'code') { closeModal(true); window.setTimeout(() => showSpotifyCode(track), 80); }
    else if (action === 'lyrics') showLyrics();
    else if (action === 'favorite') { toggleFavorite(track); closeModal(); }
    else if (action === 'playlist') { closeModal(true); setTimeout(() => showSaveToPlaylistSheet(track), 90); }
    else if (action === 'addqueue') { addCurrentToQueue(track); closeModal(); }
    else if (action === 'queue') { closeModal(); showQueue(); }
    else if (action === 'album') { const albumId=String(track.spotifyAlbumId||track.spotifyMetadata?.albumId||''); if(/^[A-Za-z0-9]{22}$/.test(albumId)){closeModal(true);openSpotifyCollection('album',albumId);} else { state.searchQuery=track.album||cleanTitle(track);closeModal();navigate('search');setTimeout(()=>$('#searchForm',view)?.requestSubmit(),0); } }
    else if (action === 'artist') { closeModal(); openArtistSearch(track.artist); }
    else if (action === 'group') { closeModal(true); setTimeout(() => showListenTogetherFriends(track), 90); }
    else if (action === 'exclude') { closeModal(true); showHideTrackConfirm(track); }
    else if (action === 'timer') { closeModal(); showTimer(); }
    else if (action === 'credits') { closeModal(); showTrackCredits(track); }
    else if (action === 'download') { closeModal(); downloadTrack(track); }
  });
}

function cleanDownloadPart(value, fallback = '') {
  return String(value || fallback)
    .replace(/^\s*SpotiDown(?:\.App)?\s*-\s*/i, '')
    .replace(/[<>:"/\\|?*\u0000-\u001F]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

function downloadFileName(track) {
  const title = cleanDownloadPart(cleanTitle(track), 'DATZON Music');
  const artist = cleanDownloadPart(track?.artist, 'Artis tidak diketahui');
  return `${title} - ${artist}.mp3`;
}

function triggerBlobDownload(blob, fileName) {
  const objectUrl = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = objectUrl;
  anchor.download = fileName;
  anchor.rel = 'noopener';
  anchor.style.display = 'none';
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(objectUrl), 60000);
}

function triggerHiddenDownload(url, fileName) {
  const frameName = `datzon_download_${Date.now()}_${Math.random().toString(36).slice(2)}`;
  const frame = document.createElement('iframe');
  frame.name = frameName;
  frame.hidden = true;
  frame.setAttribute('aria-hidden', 'true');
  document.body.appendChild(frame);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.target = frameName;
  anchor.download = fileName;
  anchor.rel = 'noopener';
  anchor.style.display = 'none';
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => frame.remove(), 120000);
}

async function downloadTrack(track){
  const requested = normalizeTrack(track);
  const isCurrent = state.current && trackKey(requested) === trackKey(state.current);
  const currentReadyUrl = isCurrent ? (state.current?.downloadUrl || state.current?.audioUrl || '') : '';
  if (isCurrent && (state.resolving || !state.audioReady || !currentReadyUrl)) {
    notify('Harap tunggu sebentar, unduhan lagu full masih diproses.');
    return;
  }
  if (isCurrent && !cachedFullAudio(currentReadyUrl) && !state.audioFullyBuffered) {
    notify(`Harap tunggu sebentar, unduhan lagu full masih diproses${state.audioBufferingProgress ? ` (${state.audioBufferingProgress}%)` : ''}.`);
    return;
  }
  notify('Menyiapkan download di latar belakang...');
  try{
    const prepared = isCurrent ? normalizeTrack(state.current) : await resolveTrackMetadataWithPrimary(requested);
    const url = await resolveDownloadUrl(prepared);
    const fileName = downloadFileName(prepared);
    const buffered = cachedFullAudio(url);
    if (buffered?.blob?.size) {
      triggerBlobDownload(buffered.blob, fileName);
    } else try {
      const response = await fetch(url, { method: 'GET', mode: 'cors', credentials: 'omit', redirect: 'follow', cache: 'no-store' });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const sourceBlob = await response.blob();
      if (!sourceBlob.size) throw new Error('Berkas audio kosong');
      const blob = sourceBlob.type && /audio|octet-stream/i.test(sourceBlob.type)
        ? sourceBlob
        : new Blob([sourceBlob], { type: 'audio/mpeg' });
      triggerBlobDownload(blob, fileName);
    } catch (corsError) {
      // Fallback tetap bekerja di iframe tersembunyi sehingga halaman DATZON tidak berpindah atau membuka tab baru.
      triggerHiddenDownload(url, fileName);
    }
    const resolvedAt = Date.now();
    const downloadEntry = normalizeTrack({ ...prepared, audioUrl: url, downloadUrl: url, audioResolvedAt: resolvedAt, downloadedAt: resolvedAt, fileName });
    downloadEntry.downloadedAt = resolvedAt;
    downloadEntry.fileName = fileName;
    updateResolvedTrackReferences(downloadEntry);
    state.downloads = [downloadEntry, ...state.downloads.filter(item => trackKey(item) !== trackKey(downloadEntry))].slice(0, 150);
    persist();
    if (state.settings.notifyDownloads !== false) notify(`Download ${fileName} sudah dikirim ke browser.`);
  }
  catch(error){ if (state.settings.notifyFailures !== false) notify(error?.message || 'Download penuh dari provider aktif sedang tidak tersedia'); }
}

function currentOriginUrl(path = '/') {
  const cleanPath = String(path || '/').startsWith('/') ? String(path || '/') : `/${path}`;
  return new URL(cleanPath, location.origin).href;
}

async function shareTrack(track){
  const normalized = normalizeTrack(track);
  const trackId = spotifyTrackIdFromTrack(normalized);
  const url = trackId ? currentOriginUrl(`/track/${trackId}`) : location.href;
  const data={title:cleanTitle(normalized),text:`${cleanTitle(normalized)} oleh ${normalized.artist}`,url};
  try{if(navigator.share)await navigator.share(data);else{await navigator.clipboard.writeText(data.url);notify('Tautan disalin');}}catch{}
}
function preferenceSwitch(key,title,description='') {
  return `<button class="preference-row" data-pref-toggle="${key}"><span><strong>${esc(title)}</strong>${description?`<small>${esc(description)}</small>`:''}</span><i class="switch ${state.settings[key]?'on':''}"></i></button>`;
}
function preferenceSelect(key,title,description,options) {
  return `<label class="preference-select"><span><strong>${esc(title)}</strong>${description?`<small>${esc(description)}</small>`:''}</span><select data-pref-select="${key}">${options.map(option=>{const value=typeof option==='string'?option:option.value;const label=typeof option==='string'?option:option.label;return `<option value="${esc(value)}" ${String(state.settings[key])===String(value)?'selected':''}>${esc(label)}</option>`;}).join('')}</select></label>`;
}
function bindPreferencePanel(root, afterChange=null) {
  $$('[data-pref-toggle]',root).forEach(button=>button.onclick=()=>{const key=button.dataset.prefToggle;state.settings[key]=!state.settings[key];button.querySelector('.switch').classList.toggle('on',state.settings[key]);persist();applyExperienceSettings();applyGlobalAppTheme(state.current);if(afterChange)afterChange(key);});
  $$('[data-pref-select]',root).forEach(select=>select.onchange=()=>{state.settings[select.dataset.prefSelect]=/^\d+$/.test(select.value)?Number(select.value):select.value;persist();applyExperienceSettings();applyGlobalAppTheme(state.current);if(afterChange)afterChange(select.dataset.prefSelect);});
}
function openPreferencePanel(title, body, afterChange=null, afterOpen=null) {
  openModal(title, `<div class="preference-panel">${body}</div><button class="primary-btn preference-done" data-pref-done>Selesai</button>`, root=>{bindPreferencePanel(root,afterChange);$('[data-pref-done]',root).onclick=()=>{closeModal();if(state.route==='settings')renderSettings();};if(afterOpen)afterOpen(root);});
}

function showAppearanceSettings(){
  openPreferencePanel('Tampilan dan tema',[
    preferenceSwitch('dynamicTheme','Warna dinamis dari cover','Gunakan warna dominan sampul sebagai latar aplikasi'),
    preferenceSelect('themeMode','Pilihan warna','Dipakai ketika warna dinamis dimatikan',[{value:'auto',label:'Otomatis dari cover'},{value:'green',label:'Hijau DATZON'},{value:'blue',label:'Biru'},{value:'purple',label:'Ungu'},{value:'off',label:'Netral'}]),
    preferenceSwitch('reduceMotion','Kurangi animasi','Mematikan transisi dan carousel otomatis yang berat'),
    preferenceSwitch('liquidGlass','Efek Liquid Glass','Blur ringan pada notifikasi dan panel'),
    preferenceSwitch('showCanvas','Tampilkan Canvas','Menampilkan visual bergerak jika tersedia'),
    preferenceSelect('textScale','Ukuran teks','Sesuaikan keterbacaan',['Sangat kecil','Kecil','Normal','Besar','Sangat besar']),
    preferenceSelect('coverShape','Bentuk cover','Berlaku pada daftar dan koleksi',['Membulat','Persegi'])
  ].join(''));
}

function showPlaybackSettings(){
  openPreferencePanel('Playback',[
    preferenceSwitch('autoplay','Autoplay lagu berikutnya','Melanjutkan musik setelah lagu selesai'),
    preferenceSwitch('gapless','Playback tanpa jeda','Mengurangi jeda saat mengganti lagu'),
    preferenceSwitch('continueQueue','Lanjutkan antrean terakhir','Antrean dipulihkan setelah website dibuka kembali'),
    preferenceSwitch('savePosition','Simpan posisi lagu terakhir','Menyimpan detik terakhir pada perangkat'),
    preferenceSwitch('normalizeVolume','Normalisasi volume','Mengurangi perbedaan volume antarlagu'),
    preferenceSwitch('playOnSelect','Putar saat lagu dipilih','Lagu langsung diproses ketika ditekan'),
    preferenceSwitch('skipFailed','Lewati lagu yang gagal dimuat','Otomatis mencoba lagu berikutnya'),
    preferenceSwitch('confirmQueueClear','Konfirmasi sebelum menghapus antrean','Mencegah antrean terhapus tanpa sengaja'),
    preferenceSelect('crossfadeSeconds','Transisi halus','Durasi fade antarpergantian lagu',[{value:0,label:'Nonaktif'},{value:3,label:'3 detik'},{value:5,label:'5 detik'},{value:8,label:'8 detik'}])
  ].join(''));
}

function showQualitySettings(){
  openPreferencePanel('Kualitas audio',[
    preferenceSelect('streamingQuality','Kualitas streaming','Dipakai bila endpoint audio mendukung pilihan kualitas',['Otomatis','Hemat, 64 kbps','Normal, 128 kbps','Tinggi, 192 kbps','Sangat tinggi, 320 kbps']),
    preferenceSelect('downloadQuality','Kualitas download','Preferensi file unduhan',['128 kbps','192 kbps','320 kbps']),
    preferenceSwitch('downloadCellular','Download memakai data seluler','Izinkan unduhan ketika tidak memakai Wi-Fi')
  ].join(''), key=>{
    if(key==='streamingQuality'){
      const q=String(state.settings.streamingQuality);state.settings.dataSaver=/192/.test(q);state.settings.highQuality=/320/.test(q);persist();
    }
  });
}

function showStorageSettings(){
  openModal('Riwayat dan penyimpanan', `<div class="preference-panel">${preferenceSelect('historyLimit','Jumlah lagu dalam Riwayat','Batas maksimum metadata riwayat',[{value:25,label:'25 lagu'},{value:50,label:'50 lagu'},{value:100,label:'100 lagu'},{value:200,label:'200 lagu'}])}<div class="storage-meter"><span>Penggunaan data lokal</span><strong>${localStorageUsageText()}</strong></div><button class="preference-action" data-storage-clear-history>${icon('history')}<span><strong>Hapus Riwayat</strong><small>Termasuk pencarian terakhir</small></span></button><button class="preference-action" data-storage-clear-artists>${icon('artist')}<span><strong>Hapus data Tetap Mendengarkan</strong><small>Mengosongkan artis dari riwayat lokal</small></span></button><button class="preference-action" data-storage-clear-cover>${icon('refresh')}<span><strong>Hapus cache cover dan warna</strong><small>Memuat ulang sampul serta tema dominan</small></span></button><button class="preference-action" data-storage-clear-queue>${icon('queue')}<span><strong>Hapus antrean tersimpan</strong><small>Mempertahankan lagu yang sedang diputar</small></span></button><button class="preference-action" data-storage-export>${icon('download')}<span><strong>Ekspor data</strong><small>Cadangan JSON</small></span></button><button class="preference-action" data-storage-import>${icon('arrow-up')}<span><strong>Impor data</strong><small>Pulihkan cadangan JSON</small></span></button></div>`, root=>{
    bindPreferencePanel(root);
    $('[data-storage-clear-history]',root).onclick=()=>confirmClearHistory();
    $('[data-storage-clear-artists]',root).onclick=()=>{state.history=[];persist();closeModal();notify('Data Tetap Mendengarkan dihapus');};
    $('[data-storage-clear-cover]',root).onclick=()=>{playerThemeCache.clear();publicJsonCache.clear();storage.remove('appThemeRgb');applyGlobalAppTheme(state.current);notify('Cache cover dan warna dihapus');};
    $('[data-storage-clear-queue]',root).onclick=()=>{state.queue=state.current?[state.current]:[];state.currentIndex=state.current?0:-1;persist();notify('Antrean tersimpan dihapus');};
    $('[data-storage-export]',root).onclick=backupData;
    $('[data-storage-import]',root).onclick=()=>restoreInput.click();
  });
}

function showPrivacySettings(){
  openPreferencePanel('Privasi dan personalisasi',[
    preferenceSwitch('privateSession','Sesi pribadi','Tidak menyimpan riwayat dan statistik baru'),
    preferenceSwitch('saveHistory','Simpan Riwayat','Mencatat lagu yang dibuka'),
    preferenceSwitch('useHistoryRecommendations','Gunakan Riwayat untuk rekomendasi','Menyesuaikan Home dari data lokal'),
    preferenceSwitch('showRecentArtists','Tampilkan artis terakhir','Mengisi bagian Tetap Mendengarkan'),
    preferenceSwitch('saveSearchHistory','Simpan pencarian terakhir','Menampilkan kueri terakhir di halaman Cari'),
    preferenceSwitch('explicitFilter','Filter konten eksplisit','Menyembunyikan hasil yang ditandai eksplisit jika metadata tersedia')
  ].join(''));
}

function showNotificationPreferences(){
  openPreferencePanel('Notifikasi',[
    preferenceSwitch('notifyDownloads','Lagu selesai diunduh','Tampilkan konfirmasi download'),
    preferenceSwitch('notifyFailures','Download atau audio gagal','Tampilkan gangguan penting'),
    preferenceSwitch('notifyLyrics','Lirik tidak tersedia','Beritahu ketika lagu tidak memiliki lirik'),
    preferenceSwitch('notifyUpdates','Pembaruan aplikasi','Beritahu versi baru'),
    preferenceSwitch('notifyProvider','Gangguan provider','Pesan teknis tetap disimpan di Status Sistem')
  ].join(''));
}

async function requestWakeLockIfNeeded(){
  if(!state.settings.preventSleepLyrics||!state.isPlaying||!('wakeLock'in navigator))return;
  try{wakeLockSentinel=await navigator.wakeLock.request('screen');wakeLockSentinel.addEventListener('release',()=>{wakeLockSentinel=null;});}catch{}
}
async function releaseWakeLock(){try{await wakeLockSentinel?.release();}catch{}wakeLockSentinel=null;}

function showDeviceSettings(){
  openModal('Aplikasi dan perangkat', `<div class="preference-panel">${preferenceSwitch('mediaControls','Media control Android','Tampilkan judul, artis, cover, dan kontrol di sistem')}${preferenceSwitch('backgroundPlayback','Pemutaran di latar belakang','Pertahankan audio ketika browser diminimalkan')}${preferenceSwitch('preventSleepLyrics','Cegah layar mati saat lirik penuh','Menggunakan Screen Wake Lock bila didukung')}${preferenceSwitch('autoPip','Auto-PiP','Digunakan bila browser mendukung audio Picture-in-Picture')}<button class="preference-action" data-device-timer>${icon('timer')}<span><strong>Pengatur waktu tidur</strong><small>${esc(sleepTimerDisplayLabel())}</small></span></button><button class="preference-action" data-install-pwa>${icon('download')}<span><strong>Instal aplikasi PWA</strong><small>Tambahkan DATZON Music ke layar utama</small></span></button><button class="preference-action" data-check-update>${icon('refresh')}<span><strong>Periksa pembaruan</strong><small>Mengambil versi terbaru dari EdgeOne</small></span></button><button class="preference-action" data-reset-media>${icon('device')}<span><strong>Reset Media Session</strong><small>Memuat ulang metadata kontrol Android</small></span></button></div>`,root=>{
    bindPreferencePanel(root, key=>{if(key==='preventSleepLyrics'){state.settings.preventSleepLyrics?requestWakeLockIfNeeded():releaseWakeLock();}});
    $('[data-device-timer]',root).onclick=()=>{closeModal();showTimer();};
    $('[data-install-pwa]',root).onclick=async()=>{if(deferredInstallPrompt){deferredInstallPrompt.prompt();await deferredInstallPrompt.userChoice;deferredInstallPrompt=null;}else notify('Gunakan menu browser lalu pilih Tambahkan ke layar utama');};
    $('[data-check-update]',root).onclick=async()=>{const registration=await navigator.serviceWorker?.getRegistration();await registration?.update();notify('Pemeriksaan pembaruan selesai');};
    $('[data-reset-media]',root).onclick=()=>{updateMediaSessionMetadata(state.current);updateMediaSessionPlaybackState();notify('Media Session diperbarui');};
  });
}

function showApiCopyright(){
  // Daftar ini sengaja hanya menampilkan provider utama/perwakilan yang dipilih untuk halaman Copyright.
  // Provider fallback lain di mesin aplikasi tetap dipertahankan agar sistem pemutaran tidak ikut rusak.
  const providers = [
    { name:'Theresav API', role:'Provider utama pencarian Spotify, metadata, cover, audio penuh, download, dan lirik bertimestamp bila tersedia', href:'https://api.theresav.eu/', textLogo:'TH' },
    { name:'CMNTY API', role:'Fallback pencarian Spotify, metadata, cover, audio putar, download, dan lirik', href:'https://api.cmnty.eu.cc/', logo:'assets/api-cmnty.png', logoAlt:'Logo CMNTY API' },
    { name:'Sylvatica API', role:'Profil artis utama melalui Spotyloader, lirik bertimestamp, serta fallback pencarian, metadata, audio, dan download', href:'https://sylvatica.my.id/', logo:'assets/api-sylvatica.png', logoAlt:'Logo Sylvatica API' },
    { name:'Ikyy API', role:'Fallback pencarian dan audio Spotify', href:'https://api.ikyyxd.my.id/', textLogo:'ikyy' },
    { name:'Bintang API', role:'Fallback audio Spotify', href:'https://bintangapi.my.id/api/', textLogo:'bintang' },
    { name:'Jerex API', role:'Fallback audio Spotify V1, V2, dan V3', href:'https://api.jerexd.my.id/', textLogo:'jerex' },
    { name:'Spotify', role:'Katalog metadata server-side untuk artis, album, playlist, dan enrichment track; bukan sumber audio penuh', href:'https://www.spotify.com/', logo:'assets/api-spotify.png', logoAlt:'Logo Spotify' },
    { name:'Firebase', role:'Login, sinkronisasi akun, profil, laporan, dan notifikasi', href:'https://firebase.google.com/', logo:'assets/api-firebase.png', logoAlt:'Logo Firebase' },
    { name:'Cloudinary', role:'Penyimpanan gambar profil pengguna', href:'https://cloudinary.com/', logo:'assets/api-cloudinary.png', logoAlt:'Logo Cloudinary' }
  ];
  const rows = providers.map(provider => {
    const mark = provider.logo
      ? `<span class="api-credit-mark api-credit-mark-image"><img src="${esc(provider.logo)}" alt="${esc(provider.logoAlt || provider.name)}" loading="lazy"></span>`
      : `<span class="api-credit-mark api-credit-mark-text"><b>${esc(provider.textLogo || provider.name)}</b></span>`;
    return `<a class="api-credit-row" href="${esc(provider.href)}" target="_blank" rel="noopener noreferrer">${mark}<span class="api-credit-copy"><strong>${esc(provider.name)}</strong><small>${esc(provider.role)}</small></span><span class="api-credit-external" aria-hidden="true">${icon('external')}</span></a>`;
  }).join('');
  openModal('Copyright & API', `<div class="copyright-panel"><div class="copyright-hero">${icon('copyright')}<h3>DATZON Music</h3><p>Platform dan layanan API utama/perwakilan yang digunakan aplikasi ini.</p></div><div class="api-credit-list">${rows}</div><p class="api-credit-note">Logo, nama layanan, dan merek dagang tetap menjadi milik masing-masing pemiliknya. Tekan salah satu layanan untuk membuka situs resminya.</p></div>`);
}

function showAboutSupport(){
  openModal('Tentang dan dukungan', `<div class="about-panel"><img src="assets/datzon-logo.png" alt="Logo DATZON Music"><h3>DATZON Music</h3><p>Versi 1.62.9</p><span class="status-pill"><span class="status-dot ${state.apiOnline?'ok':''}"></span>${state.apiOnline===true?'Layanan metadata tersedia':state.apiOnline===false?'Sebagian layanan sedang bermasalah':'Status belum diuji'}</span><div class="preference-panel"><button class="preference-action" data-about-changelog>${icon('history')}<span><strong>Catatan pembaruan</strong><small>Kontras playlist dan ikon Publik diperbarui</small></span></button><button class="preference-action" data-about-status>${icon('alert')}<span><strong>Status layanan</strong><small>Proses audio, metadata, lirik, dan provider</small></span></button><button class="preference-action" data-about-help>${icon('info')}<span><strong>Bantuan</strong><small>FAQ lengkap dan akses laporan masalah</small></span></button><button class="preference-action" data-about-privacy>${icon('lock')}<span><strong>Kebijakan privasi</strong><small>Data lokal dan koneksi pihak ketiga</small></span></button><button class="preference-action" data-about-copyright>${icon('copyright')}<span><strong>Copyright</strong><small>Platform dan layanan API yang digunakan DATZON Music</small></span></button><button class="preference-action" data-about-report>${icon('report')}<span><strong>Laporkan masalah</strong><small>Kirim laporan lengkap dengan maksimal 3 screenshot</small></span></button></div></div>`,root=>{
    $('[data-about-changelog]',root).onclick=()=>openModal('Catatan pembaruan',`<div class="changelog"><h3>V1.62.9</h3><p>Tampilan playlist dirapikan tanpa mengubah sistem data: teks sekunder pada background dinamis sekarang memiliki kontras lebih kuat, pesan playlist kosong dipendekkan, dan ikon Publik diganti menjadi ikon komunitas pengguna.</p><h3>V1.62.8</h3><p>Pemilik playlist sekarang dapat memilih Hapus Playlist dari pengaturan privasi. Penghapusan memakai konfirmasi dua tahap, menghapus snapshot playlist dari Koleksi Firebase pemilik dan seluruh kolaborator, canonical musicPlaylists, seluruh musicPlaylistProfiles, serta fallback publicProfiles. Link publik lama tetap menampilkan status Playlist sudah dihapus melalui tombstone minimal yang tidak menyimpan nama, cover, track, durasi, atau data kolaborator. Tombstone juga mencegah perangkat lama menghidupkan kembali playlist yang sudah dihapus.</p><h3>V1.62.7</h3><p>Playlist kolaboratif private sekarang muncul di profil seluruh anggota hanya untuk viewer yang juga menjadi anggota. Pembacaan private memiliki fallback membership server-side dari canonical musicPlaylists, sehingga keterlambatan atau indeks profil Firebase yang terlewat tidak lagi membuat playlist private hilang. Endpoint juga memperbaiki indeks profil anggota secara aman saat diperlukan; user di luar kolaborasi tetap tidak menerima data private.</p><h3>V1.62.6</h3><p>Perbaikan profil playlist memulihkan flag listed dari jumlah track aktual, sehingga playlist yang dibuat kosong lalu diisi lagu langsung tampil pada profil pembuat maupun seluruh kolaborator. Listener profil pemilik sekarang selalu menggabungkan snapshot lokal valid dengan indeks realtime Firebase dan perubahan playlist lokal langsung memperbarui halaman profil tanpa menunggu round-trip server.</p><h3>V1.62.5</h3><p>Hotfix realtime memperbaiki endpoint sinkronisasi playlist Firebase Admin yang sebelumnya belum dirutekan oleh handler auth. Playlist publik dan kolaboratif sekarang langsung menulis canonical snapshot serta indeks semua profil tanpa menunggu kolaborator login. Profil pemilik memakai fallback playlist lokal secara langsung, Leaderboard memakai listener realtime saat halaman dibuka, link /datzon-playlist/ID dipastikan tersinkron sebelum dibagikan dan hanya playlist publik yang dapat dibagikan, navigasi playlist → profil → kembali mempertahankan snapshot yang sudah valid, dan gradasi halaman playlist DATZON mengikuti warna dominan lagu yang sedang diputar.</p><h3>V1.62.4</h3><p>Music Code menghapus satu visual bar terluar lagi di sisi kiri dan kanan sehingga waveform DATZON lebih simetris. Sinkronisasi playlist publik single maupun kolaboratif kini dipublikasikan melalui gateway server Firebase Admin yang sudah ada, sehingga snapshot canonical dan indeks profil semua anggota ditulis secara autoritatif tanpa menunggu akun kolaborator login. Profil pengguna selalu menggabungkan fallback playlist publik pemilik dengan indeks realtime, sedangkan playlist private kolaboratif tetap hanya terlihat oleh anggota yang punya akses. Halaman playlist dari profil tetap dibuka sebagai halaman penuh DATZON bergaya Spotify, bukan pop-up.</p><h3>V1.62.3</h3><p>Firestore Rules dikembalikan ke baseline murni DATZON Music dengan proteksi sesi OTP tetap utuh. Alias login utama kembali memakai collection usernames sesuai rules production, sementara musicUsernames tetap dibaca sebagai fallback kompatibilitas agar akun dari build singkat sebelumnya tidak kehilangan akses. Akses playlist realtime ditambahkan khusus melalui musicPlaylists dan musicPlaylistProfiles untuk publik, anggota kolaborasi private, serta halaman detail penuh.</p><h3>V1.62.2</h3><p>Playlist publik single maupun kolaboratif kini memakai indeks bersama realtime sehingga langsung tampil di profil seluruh anggota tanpa menunggu mereka login. Playlist kolaboratif private tampil hanya bagi anggota yang punya akses. Klik playlist dari profil membuka halaman penuh bergaya Spotify dengan identitas DATZON, pembuat dan seluruh kolaborator yang dapat dikunjungi, jumlah lagu, total durasi, aksi koleksi atau bagikan, serta status pemutaran sinkron. Music Code dipangkas satu bar lagi di kedua sisi dan direntangkan simetris.</p><h3>V1.62.1</h3><p>Sinkronisasi Firebase kini kompatibel dengan Firestore Rules gabungan DATZON: record Music diberi marker aplikasi, pembacaan subkoleksi diisolasi dari data DATZON Main/AMPREM, alias login dipindahkan ke musicUsernames, dan profil lama dimigrasikan aman tanpa membuka field koin atau backend. Privasi playlist tetap memakai penyimpanan owner-only dengan snapshot publik terpisah.</p><h3>V1.62.0</h3><p>Tombol play dan pause pada lagu aktif sekarang tersinkron di halaman artis, album, playlist, Home, dan Koleksi. Playlist single maupun kolaboratif dapat dibuat sebagai Publik atau Private; playlist publik tampil di profil setiap kolaborator dan bisa diputar, dibagikan, atau disalin ke Koleksi, sedangkan playlist private hanya tersedia bagi anggota. Visual DATZON Music Code juga dirapikan dengan menghapus satu bar terluar di tiap sisi dan memperpanjang bar tepi yang baru.</p><h3>V1.61.2</h3><p>Template email OTP production tidak lagi memuat gambar eksternal: logo header dan footer sekarang berupa lingkaran hijau berhuruf D yang dibuat langsung dengan table + inline CSS email-safe. Flow login password juga mempertahankan seluruh form tetap terkunci dari Memeriksa ke Mengirim kode sampai halaman Verifikasi Email terbuka, dengan proteksi double-submit dan Google Sign-In sementara dinonaktifkan selama proses.</p><h3>V1.61.1</h3><p>Hotfix autentikasi OTP: sesi password sementara sekarang ditutup sebelum request OTP server untuk mencegah pembacaan Firestore prematur, dan aturan profil Google mengizinkan pengecekan dokumen sendiri walau profil aplikasi belum ada agar Google user baru dapat diarahkan ke Register tanpa permission-denied. Kartu Home/Top 50 kini mengunci lebar card/ranked-card serta menerapkan ellipsis pada judul dan artis sehingga teks panjang tidak lagi memperlebar carousel atau membuat celah.</p><h3>V1.61.0</h3><p>Auth DATZON/Spotizon diperkuat dengan verifikasi OTP email 6 digit untuk pendaftaran baru dan login email/username + password. OTP diproses server-side, sekali pakai, berlaku 10 menit, resend memiliki cooldown, percobaan/rate limit dibatasi, dan template email Spotizon resmi digunakan melalui Resend. Google existing user tetap login normal; Google tanpa profil menyelesaikan Register lalu OTP. Register mendapat email Google readonly + reset akun, tampilan Verifikasi Email baru, serta username reservation atomik. Judul panjang pada kartu Home/Top 50 kini dipotong visual dengan ellipsis tanpa mengubah metadata asli.</p><h3>V1.60.6</h3><p>Music Code dan Pemindai kini memuat modul secara sinkron dengan retry loader sehingga tidak lagi berhenti pada status belum siap. Music Code dapat dibuat oleh akun login maupun Tamu; collection codeTrack tetap top-level dan untuk track Spotify Document ID memakai Spotify Track ID agar satu lagu hanya punya satu record global. Avatar kolaborator tanpa foto memakai lingkaran hijau berinisial, dan badge kolaboratif selalu hanya menampilkan maksimal dua avatar tanpa ikon +.</p><h3>V1.60.5</h3><p>Playlist kolaboratif mendapat mode Track/Users di Player Sheet: Track tetap bisa naik/turun/hapus, Users menampilkan anggota, akun sendiri ditandai hijau, pembuat playlist dapat Kick dan menambah teman melalui sheet terpisah, dan badge cover kini hanya berisi avatar kecil tanpa teks. Music Code diubah menjadi poster terpadu dengan cover besar, judul/artis di atas cover, strip kode menempel di bawah, QR berisi deep-link /track/ untuk Google Lens, Code128 tetap berada di tengah waveform untuk scanner DATZON, dan poster penuh ikut terunduh. Metadata Music Code disimpan best-effort ke collection codeTrack Firebase. Overlay equalizer pada cover kini mengikuti bentuk kotak rounded cover, bukan lingkaran.</p><h3>V1.60.4</h3><p>Music Code dan scanner sekarang memakai draggable Player Sheet yang sama dengan Antrean, visual kode diperbesar dengan bar rounded yang lebih sedikit serta PNG Download Kode, dan scan screenshot mempertahankan resolusi lebih tinggi dengan fallback decoder multi-threshold. Navigasi Full Lyrics diperbaiki agar tidak membentuk loop history. Indikator lagu aktif dianimasikan di Album, Artist, Playlist Spotify, dan playlist lokal. Playlist kolaboratif mendapat badge anggota pada cover serta editor kolaborator untuk menambah atau mengeluarkan teman.</p><h3>V1.60.3</h3><p>Mixed search artist/album/playlist dirapikan setara track row. Album detail mendapat artist link internal, share, open Spotify, tombol play/pause dan track aktif hijau. Audio Settings menyembunyikan kontrol compressor dan merapikan visualizer. Playlist kolaboratif dan Blend diaktifkan. Ditambahkan DATZON Music Code deterministic global dengan generator visual, scan kamera, scan screenshot/gambar, resolver canonical track, serta integrasi player existing.</p><h3>V1.60.2</h3><p>Search Spotify disesuaikan dengan batas Search API 2026 (maksimal 10 hasil per page) dan digabung menjadi satu request catalog track/artis/album/playlist. Skeleton search dirapikan, header hasil tanpa bar hitam, tombol hapus input animatif ditambahkan, klik album dari profil artis membuka Album Detail internal, kontrol Audio Settings dipindah menjadi 3+3, dan Audio Settings sekarang memakai player-sheet draggable yang sama dengan Antrean.</p><h3>V1.60.1</h3><p>Hotfix deployment Vercel Hobby: 23 API entrypoints dikonsolidasikan menjadi 7 gateway Functions tanpa menghapus fitur Spotify Catalog, provider playback existing, mixed search, album detail, Audio Lab, dominant profile color, playlist resolver, atau enrichment metadata.</p><h3>V1.60.0</h3><p>Spotify Web API Client Credentials ditambahkan server-side sebagai katalog metadata untuk artis, album, playlist, dan track tanpa Spotify user OAuth. Search menjadi mixed feed track/artis/album/playlist dengan dedupe konservatif. Artist image dan discography memprioritaskan Spotify Artist ID exact, album memiliki detail internal + full tracklist tanpa cover berulang, playlist tetap memakai resolver playback existing. Ditambahkan Audio Settings berbasis Web Audio API (preamp, bass, treble, EQ 10 band, reverb, stereo, compressor, visualizer, preset, reset), warna profil publik mengikuti warna dominan avatar, serta onboarding artis memakai foto profile Spotify yang akurat.</p><h3>V1.50.0</h3><p>Artist pipeline dikunci ke Spotify Artist ID/URL exact dari metadata track Theresav sebelum dikirim ke Sylvatica Spotyloader. Profil multi-artis tetap membawa seluruh konteks kolaborator saat berpindah artis. Top tracks Sylvatica diperkaya dengan Spotify track metadata agar cover lagu, album, dan durasi lebih akurat; iTunes/MusicBrainz/Wikipedia/Anabot melengkapi rilis, bio, genre, followers, dan monthly listeners. Home Serupa dengan hanya memakai track yang benar-benar termasuk artis terkait, maksimal empat track unik dari credit lagu, tanpa filler artis lain. Kartu Import playlist dirapikan sama besar dengan kartu playlist. Playback dipercepat, seek jauh sebelum buffer selesai dialihkan ke proxy Range/206, dan next-track menyiapkan URL/warmup segera lalu full-buffer di background.</p><h3>V1.49.0</h3><p>Profil artis sekarang mempertahankan Spotify Artist ID/URL exact dari metadata Theresav lalu memakai Sylvatica Spotyloader sebagai sumber utama profile image dan top tracks. Konteks kolaborasi tidak hilang saat berpindah antar artis; kartu Artis lainnya tetap membawa semua credit lagu asal. Anabot, Wikipedia, iTunes/MusicBrainz melengkapi followers, monthly listeners, bio, genre, dan rilis jika tersedia. Home mendapat kartu Import playlist Spotify serta rekomendasi Serupa dengan berbasis top tracks Sylvatica yang dideduplikasi maksimal empat lagu. Playback memulai stream lebih cepat, full-buffer berjalan di latar belakang, next track tetap dipersiapkan penuh, dan request lama dibatalkan agar audio tidak tertukar.</p><h3>V1.48.0</h3><p>Sylvatica Spotyloader menjadi sumber utama profil artis Spotify dan fallback tambahan untuk pencarian, metadata, audio, serta download. Profil artis memakai image, Spotify artist ID, URL, top tracks, durasi, dan credit artis dari Spotyloader. Pencarian mendapat kata relevan live satu baris seperti autocomplete. Buffer audio penuh kini mencoba proxy Sylvatica lalu Theresav, sedangkan lagu berikutnya dipersiapkan lebih awal dan dicoba full-buffer ulang agar perpindahan antrean lebih siap.</p><h3>V1.47.1</h3><p>Playback diperkuat dengan buffer audio penuh, seek yang tidak lagi ditimpa sinkronisasi progress, pemulihan otomatis saat stream macet, dan preload penuh lagu berikutnya. Track multi-artis kini membuka artis utama secara terpisah serta menampilkan artis lain berbentuk kartu foto bulat di atas Tentang. Tombol tutup Track kembali ke halaman sebelumnya melalui browser history. Ditambahkan proxy audio Edge terbatas untuk Range/stream Theresav saat CDN memblokir CORS.</p><h3>V1.47.0</h3><p>Theresav menjadi provider utama untuk pencarian Spotify serta pemrosesan track penuh. Hasil pencarian diprioritaskan dari Theresav, dideduplikasi, dilengkapi fallback hingga sekitar 20 hasil, dan cover diperbaiki dari provider cadangan bila perlu. Saat track dibuka, exact Spotify URL dikirim ke Theresav untuk metadata, cover, audio, download, dan lirik; lirik bertimestamp dari respons Theresav dipakai langsung tanpa memanggil Sylvatica. Halaman Track tidak lagi memakai skeleton penuh: UI muncul segera, tombol Play menampilkan loading sampai audio siap lalu autoplay, sedangkan tombol Download memberi pesan tunggu selama file penuh masih diproses. CMNTY dipindahkan ke domain api.cmnty.eu.cc dan menjadi fallback.</p><h3>V1.46.2</h3><p>Memperbaiki statistik Teman, Followers, dan Following pada profil publik dengan snapshot sosial publik sebagai fallback saat pembacaan subkoleksi akun lain dibatasi Firestore. Daftar sosial sekarang juga tidak lagi menampilkan tombol Tambah teman, Ikuti balik, Mengikuti, atau Teman pada baris akun sendiri.</p><h3>V1.46.1</h3><p>Hotfix deployment Vercel menghapus dependency preview yang tidak diperlukan dan mengunci Framework Preset ke Other. Website statis, routing SPA, Firebase, serta Serverless Functions Spotify tetap dipertahankan tanpa proses build frontend tambahan.</p><h3>V1.46.0</h3><p>Menambahkan tombol geser kanan dan kiri pada carousel desktop, animasi masuk untuk seluruh pop-up, serta memperbaiki klik isi pop-up yang sebelumnya tertangkap sistem drag. Profil kini memiliki Teman, Followers, Following, bio, dan tautan sosial yang dideteksi otomatis. Koleksi dapat difilter berdasarkan Playlist atau Artis. Import playlist Spotify kini menyimpan playlist ke Koleksi, memakai fallback metadata, serta mendukung fungsi server EdgeOne dan Vercel.</p><h3>V1.45.4</h3><p>Sinkronisasi tombol Play utama di halaman Playlist Spotify diperkuat. Jika lagu aktif memang berasal dari daftar playlist yang sedang dibuka, tombol mengikuti status pemutar secara real-time: Pause saat berjalan, Play saat dijeda, dan indikator loading selama audio dipersiapkan. Klik tombol saat track playlist sedang aktif sekarang menjeda/melanjutkan lagu yang sama tanpa mengulang playlist dari awal.</p><h3>V1.45.3</h3><p>Gradasi Playlist Spotify sekarang berhenti di area tombol aksi agar daftar lagu kembali gelap dan mudah dibaca. Track aktif mendapat efek latar hijau Spotify seperti playlist Firebase. Koleksi Kamu kini memiliki Import playlist Spotify: tempel tautan playlist, frontend mengambil ID saja, backend memproses metadata, lalu halaman /playlist/ID dibuka tanpa reload.</p><h3>V1.45.2</h3><p>Warna dominan sekarang hanya memengaruhi gradasi halaman Playlist Spotify. Tombol Play, tanda track aktif, outline cover aktif, dan centang simpan dikunci ke hijau Spotify. Tombol Hubungkan Spotify di profil artis dihapus, track artis yang sedang diputar ikut mendapat penanda hijau Spotify, dan centang From the Community tetap hijau serta tetap terbaca tersimpan selama playlist dengan nama tersebut sudah ada di Koleksi Kamu.</p><h3>V1.45.1</h3><p>Halaman Playlist Spotify sekarang mengikuti warna dominan global DATZON tanpa gradasi hitam di bagian atas. Tombol Play besar memutar lagu pertama langsung di DATZON dan menyusun sisa track sebagai antrean, logo Spotify pada identitas playlist dihilangkan, serta track yang sedang aktif ditandai warna aksen hijau/dominan seperti playlist lokal.</p><h3>V1.45.0</h3><p>Spotify collection sementara difokuskan ke 9 playlist curated. Home menampilkan semua playlist dengan urutan acak setiap reload. Klik lagu playlist kini langsung memakai exact Spotify Track URL untuk diproses oleh player internal DATZON, sedangkan titik tiga memakai menu lagu DATZON biasa. Tombol + mengimpor seluruh track playlist ke Koleksi Kamu dan tombol bagikan membagikan URL /playlist/ID pada domain aktif.</p><h3>V1.44.0</h3><p>Menambahkan discovery Spotify Album + Playlist berbasis metadata server-side EdgeOne tanpa Client ID/Secret. Home kini memiliki carousel Album & Playlist Untukmu tepat di bawah artis Tetap Mendengarkan, dengan ranking ringan dari riwayat mendengarkan. Album dan playlist memakai halaman detail DATZON sendiri, exact Spotify Track ID/URL tanpa search fallback, konfirmasi sebelum membuka Spotify, lazy cover track playlist, cache endpoint, Retry, dan routing /album/ID serta /playlist/ID.</p><h3>V1.43.0</h3><p>Login gagal sekarang selalu mereset email/username, password, serta tombol Login agar bisa langsung dicoba ulang. From the Community kini berisi maksimal 25 lagu per kartu dengan antrean tetap sesuai urutan, tombol Dengar Bareng memilih teman dan menyinkronkan posisi lagu, sedangkan tombol + membuat playlist lokal/Firebase dan berubah menjadi centang. Antrean tidak lagi dibangun ulang ketika sheet Antrean dibuka, lagu berikutnya dipersiapkan lebih cepat untuk playback latar belakang, dan proses memuat lagu tidak lagi memaksa halaman Track muncul kembali setelah pengguna menutupnya.</p><h3>V1.42.1</h3><p>Notifikasi kegagalan, autentikasi, validasi, dan masalah layanan sekarang selalu memakai ikon X merah, sedangkan notifikasi sukses tetap memakai centang hijau. Pesan alias username tanpa email juga dipersingkat agar lebih jelas.</p><h3>V1.42.0</h3><p>Logo CMNTY pada Copyright & API sekarang memakai image lokal. Sistem sosial dipisah menjadi Cari Pengguna, Teman, Following, dan Followers dengan URL /people, /friends, /following, dan /followers. Teman mutual tetap tampil di ketiga daftar sosial, tombol daftar menggantikan ikon pencarian pada halaman profil/sosial, dan tombol Teman dapat membuka konfirmasi unfriend. Login Email/Password sekarang juga menerima @username melalui alias Firebase usernames.</p><h3>V1.41.1</h3><p>Halaman Copyright & API dirapikan menjadi delapan layanan perwakilan: CMNTY, Sylvatica, Ikyy, Bintang, Jerex, Spotify, Firebase, dan Cloudinary. CMNTY memakai logo SVG senyum hitam di atas putih, Sylvatica/Spotify/Firebase/Cloudinary memakai aset lokal, sedangkan Ikyy/Bintang/Jerex memakai logo teks. Semua logo diberi outline putih dan setiap baris dapat membuka situs layanan.</p><h3>V1.41.0</h3><p>CMNTY kembali menjadi API utama untuk pencarian Spotify, metadata, cover, audio putar, dan download. Sylvatica serta provider lain tetap menjadi fallback. Link bagikan lagu sekarang selalu memakai domain aktif dengan format /track/ID. Logo DATZON lokal dipakai pada Tentang dan favicon statis agar tidak berubah mengikuti cover lagu. Menu Copyright baru menampilkan daftar platform dan API yang terintegrasi.</p><h3>V1.40.1</h3><p>Pencarian Spotify sekarang memprioritaskan Ikyy karena responsnya menyertakan cover dan link lagu; Sylvatica dipakai hanya ketika Ikyy gagal, kosong, atau tidak merespons. Cache pencarian lama dibersihkan agar hasil tanpa cover tidak terus muncul. Pergantian lagu otomatis juga menyiapkan metadata serta URL audio lagu berikutnya sejak lagu saat ini diputar, memakai pemutaran langsung saat lagu berakhir, Media Session, repeat-one native, dan watchdog akhir lagu agar antrean lebih stabil ketika tab berada di latar belakang.</p><h3>V1.40.0</h3><p>Pencarian lagu sekarang memakai Sylvatica sebagai sumber utama dan Ikyy sebagai cadangan; pencarian CMNTY dinonaktifkan agar pesan koneksi CMNTY tidak lagi mengganggu. Audio putar serta download memakai Sylvatica terlebih dahulu, lalu Bintang dan Ikyy secara cepat, kemudian tiga endpoint Jere; CMNTY audio tetap tersimpan tetapi nonaktif. Halaman artis dilengkapi jumlah pengikut, pendengar bulanan, dan centang biru berdasarkan Anabot. Playlist pilihan Anabot di Home diperkaya otomatis melalui pencarian Spotify agar sampul dan link lagu tersedia serta dapat diputar.</p><h3>V1.39.4</h3><p>Pembaca lirik Sylvatica diperbaiki agar mengenali lebih banyak bentuk JSON dan format timestamp. Hasil dicocokkan secara bertahap memakai judul, artis, dan durasi; pencarian kedua memakai judul serta artis bila hasil pertama belum cocok. Cache lirik lama yang gagal dibaca dilewati, dan Auto Fokus aktif otomatis saat timestamp valid ditemukan. CMNTY tetap menjadi cadangan hanya ketika Sylvatica gagal atau tidak menemukan lirik bertimestamp yang sesuai.</p><h3>V1.39.3</h3><p>Audio putar dan download sekarang memakai Sylvatica Spotify sebagai provider aktif. Jalur audio CMNTY tetap disimpan tetapi dinonaktifkan melalui konfigurasi agar mudah diaktifkan kembali. Playlist kini memiliki menu tiga titik untuk menaikkan, menurunkan, atau menghapus satu lagu dan perubahan urutan langsung disinkronkan ke antrean playlist.</p><h3>V1.39.2</h3><p>Intro Admin Panel dirapikan tanpa logo SVG. Saat memutar playlist, Antrean sekarang hanya berisi lagu playlist sesuai urutan, sedangkan lagu rekomendasi ditempatkan pada bagian Cocok untukmu. Mode Ulang Antrean hanya mengulang playlist dan tidak masuk ke rekomendasi.</p><h3>V1.39.1</h3><p>Privasi detail laporan diperketat: notifikasi laporan hanya dapat membuka detail bagi akun pelapor, sedangkan pengguna lain hanya menandainya sebagai dibaca. Bagian Diagnostik di detail laporan disembunyikan dan ikon laporan baru disamakan dengan ikon Laporkan Masalah. Catatan versi juga dirapikan menjadi satu file UPDATE_LOGS.txt.</p><h3>V1.39.0</h3><p>Admin Panel berbasis web ditambahkan dengan pemeriksaan sesi Firebase dan role admin, dashboard pengguna, laporan, serta pengiriman notifikasi global. Menu Admin Panel hanya muncul di Pengaturan untuk akun dengan role admin. Sistem lirik Sylvatica dan seluruh fitur V1.38.1 tetap dipertahankan.</p></div>`);
    $('[data-about-status]',root).onclick=()=>{closeModal();showSystemActivitySheet();};
    $('[data-about-help]',root).onclick=()=>{closeModal();showHelp();};
    $('[data-about-privacy]',root).onclick=()=>openModal('Kebijakan privasi',`<p class="modal-description">Data koleksi dan pengaturan non-sensitif disimpan di perangkat melalui localStorage. Credential Spotify Client ID/Secret hanya dibaca oleh backend Vercel dan tidak dikirim ke browser. Provider audio, lirik, metadata publik, Firebase, dan layanan existing tetap digunakan sesuai fitur terkait.</p>`);
    $('[data-about-copyright]',root).onclick=()=>showApiCopyright();
    $('[data-about-report]',root).onclick=()=>{closeModal(true);navigate('report');};
  });
}

function localBackupPayload(){
  return {app:CONFIG.appName,version:CONFIG.version,source:'local',exportedAt:new Date().toISOString(),username:state.username,preferredArtists:state.preferredArtists,preferredArtistMeta:state.preferredArtistMeta||[],favorites:state.favorites,history:state.history,searchHistory:state.searchHistory,queue:state.queue,current:state.current,currentIndex:state.currentIndex,downloads:state.downloads,listeningStats:state.listeningStats,settings:state.settings,playlists:activePlaylists()};
}

function downloadBackupPayload(payload, suffix = 'local') {
  const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'});
  const url=URL.createObjectURL(blob);
  const a=document.createElement('a');
  a.href=url;
  a.download=`datzon-music-${suffix}-${new Date().toISOString().replace(/[:.]/g,'-')}.json`;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(()=>URL.revokeObjectURL(url),500);
}

async function backupData(target='local'){
  try {
    if(target==='firebase'){
      if(!isLoggedIn()) throw new Error('Login diperlukan untuk mengekspor database Firebase.');
      const payload=await firebaseService().exportCloudData();
      downloadBackupPayload(payload,'firebase');
      notify('Backup database Firebase berhasil dibuat');
      return;
    }
    downloadBackupPayload(localBackupPayload(),'local');
    notify('Backup lokal berhasil dibuat');
  } catch(error){ notify(firebaseService()?.firebaseErrorMessage?.(error)||error?.message||'Backup gagal dibuat'); }
}

function showExportTargetSheet(){
  if(!isLoggedIn()) return backupData('local');
  openModal('Pilih sumber ekspor', `<div class="backup-target-list"><button data-export-target="local">${icon('device')}<span><strong>Perangkat lokal</strong><small>Favorit, riwayat, antrean, statistik, dan pengaturan pada perangkat ini</small></span>${icon('chevron')}</button><button data-export-target="firebase">${firebaseLogoMarkup()}<span><strong>Database Firebase</strong><small>Data tersinkron milik akun ${esc(state.auth.profile?.email||'')}</small></span>${icon('chevron')}</button></div>`, root => $$('[data-export-target]',root).forEach(button=>button.onclick=async()=>{const target=button.dataset.exportTarget;button.disabled=true;await backupData(target);closeModal();}));
}

function showImportTargetSheet(){
  if(!isLoggedIn()){state.importTarget='local';restoreInput.click();return;}
  openModal('Pilih tujuan impor', `<div class="backup-target-list"><button data-import-target="local">${icon('device')}<span><strong>Perangkat lokal</strong><small>Gabungkan cadangan ke data pada browser ini</small></span>${icon('chevron')}</button><button data-import-target="firebase">${firebaseLogoMarkup()}<span><strong>Database Firebase</strong><small>Gabungkan cadangan ke akun tanpa menduplikasi ID Spotify</small></span>${icon('chevron')}</button></div>`, root => $$('[data-import-target]',root).forEach(button=>button.onclick=()=>{state.importTarget=button.dataset.importTarget;closeModal();setTimeout(()=>restoreInput.click(),80);}));
}

function applyImportedData(data){
  if(data.app&&data.app!==CONFIG.appName)throw new Error('File bukan cadangan DATZON Music');
  if(typeof data.username==='string'&&!isLoggedIn())state.username=data.username;
  if(Array.isArray(data.preferredArtists))state.preferredArtists=[...new Set([...data.preferredArtists,...state.preferredArtists])].slice(0,30);
  if(Array.isArray(data.preferredArtistMeta))state.preferredArtistMeta=data.preferredArtistMeta.slice(0,30);
  if(Array.isArray(data.favorites))state.favorites=mergeTracksByIdentity(data.favorites,state.favorites,300);
  if(Array.isArray(data.history))state.history=mergeTracksByIdentity(data.history,state.history,Math.max(10,Number(state.settings.historyLimit)||100));
  if(Array.isArray(data.searchHistory))state.searchHistory=[...new Set([...data.searchHistory,...state.searchHistory])].slice(0,20);
  if(Array.isArray(data.queue))state.queue=mergeTracksByIdentity(data.queue,state.queue,100);
  if(data.current&&!state.current)state.current=normalizeTrack(data.current);
  if(Number.isInteger(data.currentIndex)&&state.currentIndex<0)state.currentIndex=data.currentIndex;
  if(Array.isArray(data.playlists)) setActivePlaylists(mergePlaylistsById(data.playlists, activePlaylists()));
  if(Array.isArray(data.downloads))state.downloads=mergeTracksByIdentity(data.downloads,state.downloads,150).map(item=>{const raw=data.downloads.find(source=>trackFirebaseId(source)===trackFirebaseId(item))||{};return{...item,downloadedAt:raw.downloadedAt||item.downloadedAt,fileName:raw.fileName||item.fileName};});
  if(data.listeningStats&&typeof data.listeningStats==='object'&&Number(data.listeningStats.totalSeconds||0)>Number(state.listeningStats.totalSeconds||0))state.listeningStats=data.listeningStats;
  if(data.settings&&typeof data.settings==='object')state.settings={...state.settings,...data.settings};
  persist();applyExperienceSettings();applyGlobalAppTheme(state.current);
}

function confirmClearHistory(){openModal('Hapus Riwayat',`<p class="modal-description">Riwayat pencarian dan lagu yang pernah diputar akan dikosongkan. Statistik mendengarkan tetap dipertahankan.</p><button class="danger-btn" data-confirm-clear>Hapus Riwayat</button>`,root=>$('[data-confirm-clear]',root).onclick=()=>{state.history=[];state.searchHistory=[];persist();closeModal();notify('Riwayat dihapus');});}
function confirmReset(){openModal('Reset Semua Data',`<p class="modal-description">Semua favorit, riwayat, antrean, unduhan, statistik, dan pengaturan akan dihapus dari perangkat ini.</p><button class="danger-btn" data-confirm-reset>Reset Permanen</button>`,root=>$('[data-confirm-reset]',root).onclick=()=>{Object.keys(localStorage).filter(k=>k.startsWith('datzon_music_')).forEach(k=>localStorage.removeItem(k));location.reload();});}
function showAbout(){showAboutSupport();}

function syncPlaybackUI(forceLyrics = false) {
  updateProgress();
  updateLyricsUI(forceLyrics);
}

function startPlaybackSync() {
  if (playbackSyncTimer) return;
  syncPlaybackUI(true);
  playbackSyncTimer = window.setInterval(() => {
    if (audio.paused || audio.ended) {
      stopPlaybackSync(false);
      return;
    }
    syncPlaybackUI(false);
  }, 120);
}

function stopPlaybackSync(forceLyrics = true) {
  if (playbackSyncTimer) window.clearInterval(playbackSyncTimer);
  playbackSyncTimer = null;
  syncPlaybackUI(forceLyrics);
}

function syncFullAudioDuration() {
  if (!state.current || !Number.isFinite(audio.duration) || audio.duration <= 35) return;
  const fullDuration = formatTime(audio.duration);
  if (state.current.duration === fullDuration) return;
  state.current.duration = fullDuration;
  if (state.queue[state.currentIndex]) state.queue[state.currentIndex].duration = fullDuration;
  persist();
}

// Audio events
audio.addEventListener('play',()=>{if(window.DatzonAudioLab?.shouldAutoEnable?.())window.DatzonAudioLab.ensure?.();state.isPlaying=true;audio.loop=state.repeat==='one';listeningLastTick=Date.now();updateMediaSessionMetadata(state.current);updateMediaSessionPlaybackState();renderPlayerDynamic();renderMiniPlayer();renderDesktopContextRail();updateQueueNowPlayButton();updatePlaylistDetailPlayback();updatePublicPlaylistDetailPlayback();updateDatzonPlaylistPagePlayback();updateSpotifyCollectionPlayback();updateArtistPagePlayback();syncVisibleTrackPlaybackIcons();syncAccountAvatarPlaybackState();startPlaybackSync();requestWakeLockIfNeeded();scheduleNextTrackPreload(document.hidden?0:180);schedulePlaybackEndWatchdog();});
audio.addEventListener('pause',()=>{clearAudioStallRecovery();recordListeningTick(true);listeningLastTick=0;state.isPlaying=false;clearPlaybackEndWatchdog();updateMediaSessionPlaybackState();updateMediaSessionPosition();stopPlaybackSync(true);renderPlayerDynamic();renderMiniPlayer();renderDesktopContextRail();updateQueueNowPlayButton();updatePlaylistDetailPlayback();updatePublicPlaylistDetailPlayback();updateDatzonPlaylistPagePlayback();updateSpotifyCollectionPlayback();updateArtistPagePlayback();syncVisibleTrackPlaybackIcons();syncAccountAvatarPlaybackState();releaseWakeLock();});
audio.addEventListener('timeupdate',()=>{recordListeningTick(false);if(!state.settings.privateSession&&state.settings.savePosition&&state.current&&Math.floor(audio.currentTime)%5===0)storage.set('lastPosition',{key:trackKey(state.current),time:audio.currentTime});if(state.current&&Math.floor(audio.currentTime)%20===3)prepareNextTrackInBackground().catch(()=>{});syncPlaybackUI(false);updateMediaSessionPosition();});
audio.addEventListener('loadedmetadata',()=>{syncFullAudioDuration();const saved=storage.get('lastPosition',null);if(state.settings.savePosition&&saved?.key===trackKey(state.current)&&Number(saved.time)>0&&Number(saved.time)<audio.duration-5)audio.currentTime=Number(saved.time);updateMediaSessionMetadata(state.current);syncPlaybackUI(true);updateMediaSessionPosition();schedulePlaybackEndWatchdog();scheduleNextTrackPreload(document.hidden?0:180);});
audio.addEventListener('durationchange',()=>{syncFullAudioDuration();syncPlaybackUI(true);updateMediaSessionPosition();schedulePlaybackEndWatchdog();});
audio.addEventListener('seeking',()=>{syncPlaybackUI(true);updateMediaSessionPosition();clearPlaybackEndWatchdog();});
audio.addEventListener('seeked',()=>{syncPlaybackUI(true);updateMediaSessionPosition();schedulePlaybackEndWatchdog();});
audio.addEventListener('waiting',()=>{if(!audio.paused&&!audio.ended)scheduleAudioStallRecovery('waiting');});
audio.addEventListener('stalled',()=>{if(!audio.paused&&!audio.ended)scheduleAudioStallRecovery('stalled');});
audio.addEventListener('playing',()=>{clearAudioStallRecovery();});
audio.addEventListener('canplay',()=>{clearAudioStallRecovery();});
audio.addEventListener('ended',()=>{
  recordListeningTick(true); listeningLastTick=0; releaseWakeLock();
  stopPlaybackSync(true);
  if (state.sleepTimerMode === 'end' || state.sleepTimerLabel === 'Akhir lagu') {
    state.sleepTimerLabel = '';
    state.sleepTimerMode = '';
    state.sleepTimerEndAt = 0;
    persist();
    state.isPlaying = false;
    updateMediaSessionPlaybackState();
    updateMediaSessionPosition();
    renderPlayerDynamic();
    renderMiniPlayer();
    syncAccountAvatarPlaybackState();
    notify('Musik dihentikan di akhir lagu');
    return;
  }
  clearPlaybackEndWatchdog();
  void nextTrack(false);
});
audio.addEventListener('error',()=>{clearAudioStallRecovery();if(!audio.currentSrc&&!audio.getAttribute('src'))return;recordListeningTick(true);listeningLastTick=0;stopPlaybackSync(true);state.isPlaying=false;updateMediaSessionPlaybackState();renderPlayerDynamic();updatePublicPlaylistDetailPlayback();updateDatzonPlaylistPagePlayback();updateArtistPagePlayback();syncVisibleTrackPlaybackIcons();syncAccountAvatarPlaybackState();if(state.settings.notifyFailures!==false)notify('Stream audio terputus. Coba putar kembali.');if(state.settings.skipFailed&&state.queue.length>1)window.setTimeout(()=>void nextTrack(false),350);});

document.addEventListener('visibilitychange',async()=>{
  if (document.hidden && state.settings.backgroundPlayback === false && !audio.paused) audio.pause();
  if(document.hidden && state.settings.autoPip && document.pictureInPictureEnabled && !audio.paused){/* Audio-only browser tidak selalu mendukung PiP. */}
  if (document.hidden && state.isPlaying) {
    await prepareNextTrackInBackground().catch(()=>null);
    schedulePlaybackEndWatchdog();
    persist();
  }
  if (!document.hidden) {
    const duration = Number(audio.duration);
    const position = Number(audio.currentTime);
    const finishedWhileSuspended = Boolean(state.current && state.queue.length > 1 && (audio.ended || (Number.isFinite(duration) && duration > 1 && Number.isFinite(position) && position >= duration - .25)));
    if (finishedWhileSuspended && !backgroundAdvanceLock) void nextTrack(false);
    else if (state.settings.preventSleepLyrics && state.isPlaying) requestWakeLockIfNeeded();
  }
});
document.addEventListener('freeze',()=>{prepareNextTrackInBackground().catch(()=>{});persist();});
window.addEventListener('pagehide',()=>{prepareNextTrackInBackground().catch(()=>{});persist();});

window.addEventListener('beforeinstallprompt',event=>{event.preventDefault();deferredInstallPrompt=event;});
restoreInput.addEventListener('change', async event=>{
  const file=event.target.files?.[0];if(!file)return;
  try{
    const data=JSON.parse(await file.text());
    if(state.importTarget==='firebase'){
      if(!isLoggedIn())throw new Error('Login diperlukan untuk mengimpor ke Firebase.');
      await firebaseService().importCloudData(data);
      const cloud=await firebaseService().loadCloudData();
      applyCloudDataToState(cloud);
      notify('Cadangan berhasil digabungkan ke Firebase');
    }else{
      applyImportedData(data);
      notify('Cadangan lokal berhasil dipulihkan');
    }
    event.target.value='';state.importTarget='local';closeModal(true);render();
  }catch(error){event.target.value='';state.importTarget='local';notify(firebaseService()?.firebaseErrorMessage?.(error)||error?.message||'Cadangan tidak dapat dibaca');}
});

window.addEventListener('beforeunload',()=>{persist();firebaseService()?.setPresence?.(false).catch(()=>{});});
window.addEventListener('keydown',e=>{if(e.code==='Space'&&!['INPUT','TEXTAREA'].includes(document.activeElement.tagName)){e.preventDefault();togglePlay();}});

if('serviceWorker'in navigator){window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));}

const modalScrollGuard = new MutationObserver(() => {
  if (!modalRoot.children.length) unlockPageScroll(true);
});
modalScrollGuard.observe(modalRoot, { childList: true });
window.addEventListener('pageshow', () => {
  if (!modalRoot.children.length) unlockPageScroll(true);
});

function migrateActivityHistory() {
  const version = '1.34.0';
  if (storage.get('activitySchemaVersion', '') === version) return;
  state.systemActivity = [];
  state.systemActivityUnread = 0;
  storage.set('systemActivity', []);
  storage.set('systemActivityUnread', 0);
  storage.set('activitySchemaVersion', version);
}

async function bootstrapApp() {
  migrateActivityHistory();
  await initializeFirebaseIntegration();
  applyExperienceSettings();
  armSleepTimerFromState();
  setupMediaSession();
  await handleSpotifyCallback();
  applyGlobalAppTheme(state.current);
  if (state.current) updateMediaSessionMetadata(state.current);
  resetRouteViewport();
  await applyBrowserRoute({ replace: true });
  window.__datzonBootReady?.();
  loadHome(false);
}


let desktopChromeResizeTimer = null;
window.addEventListener('resize', () => {
  clearTimeout(desktopChromeResizeTimer);
  desktopChromeResizeTimer = window.setTimeout(() => renderDesktopChrome(), 120);
});

window.addEventListener('popstate', () => {
  resetModalRoot();
  applyBrowserRoute({ replace: false }).catch(() => {
    state.route = 'home';
    syncBrowserRoute('home', { replace: true });
    render();
  });
});

bootstrapApp();
