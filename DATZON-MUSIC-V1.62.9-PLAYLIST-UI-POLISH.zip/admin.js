'use strict';

(() => {
  const APP_VERSION = '1.62.9';
  const root = document.getElementById('adminRoot');
  const modalRoot = document.getElementById('adminModalRoot');
  const toastNode = document.getElementById('adminToast');
  const bootNode = document.getElementById('adminBoot');
  const service = window.DatzonFirebase;

  const state = {
    authMode: 'login',
    authError: '',
    authResolved: false,
    pendingOtp: null,
    pendingRegistration: null,
    user: null,
    profile: null,
    section: 'dashboard',
    loading: false,
    data: null,
    dataError: '',
    userSearch: '',
    userRoleFilter: 'all',
    reportFilter: 'all',
    lastLoadedAt: 0
  };

  const sectionInfo = {
    dashboard: ['Dashboard', 'Ringkasan aktivitas aplikasi'],
    users: ['Pengguna', 'Akun, status, dan aktivitas mendengarkan'],
    reports: ['Laporan', 'Konfirmasi dan tindak lanjut masalah'],
    notifications: ['Notifikasi Global', 'Kirim kabar ke seluruh pengguna terdaftar'],
    system: ['Sistem', 'Status Firebase dan konfigurasi admin']
  };

  function esc(value = '') {
    return String(value).replace(/[&<>'"]/g, char => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', "'":'&#39;', '"':'&quot;' }[char]));
  }

  function number(value = 0) {
    return new Intl.NumberFormat('id-ID').format(Number(value) || 0);
  }

  function formatDuration(seconds = 0) {
    const total = Math.max(0, Number(seconds) || 0);
    if (total < 60) return `${Math.round(total)} dtk`;
    if (total < 3600) return `${Math.round(total / 60)} mnt`;
    if (total < 86400) return `${(total / 3600).toFixed(total >= 36000 ? 0 : 1)} jam`;
    return `${(total / 86400).toFixed(1)} hari`;
  }

  function millis(value) {
    if (!value) return 0;
    if (typeof value.toMillis === 'function') return value.toMillis();
    if (typeof value.toDate === 'function') return value.toDate().getTime();
    if (typeof value === 'number') return value;
    const parsed = new Date(value).getTime();
    return Number.isFinite(parsed) ? parsed : 0;
  }

  function formatDate(value, withTime = true) {
    const time = millis(value);
    if (!time) return 'Belum tersedia';
    try {
      return new Intl.DateTimeFormat('id-ID', withTime
        ? { day:'2-digit', month:'short', year:'numeric', hour:'2-digit', minute:'2-digit' }
        : { day:'2-digit', month:'short', year:'numeric' }).format(new Date(time));
    } catch { return new Date(time).toLocaleString('id-ID'); }
  }

  function relativeTime(value) {
    const time = millis(value);
    if (!time) return 'Belum aktif';
    const diff = Date.now() - time;
    if (diff < 60000) return 'Baru saja';
    if (diff < 3600000) return `${Math.max(1, Math.floor(diff / 60000))} menit lalu`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)} jam lalu`;
    if (diff < 604800000) return `${Math.floor(diff / 86400000)} hari lalu`;
    return formatDate(time, false);
  }

  function initials(profile = {}) {
    return String(profile.fullName || profile.username || 'D').trim().slice(0, 1).toUpperCase() || 'D';
  }

  function avatar(profile = {}, className = 'avatar') {
    const photo = String(profile.photoURL || '');
    return `<span class="${className}">${photo ? `<img src="${esc(photo)}" alt="" referrerpolicy="no-referrer" onerror="this.remove();this.parentElement.textContent='${esc(initials(profile))}'">` : esc(initials(profile))}</span>`;
  }

  function statusPill(status = 'offline') {
    const value = String(status || 'offline').toLowerCase();
    const label = value === 'online' ? 'Online' : value === 'busy' ? 'Sibuk' : 'Offline';
    return `<span class="pill ${esc(value)}">${label}</span>`;
  }

  function reportPill(status = 'submitted') {
    const value = String(status || 'submitted').toLowerCase();
    const label = value === 'fixed' ? 'Selesai' : value === 'confirmed' ? 'Dikonfirmasi' : 'Menunggu';
    const cls = value === 'submitted' ? 'pending' : value;
    return `<span class="pill ${cls}">${label}</span>`;
  }

  let toastTimer = null;
  function toast(message, type = '') {
    clearTimeout(toastTimer);
    toastNode.textContent = String(message || '');
    toastNode.className = `admin-toast show ${type}`.trim();
    toastTimer = setTimeout(() => { toastNode.className = 'admin-toast'; }, 3200);
  }

  function hideBoot() {
    bootNode?.classList.add('is-hidden');
    setTimeout(() => bootNode?.remove(), 500);
  }

  function errorMessage(error) {
    return service?.firebaseErrorMessage?.(error) || error?.message || 'Terjadi kesalahan. Coba lagi.';
  }

  function setButtonBusy(button, busy, label = 'Memproses...') {
    if (!button) return;
    if (busy) {
      button.dataset.originalText = button.textContent;
      button.textContent = label;
      button.disabled = true;
    } else {
      button.textContent = button.dataset.originalText || button.textContent;
      button.disabled = false;
    }
  }

  function passwordField(id, label, autocomplete = 'current-password') {
    return `<label class="field"><span>${esc(label)}</span><div class="password-wrap"><input id="${esc(id)}" name="${esc(id)}" type="password" autocomplete="${esc(autocomplete)}" minlength="6" required><button type="button" data-toggle-password="${esc(id)}">Lihat</button></div></label>`;
  }

  function authFormMarkup() {
    if (state.pendingOtp?.challengeId) {
      const email = state.pendingOtp.email || state.pendingOtp.maskedEmail || '';
      return `<form class="auth-form" data-auth-form="otp">
        <div class="admin-otp-copy"><b>Verifikasi Email</b><span>Kode 6 digit dikirim ke ${esc(email)} dan berlaku 10 menit.</span></div>
        <div class="admin-otp-inputs" data-admin-otp-inputs>${Array.from({length:6},(_,i)=>`<input name="otp${i}" inputmode="numeric" maxlength="1" ${i===0?'autocomplete="one-time-code"':''} aria-label="Digit ${i+1}">`).join('')}</div>
        <button class="auth-link admin-otp-resend" type="button" data-admin-otp-resend>Kirim ulang kode</button>
        <button class="primary-btn" type="submit">Konfirmasi kode</button>
        <button class="secondary-btn" type="button" data-admin-otp-cancel>Batalkan</button>
      </form>`;
    }
    if (state.authMode === 'register') {
      return `<form class="auth-form" data-auth-form="register">
        <div class="auth-row">
          <label class="field"><span>Nama lengkap</span><input name="fullName" type="text" maxlength="70" placeholder="Nama pengguna" required></label>
          <label class="field"><span>Username</span><input name="username" type="text" maxlength="24" placeholder="username" required></label>
        </div>
        <label class="field"><span>Email</span><input name="email" type="email" autocomplete="email" placeholder="admin@email.com" required></label>
        ${passwordField('registerPassword','Password','new-password')}
        ${passwordField('registerConfirm','Konfirmasi password','new-password')}
        <button class="primary-btn" type="submit">Register akun</button>
        <div class="auth-divider">ATAU</div>
        <button class="google-btn" type="button" data-google-auth><b>G</b> Lanjutkan dengan Google</button>
        <p class="auth-footer-note">Akun baru selalu dibuat sebagai <b>user</b>. Akses Admin Panel hanya aktif setelah field <b>role: admin</b> ditetapkan melalui Firebase Console.</p>
      </form>`;
    }
    return `<form class="auth-form" data-auth-form="login">
      <label class="field"><span>Email atau username</span><input name="email" type="text" autocomplete="username" placeholder="admin@email.com atau @username" required></label>
      ${passwordField('loginPassword','Password','current-password')}
      <button class="primary-btn" type="submit">Login ke Admin Panel</button>
      <button class="auth-link" type="button" data-forgot-password>Lupa password?</button>
      <div class="auth-divider">ATAU</div>
      <button class="google-btn" type="button" data-google-auth><b>G</b> Lanjutkan dengan Google</button>
      <p class="auth-footer-note">Login Email/Username + Password sekarang memerlukan kode verifikasi email sebelum sesi admin aktif.</p>
    </form>`;
  }

  function renderAuth() {
    modalRoot.innerHTML = '';
    root.innerHTML = `<main class="admin-auth-page">
      <section class="auth-brand-panel">
        <div class="auth-brand"><img src="assets/icon.svg" alt=""><div><strong>DATZON</strong><span>ADMIN PANEL</span></div></div>
        <div class="auth-copy"><small>KONTROL APLIKASI</small><h1>Kelola DATZON Music dalam satu panel.</h1><p>Pantau pengguna, proses laporan, lihat aktivitas aplikasi, dan kirim notifikasi global dengan tampilan yang selaras dengan aplikasi utama.</p></div>
        <div class="auth-security-note"><span>●</span><div><b>Akses berbasis role.</b><br>Firebase Authentication memeriksa sesi login, lalu Firestore memvalidasi role admin sebelum data panel dibuka.</div></div>
      </section>
      <section class="auth-form-panel">
        <div class="auth-card">
          <header class="auth-card-head"><small>AKSES TERBATAS</small><h2>${state.pendingOtp ? 'Verifikasi Email' : state.authMode === 'register' ? 'Register DATZON' : 'Login Admin'}</h2><p>${state.pendingOtp ? 'Masukkan kode sekali pakai yang dikirim ke email akun.' : state.authMode === 'register' ? 'Buat akun baru. Role admin tetap harus diberikan secara aman dari Firebase Console.' : 'Masuk menggunakan akun DATZON yang memiliki role admin.'}</p></header>
          ${state.pendingOtp ? '' : `<div class="auth-tabs"><button class="${state.authMode === 'login' ? 'active' : ''}" data-auth-mode="login">Login</button><button class="${state.authMode === 'register' ? 'active' : ''}" data-auth-mode="register">Register</button></div>`}
          ${state.authError ? `<div class="auth-error"><span>!</span><div>${esc(state.authError)}</div></div>` : ''}
          ${authFormMarkup()}
        </div>
      </section>
    </main>`;
    const otpInputs = [...root.querySelectorAll('[data-admin-otp-inputs] input')];
    otpInputs.forEach((input,index) => {
      input.addEventListener('input', () => { input.value = String(input.value || '').replace(/\D/g,'').slice(-1); if (input.value && index < otpInputs.length - 1) otpInputs[index + 1].focus(); });
      input.addEventListener('keydown', event => { if (event.key === 'Backspace' && !input.value && index > 0) otpInputs[index - 1].focus(); });
      input.addEventListener('paste', event => { const digits = String(event.clipboardData?.getData('text') || '').replace(/\D/g,'').slice(0,6); if (!digits) return; event.preventDefault(); otpInputs.forEach((box,i)=>box.value=digits[i]||''); otpInputs[Math.min(5,digits.length-1)]?.focus(); });
    });
  }

  function renderProfileSetup(user, values = {}) {
    modalRoot.innerHTML = '';
    root.innerHTML = `<main class="admin-auth-page">
      <section class="auth-brand-panel">
        <div class="auth-brand"><img src="assets/icon.svg" alt=""><div><strong>DATZON</strong><span>ACCOUNT SETUP</span></div></div>
        <div class="auth-copy"><small>LANGKAH TERAKHIR</small><h1>Lengkapi profil DATZON.</h1><p>Akun autentikasi sudah terhubung, tetapi profil aplikasi belum tersedia. Lengkapi informasi berikut untuk melanjutkan.</p></div>
        <div class="auth-security-note"><span>●</span><div>Akun yang baru dilengkapi tetap memiliki role user dan tidak otomatis memperoleh akses admin.</div></div>
      </section>
      <section class="auth-form-panel"><div class="auth-card">
        <header class="auth-card-head"><small>PROFIL FIREBASE</small><h2>Lengkapi akun</h2><p>${esc(user?.email || '')}</p></header>
        <form class="auth-form" data-auth-form="complete-profile">
          <label class="field"><span>Nama lengkap</span><input name="fullName" maxlength="70" value="${esc(values.fullName || user?.displayName || '')}" required></label>
          <label class="field"><span>Username</span><input name="username" maxlength="24" placeholder="usernameunik" required></label>
          <label class="field"><span>Password DATZON (opsional untuk akun Google)</span><input name="password" type="password" minlength="6" autocomplete="new-password"></label>
          <button class="primary-btn" type="submit">Simpan profil</button>
          <button class="secondary-btn" type="button" data-auth-logout>Batalkan dan keluar</button>
        </form>
      </div></section>
    </main>`;
  }

  function renderRedirect(profile = state.profile) {
    root.innerHTML = `<main class="admin-auth-page"><section class="auth-form-panel" style="grid-column:1/-1"><div class="auth-card">
      <header class="auth-card-head"><small>AKSES DITOLAK</small><h2>Akun bukan admin</h2><p>Akun @${esc(profile?.username || 'pengguna')} memiliki role user. Kamu akan dialihkan kembali ke aplikasi utama.</p></header>
      <button class="primary-btn" data-open-main style="width:100%">Kembali ke Home</button>
    </div></section></main>`;
    setTimeout(() => { window.location.replace('/home'); }, 1400);
  }

  function navMarkup(mobile = false) {
    const items = [
      ['dashboard','⌂','Dashboard'],
      ['users','♙','Pengguna'],
      ['reports','!','Laporan'],
      ['notifications','♩','Notifikasi'],
      ['system','⚙','Sistem']
    ];
    if (mobile) {
      return `<nav class="mobile-admin-nav">${items.map(([key, icon, label]) => `<button class="${state.section === key ? 'active' : ''}" data-section="${key}"><b>${icon}</b><span>${label}</span></button>`).join('')}</nav>`;
    }
    const pending = Number(state.data?.metrics?.pendingReports || 0);
    return `<nav class="sidebar-nav">${items.map(([key, icon, label]) => `<button class="${state.section === key ? 'active' : ''}" data-section="${key}"><span class="nav-icon">${icon}</span><span>${label}</span>${key === 'reports' && pending ? `<em>${Math.min(99,pending)}</em>` : ''}</button>`).join('')}</nav>`;
  }

  function renderAppShell() {
    const profile = state.profile || {};
    const [title, subtitle] = sectionInfo[state.section] || sectionInfo.dashboard;
    root.innerHTML = `<div class="admin-app">
      <aside class="admin-sidebar">
        <div class="sidebar-brand"><img src="assets/icon.svg" alt=""><div><strong>DATZON</strong><span>ADMIN PANEL</span></div></div>
        <div class="sidebar-label">MENU ADMIN</div>
        ${navMarkup(false)}
        <div class="sidebar-profile">
          <div class="profile-line">${avatar(profile)}<div><strong>${esc(profile.fullName || profile.username || 'Admin')}</strong><small>@${esc(profile.username || '')} • ADMIN</small></div></div>
          <div class="sidebar-actions"><button data-open-main>← Aplikasi</button><button data-admin-logout title="Keluar">⏻</button></div>
        </div>
      </aside>
      <main class="admin-main">
        <header class="admin-topbar">
          <div class="topbar-title"><small>${esc(subtitle.toUpperCase())}</small><h1>${esc(title)}</h1></div>
          <div class="topbar-actions"><span class="status-live"><i></i> FIREBASE TERHUBUNG</span><button class="secondary-btn" data-admin-refresh>↻ Refresh</button>${avatar(profile)}</div>
        </header>
        <section id="adminContent" class="admin-content"></section>
      </main>
      ${navMarkup(true)}
    </div>`;
    renderSection();
  }

  function sectionHeader(kicker, title, description, action = '') {
    return `<div class="section-head"><div><small>${esc(kicker)}</small><h2>${esc(title)}</h2><p>${esc(description)}</p></div>${action}</div>`;
  }

  function loadingMarkup(text = 'Memuat data admin...') {
    return `<div class="loading-state"><div><i></i><br>${esc(text)}</div></div>`;
  }

  function dataErrorMarkup() {
    const permission = /permission|ditolak|akses/i.test(state.dataError);
    return `<div class="error-panel"><h3>${permission ? 'Firestore Rules belum aktif' : 'Data admin gagal dimuat'}</h3><p>${esc(state.dataError)}</p>${permission ? `<code>Publish file firestore.rules dari paket DATZON Music ini melalui Firebase Console.</code>` : ''}<button class="secondary-btn" data-admin-refresh>Coba lagi</button></div>`;
  }

  function metricCard(label, value, detail, className = '') {
    return `<article class="metric-card ${className}"><span>${esc(label)}</span><strong>${esc(value)}</strong><small>${esc(detail)}</small></article>`;
  }

  function userRow(user = {}) {
    return `<div class="data-row"><div class="data-primary">${avatar(user)}<div><strong>${esc(user.fullName || user.username)}</strong><small>@${esc(user.username || '-')} • ${esc(user.email || 'email tidak tersedia')}</small></div></div><div class="data-meta">${user.role === 'admin' ? '<span class="pill admin">Admin</span>' : statusPill(user.status)}<small>${relativeTime(user.lastSeenAtMs)}</small></div></div>`;
  }

  function reportRow(report = {}) {
    return `<div class="data-row"><div class="data-primary"><span class="avatar">!</span><div><strong>${esc(report.subject || 'Laporan masalah')}</strong><small>${esc(report.reporterFullName || report.reporterUsername || 'Pengguna')} • ${relativeTime(report.createdAtMs || report.createdAt)}</small></div></div><div class="data-meta">${reportPill(report.status)}</div></div>`;
  }

  function renderDashboard(content) {
    const data = state.data;
    const metrics = data.metrics || {};
    const latestUsers = (data.users || []).slice(0, 6);
    const latestReports = [...(data.reports || [])].sort((a,b) => Number(b.createdAtMs || 0)-Number(a.createdAtMs || 0)).slice(0, 6);
    content.innerHTML = `${sectionHeader('DATZON CONTROL CENTER','Ringkasan aplikasi','Informasi akun, aktivitas mendengarkan, laporan pengguna, dan notifikasi global diperbarui dari Firebase.', `<button class="secondary-btn" data-section="notifications">+ Kirim notifikasi</button>`)}
      <div class="metric-grid">
        ${metricCard('TOTAL PENGGUNA', number(metrics.users), `${number(metrics.admins)} akun admin`)}
        ${metricCard('AKTIF SEKARANG', number(metrics.online), 'Aktif dalam 10 menit terakhir')}
        ${metricCard('TOTAL PEMUTARAN', number(metrics.totalPlays), formatDuration(metrics.totalListeningSeconds))}
        ${metricCard('LAPORAN MENUNGGU', number(metrics.pendingReports), `${number(metrics.confirmedReports)} sedang ditinjau`, metrics.pendingReports ? 'alert' : '')}
        ${metricCard('MASALAH SELESAI', number(metrics.fixedReports), 'Laporan ditandai telah diperbaiki')}
        ${metricCard('NOTIFIKASI AKTIF', number(metrics.activeAnnouncements), 'Tampil di aplikasi utama')}
        ${metricCard('RATA-RATA PUTAR', metrics.users ? formatDuration(metrics.totalListeningSeconds / metrics.users) : '0 dtk', 'Per akun terdaftar')}
        ${metricCard('TERAKHIR SINKRON', formatDate(data.generatedAtMs), 'Data Firebase terbaru')}
      </div>
      <div class="dashboard-grid">
        <section class="panel"><header class="panel-head"><div><h3>Pengguna terbaru aktif</h3><small>${number(data.users?.length)} akun terbaca</small></div><button class="small-btn" data-section="users">Lihat semua</button></header><div class="panel-body data-list">${latestUsers.length ? latestUsers.map(userRow).join('') : '<div class="empty-state"><div><b>Belum ada pengguna</b>Data akun akan tampil setelah pengguna mendaftar.</div></div>'}</div></section>
        <section class="panel"><header class="panel-head"><div><h3>Laporan terbaru</h3><small>${number(data.reports?.length)} laporan</small></div><button class="small-btn" data-section="reports">Buka</button></header><div class="panel-body data-list">${latestReports.length ? latestReports.map(reportRow).join('') : '<div class="empty-state"><div><b>Belum ada laporan</b>Masalah dari pengguna akan tampil di sini.</div></div>'}</div></section>
      </div>
      <div class="dashboard-grid">
        <section class="panel"><div class="panel-body quick-compose"><h3>Kirim notifikasi cepat</h3><p>Notifikasi masuk ke menu lonceng aplikasi utama untuk seluruh akun yang sudah login.</p><form class="form-grid" data-announcement-form="quick"><label class="field"><span>Judul</span><input name="title" maxlength="100" placeholder="Pembaruan DATZON Music" required></label><label class="field"><span>Pesan</span><textarea name="message" maxlength="2000" placeholder="Tuliskan informasi untuk pengguna..." required></textarea></label><button class="primary-btn" type="submit">Kirim global</button></form></div></section>
        <section class="panel"><div class="panel-body quick-compose"><h3>Keamanan akses</h3><p>Panel hanya terbuka saat Firebase Auth aktif dan dokumen akun memiliki field role bernilai admin. Akun biasa selalu dialihkan ke Home.</p><button class="secondary-btn" data-section="system">Periksa sistem</button></div></section>
      </div>`;
  }

  function filteredUsers() {
    const search = state.userSearch.trim().toLowerCase();
    return (state.data?.users || []).filter(user => {
      if (state.userRoleFilter !== 'all' && user.role !== state.userRoleFilter) return false;
      if (!search) return true;
      return [user.fullName,user.username,user.email,user.uid].some(value => String(value || '').toLowerCase().includes(search));
    });
  }

  function renderUsers(content) {
    const users = filteredUsers();
    content.innerHTML = `${sectionHeader('ACCOUNT DATABASE','Daftar pengguna','Klik salah satu akun untuk melihat informasi profil, statistik, jumlah koleksi, dan riwayat pemutaran terbaru.')}
      <div class="toolbar"><label class="toolbar-search"><span>⌕</span><input data-user-search value="${esc(state.userSearch)}" placeholder="Cari nama, username, email, atau UID..."></label><div class="filter-group"><button class="${state.userRoleFilter === 'all' ? 'active' : ''}" data-user-role="all">Semua</button><button class="${state.userRoleFilter === 'user' ? 'active' : ''}" data-user-role="user">User</button><button class="${state.userRoleFilter === 'admin' ? 'active' : ''}" data-user-role="admin">Admin</button></div></div>
      ${users.length ? `<div class="table-wrap"><table class="admin-table"><thead><tr><th>PENGGUNA</th><th>ROLE</th><th>STATUS</th><th>PEMUTARAN</th><th>WAKTU DENGAR</th><th>TERAKHIR AKTIF</th></tr></thead><tbody>${users.map(user => `<tr data-user-detail="${esc(user.uid)}"><td><div class="table-user">${avatar(user)}<div><strong>${esc(user.fullName)}</strong><small>@${esc(user.username || '-')} • ${esc(user.email || user.uid)}</small></div></div></td><td>${user.role === 'admin' ? '<span class="pill admin">Admin</span>' : '<span class="pill">User</span>'}</td><td>${statusPill(user.status)}</td><td>${number(user.listeningSummary?.plays)}</td><td>${formatDuration(user.listeningSummary?.totalSeconds)}</td><td>${relativeTime(user.lastSeenAtMs)}</td></tr>`).join('')}</tbody></table></div>` : '<div class="empty-state"><div><b>Pengguna tidak ditemukan</b>Ubah kata pencarian atau filter role.</div></div>'}`;
  }

  function filteredReports() {
    return (state.data?.reports || []).filter(report => state.reportFilter === 'all' || report.status === state.reportFilter);
  }

  function renderReports(content) {
    const reports = filteredReports();
    content.innerHTML = `${sectionHeader('SUPPORT CENTER','Laporan pengguna','Konfirmasi laporan untuk memberi tahu pelapor bahwa masalah sedang ditinjau. Tandai selesai untuk mengirim notifikasi global dan notifikasi pribadi kepada pelapor.')}
      <div class="toolbar"><div class="filter-group"><button class="${state.reportFilter === 'all' ? 'active' : ''}" data-report-filter="all">Semua</button><button class="${state.reportFilter === 'submitted' ? 'active' : ''}" data-report-filter="submitted">Menunggu</button><button class="${state.reportFilter === 'confirmed' ? 'active' : ''}" data-report-filter="confirmed">Dikonfirmasi</button><button class="${state.reportFilter === 'fixed' ? 'active' : ''}" data-report-filter="fixed">Selesai</button></div><span class="pill">${number(reports.length)} laporan</span></div>
      ${reports.length ? `<div class="report-grid">${reports.map(report => `<article class="report-card"><div><small>${formatDate(report.createdAtMs || report.createdAt)} • ${esc(report.reporterFullName || report.reporterUsername || 'Pengguna')}</small><h3>${esc(report.subject || 'Laporan masalah')}</h3><p>${esc(report.description || 'Tidak ada deskripsi.')}</p><div style="margin-top:10px">${reportPill(report.status)} ${report.reporterEmail ? `<span class="pill">${esc(report.reporterEmail)}</span>` : ''}</div></div><div class="card-actions"><button class="small-btn" data-report-detail="${esc(report.id)}">Detail</button>${report.status === 'submitted' ? `<button class="secondary-btn" data-report-confirm="${esc(report.id)}">Konfirmasi</button>` : ''}${report.status !== 'fixed' ? `<button class="primary-btn" data-report-fix="${esc(report.id)}">Tandai selesai</button>` : ''}</div></article>`).join('')}</div>` : '<div class="empty-state"><div><b>Tidak ada laporan</b>Belum ada laporan pada status ini.</div></div>'}`;
  }

  function renderNotifications(content) {
    const announcements = state.data?.announcements || [];
    const now = Date.now();
    content.innerHTML = `${sectionHeader('BROADCAST CENTER','Notifikasi global','Pesan tersimpan sebagai announcement di Firestore dan otomatis muncul di pusat notifikasi aplikasi utama untuk akun terdaftar.')}
      <div class="compose-layout">
        <section class="compose-card"><h3>Buat notifikasi</h3><p>Gunakan judul singkat dan isi yang jelas. Masa aktif menentukan berapa lama pesan ditampilkan.</p><form class="form-grid" data-announcement-form="full"><label class="field"><span>Judul</span><input name="title" maxlength="100" placeholder="Judul notifikasi" required></label><label class="field"><span>Isi pesan</span><textarea name="message" maxlength="2000" placeholder="Informasi update, pemeliharaan, atau pengumuman..." required></textarea></label><div class="form-row"><label class="field"><span>Prioritas</span><select name="priority"><option value="normal">Normal</option><option value="high">Penting</option></select></label><label class="field"><span>Masa aktif</span><select name="expiresDays"><option value="7">7 hari</option><option value="14">14 hari</option><option value="30" selected>30 hari</option><option value="60">60 hari</option><option value="90">90 hari</option></select></label></div><button class="primary-btn" type="submit">Kirim ke semua pengguna</button></form></section>
        <section class="panel"><header class="panel-head"><div><h3>Riwayat notifikasi</h3><small>${number(announcements.length)} pesan tersimpan</small></div></header><div class="panel-body">${announcements.length ? `<div class="announcement-grid">${announcements.map(item => { const active = !item.expiresAtMs || Number(item.expiresAtMs) > now; return `<article class="announcement-card"><div><small>${formatDate(item.createdAtMs || item.createdAt)} • ${esc(item.createdByName || 'Admin DATZON')}</small><h3>${esc(item.title || 'Notifikasi DATZON')}</h3><p>${esc(item.message || '')}</p><div style="margin-top:10px"><span class="pill ${active ? 'online' : 'offline'}">${active ? 'Aktif' : 'Kedaluwarsa'}</span>${item.priority === 'high' ? '<span class="pill pending">Penting</span>' : ''}<span class="pill">Berakhir ${formatDate(item.expiresAtMs,false)}</span></div></div><div class="card-actions"><button class="danger-btn" data-announcement-delete="${esc(item.id)}">Hapus</button></div></article>`; }).join('')}</div>` : '<div class="empty-state"><div><b>Belum ada notifikasi</b>Kirim pengumuman pertama untuk pengguna DATZON.</div></div>'}</div></section>
      </div>`;
  }

  function renderSystem(content) {
    const cfg = window.DATZON_FIREBASE_CONFIG?.firebase || {};
    const metrics = state.data?.metrics || {};
    content.innerHTML = `${sectionHeader('SYSTEM STATUS','Konfigurasi admin','Informasi teknis untuk memastikan autentikasi, database, rules, dan sambungan aplikasi utama berjalan sesuai konfigurasi.')}
      <div class="system-grid">
        <section class="system-card"><h3>Firebase</h3><div class="system-item"><span>Status konfigurasi</span><b>${service?.isConfigured?.() ? 'Aktif' : 'Belum dikonfigurasi'}</b></div><div class="system-item"><span>Project ID</span><b>${esc(cfg.projectId || '-')}</b></div><div class="system-item"><span>Auth domain</span><b>${esc(cfg.authDomain || '-')}</b></div><div class="system-item"><span>Firebase SDK</span><b>${esc(service?.sdkVersion?.() || '-')}</b></div><div class="system-item"><span>Rules admin</span><b>${state.data ? 'Terbaca / aktif' : 'Belum diverifikasi'}</b></div></section>
        <section class="system-card"><h3>Sesi admin</h3><div class="system-item"><span>Nama akun</span><b>${esc(state.profile?.fullName || '-')}</b></div><div class="system-item"><span>Email</span><b>${esc(state.profile?.email || state.user?.email || '-')}</b></div><div class="system-item"><span>UID</span><b>${esc(state.user?.uid || '-')}</b></div><div class="system-item"><span>Role</span><b>${esc(state.profile?.role || 'user')}</b></div><div class="system-item"><span>Versi panel</span><b>${APP_VERSION}</b></div></section>
        <section class="system-card"><h3>Koneksi fitur</h3><div class="system-item"><span>Akun terbaca</span><b>${number(metrics.users)}</b></div><div class="system-item"><span>Listener notifikasi utama</span><b>announcements</b></div><div class="system-item"><span>Laporan menunggu</span><b>${number(metrics.pendingReports)}</b></div><div class="system-item"><span>Notifikasi aktif</span><b>${number(metrics.activeAnnouncements)}</b></div><div class="system-item"><span>Sinkron terakhir</span><b>${state.lastLoadedAt ? formatDate(state.lastLoadedAt) : '-'}</b></div></section>
        <section class="system-card"><h3>Aksi</h3><div class="form-grid"><button class="secondary-btn" data-admin-refresh>Sinkronkan ulang data</button><button class="secondary-btn" data-open-main>Buka aplikasi utama</button><button class="danger-btn" data-admin-logout>Keluar akun admin</button></div></section>
      </div>`;
  }

  function renderSection() {
    const content = document.getElementById('adminContent');
    if (!content) return;
    if (state.loading && !state.data) { content.innerHTML = loadingMarkup(); return; }
    if (state.dataError && !state.data) { content.innerHTML = dataErrorMarkup(); return; }
    if (!state.data) { content.innerHTML = loadingMarkup(); return; }
    if (state.section === 'users') renderUsers(content);
    else if (state.section === 'reports') renderReports(content);
    else if (state.section === 'notifications') renderNotifications(content);
    else if (state.section === 'system') renderSystem(content);
    else renderDashboard(content);
  }

  async function loadDashboard(force = false) {
    if (!state.profile || String(state.profile.role || '').toLowerCase() !== 'admin') return;
    if (state.loading) return;
    if (state.data && !force && Date.now() - state.lastLoadedAt < 60000) { renderSection(); return; }
    state.loading = true;
    state.dataError = '';
    renderSection();
    try {
      state.data = await service.adminLoadDashboard();
      state.lastLoadedAt = Date.now();
    } catch (error) {
      state.dataError = errorMessage(error);
      if (/permission/i.test(String(error?.code || ''))) state.data = null;
    } finally {
      state.loading = false;
      renderAppShell();
    }
  }

  async function submitAuthForm(form) {
    const submit = form.querySelector('button[type="submit"]');
    setButtonBusy(submit, true);
    state.authError = '';
    try {
      const values = Object.fromEntries(new FormData(form).entries());
      if (form.dataset.authForm === 'login') {
        const challenge = await service.startPasswordOtpLogin(values.email, values.loginPassword);
        state.pendingOtp = challenge;
        state.pendingRegistration = null;
        toast('Kode verifikasi dikirim ke email.');
        renderAuth();
      } else if (form.dataset.authForm === 'register') {
        if (values.registerPassword !== values.registerConfirm) throw new Error('Konfirmasi password tidak sama.');
        const draft = { fullName: values.fullName, username: values.username, email: values.email, password: values.registerPassword, provider:'password' };
        const challenge = await service.startRegistrationOtp(draft);
        state.pendingRegistration = draft;
        state.pendingOtp = challenge;
        toast('Kode verifikasi dikirim ke email.');
        renderAuth();
      } else if (form.dataset.authForm === 'otp') {
        const code = Array.from({length:6},(_,i)=>String(values[`otp${i}`]||'').replace(/\D/g,'').slice(0,1)).join('');
        if (code.length !== 6) throw new Error('Masukkan 6 digit kode verifikasi.');
        const result = await service.verifyOtp({ challengeId: state.pendingOtp?.challengeId, code, registration: state.pendingRegistration, provider: state.pendingRegistration?.provider || '' });
        state.pendingOtp = null;
        state.pendingRegistration = null;
        toast(result.purpose === 'login' ? 'Login terverifikasi.' : 'Akun berhasil dibuat.');
      } else if (form.dataset.authForm === 'complete-profile') {
        // New Google users are completed in the main Music registration flow so OTP remains mandatory.
        window.location.href = '/register';
      }
    } catch (error) {
      state.authError = errorMessage(error);
      renderAuth();
    } finally {
      setButtonBusy(submit, false);
    }
  }

  async function handleGoogleAuth(button) {
    setButtonBusy(button, true, 'Menghubungkan...');
    state.authError = '';
    try {
      const result = await service.loginGoogle();
      if (result?.needsSetup) { window.location.href = '/register'; return; }
    } catch (error) {
      state.authError = errorMessage(error);
      renderAuth();
    } finally {
      setButtonBusy(button, false);
    }
  }

  async function sendAnnouncement(form) {
    const button = form.querySelector('button[type="submit"]');
    setButtonBusy(button, true, 'Mengirim...');
    try {
      const values = Object.fromEntries(new FormData(form).entries());
      await service.adminCreateAnnouncement({
        title: values.title,
        message: values.message,
        priority: values.priority || 'normal',
        expiresDays: Number(values.expiresDays || 30)
      });
      form.reset();
      toast('Notifikasi global berhasil dikirim.');
      await loadDashboard(true);
      state.section = 'notifications';
      renderAppShell();
    } catch (error) {
      toast(errorMessage(error), 'error');
    } finally {
      setButtonBusy(button, false);
    }
  }

  async function reportAction(id, action, button) {
    setButtonBusy(button, true);
    try {
      if (action === 'confirm') await service.confirmReport(id);
      else await service.markReportFixed(id);
      toast(action === 'confirm' ? 'Laporan berhasil dikonfirmasi.' : 'Laporan ditandai selesai dan notifikasi dikirim.');
      await loadDashboard(true);
    } catch (error) {
      toast(errorMessage(error), 'error');
    } finally {
      setButtonBusy(button, false);
    }
  }

  function showReportDetail(id) {
    const report = (state.data?.reports || []).find(item => String(item.id) === String(id));
    if (!report) return;
    const screenshots = Array.isArray(report.screenshots) ? report.screenshots : [];
    modalRoot.innerHTML = `<div class="admin-modal-backdrop" data-modal-backdrop><article class="admin-modal"><header class="modal-head"><h2>Detail laporan</h2><button data-modal-close>×</button></header><div class="modal-body"><div class="user-detail-head">${avatar({ fullName: report.reporterFullName, username: report.reporterUsername, photoURL: report.reporterPhotoURL })}<div><h3>${esc(report.reporterFullName || report.reporterUsername || 'Pengguna')}</h3><p>@${esc(report.reporterUsername || '-')} • ${esc(report.reporterEmail || '-')}</p></div></div><h3 class="modal-section-title">${esc(report.subject || 'Laporan masalah')}</h3><p style="color:#b5bdb0;line-height:1.7;font-size:11px;white-space:pre-wrap">${esc(report.description || '')}</p><div class="detail-grid"><div class="detail-item"><span>Status</span><b>${reportPill(report.status)}</b></div><div class="detail-item"><span>Dikirim</span><b>${formatDate(report.createdAtMs || report.createdAt)}</b></div><div class="detail-item"><span>UID pelapor</span><b>${esc(report.reporterUid || '-')}</b></div><div class="detail-item"><span>ID laporan</span><b>${esc(report.id || '-')}</b></div></div>${screenshots.length ? `<h3 class="modal-section-title">Screenshot</h3><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:9px">${screenshots.map(url => `<a href="${esc(url)}" target="_blank" rel="noopener"><img src="${esc(url)}" alt="Screenshot laporan" style="width:100%;border-radius:12px;border:1px solid var(--line)"></a>`).join('')}</div>` : ''}</div></article></div>`;
  }

  async function showUserDetail(uid) {
    modalRoot.innerHTML = `<div class="admin-modal-backdrop"><article class="admin-modal"><header class="modal-head"><h2>Informasi pengguna</h2><button data-modal-close>×</button></header><div class="modal-body">${loadingMarkup('Membaca koleksi pengguna...')}</div></article></div>`;
    try {
      const user = await service.adminGetUserDetails(uid);
      const counts = user.collectionCounts || {};
      const history = user.recentHistory || [];
      modalRoot.innerHTML = `<div class="admin-modal-backdrop" data-modal-backdrop><article class="admin-modal"><header class="modal-head"><h2>Informasi pengguna</h2><button data-modal-close>×</button></header><div class="modal-body"><div class="user-detail-head">${avatar(user)}<div><h3>${esc(user.fullName)}</h3><p>@${esc(user.username || '-')} • ${esc(user.role.toUpperCase())} • ${esc(user.email || '-')}</p></div></div><div class="detail-grid"><div class="detail-item"><span>UID</span><b>${esc(user.uid)}</b></div><div class="detail-item"><span>Status</span><b>${statusPill(user.status)}</b></div><div class="detail-item"><span>Dibuat</span><b>${formatDate(user.createdAtMs || user.createdAtIso)}</b></div><div class="detail-item"><span>Terakhir aktif</span><b>${formatDate(user.lastSeenAtMs)}</b></div><div class="detail-item"><span>Total pemutaran</span><b>${number(user.listeningSummary?.plays)}</b></div><div class="detail-item"><span>Waktu mendengarkan</span><b>${formatDuration(user.listeningSummary?.totalSeconds)}</b></div><div class="detail-item"><span>Provider</span><b>${esc((user.providers || []).join(', ') || '-')}</b></div><div class="detail-item"><span>Onboarding</span><b>${user.onboardingCompleted ? 'Selesai' : 'Belum selesai'}</b></div></div><h3 class="modal-section-title">Koleksi Firebase</h3><div class="collection-counts"><div><b>${number(counts.favorites)}</b><span>FAVORIT</span></div><div><b>${number(counts.history)}</b><span>RIWAYAT</span></div><div><b>${number(counts.downloads)}</b><span>UNDUHAN</span></div><div><b>${number(counts.artists)}</b><span>ARTIS</span></div><div><b>${number(counts.playlists)}</b><span>PLAYLIST</span></div></div><h3 class="modal-section-title">Artis pilihan</h3><p style="color:#abb3a6;font-size:10px;line-height:1.6">${esc((user.selectedArtists || []).join(' • ') || 'Belum memilih artis.')}</p><h3 class="modal-section-title">Riwayat terbaru</h3>${history.length ? `<div class="data-list">${history.map(track => `<div class="data-row"><div class="data-primary">${track.thumbnail ? `<span class="avatar"><img src="${esc(track.thumbnail)}" alt=""></span>` : '<span class="avatar">♪</span>'}<div><strong>${esc(track.title)}</strong><small>${esc(track.artist)}${track.duration ? ` • ${esc(track.duration)}` : ''}</small></div></div></div>`).join('')}</div>` : '<div class="empty-state" style="min-height:150px"><div><b>Belum ada riwayat</b>Riwayat pemutaran belum tersinkron.</div></div>'}</div></article></div>`;
    } catch (error) {
      const body = modalRoot.querySelector('.modal-body');
      if (body) body.innerHTML = `<div class="error-panel"><h3>Data gagal dibuka</h3><p>${esc(errorMessage(error))}</p></div>`;
    }
  }

  root.addEventListener('click', async event => {
    const target = event.target.closest('button,[data-user-detail],[data-report-detail]');
    if (!target) return;
    if (target.dataset.authMode) {
      state.authMode = target.dataset.authMode;
      state.authError = '';
      renderAuth();
      return;
    }
    if (target.hasAttribute('data-admin-otp-cancel')) {
      state.pendingOtp = null; state.pendingRegistration = null; state.authError = ''; renderAuth(); return;
    }
    if (target.hasAttribute('data-admin-otp-resend')) {
      target.disabled = true;
      try { state.pendingOtp = { ...state.pendingOtp, ...(await service.resendOtp(state.pendingOtp?.challengeId)) }; toast('Kode baru berhasil dikirim.'); renderAuth(); }
      catch (error) { toast(errorMessage(error), 'error'); target.disabled = false; }
      return;
    }
    if (target.dataset.togglePassword) {
      const input = document.getElementById(target.dataset.togglePassword);
      if (input) { input.type = input.type === 'password' ? 'text' : 'password'; target.textContent = input.type === 'password' ? 'Lihat' : 'Tutup'; }
      return;
    }
    if (target.hasAttribute('data-google-auth')) { await handleGoogleAuth(target); return; }
    if (target.hasAttribute('data-forgot-password')) {
      const email = root.querySelector('input[name="email"]')?.value || window.prompt('Masukkan email akun DATZON:') || '';
      if (!email) return;
      try { await service.sendResetEmail(email); toast('Link reset password telah dikirim.'); }
      catch (error) { toast(errorMessage(error), 'error'); }
      return;
    }
    if (target.hasAttribute('data-auth-logout') || target.hasAttribute('data-admin-logout')) {
      try { await service.logout(); } catch (error) { toast(errorMessage(error), 'error'); }
      return;
    }
    if (target.hasAttribute('data-open-main')) { window.location.href = '/home'; return; }
    if (target.dataset.section) {
      state.section = target.dataset.section;
      renderAppShell();
      return;
    }
    if (target.hasAttribute('data-admin-refresh')) { await loadDashboard(true); return; }
    if (target.dataset.userRole) { state.userRoleFilter = target.dataset.userRole; renderSection(); return; }
    if (target.dataset.reportFilter) { state.reportFilter = target.dataset.reportFilter; renderSection(); return; }
    if (target.dataset.userDetail) { await showUserDetail(target.dataset.userDetail); return; }
    if (target.dataset.reportDetail) { showReportDetail(target.dataset.reportDetail); return; }
    if (target.dataset.reportConfirm) { await reportAction(target.dataset.reportConfirm, 'confirm', target); return; }
    if (target.dataset.reportFix) {
      if (!window.confirm('Tandai laporan sebagai selesai dan kirim pengumuman kepada pengguna?')) return;
      await reportAction(target.dataset.reportFix, 'fix', target);
      return;
    }
    if (target.dataset.announcementDelete) {
      if (!window.confirm('Hapus notifikasi global ini?')) return;
      setButtonBusy(target, true, 'Menghapus...');
      try { await service.adminDeleteAnnouncement(target.dataset.announcementDelete); toast('Notifikasi dihapus.'); await loadDashboard(true); }
      catch (error) { toast(errorMessage(error), 'error'); setButtonBusy(target, false); }
    }
  });

  root.addEventListener('submit', event => {
    const form = event.target.closest('form');
    if (!form) return;
    event.preventDefault();
    if (form.dataset.authForm) submitAuthForm(form);
    else if (form.dataset.announcementForm) sendAnnouncement(form);
  });

  root.addEventListener('input', event => {
    if (!event.target.matches('[data-user-search]')) return;
    state.userSearch = event.target.value;
    const position = event.target.selectionStart;
    renderSection();
    const input = root.querySelector('[data-user-search]');
    if (input) { input.focus(); input.setSelectionRange(position, position); }
  });

  modalRoot.addEventListener('click', event => {
    if (event.target.closest('[data-modal-close]') || event.target.matches('[data-modal-backdrop]')) modalRoot.innerHTML = '';
  });

  if (!service) {
    state.authError = 'Firebase Service tidak ditemukan. Pastikan firebase-service.js termuat.';
    renderAuth();
    hideBoot();
    return;
  }

  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => navigator.serviceWorker.register('/sw.js').catch(() => {}));
  }

  service.onAuthChanged(async detail => {
    if (detail.authResolved === false) return;
    state.authResolved = true;
    state.user = detail.user || null;
    state.profile = detail.profile || null;
    hideBoot();
    if (detail.error && !detail.profile) {
      state.authError = errorMessage(detail.error);
      renderAuth();
      return;
    }
    if (!detail.user) {
      state.data = null;
      state.dataError = '';
      renderAuth();
      return;
    }
    if (detail.user && !detail.profile) {
      window.location.replace('/register');
      return;
    }
    if (String(detail.profile?.role || '').toLowerCase() !== 'admin') {
      renderRedirect(detail.profile);
      return;
    }
    renderAppShell();
    await loadDashboard(false);
  });

  service.ready.catch(error => {
    state.authError = errorMessage(error);
    renderAuth();
    hideBoot();
  });
})();
