const CACHE='datzon-music-v1.62.9';
const SHELL=[
  '/', '/index.html', '/admin.html',
  '/styles.css?v=1.62.9', '/admin.css?v=1.62.9',
  '/firebase-service.js?v=1.62.9', '/spotify-catalog-client.js?v=1.62.9', '/search-aggregator.js?v=1.62.9', '/entity-merger.js?v=1.62.9', '/catalog-ui.js?v=1.62.9',
  '/dominant-color.js?v=1.62.9', '/audio-lab.js?v=1.62.9', '/music-code.js?v=1.62.9', '/app.js?v=1.62.9', '/admin.js?v=1.62.9',
  '/manifest.webmanifest','/assets/datzon-logo.png','/assets/favicon-48.png','/assets/icon-192.png','/assets/icon-512.png','/assets/icon.svg','/assets/placeholder.svg',
  '/assets/firebase-logo.png','/assets/api-cmnty.png','/assets/api-sylvatica.png','/assets/api-spotify.png','/assets/api-firebase.png','/assets/api-cloudinary.png'
];
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(SHELL)).then(()=>self.skipWaiting())));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(key=>key!==CACHE).map(key=>caches.delete(key)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',event=>{
  const request=event.request;
  const url=new URL(request.url);
  if(url.origin!==self.location.origin||request.method!=='GET')return;
  if(request.mode==='navigate'){
    const fallback=url.pathname.startsWith('/admin')?'/admin.html':'/index.html';
    event.respondWith(fetch(request).then(response=>response.ok?response:Promise.reject(new Error('navigation failed'))).catch(()=>caches.match(fallback)));
    return;
  }
  if(url.pathname==='/firebase-config.js'){
    event.respondWith(fetch(request,{cache:'no-store'}));
    return;
  }
  // Serverless APIs control their own cache. Never freeze API metadata/audio in PWA Cache Storage.
  if(url.pathname.startsWith('/api/')){
    event.respondWith(fetch(request));
    return;
  }
  const isShell=/\.(?:html|css|js|webmanifest)$/.test(url.pathname);
  if(isShell){
    event.respondWith(fetch(request).then(response=>{const copy=response.clone();caches.open(CACHE).then(cache=>cache.put(request,copy));return response;}).catch(()=>caches.match(request)));
    return;
  }
  event.respondWith(caches.match(request).then(cached=>cached||fetch(request).then(response=>{const copy=response.clone();caches.open(CACHE).then(cache=>cache.put(request,copy));return response;})));
});
