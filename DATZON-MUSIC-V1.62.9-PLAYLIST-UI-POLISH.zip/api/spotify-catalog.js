import album from '../server/spotify-catalog/album.js';
import artistBasic from '../server/spotify-catalog/artist-basic.js';
import artist from '../server/spotify-catalog/artist.js';
import artistsSearch from '../server/spotify-catalog/artists-search.js';
import enrichTracks from '../server/spotify-catalog/enrich-tracks.js';
import health from '../server/spotify-catalog/health.js';
import playlist from '../server/spotify-catalog/playlist.js';
import search from '../server/spotify-catalog/search.js';
import track from '../server/spotify-catalog/track.js';

const HANDLERS = Object.freeze({
  album,
  'artist-basic': artistBasic,
  artist,
  'artists-search': artistsSearch,
  'enrich-tracks': enrichTracks,
  health,
  playlist,
  search,
  track
});

function actionOf(request) {
  const direct = String(request.query?.action || '').trim().toLowerCase();
  if (direct) return direct;
  try { return String(new URL(request.url, 'http://localhost').searchParams.get('action') || '').trim().toLowerCase(); }
  catch { return ''; }
}

export default async function handler(request, response) {
  const action = actionOf(request);
  const target = HANDLERS[action];
  if (!target) return response.status(404).json({ ok:false, error:'Endpoint Spotify Catalog tidak tersedia.' });
  return target(request, response);
}
