export const config = { runtime: 'edge' };

function json(payload, status = 200) {
  return new Response(JSON.stringify(payload), {
    status,
    headers:{
      'content-type':'application/json; charset=utf-8',
      'cache-control':'public, max-age=60, s-maxage=180'
    }
  });
}

function cleanSuggestion(value) {
  return String(value || '').replace(/\s+/g, ' ').trim();
}

export default async function handler(request) {
  const url = new URL(request.url);
  const q = cleanSuggestion(url.searchParams.get('q'));
  const limit = Math.max(1, Math.min(12, Number(url.searchParams.get('limit') || 8)));
  if (q.length < 2) return json({ status:true, suggestions:[] });

  const sources = [
    `https://suggestqueries.google.com/complete/search?client=firefox&ds=yt&hl=id&q=${encodeURIComponent(q)}`,
    `https://suggestqueries.google.com/complete/search?client=firefox&hl=id&q=${encodeURIComponent(q)}`
  ];

  for (const source of sources) {
    try {
      const response = await fetch(source, {
        headers:{ Accept:'application/json', 'Accept-Language':'id-ID,id;q=0.9,en;q=0.6' },
        cache:'no-store',
        redirect:'follow'
      });
      if (!response.ok) continue;
      const data = await response.json();
      const list = Array.isArray(data?.[1]) ? data[1] : [];
      const suggestions = [...new Set(list.map(cleanSuggestion).filter(Boolean))].slice(0, limit);
      if (suggestions.length) return json({ status:true, suggestions });
    } catch {}
  }

  const fallback = [
    q,
    `${q} lyrics`,
    `${q} remix`,
    `${q} slowed`,
    `${q} karaoke`
  ].map(cleanSuggestion);
  return json({ status:true, suggestions:[...new Set(fallback)].slice(0, limit), fallback:true });
}
