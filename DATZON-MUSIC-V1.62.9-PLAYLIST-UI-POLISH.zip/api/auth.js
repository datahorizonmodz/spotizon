import { authErrorResponse, otpConfigSummary, resendOtp, startOtp, verifyOtp } from '../server/auth/otp-core.js';
import { playlistSyncErrorResponse, readAccessibleProfilePlaylists, syncPlaylistDirectory } from '../server/auth/playlist-sync.js';

function actionOf(request) {
  const direct = String(request.query?.action || '').trim().toLowerCase();
  if (direct) return direct;
  try { return String(new URL(request.url, 'http://localhost').searchParams.get('action') || '').trim().toLowerCase(); }
  catch { return ''; }
}

function parseBody(request) {
  if (!request.body) return {};
  if (typeof request.body === 'object') return request.body;
  try { return JSON.parse(String(request.body)); }
  catch { return {}; }
}

export default async function handler(request, response) {
  response.setHeader('Cache-Control', 'no-store, max-age=0');
  response.setHeader('X-Content-Type-Options', 'nosniff');
  const action = actionOf(request);
  if (request.method === 'GET' && action === 'health') {
    return response.status(200).json({ ok:true, service:'spotizon-auth', ...otpConfigSummary() });
  }
  if (request.method !== 'POST') return response.status(405).json({ ok:false, code:'method_not_allowed', error:'Method tidak didukung.' });
  const body = parseBody(request);
  try {
    let result;
    if (action === 'otp-send') result = await startOtp(request, body);
    else if (action === 'otp-resend') result = await resendOtp(request, body);
    else if (action === 'otp-verify') result = await verifyOtp(request, body);
    else if (action === 'playlist-sync') result = await syncPlaylistDirectory(request, body);
    else if (action === 'playlist-profile') result = await readAccessibleProfilePlaylists(request, body);
    else return response.status(404).json({ ok:false, code:'not_found', error:'Endpoint autentikasi tidak tersedia.' });
    return response.status(200).json({ ok:true, ...result });
  } catch (error) {
    const mapped = (action === 'playlist-sync' || action === 'playlist-profile') ? playlistSyncErrorResponse(error) : authErrorResponse(error);
    return response.status(mapped.status).json(mapped.body);
  }
}
