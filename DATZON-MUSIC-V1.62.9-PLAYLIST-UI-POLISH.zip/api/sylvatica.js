import { proxySylvatica } from '../server/sylvatica-proxy.js';
import spotyloaderHandler from '../server/sylvatica-spotyloader.js';

function actionOf(request) {
  const direct = String(request.query?.action || '').trim().toLowerCase();
  if (direct) return direct;
  try { return String(new URL(request.url, 'http://localhost').searchParams.get('action') || '').trim().toLowerCase(); }
  catch { return ''; }
}

export default async function handler(request, response) {
  const action = actionOf(request);
  if (action === 'spotyloader') return spotyloaderHandler(request, response);
  if (['download', 'search', 'lyrics'].includes(action)) return proxySylvatica(request, response, action);
  return response.status(404).json({ status:false, message:'Endpoint Sylvatica tidak tersedia.' });
}
