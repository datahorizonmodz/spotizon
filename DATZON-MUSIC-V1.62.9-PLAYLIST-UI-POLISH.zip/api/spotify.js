import { onRequestGet as collection } from '../cloud-functions/api/spotify/collection.js';
import { onRequestGet as health } from '../cloud-functions/api/spotify/health.js';
import { onRequestGet as homeCollections } from '../cloud-functions/api/spotify/home-collections.js';
import { onRequestGet as trackMeta } from '../cloud-functions/api/spotify/track-meta.js';
import { bridgeEdgeGet } from '../server/vercel-edge-bridge.js';

const HANDLERS = Object.freeze({
  collection,
  health,
  'home-collections': homeCollections,
  'track-meta': trackMeta
});

function actionOf(request) {
  const direct = String(request.query?.action || '').trim().toLowerCase();
  if (direct) return direct;
  try { return String(new URL(request.url, 'http://localhost').searchParams.get('action') || '').trim().toLowerCase(); }
  catch { return ''; }
}

export default async function handler(request, response) {
  const action = actionOf(request);
  const target = HANDLERS[action];
  if (!target) return response.status(404).json({ ok:false, error:'Endpoint Spotify internal tidak tersedia.' });
  return bridgeEdgeGet(request, response, target);
}
