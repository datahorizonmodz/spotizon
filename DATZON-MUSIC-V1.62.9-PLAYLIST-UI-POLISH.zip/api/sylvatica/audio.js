const API_BASE = 'https://sylvatica.my.id';
const API_KEY = process.env.SYLVATICA_API_KEY || '';

export const config = { runtime: 'edge' };

function json(payload, status = 200) {
  return new Response(JSON.stringify(payload), {
    status,
    headers:{ 'content-type':'application/json; charset=utf-8', 'cache-control':'no-store, max-age=0' }
  });
}

function validSpotifyTrack(value) {
  return /^https:\/\/open\.spotify\.com\/track\/[A-Za-z0-9]{22}(?:[?/#].*)?$/i.test(String(value || '').trim());
}

function isMediaHttpUrl(value) {
  if (typeof value !== 'string') return '';
  const text = value.trim();
  if (!/^https?:\/\//i.test(text)) return '';
  if (/open\.spotify\.com|spotify\.com\/track/i.test(text)) return '';
  return text;
}

function findPreferredMediaUrl(value, depth = 0, seen = new Set()) {
  if (value == null || depth > 9) return '';
  if (typeof value === 'string') return isMediaHttpUrl(value);
  if (typeof value !== 'object' || seen.has(value)) return '';
  seen.add(value);

  const preferred = [
    'downloadUrl','download_url','audioUrl','audio_url','mp3Url','mp3_url',
    'streamUrl','stream_url','playUrl','play_url','downloadLink','download_link',
    'download','audio','mp3','stream','play','file'
  ];
  if (!Array.isArray(value)) {
    for (const key of preferred) {
      if (Object.prototype.hasOwnProperty.call(value, key)) {
        const found = findPreferredMediaUrl(value[key], depth + 1, seen);
        if (found) return found;
      }
    }
  }
  for (const child of (Array.isArray(value) ? value : Object.values(value))) {
    const found = findPreferredMediaUrl(child, depth + 1, seen);
    if (found) return found;
  }
  return '';
}

export default async function handler(request) {
  const method = String(request.method || 'GET').toUpperCase();
  if (!['GET','HEAD'].includes(method)) return json({ status:false, message:'Metode tidak didukung.' }, 405);

  if (!API_KEY) return json({ status:false, message:'SYLVATICA_API_KEY belum dikonfigurasi di Environment Variables.' }, 503);

  const incoming = new URL(request.url);
  const spotifyUrl = String(incoming.searchParams.get('url') || '').trim();
  if (!validSpotifyTrack(spotifyUrl)) return json({ status:false, message:'URL Spotify track tidak valid.' }, 400);

  const resolver = new URL('/api/download/spotyloader', API_BASE);
  resolver.searchParams.set('url', spotifyUrl);
  resolver.searchParams.set('type', 'track');
  resolver.searchParams.set('format', 'mp3');
  resolver.searchParams.set('apikey', API_KEY);

  let resolved;
  try {
    resolved = await fetch(resolver, { headers:{ Accept:'application/json' }, cache:'no-store', redirect:'follow' });
  } catch (error) {
    return json({ status:false, message:'Sylvatica tidak dapat dihubungi.', error:String(error?.message || error || '') }, 502);
  }

  const raw = await resolved.text();
  let data = {};
  try { data = raw ? JSON.parse(raw) : {}; } catch { data = { message:raw }; }
  if (!resolved.ok) return json({ status:false, message:data?.message || `Sylvatica HTTP ${resolved.status}` }, resolved.status);

  const audioUrl = findPreferredMediaUrl(data);
  if (!audioUrl) return json({ status:false, message:'Sylvatica tidak mengirim URL audio penuh.' }, 502);

  let audioTarget;
  try {
    audioTarget = new URL(audioUrl);
    if (!['http:','https:'].includes(audioTarget.protocol)) throw new Error('protocol');
  } catch {
    return json({ status:false, message:'URL audio Sylvatica tidak valid.' }, 502);
  }

  const headers = new Headers({
    Accept:'*/*',
    Referer:'https://sylvatica.my.id/'
  });
  const range = request.headers.get('range');
  if (range) headers.set('Range', range);

  let media;
  try {
    media = await fetch(audioTarget, {
      method,
      headers,
      redirect:'follow',
      cache:'no-store'
    });
  } catch (error) {
    return json({ status:false, message:'CDN audio Sylvatica tidak dapat dihubungi.', error:String(error?.message || error || '') }, 502);
  }

  const out = new Headers();
  for (const key of ['content-type','content-length','content-range','accept-ranges','etag','last-modified']) {
    const value = media.headers.get(key);
    if (value) out.set(key, value);
  }
  if (!out.has('content-type')) out.set('content-type','audio/mpeg');
  if (!out.has('accept-ranges')) out.set('accept-ranges','bytes');
  out.set('cache-control','no-store, max-age=0');

  return new Response(method === 'HEAD' ? null : media.body, { status:media.status, headers:out });
}
