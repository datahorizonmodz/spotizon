const THERESAV_API_BASE = 'https://api.theresav.eu';
const THERESAV_API_KEY = process.env.THERESAV_API_KEY || '';

export const config = { runtime: 'edge' };

function scalarHttpUrl(value, depth = 0, seen = new Set()) {
  if (depth > 5 || value == null) return '';
  if (typeof value === 'string') {
    const text = value.trim();
    return /^https?:\/\//i.test(text) && !/open\.spotify\.com\//i.test(text) ? text : '';
  }
  if (typeof value !== 'object' || seen.has(value)) return '';
  seen.add(value);
  if (Array.isArray(value)) {
    for (const item of value) {
      const found = scalarHttpUrl(item, depth + 1, seen);
      if (found) return found;
    }
    return '';
  }
  for (const key of ['url','href','src','downloadUrl','download_url','audioUrl','audio_url','mp3Url','mp3_url','streamUrl','stream_url','playUrl','play_url']) {
    if (Object.prototype.hasOwnProperty.call(value, key)) {
      const found = scalarHttpUrl(value[key], depth + 1, seen);
      if (found) return found;
    }
  }
  for (const child of Object.values(value)) {
    const found = scalarHttpUrl(child, depth + 1, seen);
    if (found) return found;
  }
  return '';
}

function findAudioUrl(value, depth = 0, seen = new Set()) {
  if (depth > 8 || value == null || typeof value !== 'object' || seen.has(value)) return '';
  seen.add(value);
  const preferred = [
    'downloadUrl','download_url','audioUrl','audio_url','mp3Url','mp3_url',
    'streamUrl','stream_url','playUrl','play_url','download','audio','mp3','stream','play'
  ];
  for (const key of preferred) {
    if (Object.prototype.hasOwnProperty.call(value, key)) {
      const found = scalarHttpUrl(value[key]);
      if (found) return found;
    }
  }
  const children = Array.isArray(value) ? value : Object.values(value);
  for (const child of children) {
    const found = findAudioUrl(child, depth + 1, seen);
    if (found) return found;
  }
  return '';
}

function json(payload, status = 200) {
  return new Response(JSON.stringify(payload), {
    status,
    headers: {
      'content-type': 'application/json; charset=utf-8',
      'cache-control': 'no-store, max-age=0'
    }
  });
}

export default async function handler(request) {
  const method = String(request.method || 'GET').toUpperCase();
  if (!['GET', 'HEAD'].includes(method)) return json({ status:false, message:'Metode tidak didukung.' }, 405);

  if (!THERESAV_API_KEY) return json({ status:false, message:'THERESAV_API_KEY belum dikonfigurasi di Environment Variables.' }, 503);

  const requestUrl = new URL(request.url);
  const spotifyUrl = String(requestUrl.searchParams.get('url') || '').trim();
  if (!/^https:\/\/open\.spotify\.com\/track\/[A-Za-z0-9]{22}(?:[?/#].*)?$/i.test(spotifyUrl)) {
    return json({ status:false, message:'URL Spotify track tidak valid.' }, 400);
  }

  const resolver = new URL(`${THERESAV_API_BASE}/api/download/spotify`);
  resolver.searchParams.set('url', spotifyUrl);

  let providerResponse;
  try {
    providerResponse = await fetch(resolver, {
      method: 'GET',
      headers: { 'accept':'application/json', 'x-apikey': THERESAV_API_KEY },
      cache: 'no-store',
      redirect: 'follow'
    });
  } catch (error) {
    return json({ status:false, message:'Theresav tidak dapat dihubungi.', error:String(error?.message || error || '') }, 502);
  }

  const raw = await providerResponse.text();
  let data = {};
  try { data = raw ? JSON.parse(raw) : {}; } catch { data = { message: raw }; }
  if (!providerResponse.ok) {
    return json({ status:false, message:data?.message || `Theresav HTTP ${providerResponse.status}` }, providerResponse.status);
  }

  const audioUrl = findAudioUrl(data);
  if (!audioUrl) return json({ status:false, message:'Theresav tidak mengirim URL audio penuh.' }, 502);

  const mediaHeaders = new Headers({
    'accept': '*/*',
    'referer': 'https://api.theresav.eu/'
  });
  const range = request.headers.get('range');
  if (range) mediaHeaders.set('range', range);

  let media;
  try {
    media = await fetch(audioUrl, {
      method,
      headers: mediaHeaders,
      redirect: 'follow',
      cache: 'no-store'
    });
  } catch (error) {
    return json({ status:false, message:'CDN audio tidak dapat dihubungi.', error:String(error?.message || error || '') }, 502);
  }

  const headers = new Headers();
  for (const key of ['content-type','content-length','content-range','accept-ranges','etag','last-modified']) {
    const value = media.headers.get(key);
    if (value) headers.set(key, value);
  }
  if (!headers.has('content-type')) headers.set('content-type', 'audio/mpeg');
  if (!headers.has('accept-ranges')) headers.set('accept-ranges', 'bytes');
  headers.set('cache-control', 'no-store, max-age=0');

  return new Response(method === 'HEAD' ? null : media.body, {
    status: media.status,
    headers
  });
}
