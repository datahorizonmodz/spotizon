import { proxyTheresav } from '../server/theresav-proxy.js';

function actionOf(request) {
  const direct = String(request.query?.action || '').trim().toLowerCase();
  if (direct) return direct;
  try { return String(new URL(request.url, 'http://localhost').searchParams.get('action') || '').trim().toLowerCase(); }
  catch { return ''; }
}

export default async function handler(request, response) {
  const action = actionOf(request);
  if (!['search', 'download'].includes(action)) {
    return response.status(404).json({ status:false, message:'Endpoint Theresav tidak tersedia.' });
  }
  return proxyTheresav(request, response, action);
}
