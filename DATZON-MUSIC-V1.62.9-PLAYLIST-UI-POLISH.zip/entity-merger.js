(() => {
  'use strict';
  const normalize=value=>String(value||'').normalize('NFKD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/\b(featuring|feat\.?|ft\.?)\b/g,' feat ').replace(/[^a-z0-9]+/g,' ').trim();
  const versionTags=['remix','live','instrumental','acoustic','sped up','slowed','karaoke','radio edit','demo','remaster','version'];
  const version=value=>{const text=normalize(value);return versionTags.filter(tag=>text.includes(tag)).sort().join('|');};
  // Feat./ft./featuring differences are metadata noise, not a different recording.
  // Version tags are checked separately so Remix/Live/Instrumental/etc remain distinct.
  const titleCore=value=>normalize(value).replace(/\s+feat\s+.*$/,'').trim();
  const durationMs=item=>Math.max(0,Number(item?.durationMs||item?.duration_ms||0)||0);
  function sameTrack(a={},b={}){
    const isrcA=String(a?.isrc||'').toUpperCase(),isrcB=String(b?.isrc||'').toUpperCase();
    if(isrcA&&isrcB)return isrcA===isrcB;
    const idA=String(a?.spotifyId||a?.spotifyTrackId||''),idB=String(b?.spotifyId||b?.spotifyTrackId||'');
    if(idA&&idB)return idA===idB;
    if(version(a?.title)!==version(b?.title))return false;
    if(titleCore(a?.title)!==titleCore(b?.title))return false;
    if(normalize(a?.primaryArtist)!==normalize(b?.primaryArtist))return false;
    const da=durationMs(a),db=durationMs(b);
    return !(da&&db&&Math.abs(da-db)>3000);
  }
  function mergeByStableId(items=[],idKeys=['id']){
    const map=new Map();
    for(const item of items){const id=idKeys.map(key=>String(item?.[key]||'')).find(Boolean);if(id&&!map.has(id))map.set(id,item);}
    return [...map.values()];
  }
  window.DatzonEntityMerger=Object.freeze({normalize,titleCore,version,sameTrack,mergeByStableId});
})();
