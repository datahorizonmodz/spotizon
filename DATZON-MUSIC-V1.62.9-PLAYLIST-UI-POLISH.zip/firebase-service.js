'use strict';

(function createDatzonFirebaseService() {
  const rootConfig = window.DATZON_FIREBASE_CONFIG || {};
  const firebaseConfig = rootConfig.firebase || {};
  const cloudinaryConfig = rootConfig.cloudinary || {};
  const MUSIC_APP_ID = 'DATZON Music';
  const MUSIC_SCHEMA_VERSION = 3;
  const MUSIC_USERNAME_COLLECTION = 'usernames';
  const LEGACY_MUSIC_USERNAME_COLLECTION = 'musicUsernames';
  const SDK_VERSIONS = Object.freeze(['12.11.0', '11.10.0', '10.12.5']);
  const configured = Boolean(
    firebaseConfig.apiKey &&
    firebaseConfig.authDomain &&
    firebaseConfig.projectId &&
    firebaseConfig.appId
  );

  let modules = null;
  let app = null;
  let auth = null;
  let db = null;
  let profile = null;
  let pendingGoogleCredential = null;
  let heartbeatTimer = null;
  let syncTimer = null;
  let queuedSnapshot = null;
  let initError = null;
  let loadedSdkVersion = '';
  let authResolved = false;
  let passwordOtpBootstrap = false;
  const listeners = new Set();

  function emit(user = auth?.currentUser || null) {
    const detail = { configured, ready: Boolean(auth && db), authResolved, user, profile, error: initError };
    listeners.forEach(listener => {
      try { listener(detail); } catch {}
    });
    window.dispatchEvent(new CustomEvent('datzon-auth-changed', { detail }));
  }

  function onAuthChanged(listener) {
    if (typeof listener !== 'function') return () => {};
    listeners.add(listener);
    queueMicrotask(() => emit());
    return () => listeners.delete(listener);
  }

  function assertConfigured() {
    if (!configured) {
      const error = new Error('Firebase belum dikonfigurasi. Isi firebase-config.js terlebih dahulu.');
      error.code = 'datzon/firebase-not-configured';
      throw error;
    }
    if (!auth || !db || !modules) {
      const error = new Error('Firebase masih dimuat. Coba kembali beberapa detik lagi.');
      error.code = 'datzon/firebase-not-ready';
      throw error;
    }
  }

  function assertUser() {
    assertConfigured();
    const user = auth.currentUser;
    if (!user) {
      const error = new Error('Silakan login terlebih dahulu.');
      error.code = 'auth/requires-recent-login';
      throw error;
    }
    return user;
  }

  function normalizeUsername(value = '') {
    return String(value)
      .trim()
      .replace(/^@+/, '')
      .toLowerCase()
      .replace(/[^a-z0-9._]/g, '')
      .replace(/\.{2,}/g, '.')
      .slice(0, 24);
  }

  function validateUsername(value = '') {
    const normalized = normalizeUsername(value);
    if (normalized.length < 3) throw new Error('Username minimal 3 karakter.');
    if (!/^[a-z0-9][a-z0-9._]{1,22}[a-z0-9]$/.test(normalized)) {
      throw new Error('Username hanya boleh memakai huruf kecil, angka, titik, dan garis bawah.');
    }
    return normalized;
  }

  function firebaseErrorMessage(error) {
    const code = String(error?.code || '');
    const map = {
      'auth/invalid-credential': 'Email atau password salah.',
      'auth/wrong-password': 'Password lama salah.',
      'auth/user-not-found': 'Akun dengan email tersebut tidak ditemukan.',
      'auth/email-already-in-use': 'Email tersebut sudah digunakan.',
      'auth/weak-password': 'Password minimal 6 karakter.',
      'auth/invalid-email': 'Format email tidak valid.',
      'auth/popup-closed-by-user': 'Login Google dibatalkan.',
      'auth/popup-blocked': 'Popup Google diblokir browser. Izinkan popup lalu coba lagi.',
      'auth/too-many-requests': 'Terlalu banyak percobaan. Coba lagi beberapa saat nanti.',
      'auth/requires-recent-login': 'Silakan login ulang untuk melanjutkan.',
      'auth/network-request-failed': 'Koneksi ke Firebase terputus.',
      'auth/operation-not-allowed': 'Metode login ini belum diaktifkan di Firebase Authentication.',
      'auth/unauthorized-domain': 'Domain website belum diizinkan pada Firebase Authentication.',
      'auth/configuration-not-found': 'Konfigurasi Firebase Authentication belum tersedia.',
      'auth/admin-restricted-operation': 'Pembuatan akun dibatasi oleh konfigurasi Firebase.',
      'auth/internal-error': 'Firebase mengalami kesalahan internal. Coba beberapa saat lagi.',
      'datzon/firebase-not-ready': 'Firebase belum selesai dimuat. Coba kembali beberapa detik lagi.',
      'datzon/username-not-found': 'Username tidak ditemukan.',
      'datzon/username-email-missing': 'Email login belum tersimpan. Masuk dengan email sekali.',
      'permission-denied': 'Akses Firebase ditolak oleh aturan keamanan.',
      'unavailable': 'Firebase sedang tidak dapat dijangkau.'
    };
    return map[code] || error?.message || 'Terjadi kesalahan pada Firebase.';
  }

  async function loadModules() {
    let lastError = null;
    for (const version of SDK_VERSIONS) {
      const base = `https://www.gstatic.com/firebasejs/${version}`;
      try {
        const [appModule, authModule, firestoreModule] = await Promise.all([
          import(`${base}/firebase-app.js`),
          import(`${base}/firebase-auth.js`),
          import(`${base}/firebase-firestore.js`)
        ]);
        loadedSdkVersion = version;
        return { app: appModule, auth: authModule, firestore: firestoreModule };
      } catch (error) {
        lastError = error;
      }
    }
    throw lastError || new Error('Firebase SDK gagal dimuat.');
  }

  function isDatzonMusicProfileData(data = {}) {
    return Number(data.musicProfileVersion || 0) >= 1
      || (typeof data.username === 'string' && data.username.length >= 3 && (
        typeof data.onboardingCompleted === 'boolean'
        || Array.isArray(data.selectedArtists)
        || typeof data.preferredStatus === 'string'
        || data.listeningSummary?.totalSeconds != null
      ));
  }

  async function readUserDocument(user = auth?.currentUser) {
    if (!user || !db || !modules) return null;
    const { doc, getDoc } = modules.firestore;
    const snapshot = await getDoc(doc(db, 'users', user.uid));
    if (!snapshot.exists()) return null;
    return { uid: user.uid, ...snapshot.data() };
  }

  async function readProfile(user = auth?.currentUser) {
    const data = await readUserDocument(user);
    return data && isDatzonMusicProfileData(data) ? data : null;
  }

  async function reserveUsername(transaction, uid, nextUsername, previousUsername = '', email = '') {
    const { doc } = modules.firestore;
    const normalized = validateUsername(nextUsername);
    const nextRef = doc(db, MUSIC_USERNAME_COLLECTION, normalized);
    const legacyNextRef = doc(db, LEGACY_MUSIC_USERNAME_COLLECTION, normalized);
    const oldNormalized = normalizeUsername(previousUsername);
    const oldRef = oldNormalized && oldNormalized !== normalized ? doc(db, MUSIC_USERNAME_COLLECTION, oldNormalized) : null;
    const legacyOldRef = oldNormalized && oldNormalized !== normalized ? doc(db, LEGACY_MUSIC_USERNAME_COLLECTION, oldNormalized) : null;
    const nextSnapshot = await transaction.get(nextRef);
    const legacyNextSnapshot = await transaction.get(legacyNextRef);
    const oldSnapshot = oldRef ? await transaction.get(oldRef) : null;
    const legacyOldSnapshot = legacyOldRef ? await transaction.get(legacyOldRef) : null;
    if (
      (nextSnapshot.exists() && nextSnapshot.data()?.uid !== uid)
      || (legacyNextSnapshot.exists() && legacyNextSnapshot.data()?.uid !== uid)
    ) {
      const error = new Error(`Username @${normalized} sudah digunakan.`);
      error.code = 'datzon/username-taken';
      throw error;
    }
    transaction.set(nextRef, { uid, username: normalized, ...(String(email || '').trim() ? { email: String(email).trim().toLowerCase() } : {}), app:MUSIC_APP_ID, schemaVersion:MUSIC_SCHEMA_VERSION, updatedAt: modules.firestore.serverTimestamp() }, { merge: true });
    if (oldRef && oldSnapshot?.exists() && oldSnapshot.data()?.uid === uid) transaction.delete(oldRef);
    if (legacyOldRef && legacyOldSnapshot?.exists() && legacyOldSnapshot.data()?.uid === uid) transaction.delete(legacyOldRef);
    return normalized;
  }

  function normalizeProfileBio(value = '') {
    return String(value || '').trim().slice(0, 180);
  }

  function normalizeProfileSocialLinks(values = []) {
    const output = [];
    const seen = new Set();
    (Array.isArray(values) ? values : []).forEach(value => {
      if (output.length >= 8) return;
      const raw = String(value || '').trim();
      if (!raw) return;
      const candidate = /^[a-z][a-z0-9+.-]*:\/\//i.test(raw) ? raw : `https://${raw}`;
      try {
        const url = new URL(candidate);
        if (!['http:','https:'].includes(url.protocol) || !url.hostname) return;
        url.hash = '';
        const normalized = url.toString();
        if (seen.has(normalized)) return;
        seen.add(normalized);
        output.push(normalized);
      } catch {}
    });
    return output;
  }

  async function createProfileForUser(user, values, options = {}) {
    const { doc, runTransaction, serverTimestamp } = modules.firestore;
    const existingUserData = await readUserDocument(user) || {};
    const nowIso = new Date().toISOString();
    const fullName = String(values.fullName || user.displayName || 'Pengguna DATZON').trim().slice(0, 70);
    const username = validateUsername(values.username);
    const photoURL = String(values.photoURL || user.photoURL || '').slice(0, 1400);
    const selectedArtists = Array.isArray(values.selectedArtists) ? values.selectedArtists.slice(0, 30) : [];
    const bio = normalizeProfileBio(values.bio || '');
    const socialLinks = normalizeProfileSocialLinks(values.socialLinks || []);
    await runTransaction(db, async transaction => {
      await reserveUsername(transaction, user.uid, username, profile?.username || existingUserData.username || '', user.email || values.email || '');
      transaction.set(doc(db, 'users', user.uid), {
        fullName,
        username,
        usernameLower: username,
        photoURL,
        bio,
        socialLinks,
        selectedArtists,
        onboardingCompleted: Boolean(options.onboardingCompleted),
        providers: user.providerData.map(item => item.providerId),
        updatedAt: serverTimestamp(),
        lastSeenAt: serverTimestamp(),
        preferredStatus: 'online',
        status: 'online',
        musicProfileVersion: 1,
        ...(!existingUserData.uid ? { uid:user.uid } : {}),
        ...(!existingUserData.email ? { email:user.email || values.email || '' } : {}),
        ...(!existingUserData.createdAt ? { createdAt:serverTimestamp() } : {}),
        ...(!existingUserData.createdAtIso ? { createdAtIso:options.createdAtIso || nowIso } : {}),
        ...(!existingUserData.role ? { role:'user' } : {})
      }, { merge: true });
    });
    await modules.auth.updateProfile(user, { displayName: fullName, photoURL: photoURL || null });
    profile = await readProfile(user);
    try { await syncUsernameLoginAlias(user, profile); } catch {}
    try { await syncPublicProfile(user, profile); } catch {}
    emit(user);
    return profile;
  }

  async function initialize() {
    if (!configured) {
      authResolved = true;
      emit(null);
      return false;
    }
    try {
      modules = await loadModules();
      app = modules.app.initializeApp(firebaseConfig);
      auth = modules.auth.getAuth(app);
      db = modules.firestore.getFirestore(app);
      await modules.auth.setPersistence(auth, modules.auth.browserLocalPersistence);
      modules.auth.onAuthStateChanged(auth, async user => {
        authResolved = false;
        initError = null;
        stopHeartbeat();
        if (user && passwordOtpBootstrap) {
          // Password credentials are used only long enough to prove the first factor.
          // Do not expose this temporary Firebase session to the application UI.
          authResolved = true;
          return;
        }
        if (user) {
          try {
            const tokenResult = await modules.auth.getIdTokenResult(user).catch(() => null);
            if (tokenResult?.signInProvider === 'password') {
              // V1.61+: direct password sessions must complete server-side OTP first.
              // Resolve this callback before signing out so the UI never hangs on a transient password session.
              profile = null;
              authResolved = true;
              await modules.auth.signOut(auth);
              return;
            }
            profile = await readProfile(user);
            if (profile) { try { await syncUsernameLoginAlias(user, profile); } catch {} startHeartbeat(); }
          } catch (error) {
            initError = error;
            profile = null;
          }
        } else {
          profile = null;
        }
        authResolved = true;
        emit(user);
      });
      return true;
    } catch (error) {
      initError = error;
      authResolved = true;
      emit(null);
      return false;
    }
  }

  const ready = initialize();

  async function waitUntilReady(timeoutMs = 15000) {
    if (!configured) {
      const error = new Error('Firebase belum dikonfigurasi. Isi firebase-config.js terlebih dahulu.');
      error.code = 'datzon/firebase-not-configured';
      throw error;
    }
    if (auth && db && modules) return true;
    let timer = null;
    try {
      await Promise.race([
        ready,
        new Promise((_, reject) => {
          timer = setTimeout(() => {
            const error = new Error(initError?.message || 'Firebase terlalu lama dimuat. Periksa koneksi internet lalu coba lagi.');
            error.code = initError?.code || 'datzon/firebase-not-ready';
            reject(error);
          }, timeoutMs);
        })
      ]);
    } finally {
      if (timer) clearTimeout(timer);
    }
    if (!auth || !db || !modules) {
      const error = new Error(initError?.message || 'Firebase gagal dimuat. Periksa konfigurasi dan koneksi internet.');
      error.code = initError?.code || 'datzon/firebase-not-ready';
      throw error;
    }
    return true;
  }

  async function checkUsername(username) {
    await waitUntilReady();
    const normalized = validateUsername(username);
    const { doc, getDoc } = modules.firestore;
    const [snapshot, legacySnapshot] = await Promise.all([
      getDoc(doc(db, MUSIC_USERNAME_COLLECTION, normalized)),
      getDoc(doc(db, LEGACY_MUSIC_USERNAME_COLLECTION, normalized))
    ]);
    const currentUid = String(auth.currentUser?.uid || '');
    const available = [snapshot, legacySnapshot].every(item => !item.exists() || (currentUid && item.data()?.uid === currentUid));
    return { username: normalized, available };
  }

  async function syncUsernameLoginAlias(user = auth?.currentUser, source = profile || {}) {
    if (!user || !db || !modules) return false;
    const username = normalizeUsername(source?.username || '');
    const email = String(user.email || source?.email || '').trim().toLowerCase();
    if (!username || !email) return false;
    const { doc, getDoc, setDoc, serverTimestamp } = modules.firestore;
    const ref = doc(db, MUSIC_USERNAME_COLLECTION, username);
    const legacyRef = doc(db, LEGACY_MUSIC_USERNAME_COLLECTION, username);
    const [snapshot, legacySnapshot] = await Promise.all([getDoc(ref), getDoc(legacyRef)]);
    if (
      (snapshot.exists() && snapshot.data()?.uid && snapshot.data().uid !== user.uid)
      || (legacySnapshot.exists() && legacySnapshot.data()?.uid && legacySnapshot.data().uid !== user.uid)
    ) return false;
    await setDoc(ref, { uid:user.uid, username, email, app:MUSIC_APP_ID, schemaVersion:MUSIC_SCHEMA_VERSION, updatedAt:serverTimestamp() }, { merge:true });
    return true;
  }

  async function resolveLoginEmail(identifier = '') {
    await waitUntilReady();
    const raw = String(identifier || '').trim();
    if (!raw) throw new Error('Masukkan email atau username.');
    if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(raw)) return raw.toLowerCase();
    const username = validateUsername(raw);
    const { doc, getDoc } = modules.firestore;
    let snapshot = await getDoc(doc(db, MUSIC_USERNAME_COLLECTION, username));
    if (!snapshot.exists()) snapshot = await getDoc(doc(db, LEGACY_MUSIC_USERNAME_COLLECTION, username));
    if (!snapshot.exists()) {
      const error = new Error(`Username @${username} tidak ditemukan.`);
      error.code = 'datzon/username-not-found';
      throw error;
    }
    const email = String(snapshot.data()?.email || '').trim().toLowerCase();
    if (!email) {
      const error = new Error(`@${username} belum memiliki alias email untuk login username. Login memakai email sekali agar alias diperbarui otomatis.`);
      error.code = 'datzon/username-email-missing';
      throw error;
    }
    return email;
  }

  async function otpApi(action, payload = {}) {
    const response = await fetch(`/api/auth/otp/${encodeURIComponent(action)}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
      cache: 'no-store',
      body: JSON.stringify(payload)
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok || data?.ok === false) {
      const error = new Error(data?.error || 'Layanan verifikasi sedang bermasalah.');
      error.code = `otp/${String(data?.code || 'request_failed')}`;
      error.status = response.status;
      throw error;
    }
    return data;
  }

  async function startPasswordOtpLogin(identifier, password, options = {}) {
    await waitUntilReady();
    let temporaryUser = null;
    passwordOtpBootstrap = true;
    try {
      const email = await resolveLoginEmail(identifier);
      const result = await modules.auth.signInWithEmailAndPassword(auth, email, password);
      temporaryUser = result.user;
      const idToken = await modules.auth.getIdToken(result.user, true);
      try { options?.onCredentialValidated?.(); } catch {}

      // The password credential is only the first factor. Close the temporary
      // Firebase client session before waiting on the OTP API so no Firestore
      // listener/read can race against rules that require otpVerified=true.
      try { await modules.auth.signOut(auth); } catch {}
      temporaryUser = null;
      profile = null;
      passwordOtpBootstrap = false;

      const challenge = await otpApi('send', { purpose: 'login', idToken });
      return challenge;
    } catch (error) {
      passwordOtpBootstrap = false;
      if (temporaryUser || auth?.currentUser) {
        try { await modules.auth.signOut(auth); } catch {}
      }
      if (!String(error?.code || '').startsWith('otp/')) {
        const code = String(error?.code || '');
        if (['auth/invalid-credential','auth/wrong-password','auth/user-not-found','datzon/username-not-found','datzon/username-email-missing'].includes(code)) {
          const generic = new Error('Email/username atau password tidak valid.');
          generic.code = 'datzon/invalid-credentials';
          throw generic;
        }
        error.message = firebaseErrorMessage(error);
      }
      throw error;
    }
  }

  async function startRegistrationOtp({ fullName, username, email, password, provider = 'password' }) {
    await waitUntilReady();
    const normalized = validateUsername(username);
    const registration = {
      fullName: String(fullName || '').trim(),
      username: normalized,
      email: String(email || '').trim().toLowerCase(),
      password: String(password || '')
    };
    if (provider === 'google') {
      const user = assertUser();
      if (profile) throw new Error('Akun Google ini sudah mempunyai profil DATZON.');
      const idToken = await modules.auth.getIdToken(user, true);
      return otpApi('send', { purpose: 'register-google', idToken, registration });
    }
    return otpApi('send', { purpose: 'register', registration });
  }

  async function resendOtp(challengeId) {
    await waitUntilReady();
    return otpApi('resend', { challengeId: String(challengeId || '') });
  }

  async function verifyOtp({ challengeId, code, registration = null, provider = '' }) {
    await waitUntilReady();
    const payload = { challengeId: String(challengeId || ''), code: String(code || '') };
    if (registration) payload.registration = {
      fullName: String(registration.fullName || '').trim(),
      username: validateUsername(registration.username),
      email: String(registration.email || '').trim().toLowerCase(),
      password: String(registration.password || '')
    };
    if (provider === 'google') {
      const user = assertUser();
      payload.googleIdToken = await modules.auth.getIdToken(user, true);
    }
    const result = await otpApi('verify', payload);
    if (!result?.customToken) throw new Error('Token sesi setelah verifikasi tidak tersedia.');
    const credential = await modules.auth.signInWithCustomToken(auth, result.customToken);
    profile = await readProfile(credential.user);
    if (profile) {
      try { await syncUsernameLoginAlias(credential.user, profile); } catch {}
      try { await syncPublicProfile(credential.user, profile); } catch {}
      startHeartbeat();
    }
    emit(credential.user);
    return { ...result, user: credential.user, profile };
  }

  async function cancelPendingGoogleRegistration() {
    await waitUntilReady();
    if (auth?.currentUser) {
      try { await modules.auth.signOut(auth); } catch {}
    }
    profile = null;
    emit(null);
    return true;
  }

  async function registerEmail({ fullName, username, email, password }) {
    await waitUntilReady();
    const normalized = validateUsername(username);
    const availability = await checkUsername(normalized);
    if (!availability.available) throw new Error(`Username @${normalized} sudah digunakan.`);
    let credential = null;
    try {
      credential = await modules.auth.createUserWithEmailAndPassword(auth, String(email).trim(), password);
      return await createProfileForUser(credential.user, { fullName, username: normalized, email });
    } catch (error) {
      if (credential?.user && !profile) {
        try { await modules.auth.deleteUser(credential.user); } catch {}
      }
      error.message = firebaseErrorMessage(error);
      throw error;
    }
  }

  async function loginEmail(identifier, password) {
    await waitUntilReady();
    try {
      const email = await resolveLoginEmail(identifier);
      const result = await modules.auth.signInWithEmailAndPassword(auth, email, password);
      profile = await readProfile(result.user);
      if (!profile) {
        return { user: result.user, profile: null, needsSetup: true, provider: 'password' };
      }
      try { await syncUsernameLoginAlias(result.user, profile); } catch {}
      startHeartbeat();
      emit(result.user);
      return { user: result.user, profile, needsSetup: false };
    } catch (error) {
      error.message = firebaseErrorMessage(error);
      throw error;
    }
  }

  async function loginGoogle() {
    await waitUntilReady();
    const provider = new modules.auth.GoogleAuthProvider();
    provider.setCustomParameters({ prompt: 'select_account' });
    try {
      const result = await modules.auth.signInWithPopup(auth, provider);
      profile = await readProfile(result.user);
      if (!profile) {
        return {
          user: result.user,
          profile: null,
          needsSetup: true,
          provider: 'google',
          suggestedFullName: result.user.displayName || '',
          email: result.user.email || '',
          photoURL: result.user.photoURL || ''
        };
      }
      startHeartbeat();
      emit(result.user);
      return { user: result.user, profile, needsSetup: false };
    } catch (error) {
      if (error?.code === 'auth/account-exists-with-different-credential') {
        pendingGoogleCredential = modules.auth.GoogleAuthProvider.credentialFromError(error);
        let methods = [];
        try { methods = await modules.auth.fetchSignInMethodsForEmail(auth, error.customData?.email || ''); } catch {}
        return {
          needsLink: true,
          email: error.customData?.email || '',
          methods,
          message: 'Email ini sudah terdaftar. Masukkan password akun lama untuk menautkan Google dengan aman.'
        };
      }
      error.message = firebaseErrorMessage(error);
      throw error;
    }
  }

  async function linkPendingGoogle(email, password) {
    await waitUntilReady();
    if (!pendingGoogleCredential) throw new Error('Sesi penautan Google sudah berakhir. Ulangi login Google.');
    const credential = pendingGoogleCredential;
    let linkedUser = null;
    try {
      // This password sign-in is only a linking proof. Suppress it from the normal app session
      // so V1.61 password-login OTP enforcement does not race with account linking.
      passwordOtpBootstrap = true;
      const result = await modules.auth.signInWithEmailAndPassword(auth, email, password);
      linkedUser = result.user;
      await modules.auth.linkWithCredential(result.user, credential);
      pendingGoogleCredential = null;
    } catch (error) {
      error.message = firebaseErrorMessage(error);
      throw error;
    } finally {
      passwordOtpBootstrap = false;
    }

    // Re-establish the session using the Google credential. Existing Google-linked users do not
    // require OTP, while password-only logins still do.
    try { await modules.auth.signOut(auth); } catch {}
    try {
      const googleResult = await modules.auth.signInWithCredential(auth, credential);
      profile = await readProfile(googleResult.user);
      if (profile) {
        try { await syncUsernameLoginAlias(googleResult.user, profile); } catch {}
        try { await syncPublicProfile(googleResult.user, profile); } catch {}
        startHeartbeat();
      }
      emit(googleResult.user);
      return { user: googleResult.user, profile };
    } catch (error) {
      // Linking itself already succeeded. If the credential cannot be reused (provider/browser edge
      // case), require a fresh Google selection instead of falling back to an OTP-bypassing password session.
      try { if (linkedUser) await modules.auth.signOut(auth); } catch {}
      const safe = new Error('Akun Google berhasil ditautkan. Pilih akun Google sekali lagi untuk masuk.');
      safe.code = 'datzon/google-reselect-required';
      throw safe;
    }
  }

  async function completeGoogleRegistration({ fullName, username, password = '', selectedArtists = [] }) {
    await waitUntilReady();
    const user = assertUser();
    if (profile) return profile;
    if (password) {
      try {
        const emailCredential = modules.auth.EmailAuthProvider.credential(user.email, password);
        await modules.auth.linkWithCredential(user, emailCredential);
      } catch (error) {
        if (error?.code !== 'auth/provider-already-linked') {
          error.message = firebaseErrorMessage(error);
          throw error;
        }
      }
    }
    return createProfileForUser(user, {
      fullName,
      username,
      email: user.email,
      photoURL: user.photoURL,
      selectedArtists
    });
  }

  async function updateUserProfile(values) {
    await waitUntilReady();
    const user = assertUser();
    const { doc, runTransaction, serverTimestamp } = modules.firestore;
    const current = profile || await readProfile(user) || {};
    const fullName = String(values.fullName || current.fullName || user.displayName || 'Pengguna DATZON').trim().slice(0, 70);
    const username = validateUsername(values.username || current.username);
    const photoURL = String(values.photoURL ?? current.photoURL ?? user.photoURL ?? '').slice(0, 1400);
    const bio = normalizeProfileBio(values.bio ?? current.bio ?? '');
    const socialLinks = normalizeProfileSocialLinks(values.socialLinks ?? current.socialLinks ?? []);
    await runTransaction(db, async transaction => {
      await reserveUsername(transaction, user.uid, username, current.username || '', user.email || current.email || '');
      transaction.set(doc(db, 'users', user.uid), {
        fullName,
        username,
        usernameLower: username,
        photoURL,
        bio,
        socialLinks,
        musicProfileVersion: 1,
        updatedAt: serverTimestamp(),
        providers: user.providerData.map(item => item.providerId)
      }, { merge: true });
    });
    await modules.auth.updateProfile(user, { displayName: fullName, photoURL: photoURL || null });
    profile = await readProfile(user);
    try { await syncUsernameLoginAlias(user, profile); } catch {}
    try { await syncPublicProfile(user, profile); } catch {}
    emit(user);
    return profile;
  }

  async function updateAccountStatus(value = 'online') {
    await waitUntilReady();
    const user = assertUser();
    const normalized = String(value || '').toLowerCase();
    if (!['online', 'offline', 'busy'].includes(normalized)) throw new Error('Pilihan status tidak valid.');
    await modules.firestore.setDoc(modules.firestore.doc(db, 'users', user.uid), {
      preferredStatus: normalized,
      status: normalized,
      musicProfileVersion: 1,
      lastSeenAt: modules.firestore.serverTimestamp(),
      updatedAt: modules.firestore.serverTimestamp()
    }, { merge: true });
    profile = { ...(profile || {}), preferredStatus: normalized, status: normalized };
    try { await syncPublicProfile(user, profile); } catch {}
    emit(user);
    return profile;
  }

  async function updateSelectedArtists(selectedArtists, selectedArtistProfiles = null) {
    await waitUntilReady();
    const user = assertUser();
    const values = [...new Set((selectedArtists || []).map(value => String(value).trim()).filter(Boolean))].slice(0, 30);
    const profiles = Array.isArray(selectedArtistProfiles) ? selectedArtistProfiles.map(item => ({
      spotifyArtistId: String(item?.spotifyArtistId || item?.id || '').trim(),
      name: String(item?.name || '').trim(),
      image: String(item?.image || '').trim(),
      externalUrl: String(item?.externalUrl || item?.spotifyUrl || '').trim()
    })).filter(item => item.name).slice(0, 30) : null;
    const update = {
      selectedArtists: values,
      onboardingCompleted: true,
      musicProfileVersion: 1,
      updatedAt: modules.firestore.serverTimestamp()
    };
    if (profiles) update.selectedArtistProfiles = profiles;
    await modules.firestore.setDoc(modules.firestore.doc(db, 'users', user.uid), update, { merge: true });
    profile = { ...(profile || {}), selectedArtists: values, ...(profiles ? { selectedArtistProfiles: profiles } : {}), onboardingCompleted: true };
    emit(user);
    return values;
  }

  async function changePassword(oldPassword, newPassword) {
    await waitUntilReady();
    const user = assertUser();
    if (!user.email) throw new Error('Akun ini tidak memiliki email untuk autentikasi password.');
    try {
      const credential = modules.auth.EmailAuthProvider.credential(user.email, oldPassword);
      await modules.auth.reauthenticateWithCredential(user, credential);
      await modules.auth.updatePassword(user, newPassword);
      return true;
    } catch (error) {
      error.message = firebaseErrorMessage(error);
      throw error;
    }
  }

  async function sendResetEmail(email = auth?.currentUser?.email) {
    await waitUntilReady();
    if (!email) throw new Error('Email akun tidak tersedia.');
    try {
      await modules.auth.sendPasswordResetEmail(auth, email);
      return true;
    } catch (error) {
      error.message = firebaseErrorMessage(error);
      throw error;
    }
  }

  async function logout() {
    await waitUntilReady();
    try { await setPresence(false); } catch {}
    stopHeartbeat();
    await modules.auth.signOut(auth);
    profile = null;
    emit(null);
  }

  async function uploadProfileImage(file) {
    await waitUntilReady();
    const user = assertUser();
    if (!(file instanceof File)) throw new Error('Pilih file foto terlebih dahulu.');
    if (!/^image\/(jpeg|png|webp|gif)$/i.test(file.type)) throw new Error('Format foto harus JPG, PNG, WEBP, atau GIF.');
    if (file.size > 5 * 1024 * 1024) throw new Error('Ukuran foto maksimal 5 MB.');
    const cloudName = String(cloudinaryConfig.cloudName || '').trim();
    const uploadPreset = String(cloudinaryConfig.uploadPreset || '').trim();
    if (!cloudName || !uploadPreset) throw new Error('Cloudinary belum dikonfigurasi.');
    const body = new FormData();
    body.append('file', file);
    body.append('upload_preset', uploadPreset);
    const response = await fetch(`https://api.cloudinary.com/v1_1/${encodeURIComponent(cloudName)}/image/upload`, { method: 'POST', body });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok || !payload.secure_url) throw new Error(payload.error?.message || 'Foto gagal diunggah ke Cloudinary.');
    return payload.secure_url;
  }

  async function uploadCloudinaryImage(file, options = {}) {
    await waitUntilReady();
    assertUser();
    if (!(file instanceof File)) throw new Error('Pilih file gambar terlebih dahulu.');
    if (!/^image\/(jpeg|png|webp|gif)$/i.test(file.type)) throw new Error('Format gambar harus JPG, PNG, WEBP, atau GIF.');
    const maxBytes = Math.max(1, Number(options.maxMb || 5)) * 1024 * 1024;
    if (file.size > maxBytes) throw new Error(`Ukuran gambar maksimal ${Number(options.maxMb || 5)} MB.`);
    const cloudName = String(cloudinaryConfig.cloudName || '').trim();
    const uploadPreset = String(cloudinaryConfig.uploadPreset || '').trim();
    if (!cloudName || !uploadPreset) throw new Error('Cloudinary belum dikonfigurasi.');
    const body = new FormData();
    body.append('file', file);
    body.append('upload_preset', uploadPreset);
    if (options.folder) body.append('folder', String(options.folder));
    if (options.tags) body.append('tags', String(options.tags));
    const response = await fetch(`https://api.cloudinary.com/v1_1/${encodeURIComponent(cloudName)}/image/upload`, { method: 'POST', body });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok || !payload.secure_url) throw new Error(payload.error?.message || 'Gambar gagal diunggah ke Cloudinary.');
    return payload.secure_url;
  }

  async function uploadReportImages(files = []) {
    const list = [...files].slice(0, 3);
    if (!list.length) return [];
    const urls = [];
    for (const file of list) urls.push(await uploadCloudinaryImage(file, { folder: 'datzon-reports', tags: 'datzon-report', maxMb: 5 }));
    return urls;
  }

  function safeDocId(value = '') {
    const raw = String(value || '').trim();
    const spotifyMatch = raw.match(/(?:open\.spotify\.com\/track\/|spotify:track:)([A-Za-z0-9]{22})/i);
    if (spotifyMatch) return spotifyMatch[1];
    if (/^[A-Za-z0-9]{22}$/.test(raw)) return raw;
    const normalized = raw.toLowerCase().replace(/[^a-z0-9_-]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 80);
    if (normalized) return normalized;
    let hash = 2166136261;
    for (let index = 0; index < raw.length; index += 1) {
      hash ^= raw.charCodeAt(index);
      hash = Math.imul(hash, 16777619);
    }
    return `item-${(hash >>> 0).toString(36)}`;
  }

  function stableJson(value) {
    const seen = new WeakSet();
    return JSON.stringify(value, (key, item) => {
      if (item && typeof item === 'object') {
        if (seen.has(item)) return undefined;
        seen.add(item);
        if (!Array.isArray(item)) return Object.keys(item).sort().reduce((acc, name) => { acc[name] = item[name]; return acc; }, {});
      }
      return item;
    });
  }

  function fastHash(value) {
    const text = stableJson(value) || '';
    let hash = 2166136261;
    for (let index = 0; index < text.length; index += 1) {
      hash ^= text.charCodeAt(index);
      hash = Math.imul(hash, 16777619);
    }
    return (hash >>> 0).toString(36);
  }

  async function commitOperations(operations, chunkSize = 400) {
    const { writeBatch } = modules.firestore;
    const size = Math.max(1, Math.min(400, Number(chunkSize) || 400));
    for (let start = 0; start < operations.length; start += size) {
      const batch = writeBatch(db);
      operations.slice(start, start + size).forEach(operation => {
        if (operation.type === 'delete') batch.delete(operation.ref);
        else batch.set(operation.ref, operation.data, { merge: true });
      });
      await batch.commit();
    }
  }

  async function syncCollection(uid, name, items, identity) {
    const { doc, serverTimestamp } = modules.firestore;
    // Versi cache baru memaksa satu kali rewrite dokumen lama agar setiap
    // record Music mendapat marker aplikasi untuk validasi Firestore Rules.
    const cacheKey = `datzon_firebase_hashes_v1621_${uid}_${name}`;
    let previous = {};
    try { previous = JSON.parse(localStorage.getItem(cacheKey) || '{}'); } catch {}
    const next = {};
    const operations = [];
    (items || []).forEach((item, index) => {
      const rawIdentity = identity(item, index);
      const baseId = safeDocId(rawIdentity || `${name}-${index}`);
      // `history` juga dipakai DATZON Main. Namespace ID Music mencegah
      // rewrite dokumen lama lintas aplikasi ketika marker belum tersedia.
      const id = name === 'history' ? `music-${baseId}` : baseId;
      const clean = JSON.parse(JSON.stringify(item));
      const hash = fastHash(clean);
      next[id] = hash;
      if (previous[id] !== hash) {
        operations.push({
          type: 'set',
          ref: doc(db, 'users', uid, name, id),
          data: { ...clean, firebaseId:id, app:MUSIC_APP_ID, schemaVersion:MUSIC_SCHEMA_VERSION, syncedAt:serverTimestamp() }
        });
      }
    });
    Object.keys(previous).filter(id => !next[id]).forEach(id => {
      operations.push({ type: 'delete', ref: doc(db, 'users', uid, name, id) });
    });
    if (operations.length) await commitOperations(operations);
    localStorage.setItem(cacheKey, JSON.stringify(next));
  }

  async function syncSnapshot(snapshot) {
    await waitUntilReady();
    const user = assertUser();
    const { doc, setDoc, serverTimestamp } = modules.firestore;
    const appState = snapshot?.appState || {};
    const stateHashKey = `datzon_firebase_hashes_v1621_${user.uid}_appState`;
    const stateHash = fastHash(appState);
    if (localStorage.getItem(stateHashKey) !== stateHash) {
      await setDoc(doc(db, 'users', user.uid, 'private', 'appState'), {
        ...JSON.parse(JSON.stringify(appState)),
        app: MUSIC_APP_ID,
        schemaVersion: MUSIC_SCHEMA_VERSION,
        updatedAt: serverTimestamp()
      }, { merge: true });
      localStorage.setItem(stateHashKey, stateHash);
    }
    await Promise.all([
      syncCollection(user.uid, 'favorites', snapshot?.favorites || [], item => item.spotifyId || item.id || item.url || `${item.artist}|${item.title}`),
      syncCollection(user.uid, 'history', snapshot?.history || [], item => item.spotifyId || item.id || item.url || `${item.artist}|${item.title}`),
      syncCollection(user.uid, 'downloads', snapshot?.downloads || [], item => item.spotifyId || item.id || item.url || `${item.artist}|${item.title}`),
      syncCollection(user.uid, 'artists', snapshot?.artists || [], item => item.spotifyId || item.id || item.name),
      syncCollection(user.uid, 'playlists', snapshot?.playlists || [], item => item.id || item.firebaseId || item.name)
    ]);
    const listeningSummary = snapshot?.listeningSummary || {};
    const summaryHashKey = `datzon_firebase_hashes_v1621_${user.uid}_listeningSummary`;
    const summaryHash = fastHash(listeningSummary);
    if (localStorage.getItem(summaryHashKey) !== summaryHash) {
      await setDoc(doc(db, 'users', user.uid), {
        listeningSummary,
        musicProfileVersion: 1,
        updatedAt: serverTimestamp()
      }, { merge: true });
      localStorage.setItem(summaryHashKey, summaryHash);
      profile = { ...(profile || {}), listeningSummary };
      try { await syncPublicProfile(user, profile); } catch {}
    }
    return true;
  }

  function scheduleSync(snapshot, delay = 5000) {
    if (!auth?.currentUser || !profile) return;
    queuedSnapshot = snapshot;
    if (syncTimer) clearTimeout(syncTimer);
    syncTimer = setTimeout(async () => {
      const value = queuedSnapshot;
      queuedSnapshot = null;
      syncTimer = null;
      try { await syncSnapshot(value); }
      catch (error) { window.dispatchEvent(new CustomEvent('datzon-firebase-sync-error', { detail: { error, message: firebaseErrorMessage(error) } })); }
    }, delay);
  }

  async function readCollection(uid, name) {
    const { collection, getDocs, query, where } = modules.firestore;
    const ref = collection(db, 'users', uid, name);
    // `history` juga dipakai DATZON Main, jadi wajib difilter marker aplikasi.
    // Koleksi Music lainnya dibaca tanpa filter untuk migrasi data versi lama;
    // sync cache V1.62.1 akan menambahkan marker pada penulisan berikutnya.
    const snapshot = name === 'history'
      ? await getDocs(query(ref, where('app', '==', MUSIC_APP_ID)))
      : await getDocs(ref);
    return snapshot.docs.map(item => {
      const data = item.data();
      delete data.syncedAt;
      delete data.app;
      delete data.schemaVersion;
      return data;
    });
  }

  async function loadCloudData() {
    await waitUntilReady();
    const user = assertUser();
    const { doc, getDoc } = modules.firestore;
    const [appStateSnapshot, favorites, history, downloads, artists, playlists] = await Promise.all([
      getDoc(doc(db, 'users', user.uid, 'private', 'appState')),
      readCollection(user.uid, 'favorites'),
      readCollection(user.uid, 'history'),
      readCollection(user.uid, 'downloads'),
      readCollection(user.uid, 'artists'),
      readCollection(user.uid, 'playlists')
    ]);
    const appState = appStateSnapshot.exists() ? appStateSnapshot.data() : {};
    delete appState.updatedAt;
    delete appState.app;
    delete appState.schemaVersion;
    return { app: 'DATZON Music', source: 'firebase', uid: user.uid, profile: profile || await readProfile(user), appState, favorites, history, downloads, artists, playlists };
  }

  async function exportCloudData() {
    const payload = await loadCloudData();
    return { ...payload, exportedAt: new Date().toISOString() };
  }

  async function importCloudData(payload) {
    await waitUntilReady();
    const user = assertUser();
    const normalized = payload?.appState ? payload : {
      appState: {
        username: payload?.username,
        searchHistory: payload?.searchHistory,
        queue: payload?.queue,
        current: payload?.current,
        currentIndex: payload?.currentIndex,
        listeningStats: payload?.listeningStats,
        settings: payload?.settings,
        preferredArtists: payload?.preferredArtists
      },
      favorites: payload?.favorites,
      history: payload?.history,
      downloads: payload?.downloads,
      artists: payload?.artists,
      playlists: payload?.playlists
    };
    const current = await loadCloudData();
    const mergeItems = (primary = [], secondary = [], identity) => {
      const map = new Map();
      [...primary, ...secondary].forEach((item, index) => {
        if (!item) return;
        const id = safeDocId(identity(item, index));
        if (!map.has(id)) map.set(id, item);
      });
      return [...map.values()];
    };
    const mergedAppState = {
      ...(current.appState || {}),
      ...(normalized.appState || {}),
      settings: { ...(current.appState?.settings || {}), ...(normalized.appState?.settings || {}) },
      searchHistory: [...new Set([...(normalized.appState?.searchHistory || []), ...(current.appState?.searchHistory || [])])].slice(0, 20),
      preferredArtists: [...new Set([...(normalized.appState?.preferredArtists || []), ...(current.appState?.preferredArtists || [])])].slice(0, 30)
    };
    const favorites = mergeItems(normalized.favorites || [], current.favorites || [], item => item.spotifyId || item.id || item.url || `${item.artist}|${item.title}`);
    const history = mergeItems(normalized.history || [], current.history || [], item => item.spotifyId || item.id || item.url || `${item.artist}|${item.title}`);
    const downloads = mergeItems(normalized.downloads || [], current.downloads || [], item => item.spotifyId || item.id || item.url || `${item.artist}|${item.title}`);
    const artists = mergeItems(normalized.artists || [], current.artists || [], item => item.spotifyId || item.id || item.name);
    const playlists = mergeItems(normalized.playlists || [], current.playlists || [], item => item.id || item.firebaseId || item.name);
    await syncSnapshot({
      appState: mergedAppState,
      favorites,
      history,
      downloads,
      artists,
      playlists,
      listeningSummary: mergedAppState.listeningStats ? {
        totalSeconds: Number(mergedAppState.listeningStats.totalSeconds || 0),
        plays: Number(mergedAppState.listeningStats.plays || 0)
      } : {}
    });
    return { uid: user.uid, importedAt: new Date().toISOString() };
  }



  function publicSearchTokens(...values) {
    const tokens = new Set();
    const addPrefixes = value => {
      const normalized = String(value || '')
        .normalize('NFKD')
        .replace(/[\u0300-\u036f]/g, '')
        .toLowerCase()
        .replace(/^@+/, '')
        .replace(/[^a-z0-9._ ]+/g, ' ')
        .replace(/\s+/g, ' ')
        .trim();
      if (!normalized) return;
      const pieces = [normalized, ...normalized.split(' ')].filter(Boolean);
      pieces.forEach(piece => {
        for (let index = 1; index <= Math.min(piece.length, 24); index += 1) tokens.add(piece.slice(0, index));
      });
    };
    values.forEach(addPrefixes);
    return [...tokens].slice(0, 160);
  }

  function publicProfileData(user = auth?.currentUser, source = profile || {}) {
    if (!user) return null;
    const summary = source?.listeningSummary || {};
    const fullName = String(source?.fullName || user.displayName || 'Pengguna DATZON').trim().slice(0, 70);
    const username = normalizeUsername(source?.username || '');
    return {
      app: MUSIC_APP_ID,
      schemaVersion: MUSIC_SCHEMA_VERSION,
      uid: user.uid,
      fullName,
      fullNameLower: fullName.toLowerCase(),
      username,
      usernameLower: username,
      photoURL: String(source?.photoURL || user.photoURL || '').slice(0, 1400),
      bio: normalizeProfileBio(source?.bio || ''),
      socialLinks: normalizeProfileSocialLinks(source?.socialLinks || []),
      status: String(source?.status || 'offline'),
      preferredStatus: String(source?.preferredStatus || 'online'),
      createdAtIso: String(source?.createdAtIso || ''),
      role: String(source?.role || 'user').toLowerCase() === 'admin' ? 'admin' : 'user',
      listeningSummary: {
        totalSeconds: Number(summary.totalSeconds || 0),
        plays: Number(summary.plays || 0)
      },
      searchTokens: publicSearchTokens(fullName, username)
    };
  }

  const PUBLIC_PROFILE_ALLOWED_FIELDS = Object.freeze([
    'app', 'schemaVersion', 'uid', 'fullName', 'fullNameLower',
    'username', 'usernameLower', 'photoURL', 'bio', 'socialLinks',
    'status', 'preferredStatus', 'createdAtIso', 'role',
    'listeningSummary', 'searchTokens', 'socialSnapshot',
    'publicPlaylists', 'publicPlaylistsUpdatedAtMs',
    'updatedAt', 'lastSeenAt'
  ]);

  async function writePublicProfilePatch(user, patch = {}) {
    if (!user || !db || !modules) return false;
    const { doc, runTransaction } = modules.firestore;
    const ref = doc(db, 'publicProfiles', user.uid);
    await runTransaction(db, async transaction => {
      const snapshot = await transaction.get(ref);
      const current = snapshot.exists() ? snapshot.data() : {};
      const sanitized = {};
      PUBLIC_PROFILE_ALLOWED_FIELDS.forEach(key => {
        if (Object.prototype.hasOwnProperty.call(current, key)) sanitized[key] = current[key];
      });
      Object.assign(sanitized, patch, {
        app: MUSIC_APP_ID,
        schemaVersion: MUSIC_SCHEMA_VERSION,
        uid: user.uid
      });
      if (sanitized.role === 'admin' && String(profile?.role || '').toLowerCase() !== 'admin') sanitized.role = 'user';
      Object.keys(sanitized).forEach(key => { if (sanitized[key] === undefined) delete sanitized[key]; });
      transaction.set(ref, sanitized);
    });
    return true;
  }

  function compactPublicPlaylistTrack(track = {}) {
    const spotifyTrackId = String(track.spotifyTrackId || track.spotifyId || track.id || '')
      .replace(/[^A-Za-z0-9]/g, '')
      .slice(0, 64);
    const rawUrl = String(track.url || track.spotifyUrl || '').trim();
    return {
      id: String(track.id || spotifyTrackId || '').slice(0, 120),
      spotifyTrackId,
      title: String(track.title || track.name || 'Lagu').trim().slice(0, 180),
      artist: String(track.artist || track.artistName || 'Artis tidak diketahui').trim().slice(0, 220),
      artistNames: Array.isArray(track.artistNames) ? track.artistNames.slice(0, 8).map(value => String(value).slice(0, 100)) : [],
      duration: String(track.duration || '').slice(0, 20),
      thumbnail: String(track.thumbnail || track.image || '').trim().slice(0, 900),
      album: String(track.album || '').trim().slice(0, 180),
      url: rawUrl.slice(0, 900),
      source: String(track.source || 'Playlist publik DATZON').slice(0, 100),
      isrc: String(track.isrc || '').slice(0, 32),
      explicit: Boolean(track.explicit)
    };
  }

  function compactPublicPlaylist(raw = {}, user = auth?.currentUser) {
    const currentUid = String(user?.uid || '');
    const participantUids = [...new Set((Array.isArray(raw.participantUids) ? raw.participantUids : [])
      .map(value => String(value || '').trim()).filter(Boolean))].slice(0, 24);
    if (raw.collaborative && currentUid && !participantUids.includes(currentUid)) participantUids.unshift(currentUid);
    const sourceTracks = (Array.isArray(raw.tracks) ? raw.tracks : []).slice(0, 200);
    const tracks = sourceTracks.map(compactPublicPlaylistTrack);
    return {
      id: String(raw.id || raw.firebaseId || '').replace(/[^A-Za-z0-9._-]/g, '-').slice(0, 120),
      name: String(raw.name || raw.title || 'Playlist').trim().slice(0, 80),
      visibility: 'public',
      ownerUid: String(raw.ownerUid || currentUid),
      collabOwnerUid: String(raw.collabOwnerUid || raw.ownerUid || currentUid),
      collaborative: Boolean(raw.collaborative || raw.sourceType === 'collaborative'),
      sourceType: Boolean(raw.collaborative || raw.sourceType === 'collaborative') ? 'collaborative' : 'public',
      participantUids,
      participantProfiles: (Array.isArray(raw.participantProfiles) ? raw.participantProfiles : []).slice(0, 24).map(item => ({
        uid: String(item?.uid || ''),
        fullName: String(item?.fullName || item?.username || '').slice(0, 100),
        username: String(item?.username || '').slice(0, 50),
        photoURL: String(item?.photoURL || '').slice(0, 900)
      })).filter(item => item.uid),
      createdAt: Number(raw.createdAt || Date.now()),
      updatedAt: Number(raw.updatedAt || Date.now()),
      totalTracks: tracks.length,
      tracks
    };
  }

  function jsonUtf8ByteLength(value) {
    const json = JSON.stringify(value);
    if (typeof TextEncoder !== 'undefined') return new TextEncoder().encode(json).byteLength;
    return encodeURIComponent(json).replace(/%[0-9A-F]{2}|./gi, 'x').length;
  }

  function fitPublicPlaylistsToProfile(playlists = [], user = auth?.currentUser) {
    const candidates = (Array.isArray(playlists) ? playlists : [])
      .filter(item => String(item?.visibility || '').toLowerCase() === 'public')
      .map(item => compactPublicPlaylist(item, user))
      .filter(item => item.id)
      .sort((a, b) => Number(b.updatedAt || 0) - Number(a.updatedAt || 0))
      .slice(0, 60);
    const output = [];
    const byteBudget = 640000;
    for (const source of candidates) {
      let candidate = { ...source, tracks: [...source.tracks] };
      while (candidate.tracks.length && jsonUtf8ByteLength([...output, candidate]) > byteBudget) {
        candidate.tracks = candidate.tracks.slice(0, Math.max(0, Math.floor(candidate.tracks.length * .72)));
        candidate.snapshotTruncated = candidate.tracks.length < source.tracks.length;
      }
      if (jsonUtf8ByteLength([...output, candidate]) > byteBudget) break;
      candidate.totalTracks = Number(source.totalTracks || source.tracks.length);
      output.push(candidate);
    }
    return output;
  }

  function sharedPlaylistTrackDurationSeconds(track = {}) {
    const durationMs = Number(track.durationMs || track.duration_ms || 0);
    if (Number.isFinite(durationMs) && durationMs > 0) return Math.round(durationMs / 1000);
    const parts = String(track.duration || '').trim().split(':').map(value => Number(value));
    if (!parts.length || parts.some(value => !Number.isFinite(value) || value < 0)) return 0;
    return Math.round(parts.reduce((total, value) => total * 60 + value, 0));
  }

  function compactSharedPlaylist(raw = {}, user = auth?.currentUser) {
    const currentUid = String(user?.uid || '');
    const collaborative = Boolean(raw.collaborative || raw.sourceType === 'collaborative');
    const ownerUid = String(raw.collabOwnerUid || raw.ownerUid || currentUid).trim();
    const participantUids = [...new Set([
      ownerUid,
      ...(Array.isArray(raw.participantUids) ? raw.participantUids : [])
    ].map(value => String(value || '').trim()).filter(Boolean))].slice(0, 24);
    if (collaborative && currentUid && !participantUids.includes(currentUid)) return null;
    const profileMap = new Map();
    (Array.isArray(raw.participantProfiles) ? raw.participantProfiles : []).slice(0, 24).forEach(item => {
      const uid = String(item?.uid || '').trim();
      if (!uid || !participantUids.includes(uid) || profileMap.has(uid)) return;
      profileMap.set(uid, {
        uid,
        fullName: String(item?.fullName || item?.username || 'Pengguna DATZON').slice(0, 100),
        username: String(item?.username || '').slice(0, 50),
        photoURL: String(item?.photoURL || '').slice(0, 900)
      });
    });
    if (currentUid && participantUids.includes(currentUid)) {
      profileMap.set(currentUid, {
        uid: currentUid,
        fullName: String(profile?.fullName || profile?.username || user?.displayName || 'Pengguna DATZON').slice(0, 100),
        username: String(profile?.username || '').slice(0, 50),
        photoURL: String(profile?.photoURL || user?.photoURL || '').slice(0, 900)
      });
    }
    const sourceTracks = (Array.isArray(raw.tracks) ? raw.tracks : []).slice(0, 200);
    const tracks = sourceTracks.map(compactPublicPlaylistTrack);
    const id = String(raw.id || raw.firebaseId || '').replace(/[^A-Za-z0-9._-]/g, '-').replace(/^-+|-+$/g, '').slice(0, 120);
    if (!id || !ownerUid || !participantUids.length) return null;
    const createdAt = Math.max(1, Math.round(Number(raw.createdAt || Date.now()) || Date.now()));
    const updatedAt = Math.max(createdAt, Math.round(Number(raw.updatedAt || createdAt) || createdAt));
    return {
      app: MUSIC_APP_ID,
      schemaVersion: MUSIC_SCHEMA_VERSION,
      id,
      name: String(raw.name || raw.title || 'Playlist').trim().slice(0, 80) || 'Playlist',
      visibility: String(raw.visibility || '').toLowerCase() === 'public' ? 'public' : 'private',
      ownerUid,
      collabOwnerUid: ownerUid,
      collaborative,
      sourceType: collaborative ? 'collaborative' : 'public',
      participantUids,
      profileUids: [...participantUids],
      participantProfiles: [...profileMap.values()],
      createdAt,
      updatedAt,
      totalTracks: tracks.length,
      durationSeconds: sourceTracks.reduce((total, track) => total + sharedPlaylistTrackDurationSeconds(track), 0),
      listed: tracks.length > 0,
      tracks
    };
  }

  function sharedPlaylistDirectoryCandidates(playlists = [], user = auth?.currentUser) {
    return (Array.isArray(playlists) ? playlists : [])
      .filter(item => String(item?.visibility || '').toLowerCase() === 'public' || Boolean(item?.collaborative || item?.sourceType === 'collaborative'))
      .map(item => compactSharedPlaylist(item, user))
      .filter(Boolean)
      .slice(0, 100);
  }

  async function sharedPlaylistDirectoryApi(upserts = [], deletes = [], permanentDeletes = []) {
    const user = assertUser();
    const idToken = await modules.auth.getIdToken(user, false);
    const response = await fetch('/api/auth/playlist/sync', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': `Bearer ${idToken}`
      },
      cache: 'no-store',
      body: JSON.stringify({ upserts, deletes, permanentDeletes })
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok || data?.ok === false) {
      const error = new Error(data?.error || 'Sinkronisasi playlist gagal.');
      error.code = `playlist/${String(data?.code || 'sync_failed')}`;
      error.status = response.status;
      throw error;
    }
    return data;
  }

  async function deleteSharedPlaylist(playlistId) {
    await waitUntilReady();
    const user = assertUser();
    const id = String(playlistId || '').trim().replace(/[^A-Za-z0-9._-]/g, '-').slice(0, 120);
    if (!id) throw new Error('Playlist tidak valid.');
    const data = await sharedPlaylistDirectoryApi([], [], [id]);
    const result = Array.isArray(data?.permanentlyDeleted) ? data.permanentlyDeleted.find(item => item?.id === id) : null;
    if (result && !['deleted','already_deleted','missing'].includes(String(result.status || ''))) {
      const error = new Error('Hanya pembuat playlist yang dapat menghapus playlist ini.');
      error.code = 'playlist/delete_forbidden';
      throw error;
    }
    const cacheKey = `datzon_firebase_shared_playlist_directory_v1628_${user.uid}`;
    try {
      const cache = JSON.parse(localStorage.getItem(cacheKey) || '{}');
      if (cache && typeof cache === 'object' && id in cache) {
        delete cache[id];
        localStorage.setItem(cacheKey, JSON.stringify(cache));
      }
    } catch {}
    return result || { id, status:'missing' };
  }

  async function syncSharedPlaylistDirectory(playlists = [], previousPlaylists = []) {
    await waitUntilReady();
    const user = assertUser();
    const cacheKey = `datzon_firebase_shared_playlist_directory_v1628_${user.uid}`;
    let cache = {};
    try { cache = JSON.parse(localStorage.getItem(cacheKey) || '{}'); } catch {}

    const previousMap = new Map();
    Object.entries(cache || {}).forEach(([id, item]) => {
      if (!item || typeof item !== 'object') return;
      previousMap.set(id, {
        id,
        ownerUid:String(item.ownerUid || ''),
        profileUids:Array.isArray(item.profileUids) ? item.profileUids.map(value => String(value || '')).filter(Boolean) : [],
        hash:String(item.hash || '')
      });
    });
    sharedPlaylistDirectoryCandidates(previousPlaylists, user).forEach(item => {
      const cached = previousMap.get(item.id) || {};
      previousMap.set(item.id, { id:item.id, ownerUid:item.ownerUid, profileUids:item.profileUids, hash:cached.hash || '' });
    });

    const next = {};
    const changed = [];
    sharedPlaylistDirectoryCandidates(playlists, user).forEach(item => {
      const hash = fastHash(item);
      const previous = previousMap.get(item.id) || {};
      next[item.id] = { hash, ownerUid:item.ownerUid, profileUids:item.profileUids };
      if (previous.hash !== hash) changed.push(item);
    });

    const deletes = [];
    previousMap.forEach((previous, id) => {
      if (next[id] || previous.ownerUid !== user.uid) return;
      deletes.push(id);
    });

    // V1.62.8: publish shared playlist snapshots through the existing server
    // gateway (Firebase Admin) so every participant profile index is updated in
    // one authoritative path. This avoids an entire browser writeBatch being
    // rejected because one collaborator index fails a client-side rule check.
    for (let index = 0; index < changed.length; index += 4) {
      const response = await sharedPlaylistDirectoryApi(changed.slice(index, index + 4), []);
      (Array.isArray(response?.synced) ? response.synced : [])
        .filter(item => String(item?.status || '') === 'deleted' && item?.id)
        .forEach(item => {
          try { window.dispatchEvent(new CustomEvent('datzon:playlist-deleted', { detail:{ playlistId:String(item.id) } })); } catch {}
        });
    }
    for (let index = 0; index < deletes.length; index += 16) {
      await sharedPlaylistDirectoryApi([], deletes.slice(index, index + 16));
    }

    localStorage.setItem(cacheKey, JSON.stringify(next));
    return Object.values(next);
  }

  async function syncPublicPlaylists(playlists = [], options = {}) {
    await waitUntilReady();
    const user = assertUser();
    const publicPlaylists = fitPublicPlaylistsToProfile(playlists, user);
    await Promise.all([
      writePublicProfilePatch(user, {
        publicPlaylists,
        publicPlaylistsUpdatedAtMs: Date.now(),
        updatedAt: modules.firestore.serverTimestamp(),
        lastSeenAt: modules.firestore.serverTimestamp()
      }),
      syncSharedPlaylistDirectory(playlists, options?.previousPlaylists || [])
    ]);
    return publicPlaylists;
  }

  async function syncPublicProfile(user = auth?.currentUser, source = profile || {}) {
    if (!user || !db || !modules) return false;
    const data = publicProfileData(user, source);
    if (!data) return false;
    await writePublicProfilePatch(user, {
      ...data,
      updatedAt: modules.firestore.serverTimestamp(),
      lastSeenAt: modules.firestore.serverTimestamp()
    });
    return true;
  }

  async function getPublicProfile(uid) {
    await waitUntilReady();
    const safeUid = String(uid || '').trim();
    if (!safeUid) return null;
    const snapshot = await modules.firestore.getDoc(modules.firestore.doc(db, 'publicProfiles', safeUid));
    return snapshot.exists() ? { uid: snapshot.id, ...snapshot.data() } : null;
  }

  async function getAccessibleProfilePlaylists(profileUid) {
    await waitUntilReady();
    const user = assertUser();
    const safeUid = String(profileUid || '').trim().slice(0, 128);
    if (!safeUid || safeUid.includes('/')) return [];
    const idToken = await modules.auth.getIdToken(user, false);
    const response = await fetch('/api/auth/playlist/profile', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': `Bearer ${idToken}`
      },
      cache: 'no-store',
      body: JSON.stringify({ profileUid:safeUid })
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok || data?.ok === false) {
      const error = new Error(data?.error || 'Playlist kolaborasi private gagal dimuat.');
      error.code = `playlist/${String(data?.code || 'profile_failed')}`;
      error.status = response.status;
      throw error;
    }
    return Array.isArray(data?.playlists) ? data.playlists : [];
  }

  function listenProfilePlaylists(profileUid, listener, errorListener = null) {
    assertConfigured();
    const safeUid = String(profileUid || '').trim();
    if (!safeUid || typeof listener !== 'function') return () => {};
    const { collection, query, where, onSnapshot } = modules.firestore;
    const ref = collection(db, 'musicPlaylistProfiles', safeUid, 'items');
    const currentUid = String(auth?.currentUser?.uid || '');
    let publicItems = [];
    let memberItems = [];
    let serverMemberItems = [];
    let publicReady = false;
    let memberReady = !currentUid;
    let serverReady = !currentUid;
    let disposed = false;
    const timers = [];

    const publish = () => {
      if (disposed) return;
      const map = new Map();
      [...publicItems, ...memberItems, ...serverMemberItems].forEach(item => {
        const id = String(item?.id || '');
        if (!id) return;
        const previous = map.get(id);
        if (!previous || Number(item.updatedAt || 0) >= Number(previous.updatedAt || 0)) map.set(id, item);
      });
      const playlists = [...map.values()]
        .filter(item => item.listed !== false && Number(item.totalTracks || item.tracks?.length || 0) > 0)
        .filter(item => item.visibility === 'public' || (currentUid && Array.isArray(item.participantUids) && item.participantUids.includes(currentUid)))
        .filter(item => item.visibility === 'public' || (Array.isArray(item.profileUids || item.participantUids) && (item.profileUids || item.participantUids).includes(safeUid)))
        .sort((a, b) => Number(b.updatedAt || 0) - Number(a.updatedAt || 0));
      listener({ playlists, ready:publicReady && memberReady && serverReady, profileUid:safeUid });
    };

    const refreshServerMembership = async () => {
      if (!currentUid || disposed) return;
      try {
        const items = await getAccessibleProfilePlaylists(safeUid);
        if (disposed) return;
        serverMemberItems = items.map(item => ({ ...item, directorySource:'server-membership' }));
        serverReady = true;
        publish();
      } catch (error) {
        if (disposed) return;
        serverReady = true;
        publish();
        // Public Firestore reads remain useful even when the authenticated
        // fallback is temporarily unavailable. Surface the error only if the
        // member realtime query is also unavailable.
        if (memberReady && !memberItems.length) { try { errorListener?.(error); } catch {} }
      }
    };

    const handleError = (error, kind) => {
      if (kind === 'public') publicReady = true;
      if (kind === 'member') memberReady = true;
      publish();
      if (kind === 'member' && currentUid) {
        void refreshServerMembership();
        return;
      }
      try { errorListener?.(error); } catch {}
    };

    const unsubscribers = [];
    unsubscribers.push(onSnapshot(
      query(ref, where('visibility', '==', 'public')),
      snapshot => {
        publicItems = snapshot.docs.map(item => ({ id:item.id, ...item.data(), directorySource:'shared-index' }));
        publicReady = true;
        publish();
      },
      error => handleError(error, 'public')
    ));
    if (currentUid) {
      unsubscribers.push(onSnapshot(
        query(ref, where('participantUids', 'array-contains', currentUid)),
        snapshot => {
          memberItems = snapshot.docs.map(item => ({ id:item.id, ...item.data(), directorySource:'shared-index' }));
          memberReady = true;
          publish();
        },
        error => handleError(error, 'member')
      ));

      // V1.62.8: canonical membership fallback. Run immediately and retry a
      // couple of times so a playlist created moments before profile navigation
      // is picked up even if the profile index write/realtime listener lags.
      [0, 1200, 3500].forEach(delay => {
        const timer = window.setTimeout(() => { void refreshServerMembership(); }, delay);
        timers.push(timer);
      });
    }
    return () => {
      disposed = true;
      timers.splice(0).forEach(timer => { try { window.clearTimeout(timer); } catch {} });
      unsubscribers.splice(0).forEach(unsubscribe => { try { unsubscribe?.(); } catch {} });
    };
  }

  async function getSharedPlaylist(playlistId) {
    await waitUntilReady();
    const id = String(playlistId || '').trim().replace(/[^A-Za-z0-9._-]/g, '-').slice(0, 120);
    if (!id) return null;
    const snapshot = await modules.firestore.getDoc(modules.firestore.doc(db, 'musicPlaylists', id));
    return snapshot.exists() ? { id:snapshot.id, ...snapshot.data(), directorySource:'shared-playlist' } : null;
  }


  async function getPlaylistTombstone(playlistId) {
    await waitUntilReady();
    const id = String(playlistId || '').trim().replace(/[^A-Za-z0-9._-]/g, '-').slice(0, 120);
    if (!id) return null;
    const snapshot = await modules.firestore.getDoc(modules.firestore.doc(db, 'musicPlaylistTombstones', id));
    return snapshot.exists() ? { id:snapshot.id, ...snapshot.data() } : null;
  }

  function listenSharedPlaylist(playlistId, listener, errorListener = null) {
    assertConfigured();
    const id = String(playlistId || '').trim().replace(/[^A-Za-z0-9._-]/g, '-').slice(0, 120);
    if (!id || typeof listener !== 'function') return () => {};
    return modules.firestore.onSnapshot(
      modules.firestore.doc(db, 'musicPlaylists', id),
      snapshot => listener(snapshot.exists() ? { id:snapshot.id, ...snapshot.data(), directorySource:'shared-playlist' } : null),
      error => { try { errorListener?.(error); } catch {} }
    );
  }

  async function searchUsers(term = '', maxResults = 24) {
    await waitUntilReady();
    const currentUid = auth?.currentUser?.uid || '';
    const normalized = String(term || '')
      .normalize('NFKD')
      .replace(/[\u0300-\u036f]/g, '')
      .toLowerCase()
      .replace(/^@+/, '')
      .replace(/[^a-z0-9._ ]+/g, ' ')
      .trim()
      .split(/\s+/)[0]
      .slice(0, 24);
    const { collection, getDocs, query, where, limit, orderBy } = modules.firestore;
    let snapshot;
    if (normalized) {
      snapshot = await getDocs(query(collection(db, 'publicProfiles'), where('searchTokens', 'array-contains', normalized), limit(Math.max(5, Math.min(50, maxResults)))));
    } else {
      snapshot = await getDocs(query(collection(db, 'publicProfiles'), orderBy('fullNameLower'), limit(Math.max(5, Math.min(50, maxResults)))));
    }
    return snapshot.docs
      .map(item => ({ uid: item.id, ...item.data() }))
      .filter(item => item.uid !== currentUid)
      .sort((a, b) => String(a.fullName || a.username).localeCompare(String(b.fullName || b.username), 'id'));
  }

  function relationshipIdFor(uidA, uidB) {
    return [String(uidA || '').trim(), String(uidB || '').trim()].filter(Boolean).sort().join('__');
  }

  function compactPublicProfile(source = {}, fallbackUid = '') {
    const uid = String(source?.uid || fallbackUid || '').trim();
    return {
      uid,
      fullName: String(source?.fullName || source?.username || 'Pengguna DATZON'),
      username: String(source?.username || ''),
      photoURL: String(source?.photoURL || ''),
      bio: normalizeProfileBio(source?.bio || ''),
      socialLinks: normalizeProfileSocialLinks(source?.socialLinks || []),
      status: String(source?.status || 'offline'),
      preferredStatus: String(source?.preferredStatus || 'online'),
      createdAtIso: String(source?.createdAtIso || ''),
      role: String(source?.role || 'user').toLowerCase() === 'admin' ? 'admin' : 'user',
      listeningSummary: {
        totalSeconds: Number(source?.listeningSummary?.totalSeconds || 0),
        plays: Number(source?.listeningSummary?.plays || 0)
      }
    };
  }

  function socialRelationship(ownerUid, peerUid, kind = 'following', record = {}) {
    const participants = [String(ownerUid || ''), String(peerUid || '')].filter(Boolean).sort();
    if (kind === 'friend') {
      return {
        id: relationshipIdFor(ownerUid, peerUid),
        participants,
        followerUids: participants,
        status: 'friends',
        acceptedAt: record.acceptedAt || record.updatedAt || null,
        storage: 'users-subcollections'
      };
    }
    if (kind === 'followers') {
      const mutual = String(record.status || '').toLowerCase() === 'friends';
      return {
        id: relationshipIdFor(ownerUid, peerUid),
        participants,
        followerUids: mutual ? participants : [String(peerUid || '')],
        requestedBy: String(peerUid || ''),
        status: mutual ? 'friends' : 'following',
        requestExpiresAtMs: Number(record.requestExpiresAtMs || 0),
        storage: 'users-subcollections'
      };
    }
    return {
      id: relationshipIdFor(ownerUid, peerUid),
      participants,
      followerUids: [String(ownerUid || '')],
      requestedBy: String(ownerUid || ''),
      status: String(record.status || 'following') === 'friends' ? 'friends' : 'following',
      requestExpiresAtMs: Number(record.requestExpiresAtMs || 0),
      storage: 'users-subcollections'
    };
  }

  async function readSocialCollection(uid, name) {
    const snapshot = await modules.firestore.getDocs(modules.firestore.collection(db, 'users', uid, name));
    return snapshot.docs.map(item => ({ id: item.id, ...item.data() }));
  }

  async function getRelationship(targetUid) {
    await waitUntilReady();
    const user = assertUser();
    const target = String(targetUid || '').trim();
    if (!target || target === user.uid) return null;
    const { doc, getDoc } = modules.firestore;
    const [friendSnap, followingSnap, followerSnap] = await Promise.all([
      getDoc(doc(db, 'users', user.uid, 'friend', target)),
      getDoc(doc(db, 'users', user.uid, 'following', target)),
      getDoc(doc(db, 'users', user.uid, 'followers', target))
    ]);
    if (friendSnap.exists()) return socialRelationship(user.uid, target, 'friend', friendSnap.data());
    if (followingSnap.exists()) return socialRelationship(user.uid, target, 'following', followingSnap.data());
    if (followerSnap.exists()) return socialRelationship(user.uid, target, 'followers', followerSnap.data());
    return null;
  }

  async function loadSocialGraphForOwner(ownerUid) {
    await waitUntilReady();
    const owner = String(ownerUid || '').trim();
    if (!owner) return { relationships:[], friends:[], following:[], followers:[] };
    const [friendRecords, followingRecords, followerRecords] = await Promise.all([
      readSocialCollection(owner, 'friend'),
      readSocialCollection(owner, 'following'),
      readSocialCollection(owner, 'followers')
    ]);

    const peerUids = [...new Set([
      ...friendRecords.map(item => item.friendUid || item.peerUid || item.id),
      ...followingRecords.map(item => item.targetUid || item.peerUid || item.id),
      ...followerRecords.map(item => item.followerUid || item.peerUid || item.id)
    ].map(String).filter(uid => uid && uid !== owner))];

    const profiles = {};
    await Promise.all(peerUids.map(async uid => {
      try { profiles[uid] = await getPublicProfile(uid); } catch { profiles[uid] = null; }
    }));

    const hydrate = (record, kind) => {
      const peerUid = String(
        kind === 'friend'
          ? (record.friendUid || record.peerUid || record.id)
          : kind === 'following'
            ? (record.targetUid || record.peerUid || record.id)
            : (record.followerUid || record.peerUid || record.id)
      );
      const publicProfile = profiles[peerUid] || compactPublicProfile(record.profile || {}, peerUid);
      return {
        ...publicProfile,
        uid: peerUid,
        relationship: socialRelationship(owner, peerUid, kind, record),
        socialRecord: record
      };
    };

    const friendProfiles = friendRecords.map(record => hydrate(record, 'friend'));
    const followingProfiles = followingRecords.map(record => hydrate(record, 'following'));
    const followerProfiles = followerRecords.map(record => hydrate(record, 'followers'));
    const mergeByUid = (...lists) => {
      const result = [];
      const seen = new Set();
      lists.flat().forEach(item => {
        const uid = String(item?.uid || '');
        if (!uid || seen.has(uid)) return;
        seen.add(uid);
        result.push(item);
      });
      return result;
    };

    return {
      relationships: [
        ...friendRecords.map(record => socialRelationship(owner, String(record.friendUid || record.peerUid || record.id), 'friend', record)),
        ...followingRecords.map(record => socialRelationship(owner, String(record.targetUid || record.peerUid || record.id), 'following', record)),
        ...followerRecords.map(record => socialRelationship(owner, String(record.followerUid || record.peerUid || record.id), 'followers', record))
      ],
      friends: friendProfiles,
      // Teman mutual sengaja ikut tampil di Following dan Followers.
      following: mergeByUid(friendProfiles, followingProfiles),
      followers: mergeByUid(friendProfiles, followerProfiles)
    };
  }

  function normalizedSocialUidList(values = [], ownerUid = '') {
    const owner = String(ownerUid || '').trim();
    const seen = new Set();
    const result = [];
    (Array.isArray(values) ? values : []).forEach(value => {
      const uid = String(value?.uid || value || '').trim();
      if (!uid || uid === owner || seen.has(uid)) return;
      seen.add(uid);
      result.push(uid);
    });
    return result;
  }

  function socialSnapshotFromGraph(ownerUid, graph = {}) {
    const owner = String(ownerUid || '').trim();
    const graphFriends = Array.isArray(graph.friends) ? graph.friends : [];
    const graphFollowing = Array.isArray(graph.following) ? graph.following : [];
    const graphFollowers = Array.isArray(graph.followers) ? graph.followers : [];
    const friends = normalizedSocialUidList(graphFriends, owner);
    const following = normalizedSocialUidList([...graphFollowing, ...friends], owner);
    const followers = normalizedSocialUidList([...graphFollowers, ...friends], owner);
    return {
      friends,
      following,
      followers,
      counts: {
        friends: friends.length,
        following: following.length,
        followers: followers.length
      },
      updatedAtMs: Date.now()
    };
  }

  async function syncPublicSocialSnapshot(graph = null) {
    await waitUntilReady();
    const user = assertUser();
    const resolvedGraph = graph || await loadSocialGraphForOwner(user.uid);
    const socialSnapshot = socialSnapshotFromGraph(user.uid, resolvedGraph);
    const publicData = publicProfileData(user, profile || {}) || {};
    await writePublicProfilePatch(user, {
      ...publicData,
      socialSnapshot,
      updatedAt: modules.firestore.serverTimestamp(),
      lastSeenAt: modules.firestore.serverTimestamp()
    });
    return socialSnapshot;
  }

  async function hydratePublicSocialSnapshot(ownerUid, snapshot = {}) {
    const owner = String(ownerUid || '').trim();
    const snapshotFriends = Array.isArray(snapshot.friends) ? snapshot.friends : [];
    const snapshotFollowing = Array.isArray(snapshot.following) ? snapshot.following : [];
    const snapshotFollowers = Array.isArray(snapshot.followers) ? snapshot.followers : [];
    const friendUids = normalizedSocialUidList(snapshotFriends, owner);
    const followingUids = normalizedSocialUidList([...snapshotFollowing, ...friendUids], owner);
    const followerUids = normalizedSocialUidList([...snapshotFollowers, ...friendUids], owner);
    const peerUids = [...new Set([...friendUids, ...followingUids, ...followerUids])];
    const profiles = {};
    await Promise.all(peerUids.map(async uid => {
      try { profiles[uid] = await getPublicProfile(uid); }
      catch { profiles[uid] = null; }
    }));
    const friendSet = new Set(friendUids);
    const hydrate = (uid, kind) => {
      const relationKind = friendSet.has(uid) ? 'friend' : kind;
      const publicProfile = profiles[uid] || compactPublicProfile({}, uid);
      return {
        ...publicProfile,
        uid,
        relationship: socialRelationship(owner, uid, relationKind, { status: relationKind === 'friend' ? 'friends' : 'following' }),
        socialRecord: { cachedPublicSnapshot: true }
      };
    };
    return {
      relationships: [
        ...friendUids.map(uid => socialRelationship(owner, uid, 'friend', { status:'friends' })),
        ...followingUids.filter(uid => !friendSet.has(uid)).map(uid => socialRelationship(owner, uid, 'following', { status:'following' })),
        ...followerUids.filter(uid => !friendSet.has(uid)).map(uid => socialRelationship(owner, uid, 'followers', { status:'following' }))
      ],
      friends: friendUids.map(uid => hydrate(uid, 'friend')),
      following: followingUids.map(uid => hydrate(uid, 'following')),
      followers: followerUids.map(uid => hydrate(uid, 'followers')),
      cachedPublicSnapshot: true,
      snapshotUpdatedAtMs: Number(snapshot.updatedAtMs || 0)
    };
  }

  async function loadSocialGraph() {
    await waitUntilReady();
    const user = assertUser();
    const graph = await loadSocialGraphForOwner(user.uid);
    try { await syncPublicSocialSnapshot(graph); } catch {}
    return graph;
  }

  async function loadPublicSocialGraph(uid) {
    await waitUntilReady();
    const owner = String(uid || '').trim();
    if (!owner) return { relationships:[], friends:[], following:[], followers:[] };
    try {
      return await loadSocialGraphForOwner(owner);
    } catch (directError) {
      try {
        const ownerProfile = await getPublicProfile(owner);
        const snapshot = ownerProfile?.socialSnapshot;
        if (snapshot && (Array.isArray(snapshot.friends) || Array.isArray(snapshot.following) || Array.isArray(snapshot.followers))) {
          return await hydratePublicSocialSnapshot(owner, snapshot);
        }
      } catch {}
      throw directError;
    }
  }

  function notificationExpiry(days = 3) {
    return modules.firestore.Timestamp.fromMillis(Date.now() + Math.max(1, Number(days || 3)) * 24 * 60 * 60 * 1000);
  }

  async function createUserNotification(targetUid, values = {}, id = '') {
    await waitUntilReady();
    const user = assertUser();
    const target = String(targetUid || '').trim();
    if (!target || target === user.uid) throw new Error('Penerima notifikasi tidak valid.');
    const notificationId = String(id || `${values.type || 'notice'}_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`).replace(/[^A-Za-z0-9._-]/g, '-').slice(0, 180);
    const sender = profile || await readProfile(user) || {};
    await modules.firestore.setDoc(modules.firestore.doc(db, 'users', target, 'notifications', notificationId), {
      app: MUSIC_APP_ID,
      schemaVersion: MUSIC_SCHEMA_VERSION,
      id: notificationId,
      type: String(values.type || 'notice'),
      title: String(values.title || 'Notifikasi DATZON'),
      message: String(values.message || ''),
      fromUid: user.uid,
      toUid: target,
      fromName: String(sender.fullName || sender.username || user.displayName || 'Pengguna DATZON'),
      fromUsername: String(sender.username || ''),
      fromPhotoURL: String(sender.photoURL || user.photoURL || ''),
      actionData: values.actionData || {},
      createdAt: modules.firestore.serverTimestamp(),
      createdAtMs: Date.now(),
      expiresAt: notificationExpiry(values.expiresDays || 3),
      expiresAtMs: Date.now() + Math.max(1, Number(values.expiresDays || 3)) * 24 * 60 * 60 * 1000,
      read: false
    }, { merge: true });
    return notificationId;
  }

  function socialLinkData(ownerUid, peerUid, kind, peerProfile = {}, extra = {}) {
    const base = {
      ownerUid: String(ownerUid || ''),
      peerUid: String(peerUid || ''),
      profile: compactPublicProfile(peerProfile, peerUid),
      updatedAt: modules.firestore.serverTimestamp(),
      updatedAtMs: Date.now(),
      ...extra,
      app: MUSIC_APP_ID,
      schemaVersion: MUSIC_SCHEMA_VERSION
    };
    if (kind === 'friend') return { ...base, friendUid: String(peerUid || ''), status: 'friends' };
    if (kind === 'followers') return { ...base, followerUid: String(peerUid || ''), targetUid: String(ownerUid || ''), status: String(extra.status || 'pending') };
    return { ...base, targetUid: String(peerUid || ''), followerUid: String(ownerUid || ''), status: String(extra.status || 'following') };
  }

  async function sendFriendRequest(targetUid) {
    await waitUntilReady();
    const user = assertUser();
    const target = String(targetUid || '').trim();
    if (!target || target === user.uid) throw new Error('Akun teman tidak valid.');

    const { doc, getDoc, writeBatch, serverTimestamp } = modules.firestore;
    const ownFriendRef = doc(db, 'users', user.uid, 'friend', target);
    const ownFollowingRef = doc(db, 'users', user.uid, 'following', target);
    const ownFollowerRef = doc(db, 'users', user.uid, 'followers', target);
    const [friendSnap, followingSnap, followerSnap, targetProfile] = await Promise.all([
      getDoc(ownFriendRef),
      getDoc(ownFollowingRef),
      getDoc(ownFollowerRef),
      getPublicProfile(target)
    ]);

    if (!targetProfile) throw new Error('Profil pengguna tidak ditemukan.');
    if (friendSnap.exists()) return { relationshipId: relationshipIdFor(user.uid, target), status: 'friends' };
    if (followingSnap.exists()) return { relationshipId: relationshipIdFor(user.uid, target), status: 'pending' };

    const senderProfile = compactPublicProfile(profile || await readProfile(user) || {}, user.uid);
    const relationshipId = relationshipIdFor(user.uid, target);
    const batch = writeBatch(db);

    if (followerSnap.exists()) {
      batch.set(ownFriendRef, {
        ...socialLinkData(user.uid, target, 'friend', targetProfile),
        acceptedAt: serverTimestamp(),
        acceptedAtMs: Date.now()
      }, { merge: true });
      batch.set(doc(db, 'users', target, 'friend', user.uid), {
        ...socialLinkData(target, user.uid, 'friend', senderProfile),
        acceptedAt: serverTimestamp(),
        acceptedAtMs: Date.now()
      }, { merge: true });
      // Pertemanan mutual tetap mempertahankan kedua arah follow agar user muncul
      // di Teman, Following, dan Followers.
      batch.set(ownFollowingRef, socialLinkData(user.uid, target, 'following', targetProfile, { status:'friends', acceptedAt:serverTimestamp(), acceptedAtMs:Date.now() }), { merge:true });
      batch.set(doc(db, 'users', target, 'followers', user.uid), socialLinkData(target, user.uid, 'followers', senderProfile, { status:'friends', acceptedAt:serverTimestamp(), acceptedAtMs:Date.now() }), { merge:true });
      batch.set(ownFollowerRef, socialLinkData(user.uid, target, 'followers', targetProfile, { status:'friends', acceptedAt:serverTimestamp(), acceptedAtMs:Date.now() }), { merge:true });
      batch.set(doc(db, 'users', target, 'following', user.uid), socialLinkData(target, user.uid, 'following', senderProfile, { status:'friends', acceptedAt:serverTimestamp(), acceptedAtMs:Date.now() }), { merge:true });
      batch.delete(doc(db, 'users', user.uid, 'notifications', `friend_${relationshipId}`));
      await batch.commit();

      try {
        await createUserNotification(target, {
          type: 'friend_accepted',
          title: 'Sekarang kalian berteman',
          message: `${senderProfile.fullName || 'Pengguna DATZON'} juga mengikuti kamu.`,
          actionData: { profileUid: user.uid }
        }, `friend_mutual_${relationshipId}`);
      } catch {}
      return { relationshipId, status: 'friends' };
    }

    const requestExpiresAtMs = Date.now() + 3 * 24 * 60 * 60 * 1000;
    batch.set(ownFollowingRef, socialLinkData(user.uid, target, 'following', targetProfile, {
      requestedBy: user.uid,
      status: 'following',
      requestExpiresAtMs,
      createdAt: serverTimestamp(),
      createdAtMs: Date.now()
    }), { merge: true });
    batch.set(doc(db, 'users', target, 'followers', user.uid), socialLinkData(target, user.uid, 'followers', senderProfile, {
      requestedBy: user.uid,
      requestExpiresAtMs,
      createdAt: serverTimestamp(),
      createdAtMs: Date.now()
    }), { merge: true });
    await batch.commit();

    await createUserNotification(target, {
      type: 'friend_request',
      title: 'Permintaan pertemanan',
      message: `${senderProfile.fullName || 'Seseorang'} ingin berteman denganmu.`,
      actionData: { relationshipId, requesterUid: user.uid }
    }, `friend_${relationshipId}`);
    return { relationshipId, status: 'pending' };
  }

  async function acceptFriendRequest(notification) {
    await waitUntilReady();
    const user = assertUser();
    const data = notification?.actionData || {};
    const requesterUid = String(data.requesterUid || notification?.fromUid || '').trim();
    if (!requesterUid || requesterUid === user.uid) throw new Error('Permintaan teman tidak valid.');

    const { doc, writeBatch, serverTimestamp } = modules.firestore;
    const requesterProfile = await getPublicProfile(requesterUid);
    const currentProfile = compactPublicProfile(profile || await readProfile(user) || {}, user.uid);
    const batch = writeBatch(db);

    batch.set(doc(db, 'users', user.uid, 'friend', requesterUid), {
      ...socialLinkData(user.uid, requesterUid, 'friend', requesterProfile || {}),
      acceptedAt: serverTimestamp(),
      acceptedAtMs: Date.now()
    }, { merge: true });
    batch.set(doc(db, 'users', requesterUid, 'friend', user.uid), {
      ...socialLinkData(requesterUid, user.uid, 'friend', currentProfile),
      acceptedAt: serverTimestamp(),
      acceptedAtMs: Date.now()
    }, { merge: true });

    batch.set(doc(db, 'users', user.uid, 'following', requesterUid), socialLinkData(user.uid, requesterUid, 'following', requesterProfile || {}, { status:'friends', acceptedAt:serverTimestamp(), acceptedAtMs:Date.now() }), { merge:true });
    batch.set(doc(db, 'users', requesterUid, 'followers', user.uid), socialLinkData(requesterUid, user.uid, 'followers', currentProfile, { status:'friends', acceptedAt:serverTimestamp(), acceptedAtMs:Date.now() }), { merge:true });
    batch.set(doc(db, 'users', user.uid, 'followers', requesterUid), socialLinkData(user.uid, requesterUid, 'followers', requesterProfile || {}, { status:'friends', acceptedAt:serverTimestamp(), acceptedAtMs:Date.now() }), { merge:true });
    batch.set(doc(db, 'users', requesterUid, 'following', user.uid), socialLinkData(requesterUid, user.uid, 'following', currentProfile, { status:'friends', acceptedAt:serverTimestamp(), acceptedAtMs:Date.now() }), { merge:true });
    batch.delete(doc(db, 'users', user.uid, 'notifications', String(notification.id)));
    await batch.commit();

    try {
      await createUserNotification(requesterUid, {
        type: 'friend_accepted',
        title: 'Permintaan teman diterima',
        message: `${currentProfile.fullName || 'Temanmu'} menerima permintaan pertemananmu.`,
        actionData: { profileUid: user.uid }
      });
    } catch {}
    return true;
  }

  async function rejectFriendRequest(notification) {
    await waitUntilReady();
    const user = assertUser();
    await modules.firestore.deleteDoc(modules.firestore.doc(db, 'users', user.uid, 'notifications', String(notification.id)));
    return true;
  }

  async function removeRelationship(targetUid) {
    await waitUntilReady();
    const user = assertUser();
    const target = String(targetUid || '').trim();
    if (!target || target === user.uid) return false;
    const { doc, writeBatch } = modules.firestore;
    const batch = writeBatch(db);
    batch.delete(doc(db, 'users', user.uid, 'friend', target));
    batch.delete(doc(db, 'users', target, 'friend', user.uid));
    batch.delete(doc(db, 'users', user.uid, 'following', target));
    batch.delete(doc(db, 'users', target, 'followers', user.uid));
    batch.delete(doc(db, 'users', user.uid, 'followers', target));
    batch.delete(doc(db, 'users', target, 'following', user.uid));
    await batch.commit();
    return true;
  }

  async function unfollowUser(targetUid) {
    await waitUntilReady();
    const user = assertUser();
    const target = String(targetUid || '').trim();
    if (!target || target === user.uid) return false;
    const { doc, writeBatch } = modules.firestore;
    const batch = writeBatch(db);
    batch.delete(doc(db, 'users', user.uid, 'following', target));
    batch.delete(doc(db, 'users', target, 'followers', user.uid));
    // Batalkan juga notifikasi permintaan yang belum diterima, supaya target
    // tidak bisa menerima pertemanan setelah hubungan follow sudah dibatalkan.
    batch.delete(doc(db, 'users', target, 'notifications', `friend_${relationshipIdFor(user.uid, target)}`));
    await batch.commit();
    return true;
  }

  async function markNotificationRead(id) {
    await waitUntilReady();
    const user = assertUser();
    await modules.firestore.setDoc(modules.firestore.doc(db, 'users', user.uid, 'notifications', String(id)), {
      read: true,
      readAt: modules.firestore.serverTimestamp()
    }, { merge: true });
    return true;
  }

  async function deleteNotification(id) {
    await waitUntilReady();
    const user = assertUser();
    await modules.firestore.deleteDoc(modules.firestore.doc(db, 'users', user.uid, 'notifications', String(id)));
    return true;
  }

  async function pruneExpiredNotifications() {
    await waitUntilReady();
    const user = assertUser();
    const snapshot = await modules.firestore.getDocs(modules.firestore.collection(db, 'users', user.uid, 'notifications'));
    const now = Date.now();
    const expired = snapshot.docs.filter(item => Number(item.data()?.expiresAtMs || 0) > 0 && Number(item.data().expiresAtMs) <= now);
    if (!expired.length) return 0;
    const batch = modules.firestore.writeBatch(db);
    expired.forEach(item => batch.delete(item.ref));
    await batch.commit();
    return expired.length;
  }

  function listenNotifications(callback) {
    if (typeof callback !== 'function') return () => {};
    let unsubUser = () => {};
    let unsubAnnouncements = () => {};
    let userItems = [];
    let announcements = [];
    const emitNotifications = () => callback({ notifications: userItems, announcements });
    const start = async () => {
      try {
        await waitUntilReady();
        const user = auth?.currentUser;
        if (user) {
          const userQuery = modules.firestore.query(
            modules.firestore.collection(db, 'users', user.uid, 'notifications'),
            modules.firestore.orderBy('createdAtMs', 'desc'),
            modules.firestore.limit(100)
          );
          unsubUser = modules.firestore.onSnapshot(userQuery, snapshot => {
            const now = Date.now();
            userItems = snapshot.docs
              .map(item => ({ id:item.id, ...item.data() }))
              .filter(item => !item.expiresAtMs || Number(item.expiresAtMs) > now)
              .sort((a,b) => Number(b.createdAtMs || 0) - Number(a.createdAtMs || 0));
            emitNotifications();
          }, () => {});
        }
        const announcementQuery = modules.firestore.query(modules.firestore.collection(db, 'announcements'), modules.firestore.orderBy('createdAtMs', 'desc'), modules.firestore.limit(30));
        unsubAnnouncements = modules.firestore.onSnapshot(announcementQuery, snapshot => {
          const now = Date.now();
          announcements = snapshot.docs.map(item => ({ id: item.id, type: 'announcement', ...item.data() })).filter(item => !item.expiresAtMs || Number(item.expiresAtMs) > now);
          emitNotifications();
        }, () => {});
      } catch {}
    };
    start();
    return () => { try { unsubUser(); } catch {} try { unsubAnnouncements(); } catch {} };
  }

  async function sendListenTogetherRequest(targetUid, track) {
    await waitUntilReady();
    const user = assertUser();
    const target = String(targetUid || '').trim();
    if (!target || target === user.uid) throw new Error('Teman tidak valid.');
    const relationship = await getRelationship(target);
    if (!relationship || relationship.status !== 'friends') throw new Error('Dengar Bareng hanya dapat dikirim kepada teman.');
    const requestId = `listen_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;
    const cleanTrack = JSON.parse(JSON.stringify(track || {}));
    await createUserNotification(target, {
      type: 'listen_together_request',
      title: 'Ajakan Dengar Bareng',
      message: `${profile?.fullName || 'Temanmu'} mengajakmu mendengarkan ${cleanTrack.title || 'sebuah lagu'}.`,
      actionData: { requestId, inviterUid: user.uid, track: cleanTrack }
    }, requestId);
    return requestId;
  }

  async function respondListenTogether(notification, accepted = false) {
    await waitUntilReady();
    const user = assertUser();
    const actionData = notification?.actionData || {};
    const inviterUid = String(actionData.inviterUid || notification?.fromUid || '').trim();
    await deleteNotification(notification.id);
    if (!accepted) return { accepted: false };
    if (inviterUid) {
      try {
        await createUserNotification(inviterUid, {
          type: 'listen_together_accepted',
          title: 'Ajakan Dengar Bareng diterima',
          message: `${profile?.fullName || 'Temanmu'} menerima ajakanmu. Mulai mendengarkan bersama.`,
          actionData: { requestId: actionData.requestId || notification.id, listenerUid: user.uid, track: actionData.track || {} }
        });
      } catch {}
    }
    return { accepted: true, track: actionData.track || null, inviterUid };
  }


  function compactCollaborativeTrack(track = {}) {
    return {
      id: String(track.spotifyTrackId || track.spotifyId || track.id || ''),
      spotifyTrackId: String(track.spotifyTrackId || track.spotifyId || ''),
      title: String(track.title || track.name || '').slice(0, 180),
      artist: String(track.artist || track.artistName || '').slice(0, 220),
      artistNames: Array.isArray(track.artistNames) ? track.artistNames.slice(0, 8).map(value => String(value).slice(0, 100)) : [],
      duration: String(track.duration || '').slice(0, 20),
      thumbnail: String(track.thumbnail || track.image || '').slice(0, 1200),
      album: String(track.album || '').slice(0, 180),
      url: String(track.url || track.spotifyUrl || '').slice(0, 1200),
      source: String(track.source || '').slice(0, 100),
      isrc: String(track.isrc || '').slice(0, 32),
      explicit: Boolean(track.explicit)
    };
  }

  async function sendCollaborativePlaylistSnapshot(targetUids = [], playlist = {}) {
    await waitUntilReady();
    const user = assertUser();
    const targets = [...new Set((Array.isArray(targetUids) ? targetUids : []).map(value => String(value || '').trim()).filter(uid => uid && uid !== user.uid))].slice(0, 20);
    if (!targets.length) return [];
    const participantUids = [...new Set([user.uid, ...(Array.isArray(playlist.participantUids) ? playlist.participantUids : []), ...targets])].slice(0, 24);
    const cleanPlaylist = {
      id: String(playlist.id || '').replace(/[^A-Za-z0-9._-]/g, '-').slice(0, 120),
      name: String(playlist.name || 'Playlist kolaboratif').trim().slice(0, 80),
      createdAt: Number(playlist.createdAt || Date.now()),
      updatedAt: Number(playlist.updatedAt || Date.now()),
      ownerUid: String(playlist.ownerUid || user.uid),
      collabOwnerUid: String(playlist.collabOwnerUid || playlist.ownerUid || user.uid),
      visibility: String(playlist.visibility || '').toLowerCase() === 'public' ? 'public' : 'private',
      collaborative: true,
      sourceType: 'collaborative',
      participantUids,
      participantProfiles: Array.isArray(playlist.participantProfiles) ? playlist.participantProfiles.slice(0, 24).map(item => ({
        uid: String(item?.uid || ''),
        fullName: String(item?.fullName || item?.username || '').slice(0, 100),
        username: String(item?.username || '').slice(0, 50),
        photoURL: String(item?.photoURL || '').slice(0, 1200)
      })).filter(item => item.uid) : [],
      tracks: (Array.isArray(playlist.tracks) ? playlist.tracks : []).slice(0, 200).map(compactCollaborativeTrack)
    };
    const stamp = Number(cleanPlaylist.updatedAt || Date.now());
    const tasks = targets.map(target => createUserNotification(target, {
      type: 'collab_playlist_sync',
      title: 'Playlist kolaboratif diperbarui',
      message: `${profile?.fullName || profile?.username || 'Temanmu'} memperbarui “${cleanPlaylist.name}”.`,
      actionData: { playlist: cleanPlaylist, senderUid: user.uid },
      expiresDays: 30
    }, `collab_${cleanPlaylist.id}_${stamp}_${target}`).catch(() => null));
    return Promise.all(tasks);
  }


  async function saveMusicCodeTrack(record = {}) {
    // Music Code is global per TRACK. Authentication is intentionally not
    // required: Firestore rules validate a constrained, immutable payload.
    await waitUntilReady();
    if (!db || !modules) return { saved:false, reason:'firebase' };
    const user = auth?.currentUser || null;
    const musicCode = String(record.musicCode || '').trim().toUpperCase();
    if (!/^MX-[A-Z2-9]{12,24}$/.test(musicCode)) throw new Error('Music Code tidak valid.');
    const canonicalTrackKey = String(record.canonicalTrackKey || '').trim().slice(0, 260);
    const title = String(record.title || '').trim().slice(0, 180);
    const artist = String(record.artist || '').trim().slice(0, 220);
    const trackUrl = String(record.trackUrl || '').trim().slice(0, 1400);
    const spotifyTrackId = String(record.spotifyTrackId || '').trim();
    const providerTrackId = String(record.providerTrackId || '').trim().slice(0, 160);
    if (!canonicalTrackKey || !title || !/^https:\/\//i.test(trackUrl)) throw new Error('Data Music Code belum lengkap.');

    // For Spotify tracks the Firestore document id is EXACTLY the Spotify
    // Track ID, e.g. codeTrack/6dOtVTDdiauQNBQEDOtlAB. This makes lookup from
    // another account/device trivial and prevents per-user duplicates.
    const isSpotifyId = /^[A-Za-z0-9]{22}$/.test(spotifyTrackId);
    const fallbackId = String(record.documentId || providerTrackId || musicCode.slice(3))
      .replace(/[^A-Za-z0-9._-]/g, '-')
      .replace(/^-+|-+$/g, '')
      .slice(0, 120);
    const documentId = isSpotifyId ? spotifyTrackId : (fallbackId || musicCode.slice(3));

    const { doc, getDoc, setDoc, serverTimestamp } = modules.firestore;
    const ref = doc(db, 'codeTrack', documentId);
    const existing = await getDoc(ref);
    if (existing.exists()) return { saved:true, existing:true, id:documentId, data:existing.data() };

    const payload = {
      app: MUSIC_APP_ID,
      documentId,
      musicCode,
      canonicalTrackKey,
      title,
      artist,
      trackUrl,
      spotifyTrackId: isSpotifyId ? spotifyTrackId : '',
      spotifyUrl: isSpotifyId ? `https://open.spotify.com/track/${spotifyTrackId}` : '',
      providerTrackId,
      source: String(record.source || '').trim().slice(0, 80),
      cover: String(record.cover || '').trim().slice(0, 1400),
      album: String(record.album || '').trim().slice(0, 180),
      duration: String(record.duration || '').trim().slice(0, 24),
      createdByUid: user?.uid || 'guest',
      createdAt: serverTimestamp(),
      createdAtMs: Date.now(),
      schemaVersion: 2
    };
    await setDoc(ref, payload);
    return { saved:true, existing:false, id:documentId, data:payload };
  }



  async function sendCollaborativePlaylistRemoval(targetUids = [], playlist = {}) {
    await waitUntilReady();
    const user = assertUser();
    const targets = [...new Set((Array.isArray(targetUids) ? targetUids : []).map(value => String(value || '').trim()).filter(uid => uid && uid !== user.uid))].slice(0, 20);
    if (!targets.length) return [];
    const playlistId = String(playlist.id || '').replace(/[^A-Za-z0-9._-]/g, '-').slice(0, 120);
    const playlistName = String(playlist.name || 'Playlist kolaboratif').trim().slice(0, 80);
    const updatedAt = Number(playlist.updatedAt || Date.now());
    const deleted = Boolean(playlist.deleted);
    const tasks = targets.map(target => createUserNotification(target, {
      type: 'collab_playlist_remove',
      title: deleted ? 'Playlist kolaboratif dihapus' : 'Kolaborasi playlist diperbarui',
      message: deleted
        ? `${profile?.fullName || profile?.username || 'Pembuat playlist'} menghapus “${playlistName}”.`
        : `${profile?.fullName || profile?.username || 'Temanmu'} mengubah anggota “${playlistName}”.`,
      actionData: { playlistId, playlistName, updatedAt, senderUid: user.uid, deleted },
      expiresDays: 30
    }, `collab_remove_${playlistId}_${updatedAt}_${target}`).catch(() => null));
    return Promise.all(tasks);
  }


  function isAdminProfile(source = profile) {
    return String(source?.role || '').toLowerCase() === 'admin';
  }

  async function submitReport(values = {}) {
    await waitUntilReady();
    const user = assertUser();
    const sender = profile || await readProfile(user) || {};
    const subject = String(values.subject || '').trim().slice(0, 120);
    const description = String(values.description || '').trim().slice(0, 5000);
    const screenshots = Array.isArray(values.screenshots) ? values.screenshots.filter(Boolean).slice(0, 3) : [];
    if (subject.length < 4) throw new Error('Subjek laporan minimal 4 karakter.');
    if (description.length < 10) throw new Error('Deskripsi laporan minimal 10 karakter.');
    const reportRef = modules.firestore.doc(modules.firestore.collection(db, 'reports'));
    const payload = {
      app: MUSIC_APP_ID,
      schemaVersion: MUSIC_SCHEMA_VERSION,
      id: reportRef.id,
      reporterUid: user.uid,
      reporterFullName: String(sender.fullName || user.displayName || 'Pengguna DATZON'),
      reporterUsername: String(sender.username || ''),
      reporterEmail: String(sender.email || user.email || ''),
      reporterPhotoURL: String(sender.photoURL || user.photoURL || ''),
      subject,
      description,
      screenshots,
      diagnostics: values.diagnostics || {},
      status: 'submitted',
      createdAt: modules.firestore.serverTimestamp(),
      createdAtMs: Date.now(),
      updatedAt: modules.firestore.serverTimestamp(),
      updatedAtMs: Date.now()
    };
    await modules.firestore.setDoc(reportRef, payload);

    let admins = [];
    try {
      const adminQuery = modules.firestore.query(
        modules.firestore.collection(db, 'publicProfiles'),
        modules.firestore.where('role', '==', 'admin'),
        modules.firestore.limit(50)
      );
      const snapshot = await modules.firestore.getDocs(adminQuery);
      admins = snapshot.docs.map(item => ({ uid: item.id, ...item.data() })).filter(item => item.uid && item.uid !== user.uid);
    } catch {}
    await Promise.all(admins.map(admin => createUserNotification(admin.uid, {
      type: 'report_submitted',
      title: 'Laporan masalah baru',
      message: `${payload.reporterFullName} melaporkan: ${subject}`,
      actionData: { reportId: reportRef.id, reporterUid: user.uid }
    }, `report_${reportRef.id}_${admin.uid}`).catch(() => null)));
    return payload;
  }

  async function getReport(reportId) {
    await waitUntilReady();
    assertUser();
    const id = String(reportId || '').trim();
    if (!id) return null;
    const snapshot = await modules.firestore.getDoc(modules.firestore.doc(db, 'reports', id));
    return snapshot.exists() ? { id: snapshot.id, ...snapshot.data() } : null;
  }

  async function loadAdminReports(maxResults = 150) {
    await waitUntilReady();
    assertUser();
    if (!isAdminProfile()) throw new Error('Halaman ini hanya tersedia untuk admin.');
    const snapshot = await modules.firestore.getDocs(modules.firestore.query(
      modules.firestore.collection(db, 'reports'),
      modules.firestore.orderBy('createdAtMs', 'desc'),
      modules.firestore.limit(Math.max(20, Math.min(300, maxResults)))
    ));
    return snapshot.docs.map(item => ({ id: item.id, ...item.data() }));
  }

  async function confirmReport(reportId) {
    await waitUntilReady();
    const user = assertUser();
    if (!isAdminProfile()) throw new Error('Aksi ini hanya tersedia untuk admin.');
    const report = await getReport(reportId);
    if (!report) throw new Error('Laporan tidak ditemukan.');
    await modules.firestore.setDoc(modules.firestore.doc(db, 'reports', report.id), {
      status: 'confirmed',
      confirmedAt: modules.firestore.serverTimestamp(),
      confirmedAtMs: Date.now(),
      confirmedByUid: user.uid,
      confirmedByName: String(profile?.fullName || profile?.username || 'Admin DATZON'),
      updatedAt: modules.firestore.serverTimestamp(),
      updatedAtMs: Date.now()
    }, { merge: true });
    if (report.reporterUid && report.reporterUid !== user.uid) {
      await createUserNotification(report.reporterUid, {
        type: 'report_confirmed',
        title: 'Laporanmu sudah dikonfirmasi',
        message: `Terima kasih. Laporan “${report.subject || 'Masalah aplikasi'}” sudah diterima dan sedang ditinjau oleh tim DATZON.`,
        actionData: { reportId: report.id, reporterUid: report.reporterUid }
      }, `report_confirmed_${report.id}`).catch(() => null);
    }
    return { ...report, status: 'confirmed' };
  }

  async function markReportFixed(reportId) {
    await waitUntilReady();
    const user = assertUser();
    if (!isAdminProfile()) throw new Error('Aksi ini hanya tersedia untuk admin.');
    const report = await getReport(reportId);
    if (!report) throw new Error('Laporan tidak ditemukan.');
    const now = Date.now();
    await modules.firestore.setDoc(modules.firestore.doc(db, 'reports', report.id), {
      status: 'fixed',
      fixedAt: modules.firestore.serverTimestamp(),
      fixedAtMs: now,
      fixedByUid: user.uid,
      fixedByName: String(profile?.fullName || profile?.username || 'Admin DATZON'),
      updatedAt: modules.firestore.serverTimestamp(),
      updatedAtMs: now
    }, { merge: true });
    const announcementRef = modules.firestore.doc(modules.firestore.collection(db, 'announcements'));
    const username = report.reporterUsername ? `@${report.reporterUsername}` : report.reporterFullName || 'seorang pengguna';
    await modules.firestore.setDoc(announcementRef, {
      app: MUSIC_APP_ID,
      schemaVersion: MUSIC_SCHEMA_VERSION,
      id: announcementRef.id,
      type: 'announcement',
      title: 'Perbaikan masalah telah selesai',
      message: `Masalah “${report.subject || 'Laporan pengguna'}” sudah diperbaiki. Terima kasih kepada ${username} yang telah melapor dan kepada seluruh pengguna yang terus menggunakan DATZON Music.`,
      reportId: report.id,
      reporterUid: String(report.reporterUid || ''),
      createdByUid: user.uid,
      createdAt: modules.firestore.serverTimestamp(),
      createdAtMs: now,
      expiresAtMs: now + 30 * 24 * 60 * 60 * 1000
    });
    if (report.reporterUid && report.reporterUid !== user.uid) {
      await createUserNotification(report.reporterUid, {
        type: 'report_fixed',
        title: 'Masalah yang kamu laporkan sudah diperbaiki',
        message: `Perbaikan untuk “${report.subject || 'laporanmu'}” telah selesai. Terima kasih sudah membantu DATZON Music menjadi lebih baik.`,
        actionData: { reportId: report.id, reporterUid: report.reporterUid }
      }, `report_fixed_${report.id}`).catch(() => null);
    }
    return { ...report, status: 'fixed' };
  }


  function requireAdminProfile() {
    const user = assertUser();
    if (!isAdminProfile()) {
      const error = new Error('Akses admin diperlukan.');
      error.code = 'permission-denied';
      throw error;
    }
    return user;
  }

  function firestoreMillis(value) {
    if (!value) return 0;
    if (typeof value.toMillis === 'function') return value.toMillis();
    if (typeof value.toDate === 'function') return value.toDate().getTime();
    if (typeof value === 'number') return value;
    const parsed = new Date(value).getTime();
    return Number.isFinite(parsed) ? parsed : 0;
  }

  function cleanAdminUser(uid, data = {}) {
    const summary = data.listeningSummary || {};
    return {
      uid: String(uid || data.uid || ''),
      fullName: String(data.fullName || data.username || 'Pengguna DATZON'),
      username: String(data.username || ''),
      email: String(data.email || ''),
      photoURL: String(data.photoURL || ''),
      role: String(data.role || 'user').toLowerCase() === 'admin' ? 'admin' : 'user',
      status: String(data.status || 'offline'),
      preferredStatus: String(data.preferredStatus || 'online'),
      providers: Array.isArray(data.providers) ? data.providers.slice(0, 10) : [],
      selectedArtists: Array.isArray(data.selectedArtists) ? data.selectedArtists.slice(0, 30) : [],
      onboardingCompleted: Boolean(data.onboardingCompleted),
      createdAtIso: String(data.createdAtIso || ''),
      createdAtMs: firestoreMillis(data.createdAt) || firestoreMillis(data.createdAtIso),
      updatedAtMs: firestoreMillis(data.updatedAt),
      lastSeenAtMs: firestoreMillis(data.lastSeenAt),
      listeningSummary: {
        totalSeconds: Number(summary.totalSeconds || 0),
        plays: Number(summary.plays || 0)
      }
    };
  }

  async function adminLoadUsers(maxResults = 500) {
    await waitUntilReady();
    requireAdminProfile();
    const limitValue = Math.max(20, Math.min(1000, Number(maxResults) || 500));
    const snapshot = await modules.firestore.getDocs(modules.firestore.query(
      modules.firestore.collection(db, 'users'),
      modules.firestore.limit(limitValue)
    ));
    return snapshot.docs
      .map(item => cleanAdminUser(item.id, item.data()))
      .sort((a, b) => (b.lastSeenAtMs || b.updatedAtMs || b.createdAtMs) - (a.lastSeenAtMs || a.updatedAtMs || a.createdAtMs));
  }

  async function adminGetUserDetails(uid) {
    await waitUntilReady();
    requireAdminProfile();
    const safeUid = String(uid || '').trim();
    if (!safeUid) throw new Error('UID pengguna tidak valid.');
    const { doc, getDoc, collection, query, where, limit, getDocs } = modules.firestore;
    const userRef = doc(db, 'users', safeUid);
    const publicRef = doc(db, 'publicProfiles', safeUid);
    const countCollection = async name => {
      const ref = collection(db, 'users', safeUid, name);
      const scopedQuery = query(ref, where('app', '==', MUSIC_APP_ID));
      if (typeof modules.firestore.getCountFromServer === 'function') {
        try {
          const countSnapshot = await modules.firestore.getCountFromServer(scopedQuery);
          return Number(countSnapshot.data()?.count || 0);
        } catch {}
      }
      const snapshot = await getDocs(query(ref, where('app', '==', MUSIC_APP_ID), limit(500)));
      return snapshot.size;
    };
    const recentHistoryPromise = getDocs(query(
      collection(db, 'users', safeUid, 'history'),
      where('app', '==', MUSIC_APP_ID),
      limit(50)
    )).then(snapshot => snapshot.docs
      .map(item => ({ id:item.id, ...item.data() }))
      .sort((a,b) => firestoreMillis(b.syncedAt) - firestoreMillis(a.syncedAt))
      .slice(0,10)).catch(() => []);
    const [userSnapshot, publicSnapshot, favorites, history, downloads, artists, playlists, recentHistory] = await Promise.all([
      getDoc(userRef),
      getDoc(publicRef),
      countCollection('favorites'),
      countCollection('history'),
      countCollection('downloads'),
      countCollection('artists'),
      countCollection('playlists'),
      recentHistoryPromise
    ]);
    if (!userSnapshot.exists()) throw new Error('Data pengguna tidak ditemukan.');
    return {
      ...cleanAdminUser(safeUid, userSnapshot.data()),
      publicProfile: publicSnapshot.exists() ? { uid: publicSnapshot.id, ...publicSnapshot.data() } : null,
      collectionCounts: { favorites, history, downloads, artists, playlists },
      recentHistory: recentHistory.map(item => ({
        id: item.id,
        title: String(item.title || item.name || 'Lagu'),
        artist: String(item.artist || item.author || 'Unknown'),
        thumbnail: String(item.thumbnail || item.image || ''),
        duration: String(item.duration || ''),
        playedAt: item.playedAt || item.addedAt || item.syncedAt || null
      }))
    };
  }

  async function adminLoadAnnouncements(maxResults = 100) {
    await waitUntilReady();
    requireAdminProfile();
    const snapshot = await modules.firestore.getDocs(modules.firestore.query(
      modules.firestore.collection(db, 'announcements'),
      modules.firestore.orderBy('createdAtMs', 'desc'),
      modules.firestore.limit(Math.max(10, Math.min(300, Number(maxResults) || 100)))
    ));
    return snapshot.docs.map(item => ({ id: item.id, ...item.data() }));
  }

  async function adminCreateAnnouncement(values = {}) {
    await waitUntilReady();
    const user = requireAdminProfile();
    const title = String(values.title || '').trim().slice(0, 100);
    const message = String(values.message || '').trim().slice(0, 2000);
    const priority = String(values.priority || 'normal').toLowerCase() === 'high' ? 'high' : 'normal';
    const expiresDays = Math.max(1, Math.min(90, Number(values.expiresDays) || 30));
    if (title.length < 3) throw new Error('Judul notifikasi minimal 3 karakter.');
    if (message.length < 5) throw new Error('Isi notifikasi minimal 5 karakter.');
    const now = Date.now();
    const announcementRef = modules.firestore.doc(modules.firestore.collection(db, 'announcements'));
    const payload = {
      app: MUSIC_APP_ID,
      schemaVersion: MUSIC_SCHEMA_VERSION,
      id: announcementRef.id,
      type: 'announcement',
      title,
      message,
      priority,
      audience: 'registered-users',
      createdByUid: user.uid,
      createdByName: String(profile?.fullName || profile?.username || 'Admin DATZON'),
      createdAt: modules.firestore.serverTimestamp(),
      createdAtMs: now,
      expiresAtMs: now + expiresDays * 24 * 60 * 60 * 1000
    };
    await modules.firestore.setDoc(announcementRef, payload);
    return payload;
  }

  async function adminDeleteAnnouncement(announcementId) {
    await waitUntilReady();
    requireAdminProfile();
    const id = String(announcementId || '').trim();
    if (!id) throw new Error('Notifikasi tidak valid.');
    await modules.firestore.deleteDoc(modules.firestore.doc(db, 'announcements', id));
    return true;
  }

  async function adminLoadDashboard() {
    await waitUntilReady();
    requireAdminProfile();
    const [users, reports, announcements] = await Promise.all([
      adminLoadUsers(1000),
      loadAdminReports(300),
      adminLoadAnnouncements(200)
    ]);
    const now = Date.now();
    const onlineWindow = 10 * 60 * 1000;
    const totalListeningSeconds = users.reduce((sum, item) => sum + Number(item.listeningSummary?.totalSeconds || 0), 0);
    const totalPlays = users.reduce((sum, item) => sum + Number(item.listeningSummary?.plays || 0), 0);
    return {
      generatedAtMs: now,
      metrics: {
        users: users.length,
        admins: users.filter(item => item.role === 'admin').length,
        online: users.filter(item => item.status === 'online' && item.lastSeenAtMs && now - item.lastSeenAtMs <= onlineWindow).length,
        pendingReports: reports.filter(item => item.status === 'submitted').length,
        confirmedReports: reports.filter(item => item.status === 'confirmed').length,
        fixedReports: reports.filter(item => item.status === 'fixed').length,
        activeAnnouncements: announcements.filter(item => !item.expiresAtMs || Number(item.expiresAtMs) > now).length,
        totalListeningSeconds,
        totalPlays
      },
      users,
      reports,
      announcements
    };
  }

  async function getLeaderboard(maxResults = 50) {
    await waitUntilReady();
    const { collection, getDocs, query, orderBy, limit } = modules.firestore;
    const snapshot = await getDocs(query(collection(db, 'publicProfiles'), orderBy('listeningSummary.totalSeconds', 'desc'), limit(Math.max(10, Math.min(100, maxResults)))));
    return snapshot.docs.map((item, index) => ({ rank: index + 1, uid: item.id, ...item.data() }));
  }

  function listenLeaderboard(maxResults = 50, listener, errorListener = null) {
    assertConfigured();
    if (typeof listener !== 'function') return () => {};
    const { collection, query, orderBy, limit, onSnapshot } = modules.firestore;
    const leaderboardQuery = query(
      collection(db, 'publicProfiles'),
      orderBy('listeningSummary.totalSeconds', 'desc'),
      limit(Math.max(10, Math.min(100, maxResults)))
    );
    return onSnapshot(
      leaderboardQuery,
      snapshot => listener(snapshot.docs.map((item, index) => ({ rank:index + 1, uid:item.id, ...item.data() }))),
      error => { try { errorListener?.(error); } catch {} }
    );
  }

  async function setPresence(isOnline = true) {
    if (!auth?.currentUser || !db || !modules) return false;
    const preferred = ['online', 'offline', 'busy'].includes(String(profile?.preferredStatus || '').toLowerCase())
      ? String(profile.preferredStatus).toLowerCase()
      : 'online';
    const nextStatus = isOnline ? preferred : 'offline';
    await modules.firestore.setDoc(modules.firestore.doc(db, 'users', auth.currentUser.uid), {
      status: nextStatus,
      musicProfileVersion: 1,
      lastSeenAt: modules.firestore.serverTimestamp()
    }, { merge: true });
    if (profile) profile.status = nextStatus;
    try { await syncPublicProfile(auth.currentUser, profile || {}); } catch {}
    return true;
  }

  function stopHeartbeat() {
    if (heartbeatTimer) clearInterval(heartbeatTimer);
    heartbeatTimer = null;
  }

  function startHeartbeat() {
    stopHeartbeat();
    setPresence(true).catch(() => {});
    heartbeatTimer = setInterval(() => setPresence(true).catch(() => {}), 5 * 60 * 1000);
  }

  window.addEventListener('online', () => setPresence(true).catch(() => {}));
  window.addEventListener('offline', () => {
    if (profile) profile.status = 'offline';
    emit(auth?.currentUser || null);
  });
  window.addEventListener('pagehide', () => setPresence(false).catch(() => {}));

  window.DatzonFirebase = Object.freeze({
    ready,
    isConfigured: () => configured,
    isReady: () => Boolean(auth && db),
    waitUntilReady,
    initializationError: () => initError,
    sdkVersion: () => loadedSdkVersion || SDK_VERSIONS[0],
    currentUser: () => auth?.currentUser || null,
    currentProfile: () => profile,
    onAuthChanged,
    firebaseErrorMessage,
    normalizeUsername,
    validateUsername,
    checkUsername,
    resolveLoginEmail,
    syncUsernameLoginAlias,
    startPasswordOtpLogin,
    startRegistrationOtp,
    resendOtp,
    verifyOtp,
    cancelPendingGoogleRegistration,
    registerEmail,
    loginEmail,
    loginGoogle,
    linkPendingGoogle,
    completeGoogleRegistration,
    updateUserProfile,
    updateAccountStatus,
    updateSelectedArtists,
    changePassword,
    sendResetEmail,
    logout,
    uploadProfileImage,
    uploadReportImages,
    scheduleSync,
    syncSnapshot,
    loadCloudData,
    exportCloudData,
    importCloudData,
    syncPublicProfile,
    syncPublicPlaylists,
    syncSharedPlaylistDirectory,
    deleteSharedPlaylist,
    syncPublicSocialSnapshot,
    getPublicProfile,
    getAccessibleProfilePlaylists,
    listenProfilePlaylists,
    getSharedPlaylist,
    getPlaylistTombstone,
    listenSharedPlaylist,
    searchUsers,
    getRelationship,
    loadSocialGraph,
    loadPublicSocialGraph,
    sendFriendRequest,
    acceptFriendRequest,
    rejectFriendRequest,
    removeRelationship,
    unfollowUser,
    listenNotifications,
    markNotificationRead,
    deleteNotification,
    pruneExpiredNotifications,
    sendListenTogetherRequest,
    respondListenTogether,
    sendCollaborativePlaylistSnapshot,
    sendCollaborativePlaylistRemoval,
    saveMusicCodeTrack,
    submitReport,
    getReport,
    loadAdminReports,
    confirmReport,
    markReportFixed,
    adminLoadDashboard,
    adminLoadUsers,
    adminGetUserDetails,
    adminLoadAnnouncements,
    adminCreateAnnouncement,
    adminDeleteAnnouncement,
    getLeaderboard,
    listenLeaderboard,
    setPresence
  });
})();
